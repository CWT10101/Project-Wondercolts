using UnityEngine;

public class Invert : MonoBehaviour
{
	private Material InvertMat;

	[Range(0f, 1f)]
	public float Mix;

	private float _lastMix;

	private void UpdateMaterials()
	{
		if ((bool)InvertMat && _lastMix != Mix)
		{
			InvertMat.SetFloat("_Mix", Mix);
			_lastMix = Mix;
		}
	}

	private void Start()
	{
		InvertMat = new Material(Shader.Find("Hidden/Invert"));
		UpdateMaterials();
	}

	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		UpdateMaterials();
		PTAGraphics.Blit(source, destination, InvertMat);
	}
}
