using System;
using ESStnd;
using LanguageExt;

public class BlurFragment : IFragment<RGame, RBlur>, ICompletable<RBlur>, ITemporal<RBlur>
{
	private GenericFadeFragment<RBlur> _frag = new GenericFadeFragment<RBlur>(RBlur.Empty);

	private readonly Caching.CachedProperty<RGame> _prop = new Caching.CachedProperty<RGame>();

	private readonly Action<RGame, Action<Option<RBlur>>> _cache = Caching.CacheAction(Prelude.lens(RGame.Lworld, RWorld.Lblur));

	public bool Completed => _frag.Completed;

	public RGame InputValue
	{
		get
		{
			return _prop.Value;
		}
		set
		{
			_prop.Setter(delegate(RGame v)
			{
				_cache(v, delegate(Option<RBlur> blur)
				{
					_frag.InputValue = blur.IfNone(RBlur.Empty);
				});
			}, value);
		}
	}

	public RBlur OutputValue
	{
		get
		{
			var (option, toV, alp) = _frag.OutputValue;
			return option.Match((RBlur fromV) => RBlur.Of(UnityFuncs.Lerp(fromV.magnitude, toV.magnitude, alp), ((alp < 0.5f) ? fromV : toV).direction, ((alp < 0.5f) ? fromV : toV).gauss, ((alp < 0.5f) ? fromV : toV).quality), toV);
		}
	}

	public void Update(float dt)
	{
		_frag.Update(dt);
	}

	public void InstantComplete()
	{
		_frag.InstantComplete();
	}
}
