using System.Collections;
using System.Collections.Generic;
using ESStnd;
using PTAEnum;
using UnityEngine;

public class CameraShakeTrigger : MonoBehaviour, ITrigger<RShake>, ITrigger
{
	private class ShakeRoutine : SubRoutine
	{
		private List<Displace> _displaces;

		private readonly AnimationCurve _curve;

		private readonly RShake _shake;

		private Vector2 ShakeOffset(direction direction)
		{
			switch (direction)
			{
			case direction.horizontal:
				return Random.insideUnitCircle.With(null, 0f);
			case direction.vertical:
				return Random.insideUnitCircle.With(0f);
			case direction.both:
				return Random.insideUnitCircle;
			default:
				Log.Error($"Unknown direction '{direction}'");
				return new Vector2(0f, 0f);
			}
		}

		protected override IEnumerator Start()
		{
			float progress = 0f;
			while (progress < _shake.duration)
			{
				progress += TimeState.WorldDT;
				foreach (Displace displace in _displaces)
				{
					Vector2 displaceVec = ShakeOffset(_shake.direction) * _curve.Evaluate(progress / _shake.duration) * _shake.intensity * 0.1f;
					if (displaceVec.x < 0.001f && displaceVec.y < 0.001f)
					{
						displace.enabled = false;
						continue;
					}
					displace.enabled = true;
					displace.DisplaceVec = displaceVec;
				}
				yield return null;
			}
		}

		protected override void CleanUp()
		{
			foreach (Displace displace in _displaces)
			{
				displace.DisplaceVec = new Vector2(0f, 0f);
			}
		}

		public ShakeRoutine(List<Displace> displaces, AnimationCurve curve, RShake shake)
		{
			_displaces = displaces;
			_curve = curve;
			_shake = shake;
		}
	}

	private RoutineManager _routines = new RoutineManager();

	[SerializeField]
	private AnimationCurve _curve;

	[SerializeField]
	private List<Displace> _displaces = new List<Displace>();

	private void Update()
	{
		_routines.MoveNext();
	}

	public void Trigger(RShake data)
	{
		_routines.Add(new ShakeRoutine(_displaces, _curve, data));
	}

	public void Clear()
	{
		_routines.Clear();
	}
}
