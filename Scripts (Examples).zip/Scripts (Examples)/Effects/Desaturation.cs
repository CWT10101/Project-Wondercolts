using UnityEngine;

public class Desaturation : MonoBehaviour
{
	private Material DesaturationMat;

	[Range(0f, 1f)]
	public float Mix;

	private float _lastMix;

	private void UpdateMaterials()
	{
		if ((bool)DesaturationMat && _lastMix != Mix)
		{
			DesaturationMat.SetFloat("_Mix", Mix);
			_lastMix = Mix;
		}
	}

	private void Start()
	{
		DesaturationMat = new Material(Shader.Find("Hidden/Desaturation"));
		UpdateMaterials();
	}

	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		UpdateMaterials();
		PTAGraphics.Blit(source, destination, DesaturationMat);
	}
}
