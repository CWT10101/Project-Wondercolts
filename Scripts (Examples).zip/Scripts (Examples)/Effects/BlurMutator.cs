using System;
using System.Collections.Generic;
using ESStnd;
using UnityEngine;

public class BlurMutator : MonoBehaviour, IMutator<RBlur>
{
	[SerializeField]
	private List<Blur> _blurs;

	private Action<RBlur> __cache;

	private Action<RBlur> _cache
	{
		get
		{
			Action<RBlur> obj = __cache ?? ESStnd.Caching.CacheAction(delegate(RBlur b)
			{
				foreach (Blur blur in _blurs)
				{
					blur.enabled = b.magnitude > 0.01f;
					blur.Magnitude = b.magnitude;
					blur.Direction = b.direction;
					blur.Gauss = b.gauss;
					blur.Quality = b.quality;
				}
			});
			Action<RBlur> result = obj;
			__cache = obj;
			return result;
		}
	}

	public void Mutate(RBlur view)
	{
		_cache(view);
	}
}
