using UnityEngine;

public class Displace : MonoBehaviour
{
	private Material _displaceMat;

	private Vector2 _lastDisplace;

	public Vector2 DisplaceVec = new Vector2(0f, 0f);

	private void UpdateMaterials()
	{
		if ((bool)_displaceMat && _lastDisplace != DisplaceVec)
		{
			_displaceMat.SetVector("_Displace", DisplaceVec);
			_lastDisplace = DisplaceVec;
		}
	}

	private void Start()
	{
		_displaceMat = new Material(Shader.Find("Hidden/displace"));
		UpdateMaterials();
	}

	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		UpdateMaterials();
		PTAGraphics.Blit(source, destination, _displaceMat);
	}
}
