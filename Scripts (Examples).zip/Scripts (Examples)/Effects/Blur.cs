using System;
using ESStnd;
using PTAEnum;
using UnityEngine;

public class Blur : MonoBehaviour
{
	private Material _mat;

	public float Magnitude;

	public direction Direction = direction.both;

	public bool Gauss = true;

	public quality Quality = quality.Fantastique;

	private Action<float, bool, quality> _CacheUpdateMaterials;

	private Action<float, bool, quality> CacheUpdateMaterials => _CacheUpdateMaterials ?? (_CacheUpdateMaterials = ESStnd.Caching.CacheAction<float, bool, quality>(UpdateMaterials));

	private void UpdateMaterials(float magnitude, bool gauss, quality quality)
	{
		_mat.SetFloat("_BlurSize", Magnitude);
		if (Gauss)
		{
			_mat.EnableKeyword("GAUSS");
		}
		else
		{
			_mat.DisableKeyword("GAUSS");
		}
		switch (Quality)
		{
		case quality.Ragged:
			_mat.EnableKeyword("_SAMPLES_LOW");
			_mat.DisableKeyword("_SAMPLES_MEDIUM");
			_mat.DisableKeyword("_SAMPLES_HIGH");
			break;
		case quality.Mediocre:
			_mat.DisableKeyword("_SAMPLES_LOW");
			_mat.EnableKeyword("_SAMPLES_MEDIUM");
			_mat.DisableKeyword("_SAMPLES_HIGH");
			break;
		case quality.Fantastique:
			_mat.DisableKeyword("_SAMPLES_LOW");
			_mat.DisableKeyword("_SAMPLES_MEDIUM");
			_mat.EnableKeyword("_SAMPLES_HIGH");
			break;
		default:
			Log.Warn("Invalid blur quality", Quality);
			_mat.DisableKeyword("_SAMPLES_LOW");
			_mat.EnableKeyword("_SAMPLES_MEDIUM");
			_mat.DisableKeyword("_SAMPLES_HIGH");
			break;
		}
	}

	private void Start()
	{
		_mat = new Material(Shader.Find("Hidden/Blur"));
		CacheUpdateMaterials(Magnitude, Gauss, Quality);
	}

	private void Vertical(RenderTexture source, RenderTexture destination)
	{
		Graphics.Blit(source, destination, _mat, 1);
	}

	private void Horizontal(RenderTexture source, RenderTexture destination)
	{
		Graphics.Blit(source, destination, _mat, 0);
	}

	private void Both(RenderTexture source, RenderTexture destination)
	{
		RenderTexture temporary = RenderTexture.GetTemporary(source.width, source.height);
		Graphics.Blit(source, temporary, _mat, 0);
		Graphics.Blit(temporary, destination, _mat, 1);
		RenderTexture.ReleaseTemporary(temporary);
	}

	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		CacheUpdateMaterials(Magnitude, Gauss, Quality);
		switch (Direction)
		{
		case direction.horizontal:
			Horizontal(source, destination);
			break;
		case direction.vertical:
			Vertical(source, destination);
			break;
		case direction.both:
			Both(source, destination);
			break;
		default:
			Log.Error("Invalid blur direction", Direction);
			Both(source, destination);
			break;
		}
	}
}
