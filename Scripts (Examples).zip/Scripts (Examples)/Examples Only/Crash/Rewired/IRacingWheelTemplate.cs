﻿using System;

namespace Rewired
{
	// Token: 0x0200016F RID: 367
	public interface IRacingWheelTemplate : IControllerTemplate
	{
		// Token: 0x17000149 RID: 329
		// (get) Token: 0x06000A82 RID: 2690
		IControllerTemplateAxis wheel { get; }

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x06000A83 RID: 2691
		IControllerTemplateAxis accelerator { get; }

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x06000A84 RID: 2692
		IControllerTemplateAxis brake { get; }

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x06000A85 RID: 2693
		IControllerTemplateAxis clutch { get; }

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x06000A86 RID: 2694
		IControllerTemplateButton shiftDown { get; }

		// Token: 0x1700014E RID: 334
		// (get) Token: 0x06000A87 RID: 2695
		IControllerTemplateButton shiftUp { get; }

		// Token: 0x1700014F RID: 335
		// (get) Token: 0x06000A88 RID: 2696
		IControllerTemplateButton wheelButton1 { get; }

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x06000A89 RID: 2697
		IControllerTemplateButton wheelButton2 { get; }

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x06000A8A RID: 2698
		IControllerTemplateButton wheelButton3 { get; }

		// Token: 0x17000152 RID: 338
		// (get) Token: 0x06000A8B RID: 2699
		IControllerTemplateButton wheelButton4 { get; }

		// Token: 0x17000153 RID: 339
		// (get) Token: 0x06000A8C RID: 2700
		IControllerTemplateButton wheelButton5 { get; }

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x06000A8D RID: 2701
		IControllerTemplateButton wheelButton6 { get; }

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x06000A8E RID: 2702
		IControllerTemplateButton wheelButton7 { get; }

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x06000A8F RID: 2703
		IControllerTemplateButton wheelButton8 { get; }

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x06000A90 RID: 2704
		IControllerTemplateButton wheelButton9 { get; }

		// Token: 0x17000158 RID: 344
		// (get) Token: 0x06000A91 RID: 2705
		IControllerTemplateButton wheelButton10 { get; }

		// Token: 0x17000159 RID: 345
		// (get) Token: 0x06000A92 RID: 2706
		IControllerTemplateButton consoleButton1 { get; }

		// Token: 0x1700015A RID: 346
		// (get) Token: 0x06000A93 RID: 2707
		IControllerTemplateButton consoleButton2 { get; }

		// Token: 0x1700015B RID: 347
		// (get) Token: 0x06000A94 RID: 2708
		IControllerTemplateButton consoleButton3 { get; }

		// Token: 0x1700015C RID: 348
		// (get) Token: 0x06000A95 RID: 2709
		IControllerTemplateButton consoleButton4 { get; }

		// Token: 0x1700015D RID: 349
		// (get) Token: 0x06000A96 RID: 2710
		IControllerTemplateButton consoleButton5 { get; }

		// Token: 0x1700015E RID: 350
		// (get) Token: 0x06000A97 RID: 2711
		IControllerTemplateButton consoleButton6 { get; }

		// Token: 0x1700015F RID: 351
		// (get) Token: 0x06000A98 RID: 2712
		IControllerTemplateButton consoleButton7 { get; }

		// Token: 0x17000160 RID: 352
		// (get) Token: 0x06000A99 RID: 2713
		IControllerTemplateButton consoleButton8 { get; }

		// Token: 0x17000161 RID: 353
		// (get) Token: 0x06000A9A RID: 2714
		IControllerTemplateButton consoleButton9 { get; }

		// Token: 0x17000162 RID: 354
		// (get) Token: 0x06000A9B RID: 2715
		IControllerTemplateButton consoleButton10 { get; }

		// Token: 0x17000163 RID: 355
		// (get) Token: 0x06000A9C RID: 2716
		IControllerTemplateButton shifter1 { get; }

		// Token: 0x17000164 RID: 356
		// (get) Token: 0x06000A9D RID: 2717
		IControllerTemplateButton shifter2 { get; }

		// Token: 0x17000165 RID: 357
		// (get) Token: 0x06000A9E RID: 2718
		IControllerTemplateButton shifter3 { get; }

		// Token: 0x17000166 RID: 358
		// (get) Token: 0x06000A9F RID: 2719
		IControllerTemplateButton shifter4 { get; }

		// Token: 0x17000167 RID: 359
		// (get) Token: 0x06000AA0 RID: 2720
		IControllerTemplateButton shifter5 { get; }

		// Token: 0x17000168 RID: 360
		// (get) Token: 0x06000AA1 RID: 2721
		IControllerTemplateButton shifter6 { get; }

		// Token: 0x17000169 RID: 361
		// (get) Token: 0x06000AA2 RID: 2722
		IControllerTemplateButton shifter7 { get; }

		// Token: 0x1700016A RID: 362
		// (get) Token: 0x06000AA3 RID: 2723
		IControllerTemplateButton shifter8 { get; }

		// Token: 0x1700016B RID: 363
		// (get) Token: 0x06000AA4 RID: 2724
		IControllerTemplateButton shifter9 { get; }

		// Token: 0x1700016C RID: 364
		// (get) Token: 0x06000AA5 RID: 2725
		IControllerTemplateButton shifter10 { get; }

		// Token: 0x1700016D RID: 365
		// (get) Token: 0x06000AA6 RID: 2726
		IControllerTemplateButton reverseGear { get; }

		// Token: 0x1700016E RID: 366
		// (get) Token: 0x06000AA7 RID: 2727
		IControllerTemplateButton select { get; }

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x06000AA8 RID: 2728
		IControllerTemplateButton start { get; }

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x06000AA9 RID: 2729
		IControllerTemplateButton systemButton { get; }

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x06000AAA RID: 2730
		IControllerTemplateButton horn { get; }

		// Token: 0x17000172 RID: 370
		// (get) Token: 0x06000AAB RID: 2731
		IControllerTemplateDPad dPad { get; }
	}
}
