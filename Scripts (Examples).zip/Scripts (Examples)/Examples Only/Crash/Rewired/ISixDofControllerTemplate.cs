﻿using System;

namespace Rewired
{
	// Token: 0x02000173 RID: 371
	public interface ISixDofControllerTemplate : IControllerTemplate
	{
		// Token: 0x170001FF RID: 511
		// (get) Token: 0x06000B38 RID: 2872
		IControllerTemplateAxis extraAxis1 { get; }

		// Token: 0x17000200 RID: 512
		// (get) Token: 0x06000B39 RID: 2873
		IControllerTemplateAxis extraAxis2 { get; }

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x06000B3A RID: 2874
		IControllerTemplateAxis extraAxis3 { get; }

		// Token: 0x17000202 RID: 514
		// (get) Token: 0x06000B3B RID: 2875
		IControllerTemplateAxis extraAxis4 { get; }

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x06000B3C RID: 2876
		IControllerTemplateButton button1 { get; }

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x06000B3D RID: 2877
		IControllerTemplateButton button2 { get; }

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x06000B3E RID: 2878
		IControllerTemplateButton button3 { get; }

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x06000B3F RID: 2879
		IControllerTemplateButton button4 { get; }

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x06000B40 RID: 2880
		IControllerTemplateButton button5 { get; }

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x06000B41 RID: 2881
		IControllerTemplateButton button6 { get; }

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x06000B42 RID: 2882
		IControllerTemplateButton button7 { get; }

		// Token: 0x1700020A RID: 522
		// (get) Token: 0x06000B43 RID: 2883
		IControllerTemplateButton button8 { get; }

		// Token: 0x1700020B RID: 523
		// (get) Token: 0x06000B44 RID: 2884
		IControllerTemplateButton button9 { get; }

		// Token: 0x1700020C RID: 524
		// (get) Token: 0x06000B45 RID: 2885
		IControllerTemplateButton button10 { get; }

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x06000B46 RID: 2886
		IControllerTemplateButton button11 { get; }

		// Token: 0x1700020E RID: 526
		// (get) Token: 0x06000B47 RID: 2887
		IControllerTemplateButton button12 { get; }

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x06000B48 RID: 2888
		IControllerTemplateButton button13 { get; }

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x06000B49 RID: 2889
		IControllerTemplateButton button14 { get; }

		// Token: 0x17000211 RID: 529
		// (get) Token: 0x06000B4A RID: 2890
		IControllerTemplateButton button15 { get; }

		// Token: 0x17000212 RID: 530
		// (get) Token: 0x06000B4B RID: 2891
		IControllerTemplateButton button16 { get; }

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x06000B4C RID: 2892
		IControllerTemplateButton button17 { get; }

		// Token: 0x17000214 RID: 532
		// (get) Token: 0x06000B4D RID: 2893
		IControllerTemplateButton button18 { get; }

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x06000B4E RID: 2894
		IControllerTemplateButton button19 { get; }

		// Token: 0x17000216 RID: 534
		// (get) Token: 0x06000B4F RID: 2895
		IControllerTemplateButton button20 { get; }

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06000B50 RID: 2896
		IControllerTemplateButton button21 { get; }

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x06000B51 RID: 2897
		IControllerTemplateButton button22 { get; }

		// Token: 0x17000219 RID: 537
		// (get) Token: 0x06000B52 RID: 2898
		IControllerTemplateButton button23 { get; }

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x06000B53 RID: 2899
		IControllerTemplateButton button24 { get; }

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x06000B54 RID: 2900
		IControllerTemplateButton button25 { get; }

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x06000B55 RID: 2901
		IControllerTemplateButton button26 { get; }

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x06000B56 RID: 2902
		IControllerTemplateButton button27 { get; }

		// Token: 0x1700021E RID: 542
		// (get) Token: 0x06000B57 RID: 2903
		IControllerTemplateButton button28 { get; }

		// Token: 0x1700021F RID: 543
		// (get) Token: 0x06000B58 RID: 2904
		IControllerTemplateButton button29 { get; }

		// Token: 0x17000220 RID: 544
		// (get) Token: 0x06000B59 RID: 2905
		IControllerTemplateButton button30 { get; }

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x06000B5A RID: 2906
		IControllerTemplateButton button31 { get; }

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x06000B5B RID: 2907
		IControllerTemplateButton button32 { get; }

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x06000B5C RID: 2908
		IControllerTemplateHat hat1 { get; }

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x06000B5D RID: 2909
		IControllerTemplateHat hat2 { get; }

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x06000B5E RID: 2910
		IControllerTemplateThrottle throttle1 { get; }

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x06000B5F RID: 2911
		IControllerTemplateThrottle throttle2 { get; }

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x06000B60 RID: 2912
		IControllerTemplateStick6D stick { get; }
	}
}
