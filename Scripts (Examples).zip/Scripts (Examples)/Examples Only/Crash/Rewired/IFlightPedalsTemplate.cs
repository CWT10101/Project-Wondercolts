﻿using System;

namespace Rewired
{
	// Token: 0x02000172 RID: 370
	public interface IFlightPedalsTemplate : IControllerTemplate
	{
		// Token: 0x170001FC RID: 508
		// (get) Token: 0x06000B35 RID: 2869
		IControllerTemplateAxis leftPedal { get; }

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x06000B36 RID: 2870
		IControllerTemplateAxis rightPedal { get; }

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x06000B37 RID: 2871
		IControllerTemplateAxis slide { get; }
	}
}
