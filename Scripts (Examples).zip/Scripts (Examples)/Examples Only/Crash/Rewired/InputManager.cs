﻿using System;
using System.ComponentModel;
using System.Text.RegularExpressions;
using Rewired.Platforms;
using Rewired.Utils;
using Rewired.Utils.Interfaces;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Rewired
{
	// Token: 0x0200017A RID: 378
	[AddComponentMenu("Rewired/Input Manager")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public sealed class InputManager : InputManager_Base
	{
		// Token: 0x06000C69 RID: 3177 RVA: 0x0002A072 File Offset: 0x00028272
		protected override void OnInitialized()
		{
			this.SubscribeEvents();
		}

		// Token: 0x06000C6A RID: 3178 RVA: 0x0002A07A File Offset: 0x0002827A
		protected override void OnDeinitialized()
		{
			this.UnsubscribeEvents();
		}

		// Token: 0x06000C6B RID: 3179 RVA: 0x0002A084 File Offset: 0x00028284
		protected override void DetectPlatform()
		{
			this.scriptingBackend = ScriptingBackend.Mono;
			this.scriptingAPILevel = ScriptingAPILevel.Net20;
			this.editorPlatform = EditorPlatform.None;
			this.platform = Platform.Unknown;
			this.webplayerPlatform = WebplayerPlatform.None;
			this.isEditor = false;
			if (SystemInfo.deviceName == null)
			{
				string empty = string.Empty;
			}
			if (SystemInfo.deviceModel == null)
			{
				string empty2 = string.Empty;
			}
			this.platform = Platform.Windows;
			this.scriptingBackend = ScriptingBackend.Mono;
			this.scriptingAPILevel = ScriptingAPILevel.NetStandard20;
		}

		// Token: 0x06000C6C RID: 3180 RVA: 0x0002A0EA File Offset: 0x000282EA
		protected override void CheckRecompile()
		{
		}

		// Token: 0x06000C6D RID: 3181 RVA: 0x0002A0EC File Offset: 0x000282EC
		protected override IExternalTools GetExternalTools()
		{
			return new ExternalTools();
		}

		// Token: 0x06000C6E RID: 3182 RVA: 0x0002A0F3 File Offset: 0x000282F3
		private bool CheckDeviceName(string searchPattern, string deviceName, string deviceModel)
		{
			return Regex.IsMatch(deviceName, searchPattern, RegexOptions.IgnoreCase) || Regex.IsMatch(deviceModel, searchPattern, RegexOptions.IgnoreCase);
		}

		// Token: 0x06000C6F RID: 3183 RVA: 0x0002A109 File Offset: 0x00028309
		private void SubscribeEvents()
		{
			this.UnsubscribeEvents();
			SceneManager.sceneLoaded += this.OnSceneLoaded;
		}

		// Token: 0x06000C70 RID: 3184 RVA: 0x0002A122 File Offset: 0x00028322
		private void UnsubscribeEvents()
		{
			SceneManager.sceneLoaded -= this.OnSceneLoaded;
		}

		// Token: 0x06000C71 RID: 3185 RVA: 0x0002A135 File Offset: 0x00028335
		private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
		{
			base.OnSceneLoaded();
		}

		// Token: 0x04000901 RID: 2305
		private bool ignoreRecompile;
	}
}
