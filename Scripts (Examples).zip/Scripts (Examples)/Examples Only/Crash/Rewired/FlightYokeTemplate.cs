﻿using System;

namespace Rewired
{
	// Token: 0x02000177 RID: 375
	public sealed class FlightYokeTemplate : ControllerTemplate, IFlightYokeTemplate, IControllerTemplate
	{
		// Token: 0x170002C7 RID: 711
		// (get) Token: 0x06000C06 RID: 3078 RVA: 0x00029C88 File Offset: 0x00027E88
		IControllerTemplateButton IFlightYokeTemplate.leftPaddle
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(59);
			}
		}

		// Token: 0x170002C8 RID: 712
		// (get) Token: 0x06000C07 RID: 3079 RVA: 0x00029C92 File Offset: 0x00027E92
		IControllerTemplateButton IFlightYokeTemplate.rightPaddle
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(60);
			}
		}

		// Token: 0x170002C9 RID: 713
		// (get) Token: 0x06000C08 RID: 3080 RVA: 0x00029C9C File Offset: 0x00027E9C
		IControllerTemplateButton IFlightYokeTemplate.leftGripButton1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(7);
			}
		}

		// Token: 0x170002CA RID: 714
		// (get) Token: 0x06000C09 RID: 3081 RVA: 0x00029CA5 File Offset: 0x00027EA5
		IControllerTemplateButton IFlightYokeTemplate.leftGripButton2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(8);
			}
		}

		// Token: 0x170002CB RID: 715
		// (get) Token: 0x06000C0A RID: 3082 RVA: 0x00029CAE File Offset: 0x00027EAE
		IControllerTemplateButton IFlightYokeTemplate.leftGripButton3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(9);
			}
		}

		// Token: 0x170002CC RID: 716
		// (get) Token: 0x06000C0B RID: 3083 RVA: 0x00029CB8 File Offset: 0x00027EB8
		IControllerTemplateButton IFlightYokeTemplate.leftGripButton4
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(10);
			}
		}

		// Token: 0x170002CD RID: 717
		// (get) Token: 0x06000C0C RID: 3084 RVA: 0x00029CC2 File Offset: 0x00027EC2
		IControllerTemplateButton IFlightYokeTemplate.leftGripButton5
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(11);
			}
		}

		// Token: 0x170002CE RID: 718
		// (get) Token: 0x06000C0D RID: 3085 RVA: 0x00029CCC File Offset: 0x00027ECC
		IControllerTemplateButton IFlightYokeTemplate.leftGripButton6
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(12);
			}
		}

		// Token: 0x170002CF RID: 719
		// (get) Token: 0x06000C0E RID: 3086 RVA: 0x00029CD6 File Offset: 0x00027ED6
		IControllerTemplateButton IFlightYokeTemplate.rightGripButton1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(13);
			}
		}

		// Token: 0x170002D0 RID: 720
		// (get) Token: 0x06000C0F RID: 3087 RVA: 0x00029CE0 File Offset: 0x00027EE0
		IControllerTemplateButton IFlightYokeTemplate.rightGripButton2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(14);
			}
		}

		// Token: 0x170002D1 RID: 721
		// (get) Token: 0x06000C10 RID: 3088 RVA: 0x00029CEA File Offset: 0x00027EEA
		IControllerTemplateButton IFlightYokeTemplate.rightGripButton3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(15);
			}
		}

		// Token: 0x170002D2 RID: 722
		// (get) Token: 0x06000C11 RID: 3089 RVA: 0x00029CF4 File Offset: 0x00027EF4
		IControllerTemplateButton IFlightYokeTemplate.rightGripButton4
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(16);
			}
		}

		// Token: 0x170002D3 RID: 723
		// (get) Token: 0x06000C12 RID: 3090 RVA: 0x00029CFE File Offset: 0x00027EFE
		IControllerTemplateButton IFlightYokeTemplate.rightGripButton5
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(17);
			}
		}

		// Token: 0x170002D4 RID: 724
		// (get) Token: 0x06000C13 RID: 3091 RVA: 0x00029D08 File Offset: 0x00027F08
		IControllerTemplateButton IFlightYokeTemplate.rightGripButton6
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(18);
			}
		}

		// Token: 0x170002D5 RID: 725
		// (get) Token: 0x06000C14 RID: 3092 RVA: 0x00029D12 File Offset: 0x00027F12
		IControllerTemplateButton IFlightYokeTemplate.centerButton1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(19);
			}
		}

		// Token: 0x170002D6 RID: 726
		// (get) Token: 0x06000C15 RID: 3093 RVA: 0x00029D1C File Offset: 0x00027F1C
		IControllerTemplateButton IFlightYokeTemplate.centerButton2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(20);
			}
		}

		// Token: 0x170002D7 RID: 727
		// (get) Token: 0x06000C16 RID: 3094 RVA: 0x00029D26 File Offset: 0x00027F26
		IControllerTemplateButton IFlightYokeTemplate.centerButton3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(21);
			}
		}

		// Token: 0x170002D8 RID: 728
		// (get) Token: 0x06000C17 RID: 3095 RVA: 0x00029D30 File Offset: 0x00027F30
		IControllerTemplateButton IFlightYokeTemplate.centerButton4
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(22);
			}
		}

		// Token: 0x170002D9 RID: 729
		// (get) Token: 0x06000C18 RID: 3096 RVA: 0x00029D3A File Offset: 0x00027F3A
		IControllerTemplateButton IFlightYokeTemplate.centerButton5
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(23);
			}
		}

		// Token: 0x170002DA RID: 730
		// (get) Token: 0x06000C19 RID: 3097 RVA: 0x00029D44 File Offset: 0x00027F44
		IControllerTemplateButton IFlightYokeTemplate.centerButton6
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(24);
			}
		}

		// Token: 0x170002DB RID: 731
		// (get) Token: 0x06000C1A RID: 3098 RVA: 0x00029D4E File Offset: 0x00027F4E
		IControllerTemplateButton IFlightYokeTemplate.centerButton7
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(25);
			}
		}

		// Token: 0x170002DC RID: 732
		// (get) Token: 0x06000C1B RID: 3099 RVA: 0x00029D58 File Offset: 0x00027F58
		IControllerTemplateButton IFlightYokeTemplate.centerButton8
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(26);
			}
		}

		// Token: 0x170002DD RID: 733
		// (get) Token: 0x06000C1C RID: 3100 RVA: 0x00029D62 File Offset: 0x00027F62
		IControllerTemplateButton IFlightYokeTemplate.wheel1Up
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(53);
			}
		}

		// Token: 0x170002DE RID: 734
		// (get) Token: 0x06000C1D RID: 3101 RVA: 0x00029D6C File Offset: 0x00027F6C
		IControllerTemplateButton IFlightYokeTemplate.wheel1Down
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(54);
			}
		}

		// Token: 0x170002DF RID: 735
		// (get) Token: 0x06000C1E RID: 3102 RVA: 0x00029D76 File Offset: 0x00027F76
		IControllerTemplateButton IFlightYokeTemplate.wheel1Press
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(55);
			}
		}

		// Token: 0x170002E0 RID: 736
		// (get) Token: 0x06000C1F RID: 3103 RVA: 0x00029D80 File Offset: 0x00027F80
		IControllerTemplateButton IFlightYokeTemplate.wheel2Up
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(56);
			}
		}

		// Token: 0x170002E1 RID: 737
		// (get) Token: 0x06000C20 RID: 3104 RVA: 0x00029D8A File Offset: 0x00027F8A
		IControllerTemplateButton IFlightYokeTemplate.wheel2Down
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(57);
			}
		}

		// Token: 0x170002E2 RID: 738
		// (get) Token: 0x06000C21 RID: 3105 RVA: 0x00029D94 File Offset: 0x00027F94
		IControllerTemplateButton IFlightYokeTemplate.wheel2Press
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(58);
			}
		}

		// Token: 0x170002E3 RID: 739
		// (get) Token: 0x06000C22 RID: 3106 RVA: 0x00029D9E File Offset: 0x00027F9E
		IControllerTemplateButton IFlightYokeTemplate.consoleButton1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(43);
			}
		}

		// Token: 0x170002E4 RID: 740
		// (get) Token: 0x06000C23 RID: 3107 RVA: 0x00029DA8 File Offset: 0x00027FA8
		IControllerTemplateButton IFlightYokeTemplate.consoleButton2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(44);
			}
		}

		// Token: 0x170002E5 RID: 741
		// (get) Token: 0x06000C24 RID: 3108 RVA: 0x00029DB2 File Offset: 0x00027FB2
		IControllerTemplateButton IFlightYokeTemplate.consoleButton3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(45);
			}
		}

		// Token: 0x170002E6 RID: 742
		// (get) Token: 0x06000C25 RID: 3109 RVA: 0x00029DBC File Offset: 0x00027FBC
		IControllerTemplateButton IFlightYokeTemplate.consoleButton4
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(46);
			}
		}

		// Token: 0x170002E7 RID: 743
		// (get) Token: 0x06000C26 RID: 3110 RVA: 0x00029DC6 File Offset: 0x00027FC6
		IControllerTemplateButton IFlightYokeTemplate.consoleButton5
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(47);
			}
		}

		// Token: 0x170002E8 RID: 744
		// (get) Token: 0x06000C27 RID: 3111 RVA: 0x00029DD0 File Offset: 0x00027FD0
		IControllerTemplateButton IFlightYokeTemplate.consoleButton6
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(48);
			}
		}

		// Token: 0x170002E9 RID: 745
		// (get) Token: 0x06000C28 RID: 3112 RVA: 0x00029DDA File Offset: 0x00027FDA
		IControllerTemplateButton IFlightYokeTemplate.consoleButton7
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(49);
			}
		}

		// Token: 0x170002EA RID: 746
		// (get) Token: 0x06000C29 RID: 3113 RVA: 0x00029DE4 File Offset: 0x00027FE4
		IControllerTemplateButton IFlightYokeTemplate.consoleButton8
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(50);
			}
		}

		// Token: 0x170002EB RID: 747
		// (get) Token: 0x06000C2A RID: 3114 RVA: 0x00029DEE File Offset: 0x00027FEE
		IControllerTemplateButton IFlightYokeTemplate.consoleButton9
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(51);
			}
		}

		// Token: 0x170002EC RID: 748
		// (get) Token: 0x06000C2B RID: 3115 RVA: 0x00029DF8 File Offset: 0x00027FF8
		IControllerTemplateButton IFlightYokeTemplate.consoleButton10
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(52);
			}
		}

		// Token: 0x170002ED RID: 749
		// (get) Token: 0x06000C2C RID: 3116 RVA: 0x00029E02 File Offset: 0x00028002
		IControllerTemplateButton IFlightYokeTemplate.mode1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(61);
			}
		}

		// Token: 0x170002EE RID: 750
		// (get) Token: 0x06000C2D RID: 3117 RVA: 0x00029E0C File Offset: 0x0002800C
		IControllerTemplateButton IFlightYokeTemplate.mode2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(62);
			}
		}

		// Token: 0x170002EF RID: 751
		// (get) Token: 0x06000C2E RID: 3118 RVA: 0x00029E16 File Offset: 0x00028016
		IControllerTemplateButton IFlightYokeTemplate.mode3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(63);
			}
		}

		// Token: 0x170002F0 RID: 752
		// (get) Token: 0x06000C2F RID: 3119 RVA: 0x00029E20 File Offset: 0x00028020
		IControllerTemplateYoke IFlightYokeTemplate.yoke
		{
			get
			{
				return base.GetElement<IControllerTemplateYoke>(69);
			}
		}

		// Token: 0x170002F1 RID: 753
		// (get) Token: 0x06000C30 RID: 3120 RVA: 0x00029E2A File Offset: 0x0002802A
		IControllerTemplateThrottle IFlightYokeTemplate.lever1
		{
			get
			{
				return base.GetElement<IControllerTemplateThrottle>(70);
			}
		}

		// Token: 0x170002F2 RID: 754
		// (get) Token: 0x06000C31 RID: 3121 RVA: 0x00029E34 File Offset: 0x00028034
		IControllerTemplateThrottle IFlightYokeTemplate.lever2
		{
			get
			{
				return base.GetElement<IControllerTemplateThrottle>(71);
			}
		}

		// Token: 0x170002F3 RID: 755
		// (get) Token: 0x06000C32 RID: 3122 RVA: 0x00029E3E File Offset: 0x0002803E
		IControllerTemplateThrottle IFlightYokeTemplate.lever3
		{
			get
			{
				return base.GetElement<IControllerTemplateThrottle>(72);
			}
		}

		// Token: 0x170002F4 RID: 756
		// (get) Token: 0x06000C33 RID: 3123 RVA: 0x00029E48 File Offset: 0x00028048
		IControllerTemplateThrottle IFlightYokeTemplate.lever4
		{
			get
			{
				return base.GetElement<IControllerTemplateThrottle>(73);
			}
		}

		// Token: 0x170002F5 RID: 757
		// (get) Token: 0x06000C34 RID: 3124 RVA: 0x00029E52 File Offset: 0x00028052
		IControllerTemplateThrottle IFlightYokeTemplate.lever5
		{
			get
			{
				return base.GetElement<IControllerTemplateThrottle>(74);
			}
		}

		// Token: 0x170002F6 RID: 758
		// (get) Token: 0x06000C35 RID: 3125 RVA: 0x00029E5C File Offset: 0x0002805C
		IControllerTemplateHat IFlightYokeTemplate.leftGripHat
		{
			get
			{
				return base.GetElement<IControllerTemplateHat>(75);
			}
		}

		// Token: 0x170002F7 RID: 759
		// (get) Token: 0x06000C36 RID: 3126 RVA: 0x00029E66 File Offset: 0x00028066
		IControllerTemplateHat IFlightYokeTemplate.rightGripHat
		{
			get
			{
				return base.GetElement<IControllerTemplateHat>(76);
			}
		}

		// Token: 0x06000C37 RID: 3127 RVA: 0x00029E70 File Offset: 0x00028070
		public FlightYokeTemplate(object payload) : base(payload)
		{
		}

		// Token: 0x0400086B RID: 2155
		public static readonly Guid typeGuid = new Guid("f311fa16-0ccc-41c0-ac4b-50f7100bb8ff");

		// Token: 0x0400086C RID: 2156
		public const int elementId_rotateYoke = 0;

		// Token: 0x0400086D RID: 2157
		public const int elementId_yokeZ = 1;

		// Token: 0x0400086E RID: 2158
		public const int elementId_leftPaddle = 59;

		// Token: 0x0400086F RID: 2159
		public const int elementId_rightPaddle = 60;

		// Token: 0x04000870 RID: 2160
		public const int elementId_lever1Axis = 2;

		// Token: 0x04000871 RID: 2161
		public const int elementId_lever1MinDetent = 64;

		// Token: 0x04000872 RID: 2162
		public const int elementId_lever2Axis = 3;

		// Token: 0x04000873 RID: 2163
		public const int elementId_lever2MinDetent = 65;

		// Token: 0x04000874 RID: 2164
		public const int elementId_lever3Axis = 4;

		// Token: 0x04000875 RID: 2165
		public const int elementId_lever3MinDetent = 66;

		// Token: 0x04000876 RID: 2166
		public const int elementId_lever4Axis = 5;

		// Token: 0x04000877 RID: 2167
		public const int elementId_lever4MinDetent = 67;

		// Token: 0x04000878 RID: 2168
		public const int elementId_lever5Axis = 6;

		// Token: 0x04000879 RID: 2169
		public const int elementId_lever5MinDetent = 68;

		// Token: 0x0400087A RID: 2170
		public const int elementId_leftGripButton1 = 7;

		// Token: 0x0400087B RID: 2171
		public const int elementId_leftGripButton2 = 8;

		// Token: 0x0400087C RID: 2172
		public const int elementId_leftGripButton3 = 9;

		// Token: 0x0400087D RID: 2173
		public const int elementId_leftGripButton4 = 10;

		// Token: 0x0400087E RID: 2174
		public const int elementId_leftGripButton5 = 11;

		// Token: 0x0400087F RID: 2175
		public const int elementId_leftGripButton6 = 12;

		// Token: 0x04000880 RID: 2176
		public const int elementId_rightGripButton1 = 13;

		// Token: 0x04000881 RID: 2177
		public const int elementId_rightGripButton2 = 14;

		// Token: 0x04000882 RID: 2178
		public const int elementId_rightGripButton3 = 15;

		// Token: 0x04000883 RID: 2179
		public const int elementId_rightGripButton4 = 16;

		// Token: 0x04000884 RID: 2180
		public const int elementId_rightGripButton5 = 17;

		// Token: 0x04000885 RID: 2181
		public const int elementId_rightGripButton6 = 18;

		// Token: 0x04000886 RID: 2182
		public const int elementId_centerButton1 = 19;

		// Token: 0x04000887 RID: 2183
		public const int elementId_centerButton2 = 20;

		// Token: 0x04000888 RID: 2184
		public const int elementId_centerButton3 = 21;

		// Token: 0x04000889 RID: 2185
		public const int elementId_centerButton4 = 22;

		// Token: 0x0400088A RID: 2186
		public const int elementId_centerButton5 = 23;

		// Token: 0x0400088B RID: 2187
		public const int elementId_centerButton6 = 24;

		// Token: 0x0400088C RID: 2188
		public const int elementId_centerButton7 = 25;

		// Token: 0x0400088D RID: 2189
		public const int elementId_centerButton8 = 26;

		// Token: 0x0400088E RID: 2190
		public const int elementId_wheel1Up = 53;

		// Token: 0x0400088F RID: 2191
		public const int elementId_wheel1Down = 54;

		// Token: 0x04000890 RID: 2192
		public const int elementId_wheel1Press = 55;

		// Token: 0x04000891 RID: 2193
		public const int elementId_wheel2Up = 56;

		// Token: 0x04000892 RID: 2194
		public const int elementId_wheel2Down = 57;

		// Token: 0x04000893 RID: 2195
		public const int elementId_wheel2Press = 58;

		// Token: 0x04000894 RID: 2196
		public const int elementId_leftGripHatUp = 27;

		// Token: 0x04000895 RID: 2197
		public const int elementId_leftGripHatUpRight = 28;

		// Token: 0x04000896 RID: 2198
		public const int elementId_leftGripHatRight = 29;

		// Token: 0x04000897 RID: 2199
		public const int elementId_leftGripHatDownRight = 30;

		// Token: 0x04000898 RID: 2200
		public const int elementId_leftGripHatDown = 31;

		// Token: 0x04000899 RID: 2201
		public const int elementId_leftGripHatDownLeft = 32;

		// Token: 0x0400089A RID: 2202
		public const int elementId_leftGripHatLeft = 33;

		// Token: 0x0400089B RID: 2203
		public const int elementId_leftGripHatUpLeft = 34;

		// Token: 0x0400089C RID: 2204
		public const int elementId_rightGripHatUp = 35;

		// Token: 0x0400089D RID: 2205
		public const int elementId_rightGripHatUpRight = 36;

		// Token: 0x0400089E RID: 2206
		public const int elementId_rightGripHatRight = 37;

		// Token: 0x0400089F RID: 2207
		public const int elementId_rightGripHatDownRight = 38;

		// Token: 0x040008A0 RID: 2208
		public const int elementId_rightGripHatDown = 39;

		// Token: 0x040008A1 RID: 2209
		public const int elementId_rightGripHatDownLeft = 40;

		// Token: 0x040008A2 RID: 2210
		public const int elementId_rightGripHatLeft = 41;

		// Token: 0x040008A3 RID: 2211
		public const int elementId_rightGripHatUpLeft = 42;

		// Token: 0x040008A4 RID: 2212
		public const int elementId_consoleButton1 = 43;

		// Token: 0x040008A5 RID: 2213
		public const int elementId_consoleButton2 = 44;

		// Token: 0x040008A6 RID: 2214
		public const int elementId_consoleButton3 = 45;

		// Token: 0x040008A7 RID: 2215
		public const int elementId_consoleButton4 = 46;

		// Token: 0x040008A8 RID: 2216
		public const int elementId_consoleButton5 = 47;

		// Token: 0x040008A9 RID: 2217
		public const int elementId_consoleButton6 = 48;

		// Token: 0x040008AA RID: 2218
		public const int elementId_consoleButton7 = 49;

		// Token: 0x040008AB RID: 2219
		public const int elementId_consoleButton8 = 50;

		// Token: 0x040008AC RID: 2220
		public const int elementId_consoleButton9 = 51;

		// Token: 0x040008AD RID: 2221
		public const int elementId_consoleButton10 = 52;

		// Token: 0x040008AE RID: 2222
		public const int elementId_mode1 = 61;

		// Token: 0x040008AF RID: 2223
		public const int elementId_mode2 = 62;

		// Token: 0x040008B0 RID: 2224
		public const int elementId_mode3 = 63;

		// Token: 0x040008B1 RID: 2225
		public const int elementId_yoke = 69;

		// Token: 0x040008B2 RID: 2226
		public const int elementId_lever1 = 70;

		// Token: 0x040008B3 RID: 2227
		public const int elementId_lever2 = 71;

		// Token: 0x040008B4 RID: 2228
		public const int elementId_lever3 = 72;

		// Token: 0x040008B5 RID: 2229
		public const int elementId_lever4 = 73;

		// Token: 0x040008B6 RID: 2230
		public const int elementId_lever5 = 74;

		// Token: 0x040008B7 RID: 2231
		public const int elementId_leftGripHat = 75;

		// Token: 0x040008B8 RID: 2232
		public const int elementId_rightGripHat = 76;
	}
}
