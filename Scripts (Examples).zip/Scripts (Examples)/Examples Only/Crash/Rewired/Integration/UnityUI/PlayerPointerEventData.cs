﻿using System;
using System.Text;
using Rewired.UI;
using UnityEngine.EventSystems;

namespace Rewired.Integration.UnityUI
{
	// Token: 0x0200017E RID: 382
	public class PlayerPointerEventData : PointerEventData
	{
		// Token: 0x17000333 RID: 819
		// (get) Token: 0x06000CEC RID: 3308 RVA: 0x0002BCCF File Offset: 0x00029ECF
		// (set) Token: 0x06000CED RID: 3309 RVA: 0x0002BCD7 File Offset: 0x00029ED7
		public int playerId { get; set; }

		// Token: 0x17000334 RID: 820
		// (get) Token: 0x06000CEE RID: 3310 RVA: 0x0002BCE0 File Offset: 0x00029EE0
		// (set) Token: 0x06000CEF RID: 3311 RVA: 0x0002BCE8 File Offset: 0x00029EE8
		public int inputSourceIndex { get; set; }

		// Token: 0x17000335 RID: 821
		// (get) Token: 0x06000CF0 RID: 3312 RVA: 0x0002BCF1 File Offset: 0x00029EF1
		// (set) Token: 0x06000CF1 RID: 3313 RVA: 0x0002BCF9 File Offset: 0x00029EF9
		public IMouseInputSource mouseSource { get; set; }

		// Token: 0x17000336 RID: 822
		// (get) Token: 0x06000CF2 RID: 3314 RVA: 0x0002BD02 File Offset: 0x00029F02
		// (set) Token: 0x06000CF3 RID: 3315 RVA: 0x0002BD0A File Offset: 0x00029F0A
		public ITouchInputSource touchSource { get; set; }

		// Token: 0x17000337 RID: 823
		// (get) Token: 0x06000CF4 RID: 3316 RVA: 0x0002BD13 File Offset: 0x00029F13
		// (set) Token: 0x06000CF5 RID: 3317 RVA: 0x0002BD1B File Offset: 0x00029F1B
		public PointerEventType sourceType { get; set; }

		// Token: 0x17000338 RID: 824
		// (get) Token: 0x06000CF6 RID: 3318 RVA: 0x0002BD24 File Offset: 0x00029F24
		// (set) Token: 0x06000CF7 RID: 3319 RVA: 0x0002BD2C File Offset: 0x00029F2C
		public int buttonIndex { get; set; }

		// Token: 0x06000CF8 RID: 3320 RVA: 0x0002BD35 File Offset: 0x00029F35
		public PlayerPointerEventData(EventSystem eventSystem) : base(eventSystem)
		{
			this.playerId = -1;
			this.inputSourceIndex = -1;
			this.buttonIndex = -1;
		}

		// Token: 0x06000CF9 RID: 3321 RVA: 0x0002BD54 File Offset: 0x00029F54
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("<b>Player Id</b>: " + this.playerId.ToString());
			string str = "<b>Mouse Source</b>: ";
			IMouseInputSource mouseSource = this.mouseSource;
			stringBuilder.AppendLine(str + ((mouseSource != null) ? mouseSource.ToString() : null));
			stringBuilder.AppendLine("<b>Input Source Index</b>: " + this.inputSourceIndex.ToString());
			string str2 = "<b>Touch Source/b>: ";
			ITouchInputSource touchSource = this.touchSource;
			stringBuilder.AppendLine(str2 + ((touchSource != null) ? touchSource.ToString() : null));
			stringBuilder.AppendLine("<b>Source Type</b>: " + this.sourceType.ToString());
			stringBuilder.AppendLine("<b>Button Index</b>: " + this.buttonIndex.ToString());
			stringBuilder.Append(base.ToString());
			return stringBuilder.ToString();
		}
	}
}
