﻿using System;

namespace Rewired.Integration.UnityUI
{
	// Token: 0x02000181 RID: 385
	public enum PointerEventType
	{
		// Token: 0x04000930 RID: 2352
		Mouse,
		// Token: 0x04000931 RID: 2353
		Touch
	}
}
