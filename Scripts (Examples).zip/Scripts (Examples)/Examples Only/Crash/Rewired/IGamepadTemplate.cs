﻿using System;

namespace Rewired
{
	// Token: 0x0200016E RID: 366
	public interface IGamepadTemplate : IControllerTemplate
	{
		// Token: 0x1700012C RID: 300
		// (get) Token: 0x06000A65 RID: 2661
		IControllerTemplateButton actionBottomRow1 { get; }

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x06000A66 RID: 2662
		IControllerTemplateButton a { get; }

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x06000A67 RID: 2663
		IControllerTemplateButton actionBottomRow2 { get; }

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x06000A68 RID: 2664
		IControllerTemplateButton b { get; }

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x06000A69 RID: 2665
		IControllerTemplateButton actionBottomRow3 { get; }

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x06000A6A RID: 2666
		IControllerTemplateButton c { get; }

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x06000A6B RID: 2667
		IControllerTemplateButton actionTopRow1 { get; }

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x06000A6C RID: 2668
		IControllerTemplateButton x { get; }

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x06000A6D RID: 2669
		IControllerTemplateButton actionTopRow2 { get; }

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x06000A6E RID: 2670
		IControllerTemplateButton y { get; }

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x06000A6F RID: 2671
		IControllerTemplateButton actionTopRow3 { get; }

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x06000A70 RID: 2672
		IControllerTemplateButton z { get; }

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x06000A71 RID: 2673
		IControllerTemplateButton leftShoulder1 { get; }

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x06000A72 RID: 2674
		IControllerTemplateButton leftBumper { get; }

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x06000A73 RID: 2675
		IControllerTemplateAxis leftShoulder2 { get; }

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x06000A74 RID: 2676
		IControllerTemplateAxis leftTrigger { get; }

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x06000A75 RID: 2677
		IControllerTemplateButton rightShoulder1 { get; }

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x06000A76 RID: 2678
		IControllerTemplateButton rightBumper { get; }

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x06000A77 RID: 2679
		IControllerTemplateAxis rightShoulder2 { get; }

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x06000A78 RID: 2680
		IControllerTemplateAxis rightTrigger { get; }

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x06000A79 RID: 2681
		IControllerTemplateButton center1 { get; }

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x06000A7A RID: 2682
		IControllerTemplateButton back { get; }

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x06000A7B RID: 2683
		IControllerTemplateButton center2 { get; }

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x06000A7C RID: 2684
		IControllerTemplateButton start { get; }

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x06000A7D RID: 2685
		IControllerTemplateButton center3 { get; }

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x06000A7E RID: 2686
		IControllerTemplateButton guide { get; }

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x06000A7F RID: 2687
		IControllerTemplateThumbStick leftStick { get; }

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x06000A80 RID: 2688
		IControllerTemplateThumbStick rightStick { get; }

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x06000A81 RID: 2689
		IControllerTemplateDPad dPad { get; }
	}
}
