﻿using System;

namespace Rewired
{
	// Token: 0x02000170 RID: 368
	public interface IHOTASTemplate : IControllerTemplate
	{
		// Token: 0x17000173 RID: 371
		// (get) Token: 0x06000AAC RID: 2732
		IControllerTemplateButton stickTrigger { get; }

		// Token: 0x17000174 RID: 372
		// (get) Token: 0x06000AAD RID: 2733
		IControllerTemplateButton stickTriggerStage2 { get; }

		// Token: 0x17000175 RID: 373
		// (get) Token: 0x06000AAE RID: 2734
		IControllerTemplateButton stickPinkyButton { get; }

		// Token: 0x17000176 RID: 374
		// (get) Token: 0x06000AAF RID: 2735
		IControllerTemplateButton stickPinkyTrigger { get; }

		// Token: 0x17000177 RID: 375
		// (get) Token: 0x06000AB0 RID: 2736
		IControllerTemplateButton stickButton1 { get; }

		// Token: 0x17000178 RID: 376
		// (get) Token: 0x06000AB1 RID: 2737
		IControllerTemplateButton stickButton2 { get; }

		// Token: 0x17000179 RID: 377
		// (get) Token: 0x06000AB2 RID: 2738
		IControllerTemplateButton stickButton3 { get; }

		// Token: 0x1700017A RID: 378
		// (get) Token: 0x06000AB3 RID: 2739
		IControllerTemplateButton stickButton4 { get; }

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x06000AB4 RID: 2740
		IControllerTemplateButton stickButton5 { get; }

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x06000AB5 RID: 2741
		IControllerTemplateButton stickButton6 { get; }

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x06000AB6 RID: 2742
		IControllerTemplateButton stickButton7 { get; }

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x06000AB7 RID: 2743
		IControllerTemplateButton stickButton8 { get; }

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x06000AB8 RID: 2744
		IControllerTemplateButton stickButton9 { get; }

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x06000AB9 RID: 2745
		IControllerTemplateButton stickButton10 { get; }

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x06000ABA RID: 2746
		IControllerTemplateButton stickBaseButton1 { get; }

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x06000ABB RID: 2747
		IControllerTemplateButton stickBaseButton2 { get; }

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x06000ABC RID: 2748
		IControllerTemplateButton stickBaseButton3 { get; }

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x06000ABD RID: 2749
		IControllerTemplateButton stickBaseButton4 { get; }

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x06000ABE RID: 2750
		IControllerTemplateButton stickBaseButton5 { get; }

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x06000ABF RID: 2751
		IControllerTemplateButton stickBaseButton6 { get; }

		// Token: 0x17000187 RID: 391
		// (get) Token: 0x06000AC0 RID: 2752
		IControllerTemplateButton stickBaseButton7 { get; }

		// Token: 0x17000188 RID: 392
		// (get) Token: 0x06000AC1 RID: 2753
		IControllerTemplateButton stickBaseButton8 { get; }

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x06000AC2 RID: 2754
		IControllerTemplateButton stickBaseButton9 { get; }

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x06000AC3 RID: 2755
		IControllerTemplateButton stickBaseButton10 { get; }

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x06000AC4 RID: 2756
		IControllerTemplateButton stickBaseButton11 { get; }

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x06000AC5 RID: 2757
		IControllerTemplateButton stickBaseButton12 { get; }

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x06000AC6 RID: 2758
		IControllerTemplateButton mode1 { get; }

		// Token: 0x1700018E RID: 398
		// (get) Token: 0x06000AC7 RID: 2759
		IControllerTemplateButton mode2 { get; }

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x06000AC8 RID: 2760
		IControllerTemplateButton mode3 { get; }

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x06000AC9 RID: 2761
		IControllerTemplateButton throttleButton1 { get; }

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x06000ACA RID: 2762
		IControllerTemplateButton throttleButton2 { get; }

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x06000ACB RID: 2763
		IControllerTemplateButton throttleButton3 { get; }

		// Token: 0x17000193 RID: 403
		// (get) Token: 0x06000ACC RID: 2764
		IControllerTemplateButton throttleButton4 { get; }

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x06000ACD RID: 2765
		IControllerTemplateButton throttleButton5 { get; }

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x06000ACE RID: 2766
		IControllerTemplateButton throttleButton6 { get; }

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x06000ACF RID: 2767
		IControllerTemplateButton throttleButton7 { get; }

		// Token: 0x17000197 RID: 407
		// (get) Token: 0x06000AD0 RID: 2768
		IControllerTemplateButton throttleButton8 { get; }

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x06000AD1 RID: 2769
		IControllerTemplateButton throttleButton9 { get; }

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x06000AD2 RID: 2770
		IControllerTemplateButton throttleButton10 { get; }

		// Token: 0x1700019A RID: 410
		// (get) Token: 0x06000AD3 RID: 2771
		IControllerTemplateButton throttleBaseButton1 { get; }

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x06000AD4 RID: 2772
		IControllerTemplateButton throttleBaseButton2 { get; }

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x06000AD5 RID: 2773
		IControllerTemplateButton throttleBaseButton3 { get; }

		// Token: 0x1700019D RID: 413
		// (get) Token: 0x06000AD6 RID: 2774
		IControllerTemplateButton throttleBaseButton4 { get; }

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x06000AD7 RID: 2775
		IControllerTemplateButton throttleBaseButton5 { get; }

		// Token: 0x1700019F RID: 415
		// (get) Token: 0x06000AD8 RID: 2776
		IControllerTemplateButton throttleBaseButton6 { get; }

		// Token: 0x170001A0 RID: 416
		// (get) Token: 0x06000AD9 RID: 2777
		IControllerTemplateButton throttleBaseButton7 { get; }

		// Token: 0x170001A1 RID: 417
		// (get) Token: 0x06000ADA RID: 2778
		IControllerTemplateButton throttleBaseButton8 { get; }

		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x06000ADB RID: 2779
		IControllerTemplateButton throttleBaseButton9 { get; }

		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x06000ADC RID: 2780
		IControllerTemplateButton throttleBaseButton10 { get; }

		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x06000ADD RID: 2781
		IControllerTemplateButton throttleBaseButton11 { get; }

		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x06000ADE RID: 2782
		IControllerTemplateButton throttleBaseButton12 { get; }

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x06000ADF RID: 2783
		IControllerTemplateButton throttleBaseButton13 { get; }

		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x06000AE0 RID: 2784
		IControllerTemplateButton throttleBaseButton14 { get; }

		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x06000AE1 RID: 2785
		IControllerTemplateButton throttleBaseButton15 { get; }

		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x06000AE2 RID: 2786
		IControllerTemplateAxis throttleSlider1 { get; }

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x06000AE3 RID: 2787
		IControllerTemplateAxis throttleSlider2 { get; }

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x06000AE4 RID: 2788
		IControllerTemplateAxis throttleSlider3 { get; }

		// Token: 0x170001AC RID: 428
		// (get) Token: 0x06000AE5 RID: 2789
		IControllerTemplateAxis throttleSlider4 { get; }

		// Token: 0x170001AD RID: 429
		// (get) Token: 0x06000AE6 RID: 2790
		IControllerTemplateAxis throttleDial1 { get; }

		// Token: 0x170001AE RID: 430
		// (get) Token: 0x06000AE7 RID: 2791
		IControllerTemplateAxis throttleDial2 { get; }

		// Token: 0x170001AF RID: 431
		// (get) Token: 0x06000AE8 RID: 2792
		IControllerTemplateAxis throttleDial3 { get; }

		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x06000AE9 RID: 2793
		IControllerTemplateAxis throttleDial4 { get; }

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x06000AEA RID: 2794
		IControllerTemplateButton throttleWheel1Forward { get; }

		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x06000AEB RID: 2795
		IControllerTemplateButton throttleWheel1Back { get; }

		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x06000AEC RID: 2796
		IControllerTemplateButton throttleWheel1Press { get; }

		// Token: 0x170001B4 RID: 436
		// (get) Token: 0x06000AED RID: 2797
		IControllerTemplateButton throttleWheel2Forward { get; }

		// Token: 0x170001B5 RID: 437
		// (get) Token: 0x06000AEE RID: 2798
		IControllerTemplateButton throttleWheel2Back { get; }

		// Token: 0x170001B6 RID: 438
		// (get) Token: 0x06000AEF RID: 2799
		IControllerTemplateButton throttleWheel2Press { get; }

		// Token: 0x170001B7 RID: 439
		// (get) Token: 0x06000AF0 RID: 2800
		IControllerTemplateButton throttleWheel3Forward { get; }

		// Token: 0x170001B8 RID: 440
		// (get) Token: 0x06000AF1 RID: 2801
		IControllerTemplateButton throttleWheel3Back { get; }

		// Token: 0x170001B9 RID: 441
		// (get) Token: 0x06000AF2 RID: 2802
		IControllerTemplateButton throttleWheel3Press { get; }

		// Token: 0x170001BA RID: 442
		// (get) Token: 0x06000AF3 RID: 2803
		IControllerTemplateAxis leftPedal { get; }

		// Token: 0x170001BB RID: 443
		// (get) Token: 0x06000AF4 RID: 2804
		IControllerTemplateAxis rightPedal { get; }

		// Token: 0x170001BC RID: 444
		// (get) Token: 0x06000AF5 RID: 2805
		IControllerTemplateAxis slidePedals { get; }

		// Token: 0x170001BD RID: 445
		// (get) Token: 0x06000AF6 RID: 2806
		IControllerTemplateStick stick { get; }

		// Token: 0x170001BE RID: 446
		// (get) Token: 0x06000AF7 RID: 2807
		IControllerTemplateThumbStick stickMiniStick1 { get; }

		// Token: 0x170001BF RID: 447
		// (get) Token: 0x06000AF8 RID: 2808
		IControllerTemplateThumbStick stickMiniStick2 { get; }

		// Token: 0x170001C0 RID: 448
		// (get) Token: 0x06000AF9 RID: 2809
		IControllerTemplateHat stickHat1 { get; }

		// Token: 0x170001C1 RID: 449
		// (get) Token: 0x06000AFA RID: 2810
		IControllerTemplateHat stickHat2 { get; }

		// Token: 0x170001C2 RID: 450
		// (get) Token: 0x06000AFB RID: 2811
		IControllerTemplateHat stickHat3 { get; }

		// Token: 0x170001C3 RID: 451
		// (get) Token: 0x06000AFC RID: 2812
		IControllerTemplateHat stickHat4 { get; }

		// Token: 0x170001C4 RID: 452
		// (get) Token: 0x06000AFD RID: 2813
		IControllerTemplateThrottle throttle1 { get; }

		// Token: 0x170001C5 RID: 453
		// (get) Token: 0x06000AFE RID: 2814
		IControllerTemplateThrottle throttle2 { get; }

		// Token: 0x170001C6 RID: 454
		// (get) Token: 0x06000AFF RID: 2815
		IControllerTemplateThumbStick throttleMiniStick { get; }

		// Token: 0x170001C7 RID: 455
		// (get) Token: 0x06000B00 RID: 2816
		IControllerTemplateHat throttleHat1 { get; }

		// Token: 0x170001C8 RID: 456
		// (get) Token: 0x06000B01 RID: 2817
		IControllerTemplateHat throttleHat2 { get; }

		// Token: 0x170001C9 RID: 457
		// (get) Token: 0x06000B02 RID: 2818
		IControllerTemplateHat throttleHat3 { get; }

		// Token: 0x170001CA RID: 458
		// (get) Token: 0x06000B03 RID: 2819
		IControllerTemplateHat throttleHat4 { get; }
	}
}
