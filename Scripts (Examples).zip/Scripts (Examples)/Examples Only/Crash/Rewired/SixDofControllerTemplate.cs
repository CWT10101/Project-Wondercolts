﻿using System;

namespace Rewired
{
	// Token: 0x02000179 RID: 377
	public sealed class SixDofControllerTemplate : ControllerTemplate, ISixDofControllerTemplate, IControllerTemplate
	{
		// Token: 0x170002FB RID: 763
		// (get) Token: 0x06000C3E RID: 3134 RVA: 0x00029EBF File Offset: 0x000280BF
		IControllerTemplateAxis ISixDofControllerTemplate.extraAxis1
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(8);
			}
		}

		// Token: 0x170002FC RID: 764
		// (get) Token: 0x06000C3F RID: 3135 RVA: 0x00029EC8 File Offset: 0x000280C8
		IControllerTemplateAxis ISixDofControllerTemplate.extraAxis2
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(9);
			}
		}

		// Token: 0x170002FD RID: 765
		// (get) Token: 0x06000C40 RID: 3136 RVA: 0x00029ED2 File Offset: 0x000280D2
		IControllerTemplateAxis ISixDofControllerTemplate.extraAxis3
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(10);
			}
		}

		// Token: 0x170002FE RID: 766
		// (get) Token: 0x06000C41 RID: 3137 RVA: 0x00029EDC File Offset: 0x000280DC
		IControllerTemplateAxis ISixDofControllerTemplate.extraAxis4
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(11);
			}
		}

		// Token: 0x170002FF RID: 767
		// (get) Token: 0x06000C42 RID: 3138 RVA: 0x00029EE6 File Offset: 0x000280E6
		IControllerTemplateButton ISixDofControllerTemplate.button1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(12);
			}
		}

		// Token: 0x17000300 RID: 768
		// (get) Token: 0x06000C43 RID: 3139 RVA: 0x00029EF0 File Offset: 0x000280F0
		IControllerTemplateButton ISixDofControllerTemplate.button2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(13);
			}
		}

		// Token: 0x17000301 RID: 769
		// (get) Token: 0x06000C44 RID: 3140 RVA: 0x00029EFA File Offset: 0x000280FA
		IControllerTemplateButton ISixDofControllerTemplate.button3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(14);
			}
		}

		// Token: 0x17000302 RID: 770
		// (get) Token: 0x06000C45 RID: 3141 RVA: 0x00029F04 File Offset: 0x00028104
		IControllerTemplateButton ISixDofControllerTemplate.button4
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(15);
			}
		}

		// Token: 0x17000303 RID: 771
		// (get) Token: 0x06000C46 RID: 3142 RVA: 0x00029F0E File Offset: 0x0002810E
		IControllerTemplateButton ISixDofControllerTemplate.button5
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(16);
			}
		}

		// Token: 0x17000304 RID: 772
		// (get) Token: 0x06000C47 RID: 3143 RVA: 0x00029F18 File Offset: 0x00028118
		IControllerTemplateButton ISixDofControllerTemplate.button6
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(17);
			}
		}

		// Token: 0x17000305 RID: 773
		// (get) Token: 0x06000C48 RID: 3144 RVA: 0x00029F22 File Offset: 0x00028122
		IControllerTemplateButton ISixDofControllerTemplate.button7
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(18);
			}
		}

		// Token: 0x17000306 RID: 774
		// (get) Token: 0x06000C49 RID: 3145 RVA: 0x00029F2C File Offset: 0x0002812C
		IControllerTemplateButton ISixDofControllerTemplate.button8
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(19);
			}
		}

		// Token: 0x17000307 RID: 775
		// (get) Token: 0x06000C4A RID: 3146 RVA: 0x00029F36 File Offset: 0x00028136
		IControllerTemplateButton ISixDofControllerTemplate.button9
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(20);
			}
		}

		// Token: 0x17000308 RID: 776
		// (get) Token: 0x06000C4B RID: 3147 RVA: 0x00029F40 File Offset: 0x00028140
		IControllerTemplateButton ISixDofControllerTemplate.button10
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(21);
			}
		}

		// Token: 0x17000309 RID: 777
		// (get) Token: 0x06000C4C RID: 3148 RVA: 0x00029F4A File Offset: 0x0002814A
		IControllerTemplateButton ISixDofControllerTemplate.button11
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(22);
			}
		}

		// Token: 0x1700030A RID: 778
		// (get) Token: 0x06000C4D RID: 3149 RVA: 0x00029F54 File Offset: 0x00028154
		IControllerTemplateButton ISixDofControllerTemplate.button12
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(23);
			}
		}

		// Token: 0x1700030B RID: 779
		// (get) Token: 0x06000C4E RID: 3150 RVA: 0x00029F5E File Offset: 0x0002815E
		IControllerTemplateButton ISixDofControllerTemplate.button13
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(24);
			}
		}

		// Token: 0x1700030C RID: 780
		// (get) Token: 0x06000C4F RID: 3151 RVA: 0x00029F68 File Offset: 0x00028168
		IControllerTemplateButton ISixDofControllerTemplate.button14
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(25);
			}
		}

		// Token: 0x1700030D RID: 781
		// (get) Token: 0x06000C50 RID: 3152 RVA: 0x00029F72 File Offset: 0x00028172
		IControllerTemplateButton ISixDofControllerTemplate.button15
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(26);
			}
		}

		// Token: 0x1700030E RID: 782
		// (get) Token: 0x06000C51 RID: 3153 RVA: 0x00029F7C File Offset: 0x0002817C
		IControllerTemplateButton ISixDofControllerTemplate.button16
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(27);
			}
		}

		// Token: 0x1700030F RID: 783
		// (get) Token: 0x06000C52 RID: 3154 RVA: 0x00029F86 File Offset: 0x00028186
		IControllerTemplateButton ISixDofControllerTemplate.button17
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(28);
			}
		}

		// Token: 0x17000310 RID: 784
		// (get) Token: 0x06000C53 RID: 3155 RVA: 0x00029F90 File Offset: 0x00028190
		IControllerTemplateButton ISixDofControllerTemplate.button18
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(29);
			}
		}

		// Token: 0x17000311 RID: 785
		// (get) Token: 0x06000C54 RID: 3156 RVA: 0x00029F9A File Offset: 0x0002819A
		IControllerTemplateButton ISixDofControllerTemplate.button19
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(30);
			}
		}

		// Token: 0x17000312 RID: 786
		// (get) Token: 0x06000C55 RID: 3157 RVA: 0x00029FA4 File Offset: 0x000281A4
		IControllerTemplateButton ISixDofControllerTemplate.button20
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(31);
			}
		}

		// Token: 0x17000313 RID: 787
		// (get) Token: 0x06000C56 RID: 3158 RVA: 0x00029FAE File Offset: 0x000281AE
		IControllerTemplateButton ISixDofControllerTemplate.button21
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(55);
			}
		}

		// Token: 0x17000314 RID: 788
		// (get) Token: 0x06000C57 RID: 3159 RVA: 0x00029FB8 File Offset: 0x000281B8
		IControllerTemplateButton ISixDofControllerTemplate.button22
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(56);
			}
		}

		// Token: 0x17000315 RID: 789
		// (get) Token: 0x06000C58 RID: 3160 RVA: 0x00029FC2 File Offset: 0x000281C2
		IControllerTemplateButton ISixDofControllerTemplate.button23
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(57);
			}
		}

		// Token: 0x17000316 RID: 790
		// (get) Token: 0x06000C59 RID: 3161 RVA: 0x00029FCC File Offset: 0x000281CC
		IControllerTemplateButton ISixDofControllerTemplate.button24
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(58);
			}
		}

		// Token: 0x17000317 RID: 791
		// (get) Token: 0x06000C5A RID: 3162 RVA: 0x00029FD6 File Offset: 0x000281D6
		IControllerTemplateButton ISixDofControllerTemplate.button25
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(59);
			}
		}

		// Token: 0x17000318 RID: 792
		// (get) Token: 0x06000C5B RID: 3163 RVA: 0x00029FE0 File Offset: 0x000281E0
		IControllerTemplateButton ISixDofControllerTemplate.button26
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(60);
			}
		}

		// Token: 0x17000319 RID: 793
		// (get) Token: 0x06000C5C RID: 3164 RVA: 0x00029FEA File Offset: 0x000281EA
		IControllerTemplateButton ISixDofControllerTemplate.button27
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(61);
			}
		}

		// Token: 0x1700031A RID: 794
		// (get) Token: 0x06000C5D RID: 3165 RVA: 0x00029FF4 File Offset: 0x000281F4
		IControllerTemplateButton ISixDofControllerTemplate.button28
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(62);
			}
		}

		// Token: 0x1700031B RID: 795
		// (get) Token: 0x06000C5E RID: 3166 RVA: 0x00029FFE File Offset: 0x000281FE
		IControllerTemplateButton ISixDofControllerTemplate.button29
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(63);
			}
		}

		// Token: 0x1700031C RID: 796
		// (get) Token: 0x06000C5F RID: 3167 RVA: 0x0002A008 File Offset: 0x00028208
		IControllerTemplateButton ISixDofControllerTemplate.button30
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(64);
			}
		}

		// Token: 0x1700031D RID: 797
		// (get) Token: 0x06000C60 RID: 3168 RVA: 0x0002A012 File Offset: 0x00028212
		IControllerTemplateButton ISixDofControllerTemplate.button31
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(65);
			}
		}

		// Token: 0x1700031E RID: 798
		// (get) Token: 0x06000C61 RID: 3169 RVA: 0x0002A01C File Offset: 0x0002821C
		IControllerTemplateButton ISixDofControllerTemplate.button32
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(66);
			}
		}

		// Token: 0x1700031F RID: 799
		// (get) Token: 0x06000C62 RID: 3170 RVA: 0x0002A026 File Offset: 0x00028226
		IControllerTemplateHat ISixDofControllerTemplate.hat1
		{
			get
			{
				return base.GetElement<IControllerTemplateHat>(48);
			}
		}

		// Token: 0x17000320 RID: 800
		// (get) Token: 0x06000C63 RID: 3171 RVA: 0x0002A030 File Offset: 0x00028230
		IControllerTemplateHat ISixDofControllerTemplate.hat2
		{
			get
			{
				return base.GetElement<IControllerTemplateHat>(49);
			}
		}

		// Token: 0x17000321 RID: 801
		// (get) Token: 0x06000C64 RID: 3172 RVA: 0x0002A03A File Offset: 0x0002823A
		IControllerTemplateThrottle ISixDofControllerTemplate.throttle1
		{
			get
			{
				return base.GetElement<IControllerTemplateThrottle>(52);
			}
		}

		// Token: 0x17000322 RID: 802
		// (get) Token: 0x06000C65 RID: 3173 RVA: 0x0002A044 File Offset: 0x00028244
		IControllerTemplateThrottle ISixDofControllerTemplate.throttle2
		{
			get
			{
				return base.GetElement<IControllerTemplateThrottle>(53);
			}
		}

		// Token: 0x17000323 RID: 803
		// (get) Token: 0x06000C66 RID: 3174 RVA: 0x0002A04E File Offset: 0x0002824E
		IControllerTemplateStick6D ISixDofControllerTemplate.stick
		{
			get
			{
				return base.GetElement<IControllerTemplateStick6D>(54);
			}
		}

		// Token: 0x06000C67 RID: 3175 RVA: 0x0002A058 File Offset: 0x00028258
		public SixDofControllerTemplate(object payload) : base(payload)
		{
		}

		// Token: 0x040008BD RID: 2237
		public static readonly Guid typeGuid = new Guid("2599beb3-522b-43dd-a4ef-93fd60e5eafa");

		// Token: 0x040008BE RID: 2238
		public const int elementId_positionX = 1;

		// Token: 0x040008BF RID: 2239
		public const int elementId_positionY = 2;

		// Token: 0x040008C0 RID: 2240
		public const int elementId_positionZ = 0;

		// Token: 0x040008C1 RID: 2241
		public const int elementId_rotationX = 3;

		// Token: 0x040008C2 RID: 2242
		public const int elementId_rotationY = 5;

		// Token: 0x040008C3 RID: 2243
		public const int elementId_rotationZ = 4;

		// Token: 0x040008C4 RID: 2244
		public const int elementId_throttle1Axis = 6;

		// Token: 0x040008C5 RID: 2245
		public const int elementId_throttle1MinDetent = 50;

		// Token: 0x040008C6 RID: 2246
		public const int elementId_throttle2Axis = 7;

		// Token: 0x040008C7 RID: 2247
		public const int elementId_throttle2MinDetent = 51;

		// Token: 0x040008C8 RID: 2248
		public const int elementId_extraAxis1 = 8;

		// Token: 0x040008C9 RID: 2249
		public const int elementId_extraAxis2 = 9;

		// Token: 0x040008CA RID: 2250
		public const int elementId_extraAxis3 = 10;

		// Token: 0x040008CB RID: 2251
		public const int elementId_extraAxis4 = 11;

		// Token: 0x040008CC RID: 2252
		public const int elementId_button1 = 12;

		// Token: 0x040008CD RID: 2253
		public const int elementId_button2 = 13;

		// Token: 0x040008CE RID: 2254
		public const int elementId_button3 = 14;

		// Token: 0x040008CF RID: 2255
		public const int elementId_button4 = 15;

		// Token: 0x040008D0 RID: 2256
		public const int elementId_button5 = 16;

		// Token: 0x040008D1 RID: 2257
		public const int elementId_button6 = 17;

		// Token: 0x040008D2 RID: 2258
		public const int elementId_button7 = 18;

		// Token: 0x040008D3 RID: 2259
		public const int elementId_button8 = 19;

		// Token: 0x040008D4 RID: 2260
		public const int elementId_button9 = 20;

		// Token: 0x040008D5 RID: 2261
		public const int elementId_button10 = 21;

		// Token: 0x040008D6 RID: 2262
		public const int elementId_button11 = 22;

		// Token: 0x040008D7 RID: 2263
		public const int elementId_button12 = 23;

		// Token: 0x040008D8 RID: 2264
		public const int elementId_button13 = 24;

		// Token: 0x040008D9 RID: 2265
		public const int elementId_button14 = 25;

		// Token: 0x040008DA RID: 2266
		public const int elementId_button15 = 26;

		// Token: 0x040008DB RID: 2267
		public const int elementId_button16 = 27;

		// Token: 0x040008DC RID: 2268
		public const int elementId_button17 = 28;

		// Token: 0x040008DD RID: 2269
		public const int elementId_button18 = 29;

		// Token: 0x040008DE RID: 2270
		public const int elementId_button19 = 30;

		// Token: 0x040008DF RID: 2271
		public const int elementId_button20 = 31;

		// Token: 0x040008E0 RID: 2272
		public const int elementId_button21 = 55;

		// Token: 0x040008E1 RID: 2273
		public const int elementId_button22 = 56;

		// Token: 0x040008E2 RID: 2274
		public const int elementId_button23 = 57;

		// Token: 0x040008E3 RID: 2275
		public const int elementId_button24 = 58;

		// Token: 0x040008E4 RID: 2276
		public const int elementId_button25 = 59;

		// Token: 0x040008E5 RID: 2277
		public const int elementId_button26 = 60;

		// Token: 0x040008E6 RID: 2278
		public const int elementId_button27 = 61;

		// Token: 0x040008E7 RID: 2279
		public const int elementId_button28 = 62;

		// Token: 0x040008E8 RID: 2280
		public const int elementId_button29 = 63;

		// Token: 0x040008E9 RID: 2281
		public const int elementId_button30 = 64;

		// Token: 0x040008EA RID: 2282
		public const int elementId_button31 = 65;

		// Token: 0x040008EB RID: 2283
		public const int elementId_button32 = 66;

		// Token: 0x040008EC RID: 2284
		public const int elementId_hat1Up = 32;

		// Token: 0x040008ED RID: 2285
		public const int elementId_hat1UpRight = 33;

		// Token: 0x040008EE RID: 2286
		public const int elementId_hat1Right = 34;

		// Token: 0x040008EF RID: 2287
		public const int elementId_hat1DownRight = 35;

		// Token: 0x040008F0 RID: 2288
		public const int elementId_hat1Down = 36;

		// Token: 0x040008F1 RID: 2289
		public const int elementId_hat1DownLeft = 37;

		// Token: 0x040008F2 RID: 2290
		public const int elementId_hat1Left = 38;

		// Token: 0x040008F3 RID: 2291
		public const int elementId_hat1UpLeft = 39;

		// Token: 0x040008F4 RID: 2292
		public const int elementId_hat2Up = 40;

		// Token: 0x040008F5 RID: 2293
		public const int elementId_hat2UpRight = 41;

		// Token: 0x040008F6 RID: 2294
		public const int elementId_hat2Right = 42;

		// Token: 0x040008F7 RID: 2295
		public const int elementId_hat2DownRight = 43;

		// Token: 0x040008F8 RID: 2296
		public const int elementId_hat2Down = 44;

		// Token: 0x040008F9 RID: 2297
		public const int elementId_hat2DownLeft = 45;

		// Token: 0x040008FA RID: 2298
		public const int elementId_hat2Left = 46;

		// Token: 0x040008FB RID: 2299
		public const int elementId_hat2UpLeft = 47;

		// Token: 0x040008FC RID: 2300
		public const int elementId_hat1 = 48;

		// Token: 0x040008FD RID: 2301
		public const int elementId_hat2 = 49;

		// Token: 0x040008FE RID: 2302
		public const int elementId_throttle1 = 52;

		// Token: 0x040008FF RID: 2303
		public const int elementId_throttle2 = 53;

		// Token: 0x04000900 RID: 2304
		public const int elementId_stick = 54;
	}
}
