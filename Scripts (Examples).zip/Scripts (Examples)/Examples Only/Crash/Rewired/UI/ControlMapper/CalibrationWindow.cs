﻿using System;
using System.Collections.Generic;
using Rewired.Integration.UnityUI;
using Rewired.Utils;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000184 RID: 388
	[AddComponentMenu("")]
	public class CalibrationWindow : Window
	{
		// Token: 0x17000359 RID: 857
		// (get) Token: 0x06000D79 RID: 3449 RVA: 0x0002E4AC File Offset: 0x0002C6AC
		private bool axisSelected
		{
			get
			{
				return this.joystick != null && this.selectedAxis >= 0 && this.selectedAxis < this.joystick.calibrationMap.axisCount;
			}
		}

		// Token: 0x1700035A RID: 858
		// (get) Token: 0x06000D7A RID: 3450 RVA: 0x0002E4DC File Offset: 0x0002C6DC
		private AxisCalibration axisCalibration
		{
			get
			{
				if (!this.axisSelected)
				{
					return null;
				}
				return this.joystick.calibrationMap.GetAxis(this.selectedAxis);
			}
		}

		// Token: 0x06000D7B RID: 3451 RVA: 0x0002E500 File Offset: 0x0002C700
		public override void Initialize(int id, Func<int, bool> isFocusedCallback)
		{
			if (this.rightContentContainer == null || this.valueDisplayGroup == null || this.calibratedValueMarker == null || this.rawValueMarker == null || this.calibratedZeroMarker == null || this.deadzoneArea == null || this.deadzoneSlider == null || this.sensitivitySlider == null || this.zeroSlider == null || this.invertToggle == null || this.axisScrollAreaContent == null || this.doneButton == null || this.calibrateButton == null || this.axisButtonPrefab == null || this.doneButtonLabel == null || this.cancelButtonLabel == null || this.defaultButtonLabel == null || this.deadzoneSliderLabel == null || this.zeroSliderLabel == null || this.sensitivitySliderLabel == null || this.invertToggleLabel == null || this.calibrateButtonLabel == null)
			{
				Debug.LogError("Rewired Control Mapper: All inspector values must be assigned!");
				return;
			}
			this.axisButtons = new List<Button>();
			this.buttonCallbacks = new Dictionary<int, Action<int>>();
			this.doneButtonLabel.text = ControlMapper.GetLanguage().done;
			this.cancelButtonLabel.text = ControlMapper.GetLanguage().cancel;
			this.defaultButtonLabel.text = ControlMapper.GetLanguage().default_;
			this.deadzoneSliderLabel.text = ControlMapper.GetLanguage().calibrateWindow_deadZoneSliderLabel;
			this.zeroSliderLabel.text = ControlMapper.GetLanguage().calibrateWindow_zeroSliderLabel;
			this.sensitivitySliderLabel.text = ControlMapper.GetLanguage().calibrateWindow_sensitivitySliderLabel;
			this.invertToggleLabel.text = ControlMapper.GetLanguage().calibrateWindow_invertToggleLabel;
			this.calibrateButtonLabel.text = ControlMapper.GetLanguage().calibrateWindow_calibrateButtonLabel;
			base.Initialize(id, isFocusedCallback);
		}

		// Token: 0x06000D7C RID: 3452 RVA: 0x0002E738 File Offset: 0x0002C938
		public void SetJoystick(int playerId, Joystick joystick)
		{
			if (!base.initialized)
			{
				return;
			}
			this.playerId = playerId;
			this.joystick = joystick;
			if (joystick == null)
			{
				Debug.LogError("Rewired Control Mapper: Joystick cannot be null!");
				return;
			}
			float num = 0f;
			for (int i = 0; i < joystick.axisCount; i++)
			{
				int index = i;
				GameObject gameObject = UITools.InstantiateGUIObject<Button>(this.axisButtonPrefab, this.axisScrollAreaContent, "Axis" + i.ToString());
				Button button = gameObject.GetComponent<Button>();
				button.onClick.AddListener(delegate()
				{
					this.OnAxisSelected(index, button);
				});
				TMP_Text componentInSelfOrChildren = UnityTools.GetComponentInSelfOrChildren<TMP_Text>(gameObject);
				if (componentInSelfOrChildren != null)
				{
					componentInSelfOrChildren.text = ControlMapper.GetLanguage().GetElementIdentifierName(joystick, joystick.AxisElementIdentifiers[i].id, AxisRange.Full);
				}
				if (num == 0f)
				{
					num = UnityTools.GetComponentInSelfOrChildren<LayoutElement>(gameObject).minHeight;
				}
				this.axisButtons.Add(button);
			}
			float spacing = this.axisScrollAreaContent.GetComponent<VerticalLayoutGroup>().spacing;
			this.axisScrollAreaContent.sizeDelta = new Vector2(this.axisScrollAreaContent.sizeDelta.x, Mathf.Max((float)joystick.axisCount * (num + spacing) - spacing, this.axisScrollAreaContent.sizeDelta.y));
			this.origCalibrationData = joystick.calibrationMap.ToXmlString();
			this.displayAreaWidth = this.rightContentContainer.sizeDelta.x;
			this.rewiredStandaloneInputModule = base.gameObject.transform.root.GetComponentInChildren<RewiredStandaloneInputModule>();
			if (this.rewiredStandaloneInputModule != null)
			{
				this.menuHorizActionId = ReInput.mapping.GetActionId(this.rewiredStandaloneInputModule.horizontalAxis);
				this.menuVertActionId = ReInput.mapping.GetActionId(this.rewiredStandaloneInputModule.verticalAxis);
			}
			if (joystick.axisCount > 0)
			{
				this.SelectAxis(0);
			}
			base.defaultUIElement = this.doneButton.gameObject;
			this.RefreshControls();
			this.Redraw();
		}

		// Token: 0x06000D7D RID: 3453 RVA: 0x0002E94B File Offset: 0x0002CB4B
		public void SetButtonCallback(CalibrationWindow.ButtonIdentifier buttonIdentifier, Action<int> callback)
		{
			if (!base.initialized)
			{
				return;
			}
			if (callback == null)
			{
				return;
			}
			if (this.buttonCallbacks.ContainsKey((int)buttonIdentifier))
			{
				this.buttonCallbacks[(int)buttonIdentifier] = callback;
				return;
			}
			this.buttonCallbacks.Add((int)buttonIdentifier, callback);
		}

		// Token: 0x06000D7E RID: 3454 RVA: 0x0002E984 File Offset: 0x0002CB84
		public override void Cancel()
		{
			if (!base.initialized)
			{
				return;
			}
			if (this.joystick != null)
			{
				this.joystick.ImportCalibrationMapFromXmlString(this.origCalibrationData);
			}
			Action<int> action;
			if (!this.buttonCallbacks.TryGetValue(1, out action))
			{
				if (this.cancelCallback != null)
				{
					this.cancelCallback();
				}
				return;
			}
			action(base.id);
		}

		// Token: 0x06000D7F RID: 3455 RVA: 0x0002E9E4 File Offset: 0x0002CBE4
		protected override void Update()
		{
			if (!base.initialized)
			{
				return;
			}
			base.Update();
			this.UpdateDisplay();
		}

		// Token: 0x06000D80 RID: 3456 RVA: 0x0002E9FC File Offset: 0x0002CBFC
		public void OnDone()
		{
			if (!base.initialized)
			{
				return;
			}
			Action<int> action;
			if (!this.buttonCallbacks.TryGetValue(0, out action))
			{
				return;
			}
			action(base.id);
		}

		// Token: 0x06000D81 RID: 3457 RVA: 0x0002EA2F File Offset: 0x0002CC2F
		public void OnCancel()
		{
			this.Cancel();
		}

		// Token: 0x06000D82 RID: 3458 RVA: 0x0002EA37 File Offset: 0x0002CC37
		public void OnRestoreDefault()
		{
			if (!base.initialized)
			{
				return;
			}
			if (this.joystick == null)
			{
				return;
			}
			this.joystick.calibrationMap.Reset();
			this.RefreshControls();
			this.Redraw();
		}

		// Token: 0x06000D83 RID: 3459 RVA: 0x0002EA68 File Offset: 0x0002CC68
		public void OnCalibrate()
		{
			if (!base.initialized)
			{
				return;
			}
			Action<int> action;
			if (!this.buttonCallbacks.TryGetValue(3, out action))
			{
				return;
			}
			action(this.selectedAxis);
		}

		// Token: 0x06000D84 RID: 3460 RVA: 0x0002EA9B File Offset: 0x0002CC9B
		public void OnInvert(bool state)
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.invert = state;
		}

		// Token: 0x06000D85 RID: 3461 RVA: 0x0002EABB File Offset: 0x0002CCBB
		public void OnZeroValueChange(float value)
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.calibratedZero = value;
			this.RedrawCalibratedZero();
		}

		// Token: 0x06000D86 RID: 3462 RVA: 0x0002EAE1 File Offset: 0x0002CCE1
		public void OnZeroCancel()
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.calibratedZero = this.origSelectedAxisCalibrationData.zero;
			this.RedrawCalibratedZero();
			this.RefreshControls();
		}

		// Token: 0x06000D87 RID: 3463 RVA: 0x0002EB18 File Offset: 0x0002CD18
		public void OnDeadzoneValueChange(float value)
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.deadZone = Mathf.Clamp(value, 0f, 0.8f);
			if (value > 0.8f)
			{
				this.deadzoneSlider.value = 0.8f;
			}
			this.RedrawDeadzone();
		}

		// Token: 0x06000D88 RID: 3464 RVA: 0x0002EB70 File Offset: 0x0002CD70
		public void OnDeadzoneCancel()
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.deadZone = this.origSelectedAxisCalibrationData.deadZone;
			this.RedrawDeadzone();
			this.RefreshControls();
		}

		// Token: 0x06000D89 RID: 3465 RVA: 0x0002EBA6 File Offset: 0x0002CDA6
		public void OnSensitivityValueChange(float value)
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.SetSensitivity(this.axisCalibration, value);
		}

		// Token: 0x06000D8A RID: 3466 RVA: 0x0002EBC7 File Offset: 0x0002CDC7
		public void OnSensitivityCancel(float value)
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.sensitivity = this.origSelectedAxisCalibrationData.sensitivity;
			this.RefreshControls();
		}

		// Token: 0x06000D8B RID: 3467 RVA: 0x0002EBF7 File Offset: 0x0002CDF7
		public void OnAxisScrollRectScroll(Vector2 pos)
		{
			bool initialized = base.initialized;
		}

		// Token: 0x06000D8C RID: 3468 RVA: 0x0002EC00 File Offset: 0x0002CE00
		private void OnAxisSelected(int axisIndex, Button button)
		{
			if (!base.initialized)
			{
				return;
			}
			if (this.joystick == null)
			{
				return;
			}
			this.SelectAxis(axisIndex);
			this.RefreshControls();
			this.Redraw();
		}

		// Token: 0x06000D8D RID: 3469 RVA: 0x0002EC27 File Offset: 0x0002CE27
		private void UpdateDisplay()
		{
			this.RedrawValueMarkers();
		}

		// Token: 0x06000D8E RID: 3470 RVA: 0x0002EC2F File Offset: 0x0002CE2F
		private void Redraw()
		{
			this.RedrawCalibratedZero();
			this.RedrawValueMarkers();
		}

		// Token: 0x06000D8F RID: 3471 RVA: 0x0002EC40 File Offset: 0x0002CE40
		private void RefreshControls()
		{
			if (!this.axisSelected)
			{
				this.deadzoneSlider.value = 0f;
				this.zeroSlider.value = 0f;
				this.sensitivitySlider.value = 0f;
				this.invertToggle.isOn = false;
				return;
			}
			this.deadzoneSlider.value = this.axisCalibration.deadZone;
			this.zeroSlider.value = this.axisCalibration.calibratedZero;
			this.sensitivitySlider.value = this.GetSliderSensitivity(this.axisCalibration);
			this.invertToggle.isOn = this.axisCalibration.invert;
		}

		// Token: 0x06000D90 RID: 3472 RVA: 0x0002ECEC File Offset: 0x0002CEEC
		private void RedrawDeadzone()
		{
			if (!this.axisSelected)
			{
				return;
			}
			float x = this.displayAreaWidth * this.axisCalibration.deadZone;
			this.deadzoneArea.sizeDelta = new Vector2(x, this.deadzoneArea.sizeDelta.y);
			this.deadzoneArea.anchoredPosition = new Vector2(this.axisCalibration.calibratedZero * -this.deadzoneArea.parent.localPosition.x, this.deadzoneArea.anchoredPosition.y);
		}

		// Token: 0x06000D91 RID: 3473 RVA: 0x0002ED78 File Offset: 0x0002CF78
		private void RedrawCalibratedZero()
		{
			if (!this.axisSelected)
			{
				return;
			}
			this.calibratedZeroMarker.anchoredPosition = new Vector2(this.axisCalibration.calibratedZero * -this.deadzoneArea.parent.localPosition.x, this.calibratedZeroMarker.anchoredPosition.y);
			this.RedrawDeadzone();
		}

		// Token: 0x06000D92 RID: 3474 RVA: 0x0002EDD8 File Offset: 0x0002CFD8
		private void RedrawValueMarkers()
		{
			if (!this.axisSelected)
			{
				this.calibratedValueMarker.anchoredPosition = new Vector2(0f, this.calibratedValueMarker.anchoredPosition.y);
				this.rawValueMarker.anchoredPosition = new Vector2(0f, this.rawValueMarker.anchoredPosition.y);
				return;
			}
			float axis = this.joystick.GetAxis(this.selectedAxis);
			float num = Mathf.Clamp(this.joystick.GetAxisRaw(this.selectedAxis), -1f, 1f);
			this.calibratedValueMarker.anchoredPosition = new Vector2(this.displayAreaWidth * 0.5f * axis, this.calibratedValueMarker.anchoredPosition.y);
			this.rawValueMarker.anchoredPosition = new Vector2(this.displayAreaWidth * 0.5f * num, this.rawValueMarker.anchoredPosition.y);
		}

		// Token: 0x06000D93 RID: 3475 RVA: 0x0002EEC8 File Offset: 0x0002D0C8
		private void SelectAxis(int index)
		{
			if (index < 0 || index >= this.axisButtons.Count)
			{
				return;
			}
			if (this.axisButtons[index] == null)
			{
				return;
			}
			this.axisButtons[index].interactable = false;
			this.axisButtons[index].Select();
			for (int i = 0; i < this.axisButtons.Count; i++)
			{
				if (i != index)
				{
					this.axisButtons[i].interactable = true;
				}
			}
			this.selectedAxis = index;
			this.origSelectedAxisCalibrationData = this.axisCalibration.GetData();
			this.SetMinSensitivity();
		}

		// Token: 0x06000D94 RID: 3476 RVA: 0x0002EF6A File Offset: 0x0002D16A
		public override void TakeInputFocus()
		{
			base.TakeInputFocus();
			if (this.selectedAxis >= 0)
			{
				this.SelectAxis(this.selectedAxis);
			}
			this.RefreshControls();
			this.Redraw();
		}

		// Token: 0x06000D95 RID: 3477 RVA: 0x0002EF94 File Offset: 0x0002D194
		private void SetMinSensitivity()
		{
			if (!this.axisSelected)
			{
				return;
			}
			this.minSensitivity = 0.1f;
			if (this.rewiredStandaloneInputModule != null)
			{
				if (this.IsMenuAxis(this.menuHorizActionId, this.selectedAxis))
				{
					this.GetAxisButtonDeadZone(this.playerId, this.menuHorizActionId, ref this.minSensitivity);
					return;
				}
				if (this.IsMenuAxis(this.menuVertActionId, this.selectedAxis))
				{
					this.GetAxisButtonDeadZone(this.playerId, this.menuVertActionId, ref this.minSensitivity);
				}
			}
		}

		// Token: 0x06000D96 RID: 3478 RVA: 0x0002F01C File Offset: 0x0002D21C
		private bool IsMenuAxis(int actionId, int axisIndex)
		{
			if (this.rewiredStandaloneInputModule == null)
			{
				return false;
			}
			IList<Player> allPlayers = ReInput.players.AllPlayers;
			int count = allPlayers.Count;
			for (int i = 0; i < count; i++)
			{
				IList<JoystickMap> maps = allPlayers[i].controllers.maps.GetMaps<JoystickMap>(this.joystick.id);
				if (maps != null)
				{
					int count2 = maps.Count;
					for (int j = 0; j < count2; j++)
					{
						IList<ActionElementMap> axisMaps = maps[j].AxisMaps;
						if (axisMaps != null)
						{
							int count3 = axisMaps.Count;
							for (int k = 0; k < count3; k++)
							{
								ActionElementMap actionElementMap = axisMaps[k];
								if (actionElementMap.actionId == actionId && actionElementMap.elementIndex == axisIndex)
								{
									return true;
								}
							}
						}
					}
				}
			}
			return false;
		}

		// Token: 0x06000D97 RID: 3479 RVA: 0x0002F0EC File Offset: 0x0002D2EC
		private void GetAxisButtonDeadZone(int playerId, int actionId, ref float value)
		{
			InputAction action = ReInput.mapping.GetAction(actionId);
			if (action == null)
			{
				return;
			}
			int behaviorId = action.behaviorId;
			InputBehavior inputBehavior = ReInput.mapping.GetInputBehavior(playerId, behaviorId);
			if (inputBehavior == null)
			{
				return;
			}
			value = inputBehavior.buttonDeadZone + 0.1f;
		}

		// Token: 0x06000D98 RID: 3480 RVA: 0x0002F12F File Offset: 0x0002D32F
		private float GetSliderSensitivity(AxisCalibration axisCalibration)
		{
			if (axisCalibration.sensitivityType == AxisSensitivityType.Multiplier)
			{
				return axisCalibration.sensitivity;
			}
			if (axisCalibration.sensitivityType == AxisSensitivityType.Power)
			{
				return CalibrationWindow.ProcessPowerValue(axisCalibration.sensitivity, 0f, this.sensitivitySlider.maxValue);
			}
			return axisCalibration.sensitivity;
		}

		// Token: 0x06000D99 RID: 3481 RVA: 0x0002F16C File Offset: 0x0002D36C
		public void SetSensitivity(AxisCalibration axisCalibration, float sliderValue)
		{
			if (axisCalibration.sensitivityType == AxisSensitivityType.Multiplier)
			{
				axisCalibration.sensitivity = Mathf.Clamp(sliderValue, this.minSensitivity, float.PositiveInfinity);
				if (sliderValue < this.minSensitivity)
				{
					this.sensitivitySlider.value = this.minSensitivity;
					return;
				}
			}
			else
			{
				if (axisCalibration.sensitivityType == AxisSensitivityType.Power)
				{
					axisCalibration.sensitivity = CalibrationWindow.ProcessPowerValue(sliderValue, 0f, this.sensitivitySlider.maxValue);
					return;
				}
				axisCalibration.sensitivity = sliderValue;
			}
		}

		// Token: 0x06000D9A RID: 3482 RVA: 0x0002F1E0 File Offset: 0x0002D3E0
		private static float ProcessPowerValue(float value, float minValue, float maxValue)
		{
			value = Mathf.Clamp(value, minValue, maxValue);
			if (value > 1f)
			{
				value = MathTools.ValueInNewRange(value, 1f, maxValue, 1f, 0f);
			}
			else if (value < 1f)
			{
				value = MathTools.ValueInNewRange(value, 0f, 1f, maxValue, 1f);
			}
			return value;
		}

		// Token: 0x04000955 RID: 2389
		private const float minSensitivityOtherAxes = 0.1f;

		// Token: 0x04000956 RID: 2390
		private const float maxDeadzone = 0.8f;

		// Token: 0x04000957 RID: 2391
		[SerializeField]
		private RectTransform rightContentContainer;

		// Token: 0x04000958 RID: 2392
		[SerializeField]
		private RectTransform valueDisplayGroup;

		// Token: 0x04000959 RID: 2393
		[SerializeField]
		private RectTransform calibratedValueMarker;

		// Token: 0x0400095A RID: 2394
		[SerializeField]
		private RectTransform rawValueMarker;

		// Token: 0x0400095B RID: 2395
		[SerializeField]
		private RectTransform calibratedZeroMarker;

		// Token: 0x0400095C RID: 2396
		[SerializeField]
		private RectTransform deadzoneArea;

		// Token: 0x0400095D RID: 2397
		[SerializeField]
		private Slider deadzoneSlider;

		// Token: 0x0400095E RID: 2398
		[SerializeField]
		private Slider zeroSlider;

		// Token: 0x0400095F RID: 2399
		[SerializeField]
		private Slider sensitivitySlider;

		// Token: 0x04000960 RID: 2400
		[SerializeField]
		private Toggle invertToggle;

		// Token: 0x04000961 RID: 2401
		[SerializeField]
		private RectTransform axisScrollAreaContent;

		// Token: 0x04000962 RID: 2402
		[SerializeField]
		private Button doneButton;

		// Token: 0x04000963 RID: 2403
		[SerializeField]
		private Button calibrateButton;

		// Token: 0x04000964 RID: 2404
		[SerializeField]
		private TMP_Text doneButtonLabel;

		// Token: 0x04000965 RID: 2405
		[SerializeField]
		private TMP_Text cancelButtonLabel;

		// Token: 0x04000966 RID: 2406
		[SerializeField]
		private TMP_Text defaultButtonLabel;

		// Token: 0x04000967 RID: 2407
		[SerializeField]
		private TMP_Text deadzoneSliderLabel;

		// Token: 0x04000968 RID: 2408
		[SerializeField]
		private TMP_Text zeroSliderLabel;

		// Token: 0x04000969 RID: 2409
		[SerializeField]
		private TMP_Text sensitivitySliderLabel;

		// Token: 0x0400096A RID: 2410
		[SerializeField]
		private TMP_Text invertToggleLabel;

		// Token: 0x0400096B RID: 2411
		[SerializeField]
		private TMP_Text calibrateButtonLabel;

		// Token: 0x0400096C RID: 2412
		[SerializeField]
		private GameObject axisButtonPrefab;

		// Token: 0x0400096D RID: 2413
		private Joystick joystick;

		// Token: 0x0400096E RID: 2414
		private string origCalibrationData;

		// Token: 0x0400096F RID: 2415
		private int selectedAxis = -1;

		// Token: 0x04000970 RID: 2416
		private AxisCalibrationData origSelectedAxisCalibrationData;

		// Token: 0x04000971 RID: 2417
		private float displayAreaWidth;

		// Token: 0x04000972 RID: 2418
		private List<Button> axisButtons;

		// Token: 0x04000973 RID: 2419
		private Dictionary<int, Action<int>> buttonCallbacks;

		// Token: 0x04000974 RID: 2420
		private int playerId;

		// Token: 0x04000975 RID: 2421
		private RewiredStandaloneInputModule rewiredStandaloneInputModule;

		// Token: 0x04000976 RID: 2422
		private int menuHorizActionId = -1;

		// Token: 0x04000977 RID: 2423
		private int menuVertActionId = -1;

		// Token: 0x04000978 RID: 2424
		private float minSensitivity;

		// Token: 0x0200024F RID: 591
		public enum ButtonIdentifier
		{
			// Token: 0x04000DBC RID: 3516
			Done,
			// Token: 0x04000DBD RID: 3517
			Cancel,
			// Token: 0x04000DBE RID: 3518
			Default,
			// Token: 0x04000DBF RID: 3519
			Calibrate
		}
	}
}
