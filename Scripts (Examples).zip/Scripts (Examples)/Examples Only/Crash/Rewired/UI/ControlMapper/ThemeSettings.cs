﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000194 RID: 404
	[Serializable]
	public class ThemeSettings : ScriptableObject
	{
		// Token: 0x06000FEB RID: 4075 RVA: 0x000377F8 File Offset: 0x000359F8
		public void Apply(ThemedElement.ElementInfo[] elementInfo)
		{
			if (elementInfo == null)
			{
				return;
			}
			for (int i = 0; i < elementInfo.Length; i++)
			{
				if (elementInfo[i] != null)
				{
					this.Apply(elementInfo[i].themeClass, elementInfo[i].component);
				}
			}
		}

		// Token: 0x06000FEC RID: 4076 RVA: 0x00037834 File Offset: 0x00035A34
		private void Apply(string themeClass, Component component)
		{
			if (component as Selectable != null)
			{
				this.Apply(themeClass, (Selectable)component);
				return;
			}
			if (component as Image != null)
			{
				this.Apply(themeClass, (Image)component);
				return;
			}
			if (component as TMP_Text != null)
			{
				this.Apply(themeClass, (TMP_Text)component);
				return;
			}
			if (component as UIImageHelper != null)
			{
				this.Apply(themeClass, (UIImageHelper)component);
				return;
			}
		}

		// Token: 0x06000FED RID: 4077 RVA: 0x000378B4 File Offset: 0x00035AB4
		private void Apply(string themeClass, Selectable item)
		{
			if (item == null)
			{
				return;
			}
			ThemeSettings.SelectableSettings_Base selectableSettings_Base;
			if (item as Button != null)
			{
				if (themeClass == "inputGridField")
				{
					selectableSettings_Base = this._inputGridFieldSettings;
				}
				else
				{
					selectableSettings_Base = this._buttonSettings;
				}
			}
			else if (item as Scrollbar != null)
			{
				selectableSettings_Base = this._scrollbarSettings;
			}
			else if (item as Slider != null)
			{
				selectableSettings_Base = this._sliderSettings;
			}
			else if (item as Toggle != null)
			{
				if (themeClass == "button")
				{
					selectableSettings_Base = this._buttonSettings;
				}
				else
				{
					selectableSettings_Base = this._selectableSettings;
				}
			}
			else
			{
				selectableSettings_Base = this._selectableSettings;
			}
			selectableSettings_Base.Apply(item);
		}

		// Token: 0x06000FEE RID: 4078 RVA: 0x00037964 File Offset: 0x00035B64
		private void Apply(string themeClass, Image item)
		{
			if (item == null)
			{
				return;
			}
			uint num = <PrivateImplementationDetails>.ComputeStringHash(themeClass);
			if (num <= 2822822017U)
			{
				if (num <= 665291243U)
				{
					if (num != 106194061U)
					{
						if (num != 283896133U)
						{
							if (num != 665291243U)
							{
								return;
							}
							if (!(themeClass == "calibrationBackground"))
							{
								return;
							}
							if (this._calibrationBackground != null)
							{
								this._calibrationBackground.CopyTo(item);
								return;
							}
						}
						else
						{
							if (!(themeClass == "popupWindow"))
							{
								return;
							}
							if (this._popupWindowBackground != null)
							{
								this._popupWindowBackground.CopyTo(item);
								return;
							}
						}
					}
					else
					{
						if (!(themeClass == "invertToggleButtonBackground"))
						{
							return;
						}
						if (this._buttonSettings != null)
						{
							this._buttonSettings.imageSettings.CopyTo(item);
						}
					}
				}
				else if (num != 2579191547U)
				{
					if (num != 2601460036U)
					{
						if (num != 2822822017U)
						{
							return;
						}
						if (!(themeClass == "invertToggle"))
						{
							return;
						}
						if (this._invertToggle != null)
						{
							this._invertToggle.CopyTo(item);
							return;
						}
					}
					else
					{
						if (!(themeClass == "area"))
						{
							return;
						}
						if (this._areaBackground != null)
						{
							this._areaBackground.CopyTo(item);
							return;
						}
					}
				}
				else
				{
					if (!(themeClass == "calibrationDeadzone"))
					{
						return;
					}
					if (this._calibrationDeadzone != null)
					{
						this._calibrationDeadzone.CopyTo(item);
						return;
					}
				}
			}
			else if (num <= 3490313510U)
			{
				if (num != 2998767316U)
				{
					if (num != 3338297968U)
					{
						if (num != 3490313510U)
						{
							return;
						}
						if (!(themeClass == "calibrationRawValueMarker"))
						{
							return;
						}
						if (this._calibrationRawValueMarker != null)
						{
							this._calibrationRawValueMarker.CopyTo(item);
							return;
						}
					}
					else
					{
						if (!(themeClass == "calibrationCalibratedZeroMarker"))
						{
							return;
						}
						if (this._calibrationCalibratedZeroMarker != null)
						{
							this._calibrationCalibratedZeroMarker.CopyTo(item);
							return;
						}
					}
				}
				else
				{
					if (!(themeClass == "mainWindow"))
					{
						return;
					}
					if (this._mainWindowBackground != null)
					{
						this._mainWindowBackground.CopyTo(item);
						return;
					}
				}
			}
			else if (num != 3776179782U)
			{
				if (num != 3836396811U)
				{
					if (num != 3911450241U)
					{
						return;
					}
					if (!(themeClass == "invertToggleBackground"))
					{
						return;
					}
					if (this._inputGridFieldSettings != null)
					{
						this._inputGridFieldSettings.imageSettings.CopyTo(item);
						return;
					}
				}
				else
				{
					if (!(themeClass == "calibrationZeroMarker"))
					{
						return;
					}
					if (this._calibrationZeroMarker != null)
					{
						this._calibrationZeroMarker.CopyTo(item);
						return;
					}
				}
			}
			else
			{
				if (!(themeClass == "calibrationValueMarker"))
				{
					return;
				}
				if (this._calibrationValueMarker != null)
				{
					this._calibrationValueMarker.CopyTo(item);
					return;
				}
			}
		}

		// Token: 0x06000FEF RID: 4079 RVA: 0x00037BF4 File Offset: 0x00035DF4
		private void Apply(string themeClass, TMP_Text item)
		{
			if (item == null)
			{
				return;
			}
			ThemeSettings.TextSettings textSettings;
			if (!(themeClass == "button"))
			{
				if (!(themeClass == "inputGridField"))
				{
					textSettings = this._textSettings;
				}
				else
				{
					textSettings = this._inputGridFieldTextSettings;
				}
			}
			else
			{
				textSettings = this._buttonTextSettings;
			}
			if (textSettings.font != null)
			{
				item.font = textSettings.font;
			}
			item.color = textSettings.color;
			item.lineSpacing = textSettings.lineSpacing;
			if (textSettings.sizeMultiplier != 1f)
			{
				item.fontSize = (float)((int)(item.fontSize * textSettings.sizeMultiplier));
				item.fontSizeMax = (float)((int)(item.fontSizeMax * textSettings.sizeMultiplier));
				item.fontSizeMin = (float)((int)(item.fontSizeMin * textSettings.sizeMultiplier));
			}
			item.characterSpacing = textSettings.chracterSpacing;
			item.wordSpacing = textSettings.wordSpacing;
			if (textSettings.style != ThemeSettings.FontStyleOverride.Default)
			{
				item.fontStyle = ThemeSettings.GetFontStyle(textSettings.style);
			}
		}

		// Token: 0x06000FF0 RID: 4080 RVA: 0x00037CEF File Offset: 0x00035EEF
		private void Apply(string themeClass, UIImageHelper item)
		{
			if (item == null)
			{
				return;
			}
			item.SetEnabledStateColor(this._invertToggle.color);
			item.SetDisabledStateColor(this._invertToggleDisabledColor);
			item.Refresh();
		}

		// Token: 0x06000FF1 RID: 4081 RVA: 0x00037D1E File Offset: 0x00035F1E
		private static FontStyles GetFontStyle(ThemeSettings.FontStyleOverride style)
		{
			switch (style)
			{
			case ThemeSettings.FontStyleOverride.Default:
			case ThemeSettings.FontStyleOverride.Normal:
				return FontStyles.Normal;
			case ThemeSettings.FontStyleOverride.Bold:
				return FontStyles.Bold;
			case ThemeSettings.FontStyleOverride.Italic:
				return FontStyles.Italic;
			case ThemeSettings.FontStyleOverride.BoldAndItalic:
				return FontStyles.Bold | FontStyles.Italic;
			default:
				throw new NotImplementedException();
			}
		}

		// Token: 0x04000A59 RID: 2649
		[SerializeField]
		private ThemeSettings.ImageSettings _mainWindowBackground;

		// Token: 0x04000A5A RID: 2650
		[SerializeField]
		private ThemeSettings.ImageSettings _popupWindowBackground;

		// Token: 0x04000A5B RID: 2651
		[SerializeField]
		private ThemeSettings.ImageSettings _areaBackground;

		// Token: 0x04000A5C RID: 2652
		[SerializeField]
		private ThemeSettings.SelectableSettings _selectableSettings;

		// Token: 0x04000A5D RID: 2653
		[SerializeField]
		private ThemeSettings.SelectableSettings _buttonSettings;

		// Token: 0x04000A5E RID: 2654
		[SerializeField]
		private ThemeSettings.SelectableSettings _inputGridFieldSettings;

		// Token: 0x04000A5F RID: 2655
		[SerializeField]
		private ThemeSettings.ScrollbarSettings _scrollbarSettings;

		// Token: 0x04000A60 RID: 2656
		[SerializeField]
		private ThemeSettings.SliderSettings _sliderSettings;

		// Token: 0x04000A61 RID: 2657
		[SerializeField]
		private ThemeSettings.ImageSettings _invertToggle;

		// Token: 0x04000A62 RID: 2658
		[SerializeField]
		private Color _invertToggleDisabledColor;

		// Token: 0x04000A63 RID: 2659
		[SerializeField]
		private ThemeSettings.ImageSettings _calibrationBackground;

		// Token: 0x04000A64 RID: 2660
		[SerializeField]
		private ThemeSettings.ImageSettings _calibrationValueMarker;

		// Token: 0x04000A65 RID: 2661
		[SerializeField]
		private ThemeSettings.ImageSettings _calibrationRawValueMarker;

		// Token: 0x04000A66 RID: 2662
		[SerializeField]
		private ThemeSettings.ImageSettings _calibrationZeroMarker;

		// Token: 0x04000A67 RID: 2663
		[SerializeField]
		private ThemeSettings.ImageSettings _calibrationCalibratedZeroMarker;

		// Token: 0x04000A68 RID: 2664
		[SerializeField]
		private ThemeSettings.ImageSettings _calibrationDeadzone;

		// Token: 0x04000A69 RID: 2665
		[SerializeField]
		private ThemeSettings.TextSettings _textSettings;

		// Token: 0x04000A6A RID: 2666
		[SerializeField]
		private ThemeSettings.TextSettings _buttonTextSettings;

		// Token: 0x04000A6B RID: 2667
		[SerializeField]
		private ThemeSettings.TextSettings _inputGridFieldTextSettings;

		// Token: 0x02000273 RID: 627
		[Serializable]
		private abstract class SelectableSettings_Base
		{
			// Token: 0x1700056F RID: 1391
			// (get) Token: 0x06001597 RID: 5527 RVA: 0x00049611 File Offset: 0x00047811
			public Selectable.Transition transition
			{
				get
				{
					return this._transition;
				}
			}

			// Token: 0x17000570 RID: 1392
			// (get) Token: 0x06001598 RID: 5528 RVA: 0x00049619 File Offset: 0x00047819
			public ThemeSettings.CustomColorBlock selectableColors
			{
				get
				{
					return this._colors;
				}
			}

			// Token: 0x17000571 RID: 1393
			// (get) Token: 0x06001599 RID: 5529 RVA: 0x00049621 File Offset: 0x00047821
			public ThemeSettings.CustomSpriteState spriteState
			{
				get
				{
					return this._spriteState;
				}
			}

			// Token: 0x17000572 RID: 1394
			// (get) Token: 0x0600159A RID: 5530 RVA: 0x00049629 File Offset: 0x00047829
			public ThemeSettings.CustomAnimationTriggers animationTriggers
			{
				get
				{
					return this._animationTriggers;
				}
			}

			// Token: 0x0600159B RID: 5531 RVA: 0x00049634 File Offset: 0x00047834
			public virtual void Apply(Selectable item)
			{
				Selectable.Transition transition = this._transition;
				bool flag = item.transition != transition;
				item.transition = transition;
				ICustomSelectable customSelectable = item as ICustomSelectable;
				if (transition == Selectable.Transition.ColorTint)
				{
					ThemeSettings.CustomColorBlock colors = this._colors;
					colors.fadeDuration = 0f;
					item.colors = colors;
					colors.fadeDuration = this._colors.fadeDuration;
					item.colors = colors;
					if (customSelectable != null)
					{
						customSelectable.disabledHighlightedColor = colors.disabledHighlightedColor;
					}
				}
				else if (transition == Selectable.Transition.SpriteSwap)
				{
					item.spriteState = this._spriteState;
					if (customSelectable != null)
					{
						customSelectable.disabledHighlightedSprite = this._spriteState.disabledHighlightedSprite;
					}
				}
				else if (transition == Selectable.Transition.Animation)
				{
					item.animationTriggers.disabledTrigger = this._animationTriggers.disabledTrigger;
					item.animationTriggers.highlightedTrigger = this._animationTriggers.highlightedTrigger;
					item.animationTriggers.normalTrigger = this._animationTriggers.normalTrigger;
					item.animationTriggers.pressedTrigger = this._animationTriggers.pressedTrigger;
					if (customSelectable != null)
					{
						customSelectable.disabledHighlightedTrigger = this._animationTriggers.disabledHighlightedTrigger;
					}
				}
				if (flag)
				{
					item.targetGraphic.CrossFadeColor(item.targetGraphic.color, 0f, true, true);
				}
			}

			// Token: 0x04000E78 RID: 3704
			[SerializeField]
			protected Selectable.Transition _transition;

			// Token: 0x04000E79 RID: 3705
			[SerializeField]
			protected ThemeSettings.CustomColorBlock _colors;

			// Token: 0x04000E7A RID: 3706
			[SerializeField]
			protected ThemeSettings.CustomSpriteState _spriteState;

			// Token: 0x04000E7B RID: 3707
			[SerializeField]
			protected ThemeSettings.CustomAnimationTriggers _animationTriggers;
		}

		// Token: 0x02000274 RID: 628
		[Serializable]
		private class SelectableSettings : ThemeSettings.SelectableSettings_Base
		{
			// Token: 0x17000573 RID: 1395
			// (get) Token: 0x0600159D RID: 5533 RVA: 0x00049780 File Offset: 0x00047980
			public ThemeSettings.ImageSettings imageSettings
			{
				get
				{
					return this._imageSettings;
				}
			}

			// Token: 0x0600159E RID: 5534 RVA: 0x00049788 File Offset: 0x00047988
			public override void Apply(Selectable item)
			{
				if (item == null)
				{
					return;
				}
				base.Apply(item);
				if (this._imageSettings != null)
				{
					this._imageSettings.CopyTo(item.targetGraphic as Image);
				}
			}

			// Token: 0x04000E7C RID: 3708
			[SerializeField]
			private ThemeSettings.ImageSettings _imageSettings;
		}

		// Token: 0x02000275 RID: 629
		[Serializable]
		private class SliderSettings : ThemeSettings.SelectableSettings_Base
		{
			// Token: 0x17000574 RID: 1396
			// (get) Token: 0x060015A0 RID: 5536 RVA: 0x000497C1 File Offset: 0x000479C1
			public ThemeSettings.ImageSettings handleImageSettings
			{
				get
				{
					return this._handleImageSettings;
				}
			}

			// Token: 0x17000575 RID: 1397
			// (get) Token: 0x060015A1 RID: 5537 RVA: 0x000497C9 File Offset: 0x000479C9
			public ThemeSettings.ImageSettings fillImageSettings
			{
				get
				{
					return this._fillImageSettings;
				}
			}

			// Token: 0x17000576 RID: 1398
			// (get) Token: 0x060015A2 RID: 5538 RVA: 0x000497D1 File Offset: 0x000479D1
			public ThemeSettings.ImageSettings backgroundImageSettings
			{
				get
				{
					return this._backgroundImageSettings;
				}
			}

			// Token: 0x060015A3 RID: 5539 RVA: 0x000497DC File Offset: 0x000479DC
			private void Apply(Slider item)
			{
				if (item == null)
				{
					return;
				}
				if (this._handleImageSettings != null)
				{
					this._handleImageSettings.CopyTo(item.targetGraphic as Image);
				}
				if (this._fillImageSettings != null)
				{
					RectTransform fillRect = item.fillRect;
					if (fillRect != null)
					{
						this._fillImageSettings.CopyTo(fillRect.GetComponent<Image>());
					}
				}
				if (this._backgroundImageSettings != null)
				{
					Transform transform = item.transform.Find("Background");
					if (transform != null)
					{
						this._backgroundImageSettings.CopyTo(transform.GetComponent<Image>());
					}
				}
			}

			// Token: 0x060015A4 RID: 5540 RVA: 0x0004986D File Offset: 0x00047A6D
			public override void Apply(Selectable item)
			{
				base.Apply(item);
				this.Apply(item as Slider);
			}

			// Token: 0x04000E7D RID: 3709
			[SerializeField]
			private ThemeSettings.ImageSettings _handleImageSettings;

			// Token: 0x04000E7E RID: 3710
			[SerializeField]
			private ThemeSettings.ImageSettings _fillImageSettings;

			// Token: 0x04000E7F RID: 3711
			[SerializeField]
			private ThemeSettings.ImageSettings _backgroundImageSettings;
		}

		// Token: 0x02000276 RID: 630
		[Serializable]
		private class ScrollbarSettings : ThemeSettings.SelectableSettings_Base
		{
			// Token: 0x17000577 RID: 1399
			// (get) Token: 0x060015A6 RID: 5542 RVA: 0x0004988A File Offset: 0x00047A8A
			public ThemeSettings.ImageSettings handle
			{
				get
				{
					return this._handleImageSettings;
				}
			}

			// Token: 0x17000578 RID: 1400
			// (get) Token: 0x060015A7 RID: 5543 RVA: 0x00049892 File Offset: 0x00047A92
			public ThemeSettings.ImageSettings background
			{
				get
				{
					return this._backgroundImageSettings;
				}
			}

			// Token: 0x060015A8 RID: 5544 RVA: 0x0004989C File Offset: 0x00047A9C
			private void Apply(Scrollbar item)
			{
				if (item == null)
				{
					return;
				}
				if (this._handleImageSettings != null)
				{
					this._handleImageSettings.CopyTo(item.targetGraphic as Image);
				}
				if (this._backgroundImageSettings != null)
				{
					this._backgroundImageSettings.CopyTo(item.GetComponent<Image>());
				}
			}

			// Token: 0x060015A9 RID: 5545 RVA: 0x000498EA File Offset: 0x00047AEA
			public override void Apply(Selectable item)
			{
				base.Apply(item);
				this.Apply(item as Scrollbar);
			}

			// Token: 0x04000E80 RID: 3712
			[SerializeField]
			private ThemeSettings.ImageSettings _handleImageSettings;

			// Token: 0x04000E81 RID: 3713
			[SerializeField]
			private ThemeSettings.ImageSettings _backgroundImageSettings;
		}

		// Token: 0x02000277 RID: 631
		[Serializable]
		private class ImageSettings
		{
			// Token: 0x17000579 RID: 1401
			// (get) Token: 0x060015AB RID: 5547 RVA: 0x00049907 File Offset: 0x00047B07
			public Color color
			{
				get
				{
					return this._color;
				}
			}

			// Token: 0x1700057A RID: 1402
			// (get) Token: 0x060015AC RID: 5548 RVA: 0x0004990F File Offset: 0x00047B0F
			public Sprite sprite
			{
				get
				{
					return this._sprite;
				}
			}

			// Token: 0x1700057B RID: 1403
			// (get) Token: 0x060015AD RID: 5549 RVA: 0x00049917 File Offset: 0x00047B17
			public Material materal
			{
				get
				{
					return this._materal;
				}
			}

			// Token: 0x1700057C RID: 1404
			// (get) Token: 0x060015AE RID: 5550 RVA: 0x0004991F File Offset: 0x00047B1F
			public Image.Type type
			{
				get
				{
					return this._type;
				}
			}

			// Token: 0x1700057D RID: 1405
			// (get) Token: 0x060015AF RID: 5551 RVA: 0x00049927 File Offset: 0x00047B27
			public bool preserveAspect
			{
				get
				{
					return this._preserveAspect;
				}
			}

			// Token: 0x1700057E RID: 1406
			// (get) Token: 0x060015B0 RID: 5552 RVA: 0x0004992F File Offset: 0x00047B2F
			public bool fillCenter
			{
				get
				{
					return this._fillCenter;
				}
			}

			// Token: 0x1700057F RID: 1407
			// (get) Token: 0x060015B1 RID: 5553 RVA: 0x00049937 File Offset: 0x00047B37
			public Image.FillMethod fillMethod
			{
				get
				{
					return this._fillMethod;
				}
			}

			// Token: 0x17000580 RID: 1408
			// (get) Token: 0x060015B2 RID: 5554 RVA: 0x0004993F File Offset: 0x00047B3F
			public float fillAmout
			{
				get
				{
					return this._fillAmout;
				}
			}

			// Token: 0x17000581 RID: 1409
			// (get) Token: 0x060015B3 RID: 5555 RVA: 0x00049947 File Offset: 0x00047B47
			public bool fillClockwise
			{
				get
				{
					return this._fillClockwise;
				}
			}

			// Token: 0x17000582 RID: 1410
			// (get) Token: 0x060015B4 RID: 5556 RVA: 0x0004994F File Offset: 0x00047B4F
			public int fillOrigin
			{
				get
				{
					return this._fillOrigin;
				}
			}

			// Token: 0x060015B5 RID: 5557 RVA: 0x00049958 File Offset: 0x00047B58
			public virtual void CopyTo(Image image)
			{
				if (image == null)
				{
					return;
				}
				image.color = this._color;
				image.sprite = this._sprite;
				image.material = this._materal;
				image.type = this._type;
				image.preserveAspect = this._preserveAspect;
				image.fillCenter = this._fillCenter;
				image.fillMethod = this._fillMethod;
				image.fillAmount = this._fillAmout;
				image.fillClockwise = this._fillClockwise;
				image.fillOrigin = this._fillOrigin;
			}

			// Token: 0x04000E82 RID: 3714
			[SerializeField]
			private Color _color = Color.white;

			// Token: 0x04000E83 RID: 3715
			[SerializeField]
			private Sprite _sprite;

			// Token: 0x04000E84 RID: 3716
			[SerializeField]
			private Material _materal;

			// Token: 0x04000E85 RID: 3717
			[SerializeField]
			private Image.Type _type;

			// Token: 0x04000E86 RID: 3718
			[SerializeField]
			private bool _preserveAspect;

			// Token: 0x04000E87 RID: 3719
			[SerializeField]
			private bool _fillCenter;

			// Token: 0x04000E88 RID: 3720
			[SerializeField]
			private Image.FillMethod _fillMethod;

			// Token: 0x04000E89 RID: 3721
			[SerializeField]
			private float _fillAmout;

			// Token: 0x04000E8A RID: 3722
			[SerializeField]
			private bool _fillClockwise;

			// Token: 0x04000E8B RID: 3723
			[SerializeField]
			private int _fillOrigin;
		}

		// Token: 0x02000278 RID: 632
		[Serializable]
		private struct CustomColorBlock
		{
			// Token: 0x17000583 RID: 1411
			// (get) Token: 0x060015B7 RID: 5559 RVA: 0x000499FA File Offset: 0x00047BFA
			// (set) Token: 0x060015B8 RID: 5560 RVA: 0x00049A02 File Offset: 0x00047C02
			public float colorMultiplier
			{
				get
				{
					return this.m_ColorMultiplier;
				}
				set
				{
					this.m_ColorMultiplier = value;
				}
			}

			// Token: 0x17000584 RID: 1412
			// (get) Token: 0x060015B9 RID: 5561 RVA: 0x00049A0B File Offset: 0x00047C0B
			// (set) Token: 0x060015BA RID: 5562 RVA: 0x00049A13 File Offset: 0x00047C13
			public Color disabledColor
			{
				get
				{
					return this.m_DisabledColor;
				}
				set
				{
					this.m_DisabledColor = value;
				}
			}

			// Token: 0x17000585 RID: 1413
			// (get) Token: 0x060015BB RID: 5563 RVA: 0x00049A1C File Offset: 0x00047C1C
			// (set) Token: 0x060015BC RID: 5564 RVA: 0x00049A24 File Offset: 0x00047C24
			public float fadeDuration
			{
				get
				{
					return this.m_FadeDuration;
				}
				set
				{
					this.m_FadeDuration = value;
				}
			}

			// Token: 0x17000586 RID: 1414
			// (get) Token: 0x060015BD RID: 5565 RVA: 0x00049A2D File Offset: 0x00047C2D
			// (set) Token: 0x060015BE RID: 5566 RVA: 0x00049A35 File Offset: 0x00047C35
			public Color highlightedColor
			{
				get
				{
					return this.m_HighlightedColor;
				}
				set
				{
					this.m_HighlightedColor = value;
				}
			}

			// Token: 0x17000587 RID: 1415
			// (get) Token: 0x060015BF RID: 5567 RVA: 0x00049A3E File Offset: 0x00047C3E
			// (set) Token: 0x060015C0 RID: 5568 RVA: 0x00049A46 File Offset: 0x00047C46
			public Color normalColor
			{
				get
				{
					return this.m_NormalColor;
				}
				set
				{
					this.m_NormalColor = value;
				}
			}

			// Token: 0x17000588 RID: 1416
			// (get) Token: 0x060015C1 RID: 5569 RVA: 0x00049A4F File Offset: 0x00047C4F
			// (set) Token: 0x060015C2 RID: 5570 RVA: 0x00049A57 File Offset: 0x00047C57
			public Color pressedColor
			{
				get
				{
					return this.m_PressedColor;
				}
				set
				{
					this.m_PressedColor = value;
				}
			}

			// Token: 0x17000589 RID: 1417
			// (get) Token: 0x060015C3 RID: 5571 RVA: 0x00049A60 File Offset: 0x00047C60
			// (set) Token: 0x060015C4 RID: 5572 RVA: 0x00049A68 File Offset: 0x00047C68
			public Color selectedColor
			{
				get
				{
					return this.m_SelectedColor;
				}
				set
				{
					this.m_SelectedColor = value;
				}
			}

			// Token: 0x1700058A RID: 1418
			// (get) Token: 0x060015C5 RID: 5573 RVA: 0x00049A71 File Offset: 0x00047C71
			// (set) Token: 0x060015C6 RID: 5574 RVA: 0x00049A79 File Offset: 0x00047C79
			public Color disabledHighlightedColor
			{
				get
				{
					return this.m_DisabledHighlightedColor;
				}
				set
				{
					this.m_DisabledHighlightedColor = value;
				}
			}

			// Token: 0x060015C7 RID: 5575 RVA: 0x00049A84 File Offset: 0x00047C84
			public static implicit operator ColorBlock(ThemeSettings.CustomColorBlock item)
			{
				return new ColorBlock
				{
					selectedColor = item.m_SelectedColor,
					colorMultiplier = item.m_ColorMultiplier,
					disabledColor = item.m_DisabledColor,
					fadeDuration = item.m_FadeDuration,
					highlightedColor = item.m_HighlightedColor,
					normalColor = item.m_NormalColor,
					pressedColor = item.m_PressedColor
				};
			}

			// Token: 0x04000E8C RID: 3724
			[SerializeField]
			private float m_ColorMultiplier;

			// Token: 0x04000E8D RID: 3725
			[SerializeField]
			private Color m_DisabledColor;

			// Token: 0x04000E8E RID: 3726
			[SerializeField]
			private float m_FadeDuration;

			// Token: 0x04000E8F RID: 3727
			[SerializeField]
			private Color m_HighlightedColor;

			// Token: 0x04000E90 RID: 3728
			[SerializeField]
			private Color m_NormalColor;

			// Token: 0x04000E91 RID: 3729
			[SerializeField]
			private Color m_PressedColor;

			// Token: 0x04000E92 RID: 3730
			[SerializeField]
			private Color m_SelectedColor;

			// Token: 0x04000E93 RID: 3731
			[SerializeField]
			private Color m_DisabledHighlightedColor;
		}

		// Token: 0x02000279 RID: 633
		[Serializable]
		private struct CustomSpriteState
		{
			// Token: 0x1700058B RID: 1419
			// (get) Token: 0x060015C8 RID: 5576 RVA: 0x00049AF5 File Offset: 0x00047CF5
			// (set) Token: 0x060015C9 RID: 5577 RVA: 0x00049AFD File Offset: 0x00047CFD
			public Sprite disabledSprite
			{
				get
				{
					return this.m_DisabledSprite;
				}
				set
				{
					this.m_DisabledSprite = value;
				}
			}

			// Token: 0x1700058C RID: 1420
			// (get) Token: 0x060015CA RID: 5578 RVA: 0x00049B06 File Offset: 0x00047D06
			// (set) Token: 0x060015CB RID: 5579 RVA: 0x00049B0E File Offset: 0x00047D0E
			public Sprite highlightedSprite
			{
				get
				{
					return this.m_HighlightedSprite;
				}
				set
				{
					this.m_HighlightedSprite = value;
				}
			}

			// Token: 0x1700058D RID: 1421
			// (get) Token: 0x060015CC RID: 5580 RVA: 0x00049B17 File Offset: 0x00047D17
			// (set) Token: 0x060015CD RID: 5581 RVA: 0x00049B1F File Offset: 0x00047D1F
			public Sprite pressedSprite
			{
				get
				{
					return this.m_PressedSprite;
				}
				set
				{
					this.m_PressedSprite = value;
				}
			}

			// Token: 0x1700058E RID: 1422
			// (get) Token: 0x060015CE RID: 5582 RVA: 0x00049B28 File Offset: 0x00047D28
			// (set) Token: 0x060015CF RID: 5583 RVA: 0x00049B30 File Offset: 0x00047D30
			public Sprite selectedSprite
			{
				get
				{
					return this.m_SelectedSprite;
				}
				set
				{
					this.m_SelectedSprite = value;
				}
			}

			// Token: 0x1700058F RID: 1423
			// (get) Token: 0x060015D0 RID: 5584 RVA: 0x00049B39 File Offset: 0x00047D39
			// (set) Token: 0x060015D1 RID: 5585 RVA: 0x00049B41 File Offset: 0x00047D41
			public Sprite disabledHighlightedSprite
			{
				get
				{
					return this.m_DisabledHighlightedSprite;
				}
				set
				{
					this.m_DisabledHighlightedSprite = value;
				}
			}

			// Token: 0x060015D2 RID: 5586 RVA: 0x00049B4C File Offset: 0x00047D4C
			public static implicit operator SpriteState(ThemeSettings.CustomSpriteState item)
			{
				return new SpriteState
				{
					selectedSprite = item.m_SelectedSprite,
					disabledSprite = item.m_DisabledSprite,
					highlightedSprite = item.m_HighlightedSprite,
					pressedSprite = item.m_PressedSprite
				};
			}

			// Token: 0x04000E94 RID: 3732
			[SerializeField]
			private Sprite m_DisabledSprite;

			// Token: 0x04000E95 RID: 3733
			[SerializeField]
			private Sprite m_HighlightedSprite;

			// Token: 0x04000E96 RID: 3734
			[SerializeField]
			private Sprite m_PressedSprite;

			// Token: 0x04000E97 RID: 3735
			[SerializeField]
			private Sprite m_SelectedSprite;

			// Token: 0x04000E98 RID: 3736
			[SerializeField]
			private Sprite m_DisabledHighlightedSprite;
		}

		// Token: 0x0200027A RID: 634
		[Serializable]
		private class CustomAnimationTriggers
		{
			// Token: 0x060015D3 RID: 5587 RVA: 0x00049B98 File Offset: 0x00047D98
			public CustomAnimationTriggers()
			{
				this.m_DisabledTrigger = string.Empty;
				this.m_HighlightedTrigger = string.Empty;
				this.m_NormalTrigger = string.Empty;
				this.m_PressedTrigger = string.Empty;
				this.m_SelectedTrigger = string.Empty;
				this.m_DisabledHighlightedTrigger = string.Empty;
			}

			// Token: 0x17000590 RID: 1424
			// (get) Token: 0x060015D4 RID: 5588 RVA: 0x00049BED File Offset: 0x00047DED
			// (set) Token: 0x060015D5 RID: 5589 RVA: 0x00049BF5 File Offset: 0x00047DF5
			public string disabledTrigger
			{
				get
				{
					return this.m_DisabledTrigger;
				}
				set
				{
					this.m_DisabledTrigger = value;
				}
			}

			// Token: 0x17000591 RID: 1425
			// (get) Token: 0x060015D6 RID: 5590 RVA: 0x00049BFE File Offset: 0x00047DFE
			// (set) Token: 0x060015D7 RID: 5591 RVA: 0x00049C06 File Offset: 0x00047E06
			public string highlightedTrigger
			{
				get
				{
					return this.m_HighlightedTrigger;
				}
				set
				{
					this.m_HighlightedTrigger = value;
				}
			}

			// Token: 0x17000592 RID: 1426
			// (get) Token: 0x060015D8 RID: 5592 RVA: 0x00049C0F File Offset: 0x00047E0F
			// (set) Token: 0x060015D9 RID: 5593 RVA: 0x00049C17 File Offset: 0x00047E17
			public string normalTrigger
			{
				get
				{
					return this.m_NormalTrigger;
				}
				set
				{
					this.m_NormalTrigger = value;
				}
			}

			// Token: 0x17000593 RID: 1427
			// (get) Token: 0x060015DA RID: 5594 RVA: 0x00049C20 File Offset: 0x00047E20
			// (set) Token: 0x060015DB RID: 5595 RVA: 0x00049C28 File Offset: 0x00047E28
			public string pressedTrigger
			{
				get
				{
					return this.m_PressedTrigger;
				}
				set
				{
					this.m_PressedTrigger = value;
				}
			}

			// Token: 0x17000594 RID: 1428
			// (get) Token: 0x060015DC RID: 5596 RVA: 0x00049C31 File Offset: 0x00047E31
			// (set) Token: 0x060015DD RID: 5597 RVA: 0x00049C39 File Offset: 0x00047E39
			public string selectedTrigger
			{
				get
				{
					return this.m_SelectedTrigger;
				}
				set
				{
					this.m_SelectedTrigger = value;
				}
			}

			// Token: 0x17000595 RID: 1429
			// (get) Token: 0x060015DE RID: 5598 RVA: 0x00049C42 File Offset: 0x00047E42
			// (set) Token: 0x060015DF RID: 5599 RVA: 0x00049C4A File Offset: 0x00047E4A
			public string disabledHighlightedTrigger
			{
				get
				{
					return this.m_DisabledHighlightedTrigger;
				}
				set
				{
					this.m_DisabledHighlightedTrigger = value;
				}
			}

			// Token: 0x060015E0 RID: 5600 RVA: 0x00049C54 File Offset: 0x00047E54
			public static implicit operator AnimationTriggers(ThemeSettings.CustomAnimationTriggers item)
			{
				return new AnimationTriggers
				{
					selectedTrigger = item.m_SelectedTrigger,
					disabledTrigger = item.m_DisabledTrigger,
					highlightedTrigger = item.m_HighlightedTrigger,
					normalTrigger = item.m_NormalTrigger,
					pressedTrigger = item.m_PressedTrigger
				};
			}

			// Token: 0x04000E99 RID: 3737
			[SerializeField]
			private string m_DisabledTrigger;

			// Token: 0x04000E9A RID: 3738
			[SerializeField]
			private string m_HighlightedTrigger;

			// Token: 0x04000E9B RID: 3739
			[SerializeField]
			private string m_NormalTrigger;

			// Token: 0x04000E9C RID: 3740
			[SerializeField]
			private string m_PressedTrigger;

			// Token: 0x04000E9D RID: 3741
			[SerializeField]
			private string m_SelectedTrigger;

			// Token: 0x04000E9E RID: 3742
			[SerializeField]
			private string m_DisabledHighlightedTrigger;
		}

		// Token: 0x0200027B RID: 635
		[Serializable]
		private class TextSettings
		{
			// Token: 0x17000596 RID: 1430
			// (get) Token: 0x060015E1 RID: 5601 RVA: 0x00049CA2 File Offset: 0x00047EA2
			public Color color
			{
				get
				{
					return this._color;
				}
			}

			// Token: 0x17000597 RID: 1431
			// (get) Token: 0x060015E2 RID: 5602 RVA: 0x00049CAA File Offset: 0x00047EAA
			public TMP_FontAsset font
			{
				get
				{
					return this._font;
				}
			}

			// Token: 0x17000598 RID: 1432
			// (get) Token: 0x060015E3 RID: 5603 RVA: 0x00049CB2 File Offset: 0x00047EB2
			public ThemeSettings.FontStyleOverride style
			{
				get
				{
					return this._style;
				}
			}

			// Token: 0x17000599 RID: 1433
			// (get) Token: 0x060015E4 RID: 5604 RVA: 0x00049CBA File Offset: 0x00047EBA
			public float sizeMultiplier
			{
				get
				{
					return this._sizeMultiplier;
				}
			}

			// Token: 0x1700059A RID: 1434
			// (get) Token: 0x060015E5 RID: 5605 RVA: 0x00049CC2 File Offset: 0x00047EC2
			public float lineSpacing
			{
				get
				{
					return this._lineSpacing;
				}
			}

			// Token: 0x1700059B RID: 1435
			// (get) Token: 0x060015E6 RID: 5606 RVA: 0x00049CCA File Offset: 0x00047ECA
			public float chracterSpacing
			{
				get
				{
					return this._characterSpacing;
				}
			}

			// Token: 0x1700059C RID: 1436
			// (get) Token: 0x060015E7 RID: 5607 RVA: 0x00049CD2 File Offset: 0x00047ED2
			public float wordSpacing
			{
				get
				{
					return this._wordSpacing;
				}
			}

			// Token: 0x04000E9F RID: 3743
			[SerializeField]
			private Color _color = Color.white;

			// Token: 0x04000EA0 RID: 3744
			[SerializeField]
			private TMP_FontAsset _font;

			// Token: 0x04000EA1 RID: 3745
			[SerializeField]
			private ThemeSettings.FontStyleOverride _style;

			// Token: 0x04000EA2 RID: 3746
			[SerializeField]
			private float _sizeMultiplier = 1f;

			// Token: 0x04000EA3 RID: 3747
			[SerializeField]
			private float _lineSpacing = 1f;

			// Token: 0x04000EA4 RID: 3748
			[SerializeField]
			private float _characterSpacing = 1f;

			// Token: 0x04000EA5 RID: 3749
			[SerializeField]
			private float _wordSpacing = 1f;
		}

		// Token: 0x0200027C RID: 636
		private enum FontStyleOverride
		{
			// Token: 0x04000EA7 RID: 3751
			Default,
			// Token: 0x04000EA8 RID: 3752
			Normal,
			// Token: 0x04000EA9 RID: 3753
			Bold,
			// Token: 0x04000EAA RID: 3754
			Italic,
			// Token: 0x04000EAB RID: 3755
			BoldAndItalic
		}
	}
}
