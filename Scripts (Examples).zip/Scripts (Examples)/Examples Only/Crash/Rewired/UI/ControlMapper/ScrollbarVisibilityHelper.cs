﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000191 RID: 401
	[AddComponentMenu("")]
	public class ScrollbarVisibilityHelper : MonoBehaviour
	{
		// Token: 0x04000A53 RID: 2643
		public ScrollRect scrollRect;
	}
}
