﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000185 RID: 389
	[AddComponentMenu("")]
	public class CanvasScalerExt : CanvasScaler
	{
		// Token: 0x06000D9C RID: 3484 RVA: 0x0002F257 File Offset: 0x0002D457
		public void ForceRefresh()
		{
			this.Handle();
		}
	}
}
