﻿using System;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000195 RID: 405
	[AddComponentMenu("")]
	public class ToggleInfo : InputFieldInfo
	{
	}
}
