﻿using System;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000193 RID: 403
	[AddComponentMenu("")]
	public class ThemedElement : MonoBehaviour
	{
		// Token: 0x06000FE9 RID: 4073 RVA: 0x000377E0 File Offset: 0x000359E0
		private void Start()
		{
			ControlMapper.ApplyTheme(this._elements);
		}

		// Token: 0x04000A58 RID: 2648
		[SerializeField]
		private ThemedElement.ElementInfo[] _elements;

		// Token: 0x02000272 RID: 626
		[Serializable]
		public class ElementInfo
		{
			// Token: 0x1700056D RID: 1389
			// (get) Token: 0x06001594 RID: 5524 RVA: 0x000495F9 File Offset: 0x000477F9
			public string themeClass
			{
				get
				{
					return this._themeClass;
				}
			}

			// Token: 0x1700056E RID: 1390
			// (get) Token: 0x06001595 RID: 5525 RVA: 0x00049601 File Offset: 0x00047801
			public Component component
			{
				get
				{
					return this._component;
				}
			}

			// Token: 0x04000E76 RID: 3702
			[SerializeField]
			private string _themeClass;

			// Token: 0x04000E77 RID: 3703
			[SerializeField]
			private Component _component;
		}
	}
}
