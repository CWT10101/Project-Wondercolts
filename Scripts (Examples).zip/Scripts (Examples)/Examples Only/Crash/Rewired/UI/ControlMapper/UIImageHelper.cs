﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200019A RID: 410
	[AddComponentMenu("")]
	[RequireComponent(typeof(Image))]
	public class UIImageHelper : MonoBehaviour
	{
		// Token: 0x06001009 RID: 4105 RVA: 0x00038070 File Offset: 0x00036270
		public void SetEnabledState(bool newState)
		{
			this.currentState = newState;
			UIImageHelper.State state = newState ? this.enabledState : this.disabledState;
			if (state == null)
			{
				return;
			}
			Image component = base.gameObject.GetComponent<Image>();
			if (component == null)
			{
				Debug.LogError("Image is missing!");
				return;
			}
			state.Set(component);
		}

		// Token: 0x0600100A RID: 4106 RVA: 0x000380C1 File Offset: 0x000362C1
		public void SetEnabledStateColor(Color color)
		{
			this.enabledState.color = color;
		}

		// Token: 0x0600100B RID: 4107 RVA: 0x000380CF File Offset: 0x000362CF
		public void SetDisabledStateColor(Color color)
		{
			this.disabledState.color = color;
		}

		// Token: 0x0600100C RID: 4108 RVA: 0x000380E0 File Offset: 0x000362E0
		public void Refresh()
		{
			UIImageHelper.State state = this.currentState ? this.enabledState : this.disabledState;
			Image component = base.gameObject.GetComponent<Image>();
			if (component == null)
			{
				return;
			}
			state.Set(component);
		}

		// Token: 0x04000A78 RID: 2680
		[SerializeField]
		private UIImageHelper.State enabledState;

		// Token: 0x04000A79 RID: 2681
		[SerializeField]
		private UIImageHelper.State disabledState;

		// Token: 0x04000A7A RID: 2682
		private bool currentState;

		// Token: 0x0200027E RID: 638
		[Serializable]
		private class State
		{
			// Token: 0x060015EC RID: 5612 RVA: 0x00049D52 File Offset: 0x00047F52
			public void Set(Image image)
			{
				if (image == null)
				{
					return;
				}
				image.color = this.color;
			}

			// Token: 0x04000EAF RID: 3759
			[SerializeField]
			public Color color;
		}
	}
}
