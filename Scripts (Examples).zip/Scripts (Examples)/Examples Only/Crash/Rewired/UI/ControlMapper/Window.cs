﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200019E RID: 414
	[AddComponentMenu("")]
	[RequireComponent(typeof(CanvasGroup))]
	public class Window : MonoBehaviour
	{
		// Token: 0x1700041B RID: 1051
		// (get) Token: 0x0600101E RID: 4126 RVA: 0x000388BF File Offset: 0x00036ABF
		public bool hasFocus
		{
			get
			{
				return this._isFocusedCallback != null && this._isFocusedCallback(this._id);
			}
		}

		// Token: 0x1700041C RID: 1052
		// (get) Token: 0x0600101F RID: 4127 RVA: 0x000388DC File Offset: 0x00036ADC
		public int id
		{
			get
			{
				return this._id;
			}
		}

		// Token: 0x1700041D RID: 1053
		// (get) Token: 0x06001020 RID: 4128 RVA: 0x000388E4 File Offset: 0x00036AE4
		public RectTransform rectTransform
		{
			get
			{
				if (this._rectTransform == null)
				{
					this._rectTransform = base.gameObject.GetComponent<RectTransform>();
				}
				return this._rectTransform;
			}
		}

		// Token: 0x1700041E RID: 1054
		// (get) Token: 0x06001021 RID: 4129 RVA: 0x0003890B File Offset: 0x00036B0B
		public TMP_Text titleText
		{
			get
			{
				return this._titleText;
			}
		}

		// Token: 0x1700041F RID: 1055
		// (get) Token: 0x06001022 RID: 4130 RVA: 0x00038913 File Offset: 0x00036B13
		public List<TMP_Text> contentText
		{
			get
			{
				return this._contentText;
			}
		}

		// Token: 0x17000420 RID: 1056
		// (get) Token: 0x06001023 RID: 4131 RVA: 0x0003891B File Offset: 0x00036B1B
		// (set) Token: 0x06001024 RID: 4132 RVA: 0x00038923 File Offset: 0x00036B23
		public GameObject defaultUIElement
		{
			get
			{
				return this._defaultUIElement;
			}
			set
			{
				this._defaultUIElement = value;
			}
		}

		// Token: 0x17000421 RID: 1057
		// (get) Token: 0x06001025 RID: 4133 RVA: 0x0003892C File Offset: 0x00036B2C
		// (set) Token: 0x06001026 RID: 4134 RVA: 0x00038934 File Offset: 0x00036B34
		public Action<int> updateCallback
		{
			get
			{
				return this._updateCallback;
			}
			set
			{
				this._updateCallback = value;
			}
		}

		// Token: 0x17000422 RID: 1058
		// (get) Token: 0x06001027 RID: 4135 RVA: 0x0003893D File Offset: 0x00036B3D
		public Window.Timer timer
		{
			get
			{
				return this._timer;
			}
		}

		// Token: 0x17000423 RID: 1059
		// (get) Token: 0x06001028 RID: 4136 RVA: 0x00038945 File Offset: 0x00036B45
		// (set) Token: 0x06001029 RID: 4137 RVA: 0x00038958 File Offset: 0x00036B58
		public int width
		{
			get
			{
				return (int)this.rectTransform.sizeDelta.x;
			}
			set
			{
				Vector2 sizeDelta = this.rectTransform.sizeDelta;
				sizeDelta.x = (float)value;
				this.rectTransform.sizeDelta = sizeDelta;
			}
		}

		// Token: 0x17000424 RID: 1060
		// (get) Token: 0x0600102A RID: 4138 RVA: 0x00038986 File Offset: 0x00036B86
		// (set) Token: 0x0600102B RID: 4139 RVA: 0x0003899C File Offset: 0x00036B9C
		public int height
		{
			get
			{
				return (int)this.rectTransform.sizeDelta.y;
			}
			set
			{
				Vector2 sizeDelta = this.rectTransform.sizeDelta;
				sizeDelta.y = (float)value;
				this.rectTransform.sizeDelta = sizeDelta;
			}
		}

		// Token: 0x17000425 RID: 1061
		// (get) Token: 0x0600102C RID: 4140 RVA: 0x000389CA File Offset: 0x00036BCA
		protected bool initialized
		{
			get
			{
				return this._initialized;
			}
		}

		// Token: 0x0600102D RID: 4141 RVA: 0x000389D2 File Offset: 0x00036BD2
		private void OnEnable()
		{
			base.StartCoroutine("OnEnableAsync");
		}

		// Token: 0x0600102E RID: 4142 RVA: 0x000389E0 File Offset: 0x00036BE0
		protected virtual void Update()
		{
			if (!this._initialized)
			{
				return;
			}
			if (!this.hasFocus)
			{
				return;
			}
			this.CheckUISelection();
			if (this._updateCallback != null)
			{
				this._updateCallback(this._id);
			}
		}

		// Token: 0x0600102F RID: 4143 RVA: 0x00038A14 File Offset: 0x00036C14
		public virtual void Initialize(int id, Func<int, bool> isFocusedCallback)
		{
			if (this._initialized)
			{
				Debug.LogError("Window is already initialized!");
				return;
			}
			this._id = id;
			this._isFocusedCallback = isFocusedCallback;
			this._timer = new Window.Timer();
			this._contentText = new List<TMP_Text>();
			this._canvasGroup = base.GetComponent<CanvasGroup>();
			this._initialized = true;
		}

		// Token: 0x06001030 RID: 4144 RVA: 0x00038A6B File Offset: 0x00036C6B
		public void SetSize(int width, int height)
		{
			this.rectTransform.sizeDelta = new Vector2((float)width, (float)height);
		}

		// Token: 0x06001031 RID: 4145 RVA: 0x00038A81 File Offset: 0x00036C81
		public void CreateTitleText(GameObject prefab, Vector2 offset)
		{
			this.CreateText(prefab, ref this._titleText, "Title Text", UIPivot.TopCenter, UIAnchor.TopHStretch, offset);
		}

		// Token: 0x06001032 RID: 4146 RVA: 0x00038AA0 File Offset: 0x00036CA0
		public void CreateTitleText(GameObject prefab, Vector2 offset, string text)
		{
			this.CreateTitleText(prefab, offset);
			this.SetTitleText(text);
		}

		// Token: 0x06001033 RID: 4147 RVA: 0x00038AB4 File Offset: 0x00036CB4
		public void AddContentText(GameObject prefab, UIPivot pivot, UIAnchor anchor, Vector2 offset)
		{
			TMP_Text item = null;
			this.CreateText(prefab, ref item, "Content Text", pivot, anchor, offset);
			this._contentText.Add(item);
		}

		// Token: 0x06001034 RID: 4148 RVA: 0x00038AE1 File Offset: 0x00036CE1
		public void AddContentText(GameObject prefab, UIPivot pivot, UIAnchor anchor, Vector2 offset, string text)
		{
			this.AddContentText(prefab, pivot, anchor, offset);
			this.SetContentText(text, this._contentText.Count - 1);
		}

		// Token: 0x06001035 RID: 4149 RVA: 0x00038B03 File Offset: 0x00036D03
		public void AddContentImage(GameObject prefab, UIPivot pivot, UIAnchor anchor, Vector2 offset)
		{
			this.CreateImage(prefab, "Image", pivot, anchor, offset);
		}

		// Token: 0x06001036 RID: 4150 RVA: 0x00038B15 File Offset: 0x00036D15
		public void AddContentImage(GameObject prefab, UIPivot pivot, UIAnchor anchor, Vector2 offset, string text)
		{
			this.AddContentImage(prefab, pivot, anchor, offset);
		}

		// Token: 0x06001037 RID: 4151 RVA: 0x00038B24 File Offset: 0x00036D24
		public void CreateButton(GameObject prefab, UIPivot pivot, UIAnchor anchor, Vector2 offset, string buttonText, UnityAction confirmCallback, UnityAction cancelCallback, bool setDefault)
		{
			if (prefab == null)
			{
				return;
			}
			ButtonInfo buttonInfo;
			GameObject gameObject = this.CreateButton(prefab, "Button", anchor, pivot, offset, out buttonInfo);
			if (gameObject == null)
			{
				return;
			}
			Button component = gameObject.GetComponent<Button>();
			if (confirmCallback != null)
			{
				component.onClick.AddListener(confirmCallback);
			}
			CustomButton customButton = component as CustomButton;
			if (cancelCallback != null && customButton != null)
			{
				customButton.CancelEvent += cancelCallback;
			}
			if (buttonInfo.text != null)
			{
				buttonInfo.text.text = buttonText;
			}
			if (setDefault)
			{
				this._defaultUIElement = gameObject;
			}
		}

		// Token: 0x06001038 RID: 4152 RVA: 0x00038BB2 File Offset: 0x00036DB2
		public string GetTitleText(string text)
		{
			if (this._titleText == null)
			{
				return string.Empty;
			}
			return this._titleText.text;
		}

		// Token: 0x06001039 RID: 4153 RVA: 0x00038BD3 File Offset: 0x00036DD3
		public void SetTitleText(string text)
		{
			if (this._titleText == null)
			{
				return;
			}
			this._titleText.text = text;
		}

		// Token: 0x0600103A RID: 4154 RVA: 0x00038BF0 File Offset: 0x00036DF0
		public string GetContentText(int index)
		{
			if (this._contentText == null || this._contentText.Count <= index || this._contentText[index] == null)
			{
				return string.Empty;
			}
			return this._contentText[index].text;
		}

		// Token: 0x0600103B RID: 4155 RVA: 0x00038C40 File Offset: 0x00036E40
		public float GetContentTextHeight(int index)
		{
			if (this._contentText == null || this._contentText.Count <= index || this._contentText[index] == null)
			{
				return 0f;
			}
			return this._contentText[index].rectTransform.sizeDelta.y;
		}

		// Token: 0x0600103C RID: 4156 RVA: 0x00038C98 File Offset: 0x00036E98
		public void SetContentText(string text, int index)
		{
			if (this._contentText == null || this._contentText.Count <= index || this._contentText[index] == null)
			{
				return;
			}
			this._contentText[index].text = text;
		}

		// Token: 0x0600103D RID: 4157 RVA: 0x00038CD7 File Offset: 0x00036ED7
		public void SetUpdateCallback(Action<int> callback)
		{
			this.updateCallback = callback;
		}

		// Token: 0x0600103E RID: 4158 RVA: 0x00038CE0 File Offset: 0x00036EE0
		public virtual void TakeInputFocus()
		{
			if (EventSystem.current == null)
			{
				return;
			}
			EventSystem.current.SetSelectedGameObject(this._defaultUIElement);
			this.Enable();
		}

		// Token: 0x0600103F RID: 4159 RVA: 0x00038D06 File Offset: 0x00036F06
		public virtual void Enable()
		{
			this._canvasGroup.interactable = true;
		}

		// Token: 0x06001040 RID: 4160 RVA: 0x00038D14 File Offset: 0x00036F14
		public virtual void Disable()
		{
			this._canvasGroup.interactable = false;
		}

		// Token: 0x06001041 RID: 4161 RVA: 0x00038D22 File Offset: 0x00036F22
		public virtual void Cancel()
		{
			if (!this.initialized)
			{
				return;
			}
			if (this.cancelCallback != null)
			{
				this.cancelCallback();
			}
		}

		// Token: 0x06001042 RID: 4162 RVA: 0x00038D40 File Offset: 0x00036F40
		private void CreateText(GameObject prefab, ref TMP_Text textComponent, string name, UIPivot pivot, UIAnchor anchor, Vector2 offset)
		{
			if (prefab == null || this.content == null)
			{
				return;
			}
			if (textComponent != null)
			{
				Debug.LogError("Window already has " + name + "!");
				return;
			}
			GameObject gameObject = UITools.InstantiateGUIObject<TMP_Text>(prefab, this.content.transform, name, pivot, anchor.min, anchor.max, offset);
			if (gameObject == null)
			{
				return;
			}
			textComponent = gameObject.GetComponent<TMP_Text>();
		}

		// Token: 0x06001043 RID: 4163 RVA: 0x00038DC4 File Offset: 0x00036FC4
		private void CreateImage(GameObject prefab, string name, UIPivot pivot, UIAnchor anchor, Vector2 offset)
		{
			if (prefab == null || this.content == null)
			{
				return;
			}
			UITools.InstantiateGUIObject<Image>(prefab, this.content.transform, name, pivot, anchor.min, anchor.max, offset);
		}

		// Token: 0x06001044 RID: 4164 RVA: 0x00038E14 File Offset: 0x00037014
		private GameObject CreateButton(GameObject prefab, string name, UIAnchor anchor, UIPivot pivot, Vector2 offset, out ButtonInfo buttonInfo)
		{
			buttonInfo = null;
			if (prefab == null)
			{
				return null;
			}
			GameObject gameObject = UITools.InstantiateGUIObject<ButtonInfo>(prefab, this.content.transform, name, pivot, anchor.min, anchor.max, offset);
			if (gameObject == null)
			{
				return null;
			}
			buttonInfo = gameObject.GetComponent<ButtonInfo>();
			if (gameObject.GetComponent<Button>() == null)
			{
				Debug.Log("Button prefab is missing Button component!");
				return null;
			}
			if (buttonInfo == null)
			{
				Debug.Log("Button prefab is missing ButtonInfo component!");
				return null;
			}
			return gameObject;
		}

		// Token: 0x06001045 RID: 4165 RVA: 0x00038E9E File Offset: 0x0003709E
		private IEnumerator OnEnableAsync()
		{
			yield return 1;
			if (EventSystem.current == null)
			{
				yield break;
			}
			if (this.defaultUIElement != null)
			{
				EventSystem.current.SetSelectedGameObject(this.defaultUIElement);
			}
			else
			{
				EventSystem.current.SetSelectedGameObject(null);
			}
			yield break;
		}

		// Token: 0x06001046 RID: 4166 RVA: 0x00038EB0 File Offset: 0x000370B0
		private void CheckUISelection()
		{
			if (!this.hasFocus)
			{
				return;
			}
			if (EventSystem.current == null)
			{
				return;
			}
			if (EventSystem.current.currentSelectedGameObject == null)
			{
				this.RestoreDefaultOrLastUISelection();
			}
			this.lastUISelection = EventSystem.current.currentSelectedGameObject;
		}

		// Token: 0x06001047 RID: 4167 RVA: 0x00038EFC File Offset: 0x000370FC
		private void RestoreDefaultOrLastUISelection()
		{
			if (!this.hasFocus)
			{
				return;
			}
			if (this.lastUISelection == null || !this.lastUISelection.activeInHierarchy)
			{
				this.SetUISelection(this._defaultUIElement);
				return;
			}
			this.SetUISelection(this.lastUISelection);
		}

		// Token: 0x06001048 RID: 4168 RVA: 0x00038F3B File Offset: 0x0003713B
		private void SetUISelection(GameObject selection)
		{
			if (EventSystem.current == null)
			{
				return;
			}
			EventSystem.current.SetSelectedGameObject(selection);
		}

		// Token: 0x04000A80 RID: 2688
		public Image backgroundImage;

		// Token: 0x04000A81 RID: 2689
		public GameObject content;

		// Token: 0x04000A82 RID: 2690
		private bool _initialized;

		// Token: 0x04000A83 RID: 2691
		private int _id = -1;

		// Token: 0x04000A84 RID: 2692
		private RectTransform _rectTransform;

		// Token: 0x04000A85 RID: 2693
		private TMP_Text _titleText;

		// Token: 0x04000A86 RID: 2694
		private List<TMP_Text> _contentText;

		// Token: 0x04000A87 RID: 2695
		private GameObject _defaultUIElement;

		// Token: 0x04000A88 RID: 2696
		private Action<int> _updateCallback;

		// Token: 0x04000A89 RID: 2697
		private Func<int, bool> _isFocusedCallback;

		// Token: 0x04000A8A RID: 2698
		private Window.Timer _timer;

		// Token: 0x04000A8B RID: 2699
		private CanvasGroup _canvasGroup;

		// Token: 0x04000A8C RID: 2700
		public UnityAction cancelCallback;

		// Token: 0x04000A8D RID: 2701
		private GameObject lastUISelection;

		// Token: 0x02000280 RID: 640
		public class Timer
		{
			// Token: 0x1700059D RID: 1437
			// (get) Token: 0x060015F1 RID: 5617 RVA: 0x00049D94 File Offset: 0x00047F94
			public bool started
			{
				get
				{
					return this._started;
				}
			}

			// Token: 0x1700059E RID: 1438
			// (get) Token: 0x060015F2 RID: 5618 RVA: 0x00049D9C File Offset: 0x00047F9C
			public bool finished
			{
				get
				{
					if (!this.started)
					{
						return false;
					}
					if (Time.realtimeSinceStartup < this.end)
					{
						return false;
					}
					this._started = false;
					return true;
				}
			}

			// Token: 0x1700059F RID: 1439
			// (get) Token: 0x060015F3 RID: 5619 RVA: 0x00049DBF File Offset: 0x00047FBF
			public float remaining
			{
				get
				{
					if (!this._started)
					{
						return 0f;
					}
					return this.end - Time.realtimeSinceStartup;
				}
			}

			// Token: 0x060015F5 RID: 5621 RVA: 0x00049DE3 File Offset: 0x00047FE3
			public void Start(float length)
			{
				this.end = Time.realtimeSinceStartup + length;
				this._started = true;
			}

			// Token: 0x060015F6 RID: 5622 RVA: 0x00049DF9 File Offset: 0x00047FF9
			public void Stop()
			{
				this._started = false;
			}

			// Token: 0x04000EB1 RID: 3761
			private bool _started;

			// Token: 0x04000EB2 RID: 3762
			private float end;
		}
	}
}
