﻿using System;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000183 RID: 387
	[AddComponentMenu("")]
	public class ButtonInfo : UIElementInfo
	{
	}
}
