﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200019C RID: 412
	[AddComponentMenu("")]
	public class UISliderControl : UIControl
	{
		// Token: 0x17000419 RID: 1049
		// (get) Token: 0x06001010 RID: 4112 RVA: 0x00038349 File Offset: 0x00036549
		// (set) Token: 0x06001011 RID: 4113 RVA: 0x00038351 File Offset: 0x00036551
		public bool showIcon
		{
			get
			{
				return this._showIcon;
			}
			set
			{
				if (this.iconImage == null)
				{
					return;
				}
				this.iconImage.gameObject.SetActive(value);
				this._showIcon = value;
			}
		}

		// Token: 0x1700041A RID: 1050
		// (get) Token: 0x06001012 RID: 4114 RVA: 0x0003837A File Offset: 0x0003657A
		// (set) Token: 0x06001013 RID: 4115 RVA: 0x00038382 File Offset: 0x00036582
		public bool showSlider
		{
			get
			{
				return this._showSlider;
			}
			set
			{
				if (this.slider == null)
				{
					return;
				}
				this.slider.gameObject.SetActive(value);
				this._showSlider = value;
			}
		}

		// Token: 0x06001014 RID: 4116 RVA: 0x000383AC File Offset: 0x000365AC
		public override void SetCancelCallback(Action cancelCallback)
		{
			base.SetCancelCallback(cancelCallback);
			if (cancelCallback == null || this.slider == null)
			{
				return;
			}
			if (this.slider is ICustomSelectable)
			{
				(this.slider as ICustomSelectable).CancelEvent += delegate()
				{
					cancelCallback();
				};
				return;
			}
			EventTrigger eventTrigger = this.slider.GetComponent<EventTrigger>();
			if (eventTrigger == null)
			{
				eventTrigger = this.slider.gameObject.AddComponent<EventTrigger>();
			}
			EventTrigger.Entry entry = new EventTrigger.Entry();
			entry.callback = new EventTrigger.TriggerEvent();
			entry.eventID = EventTriggerType.Cancel;
			entry.callback.AddListener(delegate(BaseEventData data)
			{
				cancelCallback();
			});
			if (eventTrigger.triggers == null)
			{
				eventTrigger.triggers = new List<EventTrigger.Entry>();
			}
			eventTrigger.triggers.Add(entry);
		}

		// Token: 0x04000A7C RID: 2684
		public Image iconImage;

		// Token: 0x04000A7D RID: 2685
		public Slider slider;

		// Token: 0x04000A7E RID: 2686
		private bool _showIcon;

		// Token: 0x04000A7F RID: 2687
		private bool _showSlider;
	}
}
