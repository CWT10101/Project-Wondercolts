﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000198 RID: 408
	[AddComponentMenu("")]
	public abstract class UIElementInfo : MonoBehaviour, ISelectHandler, IEventSystemHandler
	{
		// Token: 0x1400001A RID: 26
		// (add) Token: 0x06001000 RID: 4096 RVA: 0x00037F70 File Offset: 0x00036170
		// (remove) Token: 0x06001001 RID: 4097 RVA: 0x00037FA8 File Offset: 0x000361A8
		public event Action<GameObject> OnSelectedEvent;

		// Token: 0x06001002 RID: 4098 RVA: 0x00037FDD File Offset: 0x000361DD
		public void OnSelect(BaseEventData eventData)
		{
			if (this.OnSelectedEvent != null)
			{
				this.OnSelectedEvent(base.gameObject);
			}
		}

		// Token: 0x04000A72 RID: 2674
		public string identifier;

		// Token: 0x04000A73 RID: 2675
		public int intData;

		// Token: 0x04000A74 RID: 2676
		public TMP_Text text;
	}
}
