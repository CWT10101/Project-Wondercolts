﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000188 RID: 392
	[AddComponentMenu("")]
	public class CustomButton : Button, ICustomSelectable, ICancelHandler, IEventSystemHandler
	{
		// Token: 0x17000396 RID: 918
		// (get) Token: 0x06000EC0 RID: 3776 RVA: 0x00035992 File Offset: 0x00033B92
		// (set) Token: 0x06000EC1 RID: 3777 RVA: 0x0003599A File Offset: 0x00033B9A
		public Sprite disabledHighlightedSprite
		{
			get
			{
				return this._disabledHighlightedSprite;
			}
			set
			{
				this._disabledHighlightedSprite = value;
			}
		}

		// Token: 0x17000397 RID: 919
		// (get) Token: 0x06000EC2 RID: 3778 RVA: 0x000359A3 File Offset: 0x00033BA3
		// (set) Token: 0x06000EC3 RID: 3779 RVA: 0x000359AB File Offset: 0x00033BAB
		public Color disabledHighlightedColor
		{
			get
			{
				return this._disabledHighlightedColor;
			}
			set
			{
				this._disabledHighlightedColor = value;
			}
		}

		// Token: 0x17000398 RID: 920
		// (get) Token: 0x06000EC4 RID: 3780 RVA: 0x000359B4 File Offset: 0x00033BB4
		// (set) Token: 0x06000EC5 RID: 3781 RVA: 0x000359BC File Offset: 0x00033BBC
		public string disabledHighlightedTrigger
		{
			get
			{
				return this._disabledHighlightedTrigger;
			}
			set
			{
				this._disabledHighlightedTrigger = value;
			}
		}

		// Token: 0x17000399 RID: 921
		// (get) Token: 0x06000EC6 RID: 3782 RVA: 0x000359C5 File Offset: 0x00033BC5
		// (set) Token: 0x06000EC7 RID: 3783 RVA: 0x000359CD File Offset: 0x00033BCD
		public bool autoNavUp
		{
			get
			{
				return this._autoNavUp;
			}
			set
			{
				this._autoNavUp = value;
			}
		}

		// Token: 0x1700039A RID: 922
		// (get) Token: 0x06000EC8 RID: 3784 RVA: 0x000359D6 File Offset: 0x00033BD6
		// (set) Token: 0x06000EC9 RID: 3785 RVA: 0x000359DE File Offset: 0x00033BDE
		public bool autoNavDown
		{
			get
			{
				return this._autoNavDown;
			}
			set
			{
				this._autoNavDown = value;
			}
		}

		// Token: 0x1700039B RID: 923
		// (get) Token: 0x06000ECA RID: 3786 RVA: 0x000359E7 File Offset: 0x00033BE7
		// (set) Token: 0x06000ECB RID: 3787 RVA: 0x000359EF File Offset: 0x00033BEF
		public bool autoNavLeft
		{
			get
			{
				return this._autoNavLeft;
			}
			set
			{
				this._autoNavLeft = value;
			}
		}

		// Token: 0x1700039C RID: 924
		// (get) Token: 0x06000ECC RID: 3788 RVA: 0x000359F8 File Offset: 0x00033BF8
		// (set) Token: 0x06000ECD RID: 3789 RVA: 0x00035A00 File Offset: 0x00033C00
		public bool autoNavRight
		{
			get
			{
				return this._autoNavRight;
			}
			set
			{
				this._autoNavRight = value;
			}
		}

		// Token: 0x1700039D RID: 925
		// (get) Token: 0x06000ECE RID: 3790 RVA: 0x00035A09 File Offset: 0x00033C09
		private bool isDisabled
		{
			get
			{
				return !this.IsInteractable();
			}
		}

		// Token: 0x14000013 RID: 19
		// (add) Token: 0x06000ECF RID: 3791 RVA: 0x00035A14 File Offset: 0x00033C14
		// (remove) Token: 0x06000ED0 RID: 3792 RVA: 0x00035A4C File Offset: 0x00033C4C
		private event UnityAction _CancelEvent;

		// Token: 0x14000014 RID: 20
		// (add) Token: 0x06000ED1 RID: 3793 RVA: 0x00035A81 File Offset: 0x00033C81
		// (remove) Token: 0x06000ED2 RID: 3794 RVA: 0x00035A8A File Offset: 0x00033C8A
		public event UnityAction CancelEvent
		{
			add
			{
				this._CancelEvent += value;
			}
			remove
			{
				this._CancelEvent -= value;
			}
		}

		// Token: 0x06000ED3 RID: 3795 RVA: 0x00035A94 File Offset: 0x00033C94
		public override Selectable FindSelectableOnLeft()
		{
			if ((base.navigation.mode & Navigation.Mode.Horizontal) != Navigation.Mode.None || this._autoNavLeft)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Vector3.left);
			}
			return base.FindSelectableOnLeft();
		}

		// Token: 0x06000ED4 RID: 3796 RVA: 0x00035AD4 File Offset: 0x00033CD4
		public override Selectable FindSelectableOnRight()
		{
			if ((base.navigation.mode & Navigation.Mode.Horizontal) != Navigation.Mode.None || this._autoNavRight)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Vector3.right);
			}
			return base.FindSelectableOnRight();
		}

		// Token: 0x06000ED5 RID: 3797 RVA: 0x00035B14 File Offset: 0x00033D14
		public override Selectable FindSelectableOnUp()
		{
			if ((base.navigation.mode & Navigation.Mode.Vertical) != Navigation.Mode.None || this._autoNavUp)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Vector3.up);
			}
			return base.FindSelectableOnUp();
		}

		// Token: 0x06000ED6 RID: 3798 RVA: 0x00035B54 File Offset: 0x00033D54
		public override Selectable FindSelectableOnDown()
		{
			if ((base.navigation.mode & Navigation.Mode.Vertical) != Navigation.Mode.None || this._autoNavDown)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Vector3.down);
			}
			return base.FindSelectableOnDown();
		}

		// Token: 0x06000ED7 RID: 3799 RVA: 0x00035B93 File Offset: 0x00033D93
		protected override void OnCanvasGroupChanged()
		{
			base.OnCanvasGroupChanged();
			if (EventSystem.current == null)
			{
				return;
			}
			this.EvaluateHightlightDisabled(EventSystem.current.currentSelectedGameObject == base.gameObject);
		}

		// Token: 0x06000ED8 RID: 3800 RVA: 0x00035BC4 File Offset: 0x00033DC4
		protected override void DoStateTransition(Selectable.SelectionState state, bool instant)
		{
			if (this.isHighlightDisabled)
			{
				Color disabledHighlightedColor = this._disabledHighlightedColor;
				Sprite disabledHighlightedSprite = this._disabledHighlightedSprite;
				string disabledHighlightedTrigger = this._disabledHighlightedTrigger;
				if (base.gameObject.activeInHierarchy)
				{
					switch (base.transition)
					{
					case Selectable.Transition.ColorTint:
						this.StartColorTween(disabledHighlightedColor * base.colors.colorMultiplier, instant);
						return;
					case Selectable.Transition.SpriteSwap:
						this.DoSpriteSwap(disabledHighlightedSprite);
						return;
					case Selectable.Transition.Animation:
						this.TriggerAnimation(disabledHighlightedTrigger);
						return;
					default:
						return;
					}
				}
			}
			else
			{
				base.DoStateTransition(state, instant);
			}
		}

		// Token: 0x06000ED9 RID: 3801 RVA: 0x00035C4C File Offset: 0x00033E4C
		private void StartColorTween(Color targetColor, bool instant)
		{
			if (base.targetGraphic == null)
			{
				return;
			}
			base.targetGraphic.CrossFadeColor(targetColor, instant ? 0f : base.colors.fadeDuration, true, true);
		}

		// Token: 0x06000EDA RID: 3802 RVA: 0x00035C8E File Offset: 0x00033E8E
		private void DoSpriteSwap(Sprite newSprite)
		{
			if (base.image == null)
			{
				return;
			}
			base.image.overrideSprite = newSprite;
		}

		// Token: 0x06000EDB RID: 3803 RVA: 0x00035CAC File Offset: 0x00033EAC
		private void TriggerAnimation(string triggername)
		{
			if (base.animator == null || !base.animator.enabled || !base.animator.isActiveAndEnabled || base.animator.runtimeAnimatorController == null || string.IsNullOrEmpty(triggername))
			{
				return;
			}
			base.animator.ResetTrigger(this._disabledHighlightedTrigger);
			base.animator.SetTrigger(triggername);
		}

		// Token: 0x06000EDC RID: 3804 RVA: 0x00035D1A File Offset: 0x00033F1A
		public override void OnSelect(BaseEventData eventData)
		{
			base.OnSelect(eventData);
			this.EvaluateHightlightDisabled(true);
		}

		// Token: 0x06000EDD RID: 3805 RVA: 0x00035D2A File Offset: 0x00033F2A
		public override void OnDeselect(BaseEventData eventData)
		{
			base.OnDeselect(eventData);
			this.EvaluateHightlightDisabled(false);
		}

		// Token: 0x06000EDE RID: 3806 RVA: 0x00035D3A File Offset: 0x00033F3A
		private void Press()
		{
			if (!this.IsActive() || !this.IsInteractable())
			{
				return;
			}
			base.onClick.Invoke();
		}

		// Token: 0x06000EDF RID: 3807 RVA: 0x00035D58 File Offset: 0x00033F58
		public override void OnPointerClick(PointerEventData eventData)
		{
			if (!this.IsActive() || !this.IsInteractable())
			{
				return;
			}
			if (eventData.button != PointerEventData.InputButton.Left)
			{
				return;
			}
			this.Press();
			if (!this.IsActive() || !this.IsInteractable())
			{
				this.isHighlightDisabled = true;
				this.DoStateTransition(Selectable.SelectionState.Disabled, false);
			}
		}

		// Token: 0x06000EE0 RID: 3808 RVA: 0x00035DA4 File Offset: 0x00033FA4
		public override void OnSubmit(BaseEventData eventData)
		{
			this.Press();
			if (!this.IsActive() || !this.IsInteractable())
			{
				this.isHighlightDisabled = true;
				this.DoStateTransition(Selectable.SelectionState.Disabled, false);
				return;
			}
			this.DoStateTransition(Selectable.SelectionState.Pressed, false);
			base.StartCoroutine(this.OnFinishSubmit());
		}

		// Token: 0x06000EE1 RID: 3809 RVA: 0x00035DE1 File Offset: 0x00033FE1
		private IEnumerator OnFinishSubmit()
		{
			float fadeTime = base.colors.fadeDuration;
			float elapsedTime = 0f;
			while (elapsedTime < fadeTime)
			{
				elapsedTime += Time.unscaledDeltaTime;
				yield return null;
			}
			this.DoStateTransition(base.currentSelectionState, false);
			yield break;
		}

		// Token: 0x06000EE2 RID: 3810 RVA: 0x00035DF0 File Offset: 0x00033FF0
		private void EvaluateHightlightDisabled(bool isSelected)
		{
			if (!isSelected)
			{
				if (this.isHighlightDisabled)
				{
					this.isHighlightDisabled = false;
					Selectable.SelectionState state = this.isDisabled ? Selectable.SelectionState.Disabled : base.currentSelectionState;
					this.DoStateTransition(state, false);
					return;
				}
			}
			else
			{
				if (!this.isDisabled)
				{
					return;
				}
				this.isHighlightDisabled = true;
				this.DoStateTransition(Selectable.SelectionState.Disabled, false);
			}
		}

		// Token: 0x06000EE3 RID: 3811 RVA: 0x00035E42 File Offset: 0x00034042
		public void OnCancel(BaseEventData eventData)
		{
			if (this._CancelEvent != null)
			{
				this._CancelEvent();
			}
		}

		// Token: 0x040009E6 RID: 2534
		[SerializeField]
		private Sprite _disabledHighlightedSprite;

		// Token: 0x040009E7 RID: 2535
		[SerializeField]
		private Color _disabledHighlightedColor;

		// Token: 0x040009E8 RID: 2536
		[SerializeField]
		private string _disabledHighlightedTrigger;

		// Token: 0x040009E9 RID: 2537
		[SerializeField]
		private bool _autoNavUp = true;

		// Token: 0x040009EA RID: 2538
		[SerializeField]
		private bool _autoNavDown = true;

		// Token: 0x040009EB RID: 2539
		[SerializeField]
		private bool _autoNavLeft = true;

		// Token: 0x040009EC RID: 2540
		[SerializeField]
		private bool _autoNavRight = true;

		// Token: 0x040009ED RID: 2541
		private bool isHighlightDisabled;
	}
}
