﻿using System;
using TMPro;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200018E RID: 398
	[AddComponentMenu("")]
	public class InputRow : MonoBehaviour
	{
		// Token: 0x170003BA RID: 954
		// (get) Token: 0x06000F53 RID: 3923 RVA: 0x00036CF5 File Offset: 0x00034EF5
		// (set) Token: 0x06000F54 RID: 3924 RVA: 0x00036CFD File Offset: 0x00034EFD
		public ButtonInfo[] buttons { get; private set; }

		// Token: 0x06000F55 RID: 3925 RVA: 0x00036D06 File Offset: 0x00034F06
		public void Initialize(int rowIndex, string label, Action<int, ButtonInfo> inputFieldActivatedCallback)
		{
			this.rowIndex = rowIndex;
			this.label.text = label;
			this.inputFieldActivatedCallback = inputFieldActivatedCallback;
			this.buttons = base.transform.GetComponentsInChildren<ButtonInfo>(true);
		}

		// Token: 0x06000F56 RID: 3926 RVA: 0x00036D34 File Offset: 0x00034F34
		public void OnButtonActivated(ButtonInfo buttonInfo)
		{
			if (this.inputFieldActivatedCallback == null)
			{
				return;
			}
			this.inputFieldActivatedCallback(this.rowIndex, buttonInfo);
		}

		// Token: 0x04000A13 RID: 2579
		public TMP_Text label;

		// Token: 0x04000A15 RID: 2581
		private int rowIndex;

		// Token: 0x04000A16 RID: 2582
		private Action<int, ButtonInfo> inputFieldActivatedCallback;
	}
}
