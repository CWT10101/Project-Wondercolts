﻿using System;
using Rewired.Utils;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000186 RID: 390
	[RequireComponent(typeof(CanvasScalerExt))]
	public class CanvasScalerFitter : MonoBehaviour
	{
		// Token: 0x06000D9E RID: 3486 RVA: 0x0002F267 File Offset: 0x0002D467
		private void OnEnable()
		{
			this.canvasScaler = base.GetComponent<CanvasScalerExt>();
			this.Update();
			this.canvasScaler.ForceRefresh();
		}

		// Token: 0x06000D9F RID: 3487 RVA: 0x0002F286 File Offset: 0x0002D486
		private void Update()
		{
			if (Screen.width != this.screenWidth || Screen.height != this.screenHeight)
			{
				this.screenWidth = Screen.width;
				this.screenHeight = Screen.height;
				this.UpdateSize();
			}
		}

		// Token: 0x06000DA0 RID: 3488 RVA: 0x0002F2C0 File Offset: 0x0002D4C0
		private void UpdateSize()
		{
			if (this.canvasScaler.uiScaleMode != CanvasScaler.ScaleMode.ScaleWithScreenSize)
			{
				return;
			}
			if (this.breakPoints == null)
			{
				return;
			}
			float num = (float)Screen.width / (float)Screen.height;
			float num2 = float.PositiveInfinity;
			int num3 = 0;
			for (int i = 0; i < this.breakPoints.Length; i++)
			{
				float num4 = Mathf.Abs(num - this.breakPoints[i].screenAspectRatio);
				if ((num4 <= this.breakPoints[i].screenAspectRatio || MathTools.IsNear(this.breakPoints[i].screenAspectRatio, 0.01f)) && num4 < num2)
				{
					num2 = num4;
					num3 = i;
				}
			}
			this.canvasScaler.referenceResolution = this.breakPoints[num3].referenceResolution;
		}

		// Token: 0x04000979 RID: 2425
		[SerializeField]
		private CanvasScalerFitter.BreakPoint[] breakPoints;

		// Token: 0x0400097A RID: 2426
		private CanvasScalerExt canvasScaler;

		// Token: 0x0400097B RID: 2427
		private int screenWidth;

		// Token: 0x0400097C RID: 2428
		private int screenHeight;

		// Token: 0x0400097D RID: 2429
		private Action ScreenSizeChanged;

		// Token: 0x02000251 RID: 593
		[Serializable]
		private class BreakPoint
		{
			// Token: 0x04000DC3 RID: 3523
			[SerializeField]
			public string name;

			// Token: 0x04000DC4 RID: 3524
			[SerializeField]
			public float screenAspectRatio;

			// Token: 0x04000DC5 RID: 3525
			[SerializeField]
			public Vector2 referenceResolution;
		}
	}
}
