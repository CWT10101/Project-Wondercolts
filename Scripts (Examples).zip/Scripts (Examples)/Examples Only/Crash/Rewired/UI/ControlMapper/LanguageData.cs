﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200018F RID: 399
	[Serializable]
	public class LanguageData : LanguageDataBase
	{
		// Token: 0x06000F58 RID: 3928 RVA: 0x00036D59 File Offset: 0x00034F59
		public override void Initialize()
		{
			if (this._initialized)
			{
				return;
			}
			this.customDict = LanguageData.CustomEntry.ToDictionary(this._customEntries);
			this._initialized = true;
		}

		// Token: 0x06000F59 RID: 3929 RVA: 0x00036D7C File Offset: 0x00034F7C
		public override string GetCustomEntry(string key)
		{
			if (string.IsNullOrEmpty(key))
			{
				return string.Empty;
			}
			string result;
			if (!this.customDict.TryGetValue(key, out result))
			{
				return string.Empty;
			}
			return result;
		}

		// Token: 0x06000F5A RID: 3930 RVA: 0x00036DAE File Offset: 0x00034FAE
		public override bool ContainsCustomEntryKey(string key)
		{
			return !string.IsNullOrEmpty(key) && this.customDict.ContainsKey(key);
		}

		// Token: 0x170003BB RID: 955
		// (get) Token: 0x06000F5B RID: 3931 RVA: 0x00036DC6 File Offset: 0x00034FC6
		public override string yes
		{
			get
			{
				return this._yes;
			}
		}

		// Token: 0x170003BC RID: 956
		// (get) Token: 0x06000F5C RID: 3932 RVA: 0x00036DCE File Offset: 0x00034FCE
		public override string no
		{
			get
			{
				return this._no;
			}
		}

		// Token: 0x170003BD RID: 957
		// (get) Token: 0x06000F5D RID: 3933 RVA: 0x00036DD6 File Offset: 0x00034FD6
		public override string add
		{
			get
			{
				return this._add;
			}
		}

		// Token: 0x170003BE RID: 958
		// (get) Token: 0x06000F5E RID: 3934 RVA: 0x00036DDE File Offset: 0x00034FDE
		public override string replace
		{
			get
			{
				return this._replace;
			}
		}

		// Token: 0x170003BF RID: 959
		// (get) Token: 0x06000F5F RID: 3935 RVA: 0x00036DE6 File Offset: 0x00034FE6
		public override string remove
		{
			get
			{
				return this._remove;
			}
		}

		// Token: 0x170003C0 RID: 960
		// (get) Token: 0x06000F60 RID: 3936 RVA: 0x00036DEE File Offset: 0x00034FEE
		public override string swap
		{
			get
			{
				return this._swap;
			}
		}

		// Token: 0x170003C1 RID: 961
		// (get) Token: 0x06000F61 RID: 3937 RVA: 0x00036DF6 File Offset: 0x00034FF6
		public override string cancel
		{
			get
			{
				return this._cancel;
			}
		}

		// Token: 0x170003C2 RID: 962
		// (get) Token: 0x06000F62 RID: 3938 RVA: 0x00036DFE File Offset: 0x00034FFE
		public override string none
		{
			get
			{
				return this._none;
			}
		}

		// Token: 0x170003C3 RID: 963
		// (get) Token: 0x06000F63 RID: 3939 RVA: 0x00036E06 File Offset: 0x00035006
		public override string okay
		{
			get
			{
				return this._okay;
			}
		}

		// Token: 0x170003C4 RID: 964
		// (get) Token: 0x06000F64 RID: 3940 RVA: 0x00036E0E File Offset: 0x0003500E
		public override string done
		{
			get
			{
				return this._done;
			}
		}

		// Token: 0x170003C5 RID: 965
		// (get) Token: 0x06000F65 RID: 3941 RVA: 0x00036E16 File Offset: 0x00035016
		public override string default_
		{
			get
			{
				return this._default;
			}
		}

		// Token: 0x170003C6 RID: 966
		// (get) Token: 0x06000F66 RID: 3942 RVA: 0x00036E1E File Offset: 0x0003501E
		public override string assignControllerWindowTitle
		{
			get
			{
				return this._assignControllerWindowTitle;
			}
		}

		// Token: 0x170003C7 RID: 967
		// (get) Token: 0x06000F67 RID: 3943 RVA: 0x00036E26 File Offset: 0x00035026
		public override string assignControllerWindowMessage
		{
			get
			{
				return this._assignControllerWindowMessage;
			}
		}

		// Token: 0x170003C8 RID: 968
		// (get) Token: 0x06000F68 RID: 3944 RVA: 0x00036E2E File Offset: 0x0003502E
		public override string controllerAssignmentConflictWindowTitle
		{
			get
			{
				return this._controllerAssignmentConflictWindowTitle;
			}
		}

		// Token: 0x170003C9 RID: 969
		// (get) Token: 0x06000F69 RID: 3945 RVA: 0x00036E36 File Offset: 0x00035036
		public override string elementAssignmentPrePollingWindowMessage
		{
			get
			{
				return this._elementAssignmentPrePollingWindowMessage;
			}
		}

		// Token: 0x170003CA RID: 970
		// (get) Token: 0x06000F6A RID: 3946 RVA: 0x00036E3E File Offset: 0x0003503E
		public override string elementAssignmentConflictWindowMessage
		{
			get
			{
				return this._elementAssignmentConflictWindowMessage;
			}
		}

		// Token: 0x170003CB RID: 971
		// (get) Token: 0x06000F6B RID: 3947 RVA: 0x00036E46 File Offset: 0x00035046
		public override string mouseAssignmentConflictWindowTitle
		{
			get
			{
				return this._mouseAssignmentConflictWindowTitle;
			}
		}

		// Token: 0x170003CC RID: 972
		// (get) Token: 0x06000F6C RID: 3948 RVA: 0x00036E4E File Offset: 0x0003504E
		public override string calibrateControllerWindowTitle
		{
			get
			{
				return this._calibrateControllerWindowTitle;
			}
		}

		// Token: 0x170003CD RID: 973
		// (get) Token: 0x06000F6D RID: 3949 RVA: 0x00036E56 File Offset: 0x00035056
		public override string calibrateAxisStep1WindowTitle
		{
			get
			{
				return this._calibrateAxisStep1WindowTitle;
			}
		}

		// Token: 0x170003CE RID: 974
		// (get) Token: 0x06000F6E RID: 3950 RVA: 0x00036E5E File Offset: 0x0003505E
		public override string calibrateAxisStep2WindowTitle
		{
			get
			{
				return this._calibrateAxisStep2WindowTitle;
			}
		}

		// Token: 0x170003CF RID: 975
		// (get) Token: 0x06000F6F RID: 3951 RVA: 0x00036E66 File Offset: 0x00035066
		public override string inputBehaviorSettingsWindowTitle
		{
			get
			{
				return this._inputBehaviorSettingsWindowTitle;
			}
		}

		// Token: 0x170003D0 RID: 976
		// (get) Token: 0x06000F70 RID: 3952 RVA: 0x00036E6E File Offset: 0x0003506E
		public override string restoreDefaultsWindowTitle
		{
			get
			{
				return this._restoreDefaultsWindowTitle;
			}
		}

		// Token: 0x170003D1 RID: 977
		// (get) Token: 0x06000F71 RID: 3953 RVA: 0x00036E76 File Offset: 0x00035076
		public override string actionColumnLabel
		{
			get
			{
				return this._actionColumnLabel;
			}
		}

		// Token: 0x170003D2 RID: 978
		// (get) Token: 0x06000F72 RID: 3954 RVA: 0x00036E7E File Offset: 0x0003507E
		public override string keyboardColumnLabel
		{
			get
			{
				return this._keyboardColumnLabel;
			}
		}

		// Token: 0x170003D3 RID: 979
		// (get) Token: 0x06000F73 RID: 3955 RVA: 0x00036E86 File Offset: 0x00035086
		public override string mouseColumnLabel
		{
			get
			{
				return this._mouseColumnLabel;
			}
		}

		// Token: 0x170003D4 RID: 980
		// (get) Token: 0x06000F74 RID: 3956 RVA: 0x00036E8E File Offset: 0x0003508E
		public override string controllerColumnLabel
		{
			get
			{
				return this._controllerColumnLabel;
			}
		}

		// Token: 0x170003D5 RID: 981
		// (get) Token: 0x06000F75 RID: 3957 RVA: 0x00036E96 File Offset: 0x00035096
		public override string removeControllerButtonLabel
		{
			get
			{
				return this._removeControllerButtonLabel;
			}
		}

		// Token: 0x170003D6 RID: 982
		// (get) Token: 0x06000F76 RID: 3958 RVA: 0x00036E9E File Offset: 0x0003509E
		public override string calibrateControllerButtonLabel
		{
			get
			{
				return this._calibrateControllerButtonLabel;
			}
		}

		// Token: 0x170003D7 RID: 983
		// (get) Token: 0x06000F77 RID: 3959 RVA: 0x00036EA6 File Offset: 0x000350A6
		public override string assignControllerButtonLabel
		{
			get
			{
				return this._assignControllerButtonLabel;
			}
		}

		// Token: 0x170003D8 RID: 984
		// (get) Token: 0x06000F78 RID: 3960 RVA: 0x00036EAE File Offset: 0x000350AE
		public override string inputBehaviorSettingsButtonLabel
		{
			get
			{
				return this._inputBehaviorSettingsButtonLabel;
			}
		}

		// Token: 0x170003D9 RID: 985
		// (get) Token: 0x06000F79 RID: 3961 RVA: 0x00036EB6 File Offset: 0x000350B6
		public override string doneButtonLabel
		{
			get
			{
				return this._doneButtonLabel;
			}
		}

		// Token: 0x170003DA RID: 986
		// (get) Token: 0x06000F7A RID: 3962 RVA: 0x00036EBE File Offset: 0x000350BE
		public override string restoreDefaultsButtonLabel
		{
			get
			{
				return this._restoreDefaultsButtonLabel;
			}
		}

		// Token: 0x170003DB RID: 987
		// (get) Token: 0x06000F7B RID: 3963 RVA: 0x00036EC6 File Offset: 0x000350C6
		public override string controllerSettingsGroupLabel
		{
			get
			{
				return this._controllerSettingsGroupLabel;
			}
		}

		// Token: 0x170003DC RID: 988
		// (get) Token: 0x06000F7C RID: 3964 RVA: 0x00036ECE File Offset: 0x000350CE
		public override string playersGroupLabel
		{
			get
			{
				return this._playersGroupLabel;
			}
		}

		// Token: 0x170003DD RID: 989
		// (get) Token: 0x06000F7D RID: 3965 RVA: 0x00036ED6 File Offset: 0x000350D6
		public override string assignedControllersGroupLabel
		{
			get
			{
				return this._assignedControllersGroupLabel;
			}
		}

		// Token: 0x170003DE RID: 990
		// (get) Token: 0x06000F7E RID: 3966 RVA: 0x00036EDE File Offset: 0x000350DE
		public override string settingsGroupLabel
		{
			get
			{
				return this._settingsGroupLabel;
			}
		}

		// Token: 0x170003DF RID: 991
		// (get) Token: 0x06000F7F RID: 3967 RVA: 0x00036EE6 File Offset: 0x000350E6
		public override string mapCategoriesGroupLabel
		{
			get
			{
				return this._mapCategoriesGroupLabel;
			}
		}

		// Token: 0x170003E0 RID: 992
		// (get) Token: 0x06000F80 RID: 3968 RVA: 0x00036EEE File Offset: 0x000350EE
		public override string restoreDefaultsWindowMessage
		{
			get
			{
				if (ReInput.players.playerCount > 1)
				{
					return this._restoreDefaultsWindowMessage_multiPlayer;
				}
				return this._restoreDefaultsWindowMessage_onePlayer;
			}
		}

		// Token: 0x170003E1 RID: 993
		// (get) Token: 0x06000F81 RID: 3969 RVA: 0x00036F0A File Offset: 0x0003510A
		public override string calibrateWindow_deadZoneSliderLabel
		{
			get
			{
				return this._calibrateWindow_deadZoneSliderLabel;
			}
		}

		// Token: 0x170003E2 RID: 994
		// (get) Token: 0x06000F82 RID: 3970 RVA: 0x00036F12 File Offset: 0x00035112
		public override string calibrateWindow_zeroSliderLabel
		{
			get
			{
				return this._calibrateWindow_zeroSliderLabel;
			}
		}

		// Token: 0x170003E3 RID: 995
		// (get) Token: 0x06000F83 RID: 3971 RVA: 0x00036F1A File Offset: 0x0003511A
		public override string calibrateWindow_sensitivitySliderLabel
		{
			get
			{
				return this._calibrateWindow_sensitivitySliderLabel;
			}
		}

		// Token: 0x170003E4 RID: 996
		// (get) Token: 0x06000F84 RID: 3972 RVA: 0x00036F22 File Offset: 0x00035122
		public override string calibrateWindow_invertToggleLabel
		{
			get
			{
				return this._calibrateWindow_invertToggleLabel;
			}
		}

		// Token: 0x170003E5 RID: 997
		// (get) Token: 0x06000F85 RID: 3973 RVA: 0x00036F2A File Offset: 0x0003512A
		public override string calibrateWindow_calibrateButtonLabel
		{
			get
			{
				return this._calibrateWindow_calibrateButtonLabel;
			}
		}

		// Token: 0x06000F86 RID: 3974 RVA: 0x00036F32 File Offset: 0x00035132
		public override string GetControllerAssignmentConflictWindowMessage(string joystickName, string otherPlayerName, string currentPlayerName)
		{
			return string.Format(this._controllerAssignmentConflictWindowMessage, joystickName, otherPlayerName, currentPlayerName);
		}

		// Token: 0x06000F87 RID: 3975 RVA: 0x00036F42 File Offset: 0x00035142
		public override string GetJoystickElementAssignmentPollingWindowMessage(string actionName)
		{
			return string.Format(this._joystickElementAssignmentPollingWindowMessage, actionName);
		}

		// Token: 0x06000F88 RID: 3976 RVA: 0x00036F50 File Offset: 0x00035150
		public override string GetJoystickElementAssignmentPollingWindowMessage_FullAxisFieldOnly(string actionName)
		{
			return string.Format(this._joystickElementAssignmentPollingWindowMessage_fullAxisFieldOnly, actionName);
		}

		// Token: 0x06000F89 RID: 3977 RVA: 0x00036F5E File Offset: 0x0003515E
		public override string GetKeyboardElementAssignmentPollingWindowMessage(string actionName)
		{
			return string.Format(this._keyboardElementAssignmentPollingWindowMessage, actionName);
		}

		// Token: 0x06000F8A RID: 3978 RVA: 0x00036F6C File Offset: 0x0003516C
		public override string GetMouseElementAssignmentPollingWindowMessage(string actionName)
		{
			return string.Format(this._mouseElementAssignmentPollingWindowMessage, actionName);
		}

		// Token: 0x06000F8B RID: 3979 RVA: 0x00036F7A File Offset: 0x0003517A
		public override string GetMouseElementAssignmentPollingWindowMessage_FullAxisFieldOnly(string actionName)
		{
			return string.Format(this._mouseElementAssignmentPollingWindowMessage_fullAxisFieldOnly, actionName);
		}

		// Token: 0x06000F8C RID: 3980 RVA: 0x00036F88 File Offset: 0x00035188
		public override string GetElementAlreadyInUseBlocked(string elementName)
		{
			return string.Format(this._elementAlreadyInUseBlocked, elementName);
		}

		// Token: 0x06000F8D RID: 3981 RVA: 0x00036F96 File Offset: 0x00035196
		public override string GetElementAlreadyInUseCanReplace(string elementName, bool allowConflicts)
		{
			if (!allowConflicts)
			{
				return string.Format(this._elementAlreadyInUseCanReplace, elementName);
			}
			return string.Format(this._elementAlreadyInUseCanReplace_conflictAllowed, elementName);
		}

		// Token: 0x06000F8E RID: 3982 RVA: 0x00036FB4 File Offset: 0x000351B4
		public override string GetMouseAssignmentConflictWindowMessage(string otherPlayerName, string thisPlayerName)
		{
			return string.Format(this._mouseAssignmentConflictWindowMessage, otherPlayerName, thisPlayerName);
		}

		// Token: 0x06000F8F RID: 3983 RVA: 0x00036FC3 File Offset: 0x000351C3
		public override string GetCalibrateAxisStep1WindowMessage(string axisName)
		{
			return string.Format(this._calibrateAxisStep1WindowMessage, axisName);
		}

		// Token: 0x06000F90 RID: 3984 RVA: 0x00036FD1 File Offset: 0x000351D1
		public override string GetCalibrateAxisStep2WindowMessage(string axisName)
		{
			return string.Format(this._calibrateAxisStep2WindowMessage, axisName);
		}

		// Token: 0x06000F91 RID: 3985 RVA: 0x00036FDF File Offset: 0x000351DF
		public override string GetPlayerName(int playerId)
		{
			Player player = ReInput.players.GetPlayer(playerId);
			if (player == null)
			{
				throw new ArgumentException("Invalid player id: " + playerId.ToString());
			}
			return player.descriptiveName;
		}

		// Token: 0x06000F92 RID: 3986 RVA: 0x0003700B File Offset: 0x0003520B
		public override string GetControllerName(Controller controller)
		{
			if (controller == null)
			{
				throw new ArgumentNullException("controller");
			}
			return controller.name;
		}

		// Token: 0x06000F93 RID: 3987 RVA: 0x00037024 File Offset: 0x00035224
		public override string GetElementIdentifierName(ActionElementMap actionElementMap)
		{
			if (actionElementMap == null)
			{
				throw new ArgumentNullException("actionElementMap");
			}
			if (actionElementMap.controllerMap.controllerType == ControllerType.Keyboard)
			{
				return this.GetElementIdentifierName(actionElementMap.keyCode, actionElementMap.modifierKeyFlags);
			}
			return this.GetElementIdentifierName(actionElementMap.controllerMap.controller, actionElementMap.elementIdentifierId, actionElementMap.axisRange);
		}

		// Token: 0x06000F94 RID: 3988 RVA: 0x0003707C File Offset: 0x0003527C
		public override string GetElementIdentifierName(Controller controller, int elementIdentifierId, AxisRange axisRange)
		{
			if (controller == null)
			{
				throw new ArgumentNullException("controller");
			}
			ControllerElementIdentifier elementIdentifierById = controller.GetElementIdentifierById(elementIdentifierId);
			if (elementIdentifierById == null)
			{
				throw new ArgumentException("Invalid element identifier id: " + elementIdentifierId.ToString());
			}
			Controller.Element elementById = controller.GetElementById(elementIdentifierId);
			if (elementById == null)
			{
				return string.Empty;
			}
			ControllerElementType type = elementById.type;
			if (type == ControllerElementType.Axis)
			{
				return elementIdentifierById.GetDisplayName(elementById.type, axisRange);
			}
			if (type != ControllerElementType.Button)
			{
				return elementIdentifierById.name;
			}
			return elementIdentifierById.name;
		}

		// Token: 0x06000F95 RID: 3989 RVA: 0x000370F5 File Offset: 0x000352F5
		public override string GetElementIdentifierName(KeyCode keyCode, ModifierKeyFlags modifierKeyFlags)
		{
			if (modifierKeyFlags != ModifierKeyFlags.None)
			{
				return string.Format("{0}{1}{2}", this.ModifierKeyFlagsToString(modifierKeyFlags), this._modifierKeys.separator, Keyboard.GetKeyName(keyCode));
			}
			return Keyboard.GetKeyName(keyCode);
		}

		// Token: 0x06000F96 RID: 3990 RVA: 0x00037123 File Offset: 0x00035323
		public override string GetActionName(int actionId)
		{
			InputAction action = ReInput.mapping.GetAction(actionId);
			if (action == null)
			{
				throw new ArgumentException("Invalid action id: " + actionId.ToString());
			}
			return action.descriptiveName;
		}

		// Token: 0x06000F97 RID: 3991 RVA: 0x00037150 File Offset: 0x00035350
		public override string GetActionName(int actionId, AxisRange axisRange)
		{
			InputAction action = ReInput.mapping.GetAction(actionId);
			if (action == null)
			{
				throw new ArgumentException("Invalid action id: " + actionId.ToString());
			}
			switch (axisRange)
			{
			case AxisRange.Full:
				return action.descriptiveName;
			case AxisRange.Positive:
				if (string.IsNullOrEmpty(action.positiveDescriptiveName))
				{
					return action.descriptiveName + " +";
				}
				return action.positiveDescriptiveName;
			case AxisRange.Negative:
				if (string.IsNullOrEmpty(action.negativeDescriptiveName))
				{
					return action.descriptiveName + " -";
				}
				return action.negativeDescriptiveName;
			default:
				throw new NotImplementedException();
			}
		}

		// Token: 0x06000F98 RID: 3992 RVA: 0x000371ED File Offset: 0x000353ED
		public override string GetMapCategoryName(int id)
		{
			InputMapCategory mapCategory = ReInput.mapping.GetMapCategory(id);
			if (mapCategory == null)
			{
				throw new ArgumentException("Invalid map category id: " + id.ToString());
			}
			return mapCategory.descriptiveName;
		}

		// Token: 0x06000F99 RID: 3993 RVA: 0x00037219 File Offset: 0x00035419
		public override string GetActionCategoryName(int id)
		{
			InputCategory actionCategory = ReInput.mapping.GetActionCategory(id);
			if (actionCategory == null)
			{
				throw new ArgumentException("Invalid action category id: " + id.ToString());
			}
			return actionCategory.descriptiveName;
		}

		// Token: 0x06000F9A RID: 3994 RVA: 0x00037245 File Offset: 0x00035445
		public override string GetLayoutName(ControllerType controllerType, int id)
		{
			InputLayout layout = ReInput.mapping.GetLayout(controllerType, id);
			if (layout == null)
			{
				throw new ArgumentException("Invalid " + controllerType.ToString() + " layout id: " + id.ToString());
			}
			return layout.descriptiveName;
		}

		// Token: 0x06000F9B RID: 3995 RVA: 0x00037284 File Offset: 0x00035484
		public override string ModifierKeyFlagsToString(ModifierKeyFlags flags)
		{
			int num = 0;
			string text = string.Empty;
			if (Keyboard.ModifierKeyFlagsContain(flags, ModifierKey.Control))
			{
				text += this._modifierKeys.control;
				num++;
			}
			if (Keyboard.ModifierKeyFlagsContain(flags, ModifierKey.Command))
			{
				if (num > 0 && !string.IsNullOrEmpty(this._modifierKeys.separator))
				{
					text += this._modifierKeys.separator;
				}
				text += this._modifierKeys.command;
				num++;
			}
			if (Keyboard.ModifierKeyFlagsContain(flags, ModifierKey.Alt))
			{
				if (num > 0 && !string.IsNullOrEmpty(this._modifierKeys.separator))
				{
					text += this._modifierKeys.separator;
				}
				text += this._modifierKeys.alt;
				num++;
			}
			if (num >= 3)
			{
				return text;
			}
			if (Keyboard.ModifierKeyFlagsContain(flags, ModifierKey.Shift))
			{
				if (num > 0 && !string.IsNullOrEmpty(this._modifierKeys.separator))
				{
					text += this._modifierKeys.separator;
				}
				text += this._modifierKeys.shift;
				num++;
			}
			return text;
		}

		// Token: 0x04000A17 RID: 2583
		[SerializeField]
		private string _yes = "Yes";

		// Token: 0x04000A18 RID: 2584
		[SerializeField]
		private string _no = "No";

		// Token: 0x04000A19 RID: 2585
		[SerializeField]
		private string _add = "Add";

		// Token: 0x04000A1A RID: 2586
		[SerializeField]
		private string _replace = "Replace";

		// Token: 0x04000A1B RID: 2587
		[SerializeField]
		private string _remove = "Remove";

		// Token: 0x04000A1C RID: 2588
		[SerializeField]
		private string _swap = "Swap";

		// Token: 0x04000A1D RID: 2589
		[SerializeField]
		private string _cancel = "Cancel";

		// Token: 0x04000A1E RID: 2590
		[SerializeField]
		private string _none = "None";

		// Token: 0x04000A1F RID: 2591
		[SerializeField]
		private string _okay = "Okay";

		// Token: 0x04000A20 RID: 2592
		[SerializeField]
		private string _done = "Done";

		// Token: 0x04000A21 RID: 2593
		[SerializeField]
		private string _default = "Default";

		// Token: 0x04000A22 RID: 2594
		[SerializeField]
		private string _assignControllerWindowTitle = "Choose Controller";

		// Token: 0x04000A23 RID: 2595
		[SerializeField]
		private string _assignControllerWindowMessage = "Press any button or move an axis on the controller you would like to use.";

		// Token: 0x04000A24 RID: 2596
		[SerializeField]
		private string _controllerAssignmentConflictWindowTitle = "Controller Assignment";

		// Token: 0x04000A25 RID: 2597
		[SerializeField]
		[Tooltip("{0} = Joystick Name\n{1} = Other Player Name\n{2} = This Player Name")]
		private string _controllerAssignmentConflictWindowMessage = "{0} is already assigned to {1}. Do you want to assign this controller to {2} instead?";

		// Token: 0x04000A26 RID: 2598
		[SerializeField]
		private string _elementAssignmentPrePollingWindowMessage = "First center or zero all sticks and axes and press any button or wait for the timer to finish.";

		// Token: 0x04000A27 RID: 2599
		[SerializeField]
		[Tooltip("{0} = Action Name")]
		private string _joystickElementAssignmentPollingWindowMessage = "Now press a button or move an axis to assign it to {0}.";

		// Token: 0x04000A28 RID: 2600
		[SerializeField]
		[Tooltip("This text is only displayed when split-axis fields have been disabled and the user clicks on the full-axis field. Button/key/D-pad input cannot be assigned to a full-axis field.\n{0} = Action Name")]
		private string _joystickElementAssignmentPollingWindowMessage_fullAxisFieldOnly = "Now move an axis to assign it to {0}.";

		// Token: 0x04000A29 RID: 2601
		[SerializeField]
		[Tooltip("{0} = Action Name")]
		private string _keyboardElementAssignmentPollingWindowMessage = "Press a key to assign it to {0}. Modifier keys may also be used. To assign a modifier key alone, hold it down for 1 second.";

		// Token: 0x04000A2A RID: 2602
		[SerializeField]
		[Tooltip("{0} = Action Name")]
		private string _mouseElementAssignmentPollingWindowMessage = "Press a mouse button or move an axis to assign it to {0}.";

		// Token: 0x04000A2B RID: 2603
		[SerializeField]
		[Tooltip("This text is only displayed when split-axis fields have been disabled and the user clicks on the full-axis field. Button/key/D-pad input cannot be assigned to a full-axis field.\n{0} = Action Name")]
		private string _mouseElementAssignmentPollingWindowMessage_fullAxisFieldOnly = "Move an axis to assign it to {0}.";

		// Token: 0x04000A2C RID: 2604
		[SerializeField]
		private string _elementAssignmentConflictWindowMessage = "Assignment Conflict";

		// Token: 0x04000A2D RID: 2605
		[SerializeField]
		[Tooltip("{0} = Element Name")]
		private string _elementAlreadyInUseBlocked = "{0} is already in use cannot be replaced.";

		// Token: 0x04000A2E RID: 2606
		[SerializeField]
		[Tooltip("{0} = Element Name")]
		private string _elementAlreadyInUseCanReplace = "{0} is already in use. Do you want to replace it?";

		// Token: 0x04000A2F RID: 2607
		[SerializeField]
		[Tooltip("{0} = Element Name")]
		private string _elementAlreadyInUseCanReplace_conflictAllowed = "{0} is already in use. Do you want to replace it? You may also choose to add the assignment anyway.";

		// Token: 0x04000A30 RID: 2608
		[SerializeField]
		private string _mouseAssignmentConflictWindowTitle = "Mouse Assignment";

		// Token: 0x04000A31 RID: 2609
		[SerializeField]
		[Tooltip("{0} = Other Player Name\n{1} = This Player Name")]
		private string _mouseAssignmentConflictWindowMessage = "The mouse is already assigned to {0}. Do you want to assign the mouse to {1} instead?";

		// Token: 0x04000A32 RID: 2610
		[SerializeField]
		private string _calibrateControllerWindowTitle = "Calibrate Controller";

		// Token: 0x04000A33 RID: 2611
		[SerializeField]
		private string _calibrateAxisStep1WindowTitle = "Calibrate Zero";

		// Token: 0x04000A34 RID: 2612
		[SerializeField]
		[Tooltip("{0} = Axis Name")]
		private string _calibrateAxisStep1WindowMessage = "Center or zero {0} and press any button or wait for the timer to finish.";

		// Token: 0x04000A35 RID: 2613
		[SerializeField]
		private string _calibrateAxisStep2WindowTitle = "Calibrate Range";

		// Token: 0x04000A36 RID: 2614
		[SerializeField]
		[Tooltip("{0} = Axis Name")]
		private string _calibrateAxisStep2WindowMessage = "Move {0} through its entire range then press any button or wait for the timer to finish.";

		// Token: 0x04000A37 RID: 2615
		[SerializeField]
		private string _inputBehaviorSettingsWindowTitle = "Sensitivity Settings";

		// Token: 0x04000A38 RID: 2616
		[SerializeField]
		private string _restoreDefaultsWindowTitle = "Restore Defaults";

		// Token: 0x04000A39 RID: 2617
		[SerializeField]
		[Tooltip("Message for a single player game.")]
		private string _restoreDefaultsWindowMessage_onePlayer = "This will restore the default input configuration. Are you sure you want to do this?";

		// Token: 0x04000A3A RID: 2618
		[SerializeField]
		[Tooltip("Message for a multi-player game.")]
		private string _restoreDefaultsWindowMessage_multiPlayer = "This will restore the default input configuration for all players. Are you sure you want to do this?";

		// Token: 0x04000A3B RID: 2619
		[SerializeField]
		private string _actionColumnLabel = "Actions";

		// Token: 0x04000A3C RID: 2620
		[SerializeField]
		private string _keyboardColumnLabel = "Keyboard";

		// Token: 0x04000A3D RID: 2621
		[SerializeField]
		private string _mouseColumnLabel = "Mouse";

		// Token: 0x04000A3E RID: 2622
		[SerializeField]
		private string _controllerColumnLabel = "Controller";

		// Token: 0x04000A3F RID: 2623
		[SerializeField]
		private string _removeControllerButtonLabel = "Remove";

		// Token: 0x04000A40 RID: 2624
		[SerializeField]
		private string _calibrateControllerButtonLabel = "Calibrate";

		// Token: 0x04000A41 RID: 2625
		[SerializeField]
		private string _assignControllerButtonLabel = "Assign Controller";

		// Token: 0x04000A42 RID: 2626
		[SerializeField]
		private string _inputBehaviorSettingsButtonLabel = "Sensitivity";

		// Token: 0x04000A43 RID: 2627
		[SerializeField]
		private string _doneButtonLabel = "Done";

		// Token: 0x04000A44 RID: 2628
		[SerializeField]
		private string _restoreDefaultsButtonLabel = "Restore Defaults";

		// Token: 0x04000A45 RID: 2629
		[SerializeField]
		private string _playersGroupLabel = "Players:";

		// Token: 0x04000A46 RID: 2630
		[SerializeField]
		private string _controllerSettingsGroupLabel = "Controller:";

		// Token: 0x04000A47 RID: 2631
		[SerializeField]
		private string _assignedControllersGroupLabel = "Assigned Controllers:";

		// Token: 0x04000A48 RID: 2632
		[SerializeField]
		private string _settingsGroupLabel = "Settings:";

		// Token: 0x04000A49 RID: 2633
		[SerializeField]
		private string _mapCategoriesGroupLabel = "Categories:";

		// Token: 0x04000A4A RID: 2634
		[SerializeField]
		private string _calibrateWindow_deadZoneSliderLabel = "Dead Zone:";

		// Token: 0x04000A4B RID: 2635
		[SerializeField]
		private string _calibrateWindow_zeroSliderLabel = "Zero:";

		// Token: 0x04000A4C RID: 2636
		[SerializeField]
		private string _calibrateWindow_sensitivitySliderLabel = "Sensitivity:";

		// Token: 0x04000A4D RID: 2637
		[SerializeField]
		private string _calibrateWindow_invertToggleLabel = "Invert";

		// Token: 0x04000A4E RID: 2638
		[SerializeField]
		private string _calibrateWindow_calibrateButtonLabel = "Calibrate";

		// Token: 0x04000A4F RID: 2639
		[SerializeField]
		private LanguageData.ModifierKeys _modifierKeys;

		// Token: 0x04000A50 RID: 2640
		[SerializeField]
		private LanguageData.CustomEntry[] _customEntries;

		// Token: 0x04000A51 RID: 2641
		private bool _initialized;

		// Token: 0x04000A52 RID: 2642
		private Dictionary<string, string> customDict;

		// Token: 0x02000270 RID: 624
		[Serializable]
		protected class CustomEntry
		{
			// Token: 0x06001590 RID: 5520 RVA: 0x00049509 File Offset: 0x00047709
			public CustomEntry()
			{
			}

			// Token: 0x06001591 RID: 5521 RVA: 0x00049511 File Offset: 0x00047711
			public CustomEntry(string key, string value)
			{
				this.key = key;
				this.value = value;
			}

			// Token: 0x06001592 RID: 5522 RVA: 0x00049528 File Offset: 0x00047728
			public static Dictionary<string, string> ToDictionary(LanguageData.CustomEntry[] array)
			{
				if (array == null)
				{
					return new Dictionary<string, string>();
				}
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				for (int i = 0; i < array.Length; i++)
				{
					if (array[i] != null && !string.IsNullOrEmpty(array[i].key) && !string.IsNullOrEmpty(array[i].value))
					{
						if (dictionary.ContainsKey(array[i].key))
						{
							Debug.LogError("Key \"" + array[i].key + "\" is already in dictionary!");
						}
						else
						{
							dictionary.Add(array[i].key, array[i].value);
						}
					}
				}
				return dictionary;
			}

			// Token: 0x04000E6F RID: 3695
			public string key;

			// Token: 0x04000E70 RID: 3696
			public string value;
		}

		// Token: 0x02000271 RID: 625
		[Serializable]
		protected class ModifierKeys
		{
			// Token: 0x04000E71 RID: 3697
			public string control = "Control";

			// Token: 0x04000E72 RID: 3698
			public string alt = "Alt";

			// Token: 0x04000E73 RID: 3699
			public string shift = "Shift";

			// Token: 0x04000E74 RID: 3700
			public string command = "Command";

			// Token: 0x04000E75 RID: 3701
			public string separator = " + ";
		}
	}
}
