﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200018A RID: 394
	[AddComponentMenu("")]
	public class CustomToggle : Toggle, ICustomSelectable, ICancelHandler, IEventSystemHandler
	{
		// Token: 0x170003A6 RID: 934
		// (get) Token: 0x06000F06 RID: 3846 RVA: 0x000362B3 File Offset: 0x000344B3
		// (set) Token: 0x06000F07 RID: 3847 RVA: 0x000362BB File Offset: 0x000344BB
		public Sprite disabledHighlightedSprite
		{
			get
			{
				return this._disabledHighlightedSprite;
			}
			set
			{
				this._disabledHighlightedSprite = value;
			}
		}

		// Token: 0x170003A7 RID: 935
		// (get) Token: 0x06000F08 RID: 3848 RVA: 0x000362C4 File Offset: 0x000344C4
		// (set) Token: 0x06000F09 RID: 3849 RVA: 0x000362CC File Offset: 0x000344CC
		public Color disabledHighlightedColor
		{
			get
			{
				return this._disabledHighlightedColor;
			}
			set
			{
				this._disabledHighlightedColor = value;
			}
		}

		// Token: 0x170003A8 RID: 936
		// (get) Token: 0x06000F0A RID: 3850 RVA: 0x000362D5 File Offset: 0x000344D5
		// (set) Token: 0x06000F0B RID: 3851 RVA: 0x000362DD File Offset: 0x000344DD
		public string disabledHighlightedTrigger
		{
			get
			{
				return this._disabledHighlightedTrigger;
			}
			set
			{
				this._disabledHighlightedTrigger = value;
			}
		}

		// Token: 0x170003A9 RID: 937
		// (get) Token: 0x06000F0C RID: 3852 RVA: 0x000362E6 File Offset: 0x000344E6
		// (set) Token: 0x06000F0D RID: 3853 RVA: 0x000362EE File Offset: 0x000344EE
		public bool autoNavUp
		{
			get
			{
				return this._autoNavUp;
			}
			set
			{
				this._autoNavUp = value;
			}
		}

		// Token: 0x170003AA RID: 938
		// (get) Token: 0x06000F0E RID: 3854 RVA: 0x000362F7 File Offset: 0x000344F7
		// (set) Token: 0x06000F0F RID: 3855 RVA: 0x000362FF File Offset: 0x000344FF
		public bool autoNavDown
		{
			get
			{
				return this._autoNavDown;
			}
			set
			{
				this._autoNavDown = value;
			}
		}

		// Token: 0x170003AB RID: 939
		// (get) Token: 0x06000F10 RID: 3856 RVA: 0x00036308 File Offset: 0x00034508
		// (set) Token: 0x06000F11 RID: 3857 RVA: 0x00036310 File Offset: 0x00034510
		public bool autoNavLeft
		{
			get
			{
				return this._autoNavLeft;
			}
			set
			{
				this._autoNavLeft = value;
			}
		}

		// Token: 0x170003AC RID: 940
		// (get) Token: 0x06000F12 RID: 3858 RVA: 0x00036319 File Offset: 0x00034519
		// (set) Token: 0x06000F13 RID: 3859 RVA: 0x00036321 File Offset: 0x00034521
		public bool autoNavRight
		{
			get
			{
				return this._autoNavRight;
			}
			set
			{
				this._autoNavRight = value;
			}
		}

		// Token: 0x170003AD RID: 941
		// (get) Token: 0x06000F14 RID: 3860 RVA: 0x0003632A File Offset: 0x0003452A
		private bool isDisabled
		{
			get
			{
				return !this.IsInteractable();
			}
		}

		// Token: 0x14000017 RID: 23
		// (add) Token: 0x06000F15 RID: 3861 RVA: 0x00036338 File Offset: 0x00034538
		// (remove) Token: 0x06000F16 RID: 3862 RVA: 0x00036370 File Offset: 0x00034570
		private event UnityAction _CancelEvent;

		// Token: 0x14000018 RID: 24
		// (add) Token: 0x06000F17 RID: 3863 RVA: 0x000363A5 File Offset: 0x000345A5
		// (remove) Token: 0x06000F18 RID: 3864 RVA: 0x000363AE File Offset: 0x000345AE
		public event UnityAction CancelEvent
		{
			add
			{
				this._CancelEvent += value;
			}
			remove
			{
				this._CancelEvent -= value;
			}
		}

		// Token: 0x06000F19 RID: 3865 RVA: 0x000363B8 File Offset: 0x000345B8
		public override Selectable FindSelectableOnLeft()
		{
			if ((base.navigation.mode & Navigation.Mode.Horizontal) != Navigation.Mode.None || this._autoNavLeft)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Vector3.left);
			}
			return base.FindSelectableOnLeft();
		}

		// Token: 0x06000F1A RID: 3866 RVA: 0x000363F8 File Offset: 0x000345F8
		public override Selectable FindSelectableOnRight()
		{
			if ((base.navigation.mode & Navigation.Mode.Horizontal) != Navigation.Mode.None || this._autoNavRight)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Vector3.right);
			}
			return base.FindSelectableOnRight();
		}

		// Token: 0x06000F1B RID: 3867 RVA: 0x00036438 File Offset: 0x00034638
		public override Selectable FindSelectableOnUp()
		{
			if ((base.navigation.mode & Navigation.Mode.Vertical) != Navigation.Mode.None || this._autoNavUp)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Vector3.up);
			}
			return base.FindSelectableOnUp();
		}

		// Token: 0x06000F1C RID: 3868 RVA: 0x00036478 File Offset: 0x00034678
		public override Selectable FindSelectableOnDown()
		{
			if ((base.navigation.mode & Navigation.Mode.Vertical) != Navigation.Mode.None || this._autoNavDown)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Vector3.down);
			}
			return base.FindSelectableOnDown();
		}

		// Token: 0x06000F1D RID: 3869 RVA: 0x000364B7 File Offset: 0x000346B7
		protected override void OnCanvasGroupChanged()
		{
			base.OnCanvasGroupChanged();
			if (EventSystem.current == null)
			{
				return;
			}
			this.EvaluateHightlightDisabled(EventSystem.current.currentSelectedGameObject == base.gameObject);
		}

		// Token: 0x06000F1E RID: 3870 RVA: 0x000364E8 File Offset: 0x000346E8
		protected override void DoStateTransition(Selectable.SelectionState state, bool instant)
		{
			if (this.isHighlightDisabled)
			{
				Color disabledHighlightedColor = this._disabledHighlightedColor;
				Sprite disabledHighlightedSprite = this._disabledHighlightedSprite;
				string disabledHighlightedTrigger = this._disabledHighlightedTrigger;
				if (base.gameObject.activeInHierarchy)
				{
					switch (base.transition)
					{
					case Selectable.Transition.ColorTint:
						this.StartColorTween(disabledHighlightedColor * base.colors.colorMultiplier, instant);
						return;
					case Selectable.Transition.SpriteSwap:
						this.DoSpriteSwap(disabledHighlightedSprite);
						return;
					case Selectable.Transition.Animation:
						this.TriggerAnimation(disabledHighlightedTrigger);
						return;
					default:
						return;
					}
				}
			}
			else
			{
				base.DoStateTransition(state, instant);
			}
		}

		// Token: 0x06000F1F RID: 3871 RVA: 0x00036570 File Offset: 0x00034770
		private void StartColorTween(Color targetColor, bool instant)
		{
			if (base.targetGraphic == null)
			{
				return;
			}
			base.targetGraphic.CrossFadeColor(targetColor, instant ? 0f : base.colors.fadeDuration, true, true);
		}

		// Token: 0x06000F20 RID: 3872 RVA: 0x000365B2 File Offset: 0x000347B2
		private void DoSpriteSwap(Sprite newSprite)
		{
			if (base.image == null)
			{
				return;
			}
			base.image.overrideSprite = newSprite;
		}

		// Token: 0x06000F21 RID: 3873 RVA: 0x000365D0 File Offset: 0x000347D0
		private void TriggerAnimation(string triggername)
		{
			if (base.animator == null || !base.animator.enabled || !base.animator.isActiveAndEnabled || base.animator.runtimeAnimatorController == null || string.IsNullOrEmpty(triggername))
			{
				return;
			}
			base.animator.ResetTrigger(this._disabledHighlightedTrigger);
			base.animator.SetTrigger(triggername);
		}

		// Token: 0x06000F22 RID: 3874 RVA: 0x0003663E File Offset: 0x0003483E
		public override void OnSelect(BaseEventData eventData)
		{
			base.OnSelect(eventData);
			this.EvaluateHightlightDisabled(true);
		}

		// Token: 0x06000F23 RID: 3875 RVA: 0x0003664E File Offset: 0x0003484E
		public override void OnDeselect(BaseEventData eventData)
		{
			base.OnDeselect(eventData);
			this.EvaluateHightlightDisabled(false);
		}

		// Token: 0x06000F24 RID: 3876 RVA: 0x00036660 File Offset: 0x00034860
		private void EvaluateHightlightDisabled(bool isSelected)
		{
			if (!isSelected)
			{
				if (this.isHighlightDisabled)
				{
					this.isHighlightDisabled = false;
					Selectable.SelectionState state = this.isDisabled ? Selectable.SelectionState.Disabled : base.currentSelectionState;
					this.DoStateTransition(state, false);
					return;
				}
			}
			else
			{
				if (!this.isDisabled)
				{
					return;
				}
				this.isHighlightDisabled = true;
				this.DoStateTransition(Selectable.SelectionState.Disabled, false);
			}
		}

		// Token: 0x06000F25 RID: 3877 RVA: 0x000366B2 File Offset: 0x000348B2
		public void OnCancel(BaseEventData eventData)
		{
			if (this._CancelEvent != null)
			{
				this._CancelEvent();
			}
		}

		// Token: 0x040009F8 RID: 2552
		[SerializeField]
		private Sprite _disabledHighlightedSprite;

		// Token: 0x040009F9 RID: 2553
		[SerializeField]
		private Color _disabledHighlightedColor;

		// Token: 0x040009FA RID: 2554
		[SerializeField]
		private string _disabledHighlightedTrigger;

		// Token: 0x040009FB RID: 2555
		[SerializeField]
		private bool _autoNavUp = true;

		// Token: 0x040009FC RID: 2556
		[SerializeField]
		private bool _autoNavDown = true;

		// Token: 0x040009FD RID: 2557
		[SerializeField]
		private bool _autoNavLeft = true;

		// Token: 0x040009FE RID: 2558
		[SerializeField]
		private bool _autoNavRight = true;

		// Token: 0x040009FF RID: 2559
		private bool isHighlightDisabled;
	}
}
