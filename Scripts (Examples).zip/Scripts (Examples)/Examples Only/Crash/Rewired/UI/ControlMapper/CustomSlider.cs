﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000189 RID: 393
	[AddComponentMenu("")]
	public class CustomSlider : Slider, ICustomSelectable, ICancelHandler, IEventSystemHandler
	{
		// Token: 0x1700039E RID: 926
		// (get) Token: 0x06000EE5 RID: 3813 RVA: 0x00035E7B File Offset: 0x0003407B
		// (set) Token: 0x06000EE6 RID: 3814 RVA: 0x00035E83 File Offset: 0x00034083
		public Sprite disabledHighlightedSprite
		{
			get
			{
				return this._disabledHighlightedSprite;
			}
			set
			{
				this._disabledHighlightedSprite = value;
			}
		}

		// Token: 0x1700039F RID: 927
		// (get) Token: 0x06000EE7 RID: 3815 RVA: 0x00035E8C File Offset: 0x0003408C
		// (set) Token: 0x06000EE8 RID: 3816 RVA: 0x00035E94 File Offset: 0x00034094
		public Color disabledHighlightedColor
		{
			get
			{
				return this._disabledHighlightedColor;
			}
			set
			{
				this._disabledHighlightedColor = value;
			}
		}

		// Token: 0x170003A0 RID: 928
		// (get) Token: 0x06000EE9 RID: 3817 RVA: 0x00035E9D File Offset: 0x0003409D
		// (set) Token: 0x06000EEA RID: 3818 RVA: 0x00035EA5 File Offset: 0x000340A5
		public string disabledHighlightedTrigger
		{
			get
			{
				return this._disabledHighlightedTrigger;
			}
			set
			{
				this._disabledHighlightedTrigger = value;
			}
		}

		// Token: 0x170003A1 RID: 929
		// (get) Token: 0x06000EEB RID: 3819 RVA: 0x00035EAE File Offset: 0x000340AE
		// (set) Token: 0x06000EEC RID: 3820 RVA: 0x00035EB6 File Offset: 0x000340B6
		public bool autoNavUp
		{
			get
			{
				return this._autoNavUp;
			}
			set
			{
				this._autoNavUp = value;
			}
		}

		// Token: 0x170003A2 RID: 930
		// (get) Token: 0x06000EED RID: 3821 RVA: 0x00035EBF File Offset: 0x000340BF
		// (set) Token: 0x06000EEE RID: 3822 RVA: 0x00035EC7 File Offset: 0x000340C7
		public bool autoNavDown
		{
			get
			{
				return this._autoNavDown;
			}
			set
			{
				this._autoNavDown = value;
			}
		}

		// Token: 0x170003A3 RID: 931
		// (get) Token: 0x06000EEF RID: 3823 RVA: 0x00035ED0 File Offset: 0x000340D0
		// (set) Token: 0x06000EF0 RID: 3824 RVA: 0x00035ED8 File Offset: 0x000340D8
		public bool autoNavLeft
		{
			get
			{
				return this._autoNavLeft;
			}
			set
			{
				this._autoNavLeft = value;
			}
		}

		// Token: 0x170003A4 RID: 932
		// (get) Token: 0x06000EF1 RID: 3825 RVA: 0x00035EE1 File Offset: 0x000340E1
		// (set) Token: 0x06000EF2 RID: 3826 RVA: 0x00035EE9 File Offset: 0x000340E9
		public bool autoNavRight
		{
			get
			{
				return this._autoNavRight;
			}
			set
			{
				this._autoNavRight = value;
			}
		}

		// Token: 0x170003A5 RID: 933
		// (get) Token: 0x06000EF3 RID: 3827 RVA: 0x00035EF2 File Offset: 0x000340F2
		private bool isDisabled
		{
			get
			{
				return !this.IsInteractable();
			}
		}

		// Token: 0x14000015 RID: 21
		// (add) Token: 0x06000EF4 RID: 3828 RVA: 0x00035F00 File Offset: 0x00034100
		// (remove) Token: 0x06000EF5 RID: 3829 RVA: 0x00035F38 File Offset: 0x00034138
		private event UnityAction _CancelEvent;

		// Token: 0x14000016 RID: 22
		// (add) Token: 0x06000EF6 RID: 3830 RVA: 0x00035F6D File Offset: 0x0003416D
		// (remove) Token: 0x06000EF7 RID: 3831 RVA: 0x00035F76 File Offset: 0x00034176
		public event UnityAction CancelEvent
		{
			add
			{
				this._CancelEvent += value;
			}
			remove
			{
				this._CancelEvent -= value;
			}
		}

		// Token: 0x06000EF8 RID: 3832 RVA: 0x00035F80 File Offset: 0x00034180
		public override Selectable FindSelectableOnLeft()
		{
			if ((base.navigation.mode & Navigation.Mode.Horizontal) != Navigation.Mode.None || this._autoNavLeft)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Vector3.left);
			}
			return base.FindSelectableOnLeft();
		}

		// Token: 0x06000EF9 RID: 3833 RVA: 0x00035FC0 File Offset: 0x000341C0
		public override Selectable FindSelectableOnRight()
		{
			if ((base.navigation.mode & Navigation.Mode.Horizontal) != Navigation.Mode.None || this._autoNavRight)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Vector3.right);
			}
			return base.FindSelectableOnRight();
		}

		// Token: 0x06000EFA RID: 3834 RVA: 0x00036000 File Offset: 0x00034200
		public override Selectable FindSelectableOnUp()
		{
			if ((base.navigation.mode & Navigation.Mode.Vertical) != Navigation.Mode.None || this._autoNavUp)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Vector3.up);
			}
			return base.FindSelectableOnUp();
		}

		// Token: 0x06000EFB RID: 3835 RVA: 0x00036040 File Offset: 0x00034240
		public override Selectable FindSelectableOnDown()
		{
			if ((base.navigation.mode & Navigation.Mode.Vertical) != Navigation.Mode.None || this._autoNavDown)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Vector3.down);
			}
			return base.FindSelectableOnDown();
		}

		// Token: 0x06000EFC RID: 3836 RVA: 0x0003607F File Offset: 0x0003427F
		protected override void OnCanvasGroupChanged()
		{
			base.OnCanvasGroupChanged();
			if (EventSystem.current == null)
			{
				return;
			}
			this.EvaluateHightlightDisabled(EventSystem.current.currentSelectedGameObject == base.gameObject);
		}

		// Token: 0x06000EFD RID: 3837 RVA: 0x000360B0 File Offset: 0x000342B0
		protected override void DoStateTransition(Selectable.SelectionState state, bool instant)
		{
			if (this.isHighlightDisabled)
			{
				Color disabledHighlightedColor = this._disabledHighlightedColor;
				Sprite disabledHighlightedSprite = this._disabledHighlightedSprite;
				string disabledHighlightedTrigger = this._disabledHighlightedTrigger;
				if (base.gameObject.activeInHierarchy)
				{
					switch (base.transition)
					{
					case Selectable.Transition.ColorTint:
						this.StartColorTween(disabledHighlightedColor * base.colors.colorMultiplier, instant);
						return;
					case Selectable.Transition.SpriteSwap:
						this.DoSpriteSwap(disabledHighlightedSprite);
						return;
					case Selectable.Transition.Animation:
						this.TriggerAnimation(disabledHighlightedTrigger);
						return;
					default:
						return;
					}
				}
			}
			else
			{
				base.DoStateTransition(state, instant);
			}
		}

		// Token: 0x06000EFE RID: 3838 RVA: 0x00036138 File Offset: 0x00034338
		private void StartColorTween(Color targetColor, bool instant)
		{
			if (base.targetGraphic == null)
			{
				return;
			}
			base.targetGraphic.CrossFadeColor(targetColor, instant ? 0f : base.colors.fadeDuration, true, true);
		}

		// Token: 0x06000EFF RID: 3839 RVA: 0x0003617A File Offset: 0x0003437A
		private void DoSpriteSwap(Sprite newSprite)
		{
			if (base.image == null)
			{
				return;
			}
			base.image.overrideSprite = newSprite;
		}

		// Token: 0x06000F00 RID: 3840 RVA: 0x00036198 File Offset: 0x00034398
		private void TriggerAnimation(string triggername)
		{
			if (base.animator == null || !base.animator.enabled || !base.animator.isActiveAndEnabled || base.animator.runtimeAnimatorController == null || string.IsNullOrEmpty(triggername))
			{
				return;
			}
			base.animator.ResetTrigger(this._disabledHighlightedTrigger);
			base.animator.SetTrigger(triggername);
		}

		// Token: 0x06000F01 RID: 3841 RVA: 0x00036206 File Offset: 0x00034406
		public override void OnSelect(BaseEventData eventData)
		{
			base.OnSelect(eventData);
			this.EvaluateHightlightDisabled(true);
		}

		// Token: 0x06000F02 RID: 3842 RVA: 0x00036216 File Offset: 0x00034416
		public override void OnDeselect(BaseEventData eventData)
		{
			base.OnDeselect(eventData);
			this.EvaluateHightlightDisabled(false);
		}

		// Token: 0x06000F03 RID: 3843 RVA: 0x00036228 File Offset: 0x00034428
		private void EvaluateHightlightDisabled(bool isSelected)
		{
			if (!isSelected)
			{
				if (this.isHighlightDisabled)
				{
					this.isHighlightDisabled = false;
					Selectable.SelectionState state = this.isDisabled ? Selectable.SelectionState.Disabled : base.currentSelectionState;
					this.DoStateTransition(state, false);
					return;
				}
			}
			else
			{
				if (!this.isDisabled)
				{
					return;
				}
				this.isHighlightDisabled = true;
				this.DoStateTransition(Selectable.SelectionState.Disabled, false);
			}
		}

		// Token: 0x06000F04 RID: 3844 RVA: 0x0003627A File Offset: 0x0003447A
		public void OnCancel(BaseEventData eventData)
		{
			if (this._CancelEvent != null)
			{
				this._CancelEvent();
			}
		}

		// Token: 0x040009EF RID: 2543
		[SerializeField]
		private Sprite _disabledHighlightedSprite;

		// Token: 0x040009F0 RID: 2544
		[SerializeField]
		private Color _disabledHighlightedColor;

		// Token: 0x040009F1 RID: 2545
		[SerializeField]
		private string _disabledHighlightedTrigger;

		// Token: 0x040009F2 RID: 2546
		[SerializeField]
		private bool _autoNavUp = true;

		// Token: 0x040009F3 RID: 2547
		[SerializeField]
		private bool _autoNavDown = true;

		// Token: 0x040009F4 RID: 2548
		[SerializeField]
		private bool _autoNavLeft = true;

		// Token: 0x040009F5 RID: 2549
		[SerializeField]
		private bool _autoNavRight = true;

		// Token: 0x040009F6 RID: 2550
		private bool isHighlightDisabled;
	}
}
