﻿using System;
using TMPro;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000196 RID: 406
	[AddComponentMenu("")]
	public class UIControl : MonoBehaviour
	{
		// Token: 0x17000414 RID: 1044
		// (get) Token: 0x06000FF4 RID: 4084 RVA: 0x00037D59 File Offset: 0x00035F59
		public int id
		{
			get
			{
				return this._id;
			}
		}

		// Token: 0x06000FF5 RID: 4085 RVA: 0x00037D61 File Offset: 0x00035F61
		private void Awake()
		{
			this._id = UIControl.GetNextUid();
		}

		// Token: 0x17000415 RID: 1045
		// (get) Token: 0x06000FF6 RID: 4086 RVA: 0x00037D6E File Offset: 0x00035F6E
		// (set) Token: 0x06000FF7 RID: 4087 RVA: 0x00037D76 File Offset: 0x00035F76
		public bool showTitle
		{
			get
			{
				return this._showTitle;
			}
			set
			{
				if (this.title == null)
				{
					return;
				}
				this.title.gameObject.SetActive(value);
				this._showTitle = value;
			}
		}

		// Token: 0x06000FF8 RID: 4088 RVA: 0x00037D9F File Offset: 0x00035F9F
		public virtual void SetCancelCallback(Action cancelCallback)
		{
		}

		// Token: 0x06000FF9 RID: 4089 RVA: 0x00037DA1 File Offset: 0x00035FA1
		private static int GetNextUid()
		{
			if (UIControl._uidCounter == 2147483647)
			{
				UIControl._uidCounter = 0;
			}
			int uidCounter = UIControl._uidCounter;
			UIControl._uidCounter++;
			return uidCounter;
		}

		// Token: 0x04000A6C RID: 2668
		public TMP_Text title;

		// Token: 0x04000A6D RID: 2669
		private int _id;

		// Token: 0x04000A6E RID: 2670
		private bool _showTitle;

		// Token: 0x04000A6F RID: 2671
		private static int _uidCounter;
	}
}
