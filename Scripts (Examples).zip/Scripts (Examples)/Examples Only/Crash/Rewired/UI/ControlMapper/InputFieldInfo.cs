﻿using System;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200018D RID: 397
	[AddComponentMenu("")]
	public class InputFieldInfo : UIElementInfo
	{
		// Token: 0x170003B5 RID: 949
		// (get) Token: 0x06000F48 RID: 3912 RVA: 0x00036C98 File Offset: 0x00034E98
		// (set) Token: 0x06000F49 RID: 3913 RVA: 0x00036CA0 File Offset: 0x00034EA0
		public int actionId { get; set; }

		// Token: 0x170003B6 RID: 950
		// (get) Token: 0x06000F4A RID: 3914 RVA: 0x00036CA9 File Offset: 0x00034EA9
		// (set) Token: 0x06000F4B RID: 3915 RVA: 0x00036CB1 File Offset: 0x00034EB1
		public AxisRange axisRange { get; set; }

		// Token: 0x170003B7 RID: 951
		// (get) Token: 0x06000F4C RID: 3916 RVA: 0x00036CBA File Offset: 0x00034EBA
		// (set) Token: 0x06000F4D RID: 3917 RVA: 0x00036CC2 File Offset: 0x00034EC2
		public int actionElementMapId { get; set; }

		// Token: 0x170003B8 RID: 952
		// (get) Token: 0x06000F4E RID: 3918 RVA: 0x00036CCB File Offset: 0x00034ECB
		// (set) Token: 0x06000F4F RID: 3919 RVA: 0x00036CD3 File Offset: 0x00034ED3
		public ControllerType controllerType { get; set; }

		// Token: 0x170003B9 RID: 953
		// (get) Token: 0x06000F50 RID: 3920 RVA: 0x00036CDC File Offset: 0x00034EDC
		// (set) Token: 0x06000F51 RID: 3921 RVA: 0x00036CE4 File Offset: 0x00034EE4
		public int controllerId { get; set; }
	}
}
