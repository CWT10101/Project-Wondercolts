﻿using System;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000190 RID: 400
	[Serializable]
	public abstract class LanguageDataBase : ScriptableObject
	{
		// Token: 0x06000F9D RID: 3997
		public abstract void Initialize();

		// Token: 0x06000F9E RID: 3998
		public abstract string GetCustomEntry(string key);

		// Token: 0x06000F9F RID: 3999
		public abstract bool ContainsCustomEntryKey(string key);

		// Token: 0x170003E6 RID: 998
		// (get) Token: 0x06000FA0 RID: 4000
		public abstract string yes { get; }

		// Token: 0x170003E7 RID: 999
		// (get) Token: 0x06000FA1 RID: 4001
		public abstract string no { get; }

		// Token: 0x170003E8 RID: 1000
		// (get) Token: 0x06000FA2 RID: 4002
		public abstract string add { get; }

		// Token: 0x170003E9 RID: 1001
		// (get) Token: 0x06000FA3 RID: 4003
		public abstract string replace { get; }

		// Token: 0x170003EA RID: 1002
		// (get) Token: 0x06000FA4 RID: 4004
		public abstract string remove { get; }

		// Token: 0x170003EB RID: 1003
		// (get) Token: 0x06000FA5 RID: 4005
		public abstract string swap { get; }

		// Token: 0x170003EC RID: 1004
		// (get) Token: 0x06000FA6 RID: 4006
		public abstract string cancel { get; }

		// Token: 0x170003ED RID: 1005
		// (get) Token: 0x06000FA7 RID: 4007
		public abstract string none { get; }

		// Token: 0x170003EE RID: 1006
		// (get) Token: 0x06000FA8 RID: 4008
		public abstract string okay { get; }

		// Token: 0x170003EF RID: 1007
		// (get) Token: 0x06000FA9 RID: 4009
		public abstract string done { get; }

		// Token: 0x170003F0 RID: 1008
		// (get) Token: 0x06000FAA RID: 4010
		public abstract string default_ { get; }

		// Token: 0x170003F1 RID: 1009
		// (get) Token: 0x06000FAB RID: 4011
		public abstract string assignControllerWindowTitle { get; }

		// Token: 0x170003F2 RID: 1010
		// (get) Token: 0x06000FAC RID: 4012
		public abstract string assignControllerWindowMessage { get; }

		// Token: 0x170003F3 RID: 1011
		// (get) Token: 0x06000FAD RID: 4013
		public abstract string controllerAssignmentConflictWindowTitle { get; }

		// Token: 0x170003F4 RID: 1012
		// (get) Token: 0x06000FAE RID: 4014
		public abstract string elementAssignmentPrePollingWindowMessage { get; }

		// Token: 0x170003F5 RID: 1013
		// (get) Token: 0x06000FAF RID: 4015
		public abstract string elementAssignmentConflictWindowMessage { get; }

		// Token: 0x170003F6 RID: 1014
		// (get) Token: 0x06000FB0 RID: 4016
		public abstract string mouseAssignmentConflictWindowTitle { get; }

		// Token: 0x170003F7 RID: 1015
		// (get) Token: 0x06000FB1 RID: 4017
		public abstract string calibrateControllerWindowTitle { get; }

		// Token: 0x170003F8 RID: 1016
		// (get) Token: 0x06000FB2 RID: 4018
		public abstract string calibrateAxisStep1WindowTitle { get; }

		// Token: 0x170003F9 RID: 1017
		// (get) Token: 0x06000FB3 RID: 4019
		public abstract string calibrateAxisStep2WindowTitle { get; }

		// Token: 0x170003FA RID: 1018
		// (get) Token: 0x06000FB4 RID: 4020
		public abstract string inputBehaviorSettingsWindowTitle { get; }

		// Token: 0x170003FB RID: 1019
		// (get) Token: 0x06000FB5 RID: 4021
		public abstract string restoreDefaultsWindowTitle { get; }

		// Token: 0x170003FC RID: 1020
		// (get) Token: 0x06000FB6 RID: 4022
		public abstract string actionColumnLabel { get; }

		// Token: 0x170003FD RID: 1021
		// (get) Token: 0x06000FB7 RID: 4023
		public abstract string keyboardColumnLabel { get; }

		// Token: 0x170003FE RID: 1022
		// (get) Token: 0x06000FB8 RID: 4024
		public abstract string mouseColumnLabel { get; }

		// Token: 0x170003FF RID: 1023
		// (get) Token: 0x06000FB9 RID: 4025
		public abstract string controllerColumnLabel { get; }

		// Token: 0x17000400 RID: 1024
		// (get) Token: 0x06000FBA RID: 4026
		public abstract string removeControllerButtonLabel { get; }

		// Token: 0x17000401 RID: 1025
		// (get) Token: 0x06000FBB RID: 4027
		public abstract string calibrateControllerButtonLabel { get; }

		// Token: 0x17000402 RID: 1026
		// (get) Token: 0x06000FBC RID: 4028
		public abstract string assignControllerButtonLabel { get; }

		// Token: 0x17000403 RID: 1027
		// (get) Token: 0x06000FBD RID: 4029
		public abstract string inputBehaviorSettingsButtonLabel { get; }

		// Token: 0x17000404 RID: 1028
		// (get) Token: 0x06000FBE RID: 4030
		public abstract string doneButtonLabel { get; }

		// Token: 0x17000405 RID: 1029
		// (get) Token: 0x06000FBF RID: 4031
		public abstract string restoreDefaultsButtonLabel { get; }

		// Token: 0x17000406 RID: 1030
		// (get) Token: 0x06000FC0 RID: 4032
		public abstract string controllerSettingsGroupLabel { get; }

		// Token: 0x17000407 RID: 1031
		// (get) Token: 0x06000FC1 RID: 4033
		public abstract string playersGroupLabel { get; }

		// Token: 0x17000408 RID: 1032
		// (get) Token: 0x06000FC2 RID: 4034
		public abstract string assignedControllersGroupLabel { get; }

		// Token: 0x17000409 RID: 1033
		// (get) Token: 0x06000FC3 RID: 4035
		public abstract string settingsGroupLabel { get; }

		// Token: 0x1700040A RID: 1034
		// (get) Token: 0x06000FC4 RID: 4036
		public abstract string mapCategoriesGroupLabel { get; }

		// Token: 0x1700040B RID: 1035
		// (get) Token: 0x06000FC5 RID: 4037
		public abstract string restoreDefaultsWindowMessage { get; }

		// Token: 0x1700040C RID: 1036
		// (get) Token: 0x06000FC6 RID: 4038
		public abstract string calibrateWindow_deadZoneSliderLabel { get; }

		// Token: 0x1700040D RID: 1037
		// (get) Token: 0x06000FC7 RID: 4039
		public abstract string calibrateWindow_zeroSliderLabel { get; }

		// Token: 0x1700040E RID: 1038
		// (get) Token: 0x06000FC8 RID: 4040
		public abstract string calibrateWindow_sensitivitySliderLabel { get; }

		// Token: 0x1700040F RID: 1039
		// (get) Token: 0x06000FC9 RID: 4041
		public abstract string calibrateWindow_invertToggleLabel { get; }

		// Token: 0x17000410 RID: 1040
		// (get) Token: 0x06000FCA RID: 4042
		public abstract string calibrateWindow_calibrateButtonLabel { get; }

		// Token: 0x06000FCB RID: 4043
		public abstract string GetControllerAssignmentConflictWindowMessage(string joystickName, string otherPlayerName, string currentPlayerName);

		// Token: 0x06000FCC RID: 4044
		public abstract string GetJoystickElementAssignmentPollingWindowMessage(string actionName);

		// Token: 0x06000FCD RID: 4045
		public abstract string GetJoystickElementAssignmentPollingWindowMessage_FullAxisFieldOnly(string actionName);

		// Token: 0x06000FCE RID: 4046
		public abstract string GetKeyboardElementAssignmentPollingWindowMessage(string actionName);

		// Token: 0x06000FCF RID: 4047
		public abstract string GetMouseElementAssignmentPollingWindowMessage(string actionName);

		// Token: 0x06000FD0 RID: 4048
		public abstract string GetMouseElementAssignmentPollingWindowMessage_FullAxisFieldOnly(string actionName);

		// Token: 0x06000FD1 RID: 4049
		public abstract string GetElementAlreadyInUseBlocked(string elementName);

		// Token: 0x06000FD2 RID: 4050
		public abstract string GetElementAlreadyInUseCanReplace(string elementName, bool allowConflicts);

		// Token: 0x06000FD3 RID: 4051
		public abstract string GetMouseAssignmentConflictWindowMessage(string otherPlayerName, string thisPlayerName);

		// Token: 0x06000FD4 RID: 4052
		public abstract string GetCalibrateAxisStep1WindowMessage(string axisName);

		// Token: 0x06000FD5 RID: 4053
		public abstract string GetCalibrateAxisStep2WindowMessage(string axisName);

		// Token: 0x06000FD6 RID: 4054
		public abstract string GetPlayerName(int playerId);

		// Token: 0x06000FD7 RID: 4055
		public abstract string GetControllerName(Controller controller);

		// Token: 0x06000FD8 RID: 4056
		public abstract string GetElementIdentifierName(ActionElementMap actionElementMap);

		// Token: 0x06000FD9 RID: 4057
		public abstract string GetElementIdentifierName(Controller controller, int elementIdentifierId, AxisRange axisRange);

		// Token: 0x06000FDA RID: 4058
		public abstract string GetElementIdentifierName(KeyCode keyCode, ModifierKeyFlags modifierKeyFlags);

		// Token: 0x06000FDB RID: 4059
		public abstract string GetActionName(int actionId);

		// Token: 0x06000FDC RID: 4060
		public abstract string GetActionName(int actionId, AxisRange axisRange);

		// Token: 0x06000FDD RID: 4061
		public abstract string GetMapCategoryName(int id);

		// Token: 0x06000FDE RID: 4062
		public abstract string GetActionCategoryName(int id);

		// Token: 0x06000FDF RID: 4063
		public abstract string GetLayoutName(ControllerType controllerType, int id);

		// Token: 0x06000FE0 RID: 4064
		public abstract string ModifierKeyFlagsToString(ModifierKeyFlags flags);
	}
}
