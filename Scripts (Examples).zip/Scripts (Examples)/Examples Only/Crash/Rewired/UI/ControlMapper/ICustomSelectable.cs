﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200018B RID: 395
	public interface ICustomSelectable : ICancelHandler, IEventSystemHandler
	{
		// Token: 0x170003AE RID: 942
		// (get) Token: 0x06000F27 RID: 3879
		// (set) Token: 0x06000F28 RID: 3880
		Sprite disabledHighlightedSprite { get; set; }

		// Token: 0x170003AF RID: 943
		// (get) Token: 0x06000F29 RID: 3881
		// (set) Token: 0x06000F2A RID: 3882
		Color disabledHighlightedColor { get; set; }

		// Token: 0x170003B0 RID: 944
		// (get) Token: 0x06000F2B RID: 3883
		// (set) Token: 0x06000F2C RID: 3884
		string disabledHighlightedTrigger { get; set; }

		// Token: 0x170003B1 RID: 945
		// (get) Token: 0x06000F2D RID: 3885
		// (set) Token: 0x06000F2E RID: 3886
		bool autoNavUp { get; set; }

		// Token: 0x170003B2 RID: 946
		// (get) Token: 0x06000F2F RID: 3887
		// (set) Token: 0x06000F30 RID: 3888
		bool autoNavDown { get; set; }

		// Token: 0x170003B3 RID: 947
		// (get) Token: 0x06000F31 RID: 3889
		// (set) Token: 0x06000F32 RID: 3890
		bool autoNavLeft { get; set; }

		// Token: 0x170003B4 RID: 948
		// (get) Token: 0x06000F33 RID: 3891
		// (set) Token: 0x06000F34 RID: 3892
		bool autoNavRight { get; set; }

		// Token: 0x14000019 RID: 25
		// (add) Token: 0x06000F35 RID: 3893
		// (remove) Token: 0x06000F36 RID: 3894
		event UnityAction CancelEvent;
	}
}
