﻿using System;
using TMPro;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000199 RID: 409
	[AddComponentMenu("")]
	public class UIGroup : MonoBehaviour
	{
		// Token: 0x17000417 RID: 1047
		// (get) Token: 0x06001004 RID: 4100 RVA: 0x00038000 File Offset: 0x00036200
		// (set) Token: 0x06001005 RID: 4101 RVA: 0x00038021 File Offset: 0x00036221
		public string labelText
		{
			get
			{
				if (!(this._label != null))
				{
					return string.Empty;
				}
				return this._label.text;
			}
			set
			{
				if (this._label == null)
				{
					return;
				}
				this._label.text = value;
			}
		}

		// Token: 0x17000418 RID: 1048
		// (get) Token: 0x06001006 RID: 4102 RVA: 0x0003803E File Offset: 0x0003623E
		public Transform content
		{
			get
			{
				return this._content;
			}
		}

		// Token: 0x06001007 RID: 4103 RVA: 0x00038046 File Offset: 0x00036246
		public void SetLabelActive(bool state)
		{
			if (this._label == null)
			{
				return;
			}
			this._label.gameObject.SetActive(state);
		}

		// Token: 0x04000A76 RID: 2678
		[SerializeField]
		private TMP_Text _label;

		// Token: 0x04000A77 RID: 2679
		[SerializeField]
		private Transform _content;
	}
}
