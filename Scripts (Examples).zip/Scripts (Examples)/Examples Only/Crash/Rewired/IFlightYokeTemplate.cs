﻿using System;

namespace Rewired
{
	// Token: 0x02000171 RID: 369
	public interface IFlightYokeTemplate : IControllerTemplate
	{
		// Token: 0x170001CB RID: 459
		// (get) Token: 0x06000B04 RID: 2820
		IControllerTemplateButton leftPaddle { get; }

		// Token: 0x170001CC RID: 460
		// (get) Token: 0x06000B05 RID: 2821
		IControllerTemplateButton rightPaddle { get; }

		// Token: 0x170001CD RID: 461
		// (get) Token: 0x06000B06 RID: 2822
		IControllerTemplateButton leftGripButton1 { get; }

		// Token: 0x170001CE RID: 462
		// (get) Token: 0x06000B07 RID: 2823
		IControllerTemplateButton leftGripButton2 { get; }

		// Token: 0x170001CF RID: 463
		// (get) Token: 0x06000B08 RID: 2824
		IControllerTemplateButton leftGripButton3 { get; }

		// Token: 0x170001D0 RID: 464
		// (get) Token: 0x06000B09 RID: 2825
		IControllerTemplateButton leftGripButton4 { get; }

		// Token: 0x170001D1 RID: 465
		// (get) Token: 0x06000B0A RID: 2826
		IControllerTemplateButton leftGripButton5 { get; }

		// Token: 0x170001D2 RID: 466
		// (get) Token: 0x06000B0B RID: 2827
		IControllerTemplateButton leftGripButton6 { get; }

		// Token: 0x170001D3 RID: 467
		// (get) Token: 0x06000B0C RID: 2828
		IControllerTemplateButton rightGripButton1 { get; }

		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x06000B0D RID: 2829
		IControllerTemplateButton rightGripButton2 { get; }

		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x06000B0E RID: 2830
		IControllerTemplateButton rightGripButton3 { get; }

		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x06000B0F RID: 2831
		IControllerTemplateButton rightGripButton4 { get; }

		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x06000B10 RID: 2832
		IControllerTemplateButton rightGripButton5 { get; }

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x06000B11 RID: 2833
		IControllerTemplateButton rightGripButton6 { get; }

		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x06000B12 RID: 2834
		IControllerTemplateButton centerButton1 { get; }

		// Token: 0x170001DA RID: 474
		// (get) Token: 0x06000B13 RID: 2835
		IControllerTemplateButton centerButton2 { get; }

		// Token: 0x170001DB RID: 475
		// (get) Token: 0x06000B14 RID: 2836
		IControllerTemplateButton centerButton3 { get; }

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x06000B15 RID: 2837
		IControllerTemplateButton centerButton4 { get; }

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x06000B16 RID: 2838
		IControllerTemplateButton centerButton5 { get; }

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x06000B17 RID: 2839
		IControllerTemplateButton centerButton6 { get; }

		// Token: 0x170001DF RID: 479
		// (get) Token: 0x06000B18 RID: 2840
		IControllerTemplateButton centerButton7 { get; }

		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x06000B19 RID: 2841
		IControllerTemplateButton centerButton8 { get; }

		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x06000B1A RID: 2842
		IControllerTemplateButton wheel1Up { get; }

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x06000B1B RID: 2843
		IControllerTemplateButton wheel1Down { get; }

		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x06000B1C RID: 2844
		IControllerTemplateButton wheel1Press { get; }

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x06000B1D RID: 2845
		IControllerTemplateButton wheel2Up { get; }

		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x06000B1E RID: 2846
		IControllerTemplateButton wheel2Down { get; }

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x06000B1F RID: 2847
		IControllerTemplateButton wheel2Press { get; }

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x06000B20 RID: 2848
		IControllerTemplateButton consoleButton1 { get; }

		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x06000B21 RID: 2849
		IControllerTemplateButton consoleButton2 { get; }

		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x06000B22 RID: 2850
		IControllerTemplateButton consoleButton3 { get; }

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x06000B23 RID: 2851
		IControllerTemplateButton consoleButton4 { get; }

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x06000B24 RID: 2852
		IControllerTemplateButton consoleButton5 { get; }

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x06000B25 RID: 2853
		IControllerTemplateButton consoleButton6 { get; }

		// Token: 0x170001ED RID: 493
		// (get) Token: 0x06000B26 RID: 2854
		IControllerTemplateButton consoleButton7 { get; }

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x06000B27 RID: 2855
		IControllerTemplateButton consoleButton8 { get; }

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x06000B28 RID: 2856
		IControllerTemplateButton consoleButton9 { get; }

		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x06000B29 RID: 2857
		IControllerTemplateButton consoleButton10 { get; }

		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x06000B2A RID: 2858
		IControllerTemplateButton mode1 { get; }

		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x06000B2B RID: 2859
		IControllerTemplateButton mode2 { get; }

		// Token: 0x170001F3 RID: 499
		// (get) Token: 0x06000B2C RID: 2860
		IControllerTemplateButton mode3 { get; }

		// Token: 0x170001F4 RID: 500
		// (get) Token: 0x06000B2D RID: 2861
		IControllerTemplateYoke yoke { get; }

		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x06000B2E RID: 2862
		IControllerTemplateThrottle lever1 { get; }

		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x06000B2F RID: 2863
		IControllerTemplateThrottle lever2 { get; }

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x06000B30 RID: 2864
		IControllerTemplateThrottle lever3 { get; }

		// Token: 0x170001F8 RID: 504
		// (get) Token: 0x06000B31 RID: 2865
		IControllerTemplateThrottle lever4 { get; }

		// Token: 0x170001F9 RID: 505
		// (get) Token: 0x06000B32 RID: 2866
		IControllerTemplateThrottle lever5 { get; }

		// Token: 0x170001FA RID: 506
		// (get) Token: 0x06000B33 RID: 2867
		IControllerTemplateHat leftGripHat { get; }

		// Token: 0x170001FB RID: 507
		// (get) Token: 0x06000B34 RID: 2868
		IControllerTemplateHat rightGripHat { get; }
	}
}
