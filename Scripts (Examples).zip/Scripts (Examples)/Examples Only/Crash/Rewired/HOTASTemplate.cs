﻿using System;

namespace Rewired
{
	// Token: 0x02000176 RID: 374
	public sealed class HOTASTemplate : ControllerTemplate, IHOTASTemplate, IControllerTemplate
	{
		// Token: 0x1700026F RID: 623
		// (get) Token: 0x06000BAC RID: 2988 RVA: 0x00029895 File Offset: 0x00027A95
		IControllerTemplateButton IHOTASTemplate.stickTrigger
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(3);
			}
		}

		// Token: 0x17000270 RID: 624
		// (get) Token: 0x06000BAD RID: 2989 RVA: 0x0002989E File Offset: 0x00027A9E
		IControllerTemplateButton IHOTASTemplate.stickTriggerStage2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(4);
			}
		}

		// Token: 0x17000271 RID: 625
		// (get) Token: 0x06000BAE RID: 2990 RVA: 0x000298A7 File Offset: 0x00027AA7
		IControllerTemplateButton IHOTASTemplate.stickPinkyButton
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(5);
			}
		}

		// Token: 0x17000272 RID: 626
		// (get) Token: 0x06000BAF RID: 2991 RVA: 0x000298B0 File Offset: 0x00027AB0
		IControllerTemplateButton IHOTASTemplate.stickPinkyTrigger
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(154);
			}
		}

		// Token: 0x17000273 RID: 627
		// (get) Token: 0x06000BB0 RID: 2992 RVA: 0x000298BD File Offset: 0x00027ABD
		IControllerTemplateButton IHOTASTemplate.stickButton1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(6);
			}
		}

		// Token: 0x17000274 RID: 628
		// (get) Token: 0x06000BB1 RID: 2993 RVA: 0x000298C6 File Offset: 0x00027AC6
		IControllerTemplateButton IHOTASTemplate.stickButton2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(7);
			}
		}

		// Token: 0x17000275 RID: 629
		// (get) Token: 0x06000BB2 RID: 2994 RVA: 0x000298CF File Offset: 0x00027ACF
		IControllerTemplateButton IHOTASTemplate.stickButton3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(8);
			}
		}

		// Token: 0x17000276 RID: 630
		// (get) Token: 0x06000BB3 RID: 2995 RVA: 0x000298D8 File Offset: 0x00027AD8
		IControllerTemplateButton IHOTASTemplate.stickButton4
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(9);
			}
		}

		// Token: 0x17000277 RID: 631
		// (get) Token: 0x06000BB4 RID: 2996 RVA: 0x000298E2 File Offset: 0x00027AE2
		IControllerTemplateButton IHOTASTemplate.stickButton5
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(10);
			}
		}

		// Token: 0x17000278 RID: 632
		// (get) Token: 0x06000BB5 RID: 2997 RVA: 0x000298EC File Offset: 0x00027AEC
		IControllerTemplateButton IHOTASTemplate.stickButton6
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(11);
			}
		}

		// Token: 0x17000279 RID: 633
		// (get) Token: 0x06000BB6 RID: 2998 RVA: 0x000298F6 File Offset: 0x00027AF6
		IControllerTemplateButton IHOTASTemplate.stickButton7
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(12);
			}
		}

		// Token: 0x1700027A RID: 634
		// (get) Token: 0x06000BB7 RID: 2999 RVA: 0x00029900 File Offset: 0x00027B00
		IControllerTemplateButton IHOTASTemplate.stickButton8
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(13);
			}
		}

		// Token: 0x1700027B RID: 635
		// (get) Token: 0x06000BB8 RID: 3000 RVA: 0x0002990A File Offset: 0x00027B0A
		IControllerTemplateButton IHOTASTemplate.stickButton9
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(14);
			}
		}

		// Token: 0x1700027C RID: 636
		// (get) Token: 0x06000BB9 RID: 3001 RVA: 0x00029914 File Offset: 0x00027B14
		IControllerTemplateButton IHOTASTemplate.stickButton10
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(15);
			}
		}

		// Token: 0x1700027D RID: 637
		// (get) Token: 0x06000BBA RID: 3002 RVA: 0x0002991E File Offset: 0x00027B1E
		IControllerTemplateButton IHOTASTemplate.stickBaseButton1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(18);
			}
		}

		// Token: 0x1700027E RID: 638
		// (get) Token: 0x06000BBB RID: 3003 RVA: 0x00029928 File Offset: 0x00027B28
		IControllerTemplateButton IHOTASTemplate.stickBaseButton2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(19);
			}
		}

		// Token: 0x1700027F RID: 639
		// (get) Token: 0x06000BBC RID: 3004 RVA: 0x00029932 File Offset: 0x00027B32
		IControllerTemplateButton IHOTASTemplate.stickBaseButton3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(20);
			}
		}

		// Token: 0x17000280 RID: 640
		// (get) Token: 0x06000BBD RID: 3005 RVA: 0x0002993C File Offset: 0x00027B3C
		IControllerTemplateButton IHOTASTemplate.stickBaseButton4
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(21);
			}
		}

		// Token: 0x17000281 RID: 641
		// (get) Token: 0x06000BBE RID: 3006 RVA: 0x00029946 File Offset: 0x00027B46
		IControllerTemplateButton IHOTASTemplate.stickBaseButton5
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(22);
			}
		}

		// Token: 0x17000282 RID: 642
		// (get) Token: 0x06000BBF RID: 3007 RVA: 0x00029950 File Offset: 0x00027B50
		IControllerTemplateButton IHOTASTemplate.stickBaseButton6
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(23);
			}
		}

		// Token: 0x17000283 RID: 643
		// (get) Token: 0x06000BC0 RID: 3008 RVA: 0x0002995A File Offset: 0x00027B5A
		IControllerTemplateButton IHOTASTemplate.stickBaseButton7
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(24);
			}
		}

		// Token: 0x17000284 RID: 644
		// (get) Token: 0x06000BC1 RID: 3009 RVA: 0x00029964 File Offset: 0x00027B64
		IControllerTemplateButton IHOTASTemplate.stickBaseButton8
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(25);
			}
		}

		// Token: 0x17000285 RID: 645
		// (get) Token: 0x06000BC2 RID: 3010 RVA: 0x0002996E File Offset: 0x00027B6E
		IControllerTemplateButton IHOTASTemplate.stickBaseButton9
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(26);
			}
		}

		// Token: 0x17000286 RID: 646
		// (get) Token: 0x06000BC3 RID: 3011 RVA: 0x00029978 File Offset: 0x00027B78
		IControllerTemplateButton IHOTASTemplate.stickBaseButton10
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(27);
			}
		}

		// Token: 0x17000287 RID: 647
		// (get) Token: 0x06000BC4 RID: 3012 RVA: 0x00029982 File Offset: 0x00027B82
		IControllerTemplateButton IHOTASTemplate.stickBaseButton11
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(161);
			}
		}

		// Token: 0x17000288 RID: 648
		// (get) Token: 0x06000BC5 RID: 3013 RVA: 0x0002998F File Offset: 0x00027B8F
		IControllerTemplateButton IHOTASTemplate.stickBaseButton12
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(162);
			}
		}

		// Token: 0x17000289 RID: 649
		// (get) Token: 0x06000BC6 RID: 3014 RVA: 0x0002999C File Offset: 0x00027B9C
		IControllerTemplateButton IHOTASTemplate.mode1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(44);
			}
		}

		// Token: 0x1700028A RID: 650
		// (get) Token: 0x06000BC7 RID: 3015 RVA: 0x000299A6 File Offset: 0x00027BA6
		IControllerTemplateButton IHOTASTemplate.mode2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(45);
			}
		}

		// Token: 0x1700028B RID: 651
		// (get) Token: 0x06000BC8 RID: 3016 RVA: 0x000299B0 File Offset: 0x00027BB0
		IControllerTemplateButton IHOTASTemplate.mode3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(46);
			}
		}

		// Token: 0x1700028C RID: 652
		// (get) Token: 0x06000BC9 RID: 3017 RVA: 0x000299BA File Offset: 0x00027BBA
		IControllerTemplateButton IHOTASTemplate.throttleButton1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(50);
			}
		}

		// Token: 0x1700028D RID: 653
		// (get) Token: 0x06000BCA RID: 3018 RVA: 0x000299C4 File Offset: 0x00027BC4
		IControllerTemplateButton IHOTASTemplate.throttleButton2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(51);
			}
		}

		// Token: 0x1700028E RID: 654
		// (get) Token: 0x06000BCB RID: 3019 RVA: 0x000299CE File Offset: 0x00027BCE
		IControllerTemplateButton IHOTASTemplate.throttleButton3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(52);
			}
		}

		// Token: 0x1700028F RID: 655
		// (get) Token: 0x06000BCC RID: 3020 RVA: 0x000299D8 File Offset: 0x00027BD8
		IControllerTemplateButton IHOTASTemplate.throttleButton4
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(53);
			}
		}

		// Token: 0x17000290 RID: 656
		// (get) Token: 0x06000BCD RID: 3021 RVA: 0x000299E2 File Offset: 0x00027BE2
		IControllerTemplateButton IHOTASTemplate.throttleButton5
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(54);
			}
		}

		// Token: 0x17000291 RID: 657
		// (get) Token: 0x06000BCE RID: 3022 RVA: 0x000299EC File Offset: 0x00027BEC
		IControllerTemplateButton IHOTASTemplate.throttleButton6
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(55);
			}
		}

		// Token: 0x17000292 RID: 658
		// (get) Token: 0x06000BCF RID: 3023 RVA: 0x000299F6 File Offset: 0x00027BF6
		IControllerTemplateButton IHOTASTemplate.throttleButton7
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(56);
			}
		}

		// Token: 0x17000293 RID: 659
		// (get) Token: 0x06000BD0 RID: 3024 RVA: 0x00029A00 File Offset: 0x00027C00
		IControllerTemplateButton IHOTASTemplate.throttleButton8
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(57);
			}
		}

		// Token: 0x17000294 RID: 660
		// (get) Token: 0x06000BD1 RID: 3025 RVA: 0x00029A0A File Offset: 0x00027C0A
		IControllerTemplateButton IHOTASTemplate.throttleButton9
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(58);
			}
		}

		// Token: 0x17000295 RID: 661
		// (get) Token: 0x06000BD2 RID: 3026 RVA: 0x00029A14 File Offset: 0x00027C14
		IControllerTemplateButton IHOTASTemplate.throttleButton10
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(59);
			}
		}

		// Token: 0x17000296 RID: 662
		// (get) Token: 0x06000BD3 RID: 3027 RVA: 0x00029A1E File Offset: 0x00027C1E
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(60);
			}
		}

		// Token: 0x17000297 RID: 663
		// (get) Token: 0x06000BD4 RID: 3028 RVA: 0x00029A28 File Offset: 0x00027C28
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(61);
			}
		}

		// Token: 0x17000298 RID: 664
		// (get) Token: 0x06000BD5 RID: 3029 RVA: 0x00029A32 File Offset: 0x00027C32
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(62);
			}
		}

		// Token: 0x17000299 RID: 665
		// (get) Token: 0x06000BD6 RID: 3030 RVA: 0x00029A3C File Offset: 0x00027C3C
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton4
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(63);
			}
		}

		// Token: 0x1700029A RID: 666
		// (get) Token: 0x06000BD7 RID: 3031 RVA: 0x00029A46 File Offset: 0x00027C46
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton5
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(64);
			}
		}

		// Token: 0x1700029B RID: 667
		// (get) Token: 0x06000BD8 RID: 3032 RVA: 0x00029A50 File Offset: 0x00027C50
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton6
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(65);
			}
		}

		// Token: 0x1700029C RID: 668
		// (get) Token: 0x06000BD9 RID: 3033 RVA: 0x00029A5A File Offset: 0x00027C5A
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton7
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(66);
			}
		}

		// Token: 0x1700029D RID: 669
		// (get) Token: 0x06000BDA RID: 3034 RVA: 0x00029A64 File Offset: 0x00027C64
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton8
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(67);
			}
		}

		// Token: 0x1700029E RID: 670
		// (get) Token: 0x06000BDB RID: 3035 RVA: 0x00029A6E File Offset: 0x00027C6E
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton9
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(68);
			}
		}

		// Token: 0x1700029F RID: 671
		// (get) Token: 0x06000BDC RID: 3036 RVA: 0x00029A78 File Offset: 0x00027C78
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton10
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(69);
			}
		}

		// Token: 0x170002A0 RID: 672
		// (get) Token: 0x06000BDD RID: 3037 RVA: 0x00029A82 File Offset: 0x00027C82
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton11
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(132);
			}
		}

		// Token: 0x170002A1 RID: 673
		// (get) Token: 0x06000BDE RID: 3038 RVA: 0x00029A8F File Offset: 0x00027C8F
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton12
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(133);
			}
		}

		// Token: 0x170002A2 RID: 674
		// (get) Token: 0x06000BDF RID: 3039 RVA: 0x00029A9C File Offset: 0x00027C9C
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton13
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(134);
			}
		}

		// Token: 0x170002A3 RID: 675
		// (get) Token: 0x06000BE0 RID: 3040 RVA: 0x00029AA9 File Offset: 0x00027CA9
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton14
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(135);
			}
		}

		// Token: 0x170002A4 RID: 676
		// (get) Token: 0x06000BE1 RID: 3041 RVA: 0x00029AB6 File Offset: 0x00027CB6
		IControllerTemplateButton IHOTASTemplate.throttleBaseButton15
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(136);
			}
		}

		// Token: 0x170002A5 RID: 677
		// (get) Token: 0x06000BE2 RID: 3042 RVA: 0x00029AC3 File Offset: 0x00027CC3
		IControllerTemplateAxis IHOTASTemplate.throttleSlider1
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(70);
			}
		}

		// Token: 0x170002A6 RID: 678
		// (get) Token: 0x06000BE3 RID: 3043 RVA: 0x00029ACD File Offset: 0x00027CCD
		IControllerTemplateAxis IHOTASTemplate.throttleSlider2
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(71);
			}
		}

		// Token: 0x170002A7 RID: 679
		// (get) Token: 0x06000BE4 RID: 3044 RVA: 0x00029AD7 File Offset: 0x00027CD7
		IControllerTemplateAxis IHOTASTemplate.throttleSlider3
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(72);
			}
		}

		// Token: 0x170002A8 RID: 680
		// (get) Token: 0x06000BE5 RID: 3045 RVA: 0x00029AE1 File Offset: 0x00027CE1
		IControllerTemplateAxis IHOTASTemplate.throttleSlider4
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(73);
			}
		}

		// Token: 0x170002A9 RID: 681
		// (get) Token: 0x06000BE6 RID: 3046 RVA: 0x00029AEB File Offset: 0x00027CEB
		IControllerTemplateAxis IHOTASTemplate.throttleDial1
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(74);
			}
		}

		// Token: 0x170002AA RID: 682
		// (get) Token: 0x06000BE7 RID: 3047 RVA: 0x00029AF5 File Offset: 0x00027CF5
		IControllerTemplateAxis IHOTASTemplate.throttleDial2
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(142);
			}
		}

		// Token: 0x170002AB RID: 683
		// (get) Token: 0x06000BE8 RID: 3048 RVA: 0x00029B02 File Offset: 0x00027D02
		IControllerTemplateAxis IHOTASTemplate.throttleDial3
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(143);
			}
		}

		// Token: 0x170002AC RID: 684
		// (get) Token: 0x06000BE9 RID: 3049 RVA: 0x00029B0F File Offset: 0x00027D0F
		IControllerTemplateAxis IHOTASTemplate.throttleDial4
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(144);
			}
		}

		// Token: 0x170002AD RID: 685
		// (get) Token: 0x06000BEA RID: 3050 RVA: 0x00029B1C File Offset: 0x00027D1C
		IControllerTemplateButton IHOTASTemplate.throttleWheel1Forward
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(145);
			}
		}

		// Token: 0x170002AE RID: 686
		// (get) Token: 0x06000BEB RID: 3051 RVA: 0x00029B29 File Offset: 0x00027D29
		IControllerTemplateButton IHOTASTemplate.throttleWheel1Back
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(146);
			}
		}

		// Token: 0x170002AF RID: 687
		// (get) Token: 0x06000BEC RID: 3052 RVA: 0x00029B36 File Offset: 0x00027D36
		IControllerTemplateButton IHOTASTemplate.throttleWheel1Press
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(147);
			}
		}

		// Token: 0x170002B0 RID: 688
		// (get) Token: 0x06000BED RID: 3053 RVA: 0x00029B43 File Offset: 0x00027D43
		IControllerTemplateButton IHOTASTemplate.throttleWheel2Forward
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(148);
			}
		}

		// Token: 0x170002B1 RID: 689
		// (get) Token: 0x06000BEE RID: 3054 RVA: 0x00029B50 File Offset: 0x00027D50
		IControllerTemplateButton IHOTASTemplate.throttleWheel2Back
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(149);
			}
		}

		// Token: 0x170002B2 RID: 690
		// (get) Token: 0x06000BEF RID: 3055 RVA: 0x00029B5D File Offset: 0x00027D5D
		IControllerTemplateButton IHOTASTemplate.throttleWheel2Press
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(150);
			}
		}

		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x06000BF0 RID: 3056 RVA: 0x00029B6A File Offset: 0x00027D6A
		IControllerTemplateButton IHOTASTemplate.throttleWheel3Forward
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(151);
			}
		}

		// Token: 0x170002B4 RID: 692
		// (get) Token: 0x06000BF1 RID: 3057 RVA: 0x00029B77 File Offset: 0x00027D77
		IControllerTemplateButton IHOTASTemplate.throttleWheel3Back
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(152);
			}
		}

		// Token: 0x170002B5 RID: 693
		// (get) Token: 0x06000BF2 RID: 3058 RVA: 0x00029B84 File Offset: 0x00027D84
		IControllerTemplateButton IHOTASTemplate.throttleWheel3Press
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(153);
			}
		}

		// Token: 0x170002B6 RID: 694
		// (get) Token: 0x06000BF3 RID: 3059 RVA: 0x00029B91 File Offset: 0x00027D91
		IControllerTemplateAxis IHOTASTemplate.leftPedal
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(168);
			}
		}

		// Token: 0x170002B7 RID: 695
		// (get) Token: 0x06000BF4 RID: 3060 RVA: 0x00029B9E File Offset: 0x00027D9E
		IControllerTemplateAxis IHOTASTemplate.rightPedal
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(169);
			}
		}

		// Token: 0x170002B8 RID: 696
		// (get) Token: 0x06000BF5 RID: 3061 RVA: 0x00029BAB File Offset: 0x00027DAB
		IControllerTemplateAxis IHOTASTemplate.slidePedals
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(170);
			}
		}

		// Token: 0x170002B9 RID: 697
		// (get) Token: 0x06000BF6 RID: 3062 RVA: 0x00029BB8 File Offset: 0x00027DB8
		IControllerTemplateStick IHOTASTemplate.stick
		{
			get
			{
				return base.GetElement<IControllerTemplateStick>(171);
			}
		}

		// Token: 0x170002BA RID: 698
		// (get) Token: 0x06000BF7 RID: 3063 RVA: 0x00029BC5 File Offset: 0x00027DC5
		IControllerTemplateThumbStick IHOTASTemplate.stickMiniStick1
		{
			get
			{
				return base.GetElement<IControllerTemplateThumbStick>(172);
			}
		}

		// Token: 0x170002BB RID: 699
		// (get) Token: 0x06000BF8 RID: 3064 RVA: 0x00029BD2 File Offset: 0x00027DD2
		IControllerTemplateThumbStick IHOTASTemplate.stickMiniStick2
		{
			get
			{
				return base.GetElement<IControllerTemplateThumbStick>(173);
			}
		}

		// Token: 0x170002BC RID: 700
		// (get) Token: 0x06000BF9 RID: 3065 RVA: 0x00029BDF File Offset: 0x00027DDF
		IControllerTemplateHat IHOTASTemplate.stickHat1
		{
			get
			{
				return base.GetElement<IControllerTemplateHat>(174);
			}
		}

		// Token: 0x170002BD RID: 701
		// (get) Token: 0x06000BFA RID: 3066 RVA: 0x00029BEC File Offset: 0x00027DEC
		IControllerTemplateHat IHOTASTemplate.stickHat2
		{
			get
			{
				return base.GetElement<IControllerTemplateHat>(175);
			}
		}

		// Token: 0x170002BE RID: 702
		// (get) Token: 0x06000BFB RID: 3067 RVA: 0x00029BF9 File Offset: 0x00027DF9
		IControllerTemplateHat IHOTASTemplate.stickHat3
		{
			get
			{
				return base.GetElement<IControllerTemplateHat>(176);
			}
		}

		// Token: 0x170002BF RID: 703
		// (get) Token: 0x06000BFC RID: 3068 RVA: 0x00029C06 File Offset: 0x00027E06
		IControllerTemplateHat IHOTASTemplate.stickHat4
		{
			get
			{
				return base.GetElement<IControllerTemplateHat>(177);
			}
		}

		// Token: 0x170002C0 RID: 704
		// (get) Token: 0x06000BFD RID: 3069 RVA: 0x00029C13 File Offset: 0x00027E13
		IControllerTemplateThrottle IHOTASTemplate.throttle1
		{
			get
			{
				return base.GetElement<IControllerTemplateThrottle>(178);
			}
		}

		// Token: 0x170002C1 RID: 705
		// (get) Token: 0x06000BFE RID: 3070 RVA: 0x00029C20 File Offset: 0x00027E20
		IControllerTemplateThrottle IHOTASTemplate.throttle2
		{
			get
			{
				return base.GetElement<IControllerTemplateThrottle>(179);
			}
		}

		// Token: 0x170002C2 RID: 706
		// (get) Token: 0x06000BFF RID: 3071 RVA: 0x00029C2D File Offset: 0x00027E2D
		IControllerTemplateThumbStick IHOTASTemplate.throttleMiniStick
		{
			get
			{
				return base.GetElement<IControllerTemplateThumbStick>(180);
			}
		}

		// Token: 0x170002C3 RID: 707
		// (get) Token: 0x06000C00 RID: 3072 RVA: 0x00029C3A File Offset: 0x00027E3A
		IControllerTemplateHat IHOTASTemplate.throttleHat1
		{
			get
			{
				return base.GetElement<IControllerTemplateHat>(181);
			}
		}

		// Token: 0x170002C4 RID: 708
		// (get) Token: 0x06000C01 RID: 3073 RVA: 0x00029C47 File Offset: 0x00027E47
		IControllerTemplateHat IHOTASTemplate.throttleHat2
		{
			get
			{
				return base.GetElement<IControllerTemplateHat>(182);
			}
		}

		// Token: 0x170002C5 RID: 709
		// (get) Token: 0x06000C02 RID: 3074 RVA: 0x00029C54 File Offset: 0x00027E54
		IControllerTemplateHat IHOTASTemplate.throttleHat3
		{
			get
			{
				return base.GetElement<IControllerTemplateHat>(183);
			}
		}

		// Token: 0x170002C6 RID: 710
		// (get) Token: 0x06000C03 RID: 3075 RVA: 0x00029C61 File Offset: 0x00027E61
		IControllerTemplateHat IHOTASTemplate.throttleHat4
		{
			get
			{
				return base.GetElement<IControllerTemplateHat>(184);
			}
		}

		// Token: 0x06000C04 RID: 3076 RVA: 0x00029C6E File Offset: 0x00027E6E
		public HOTASTemplate(object payload) : base(payload)
		{
		}

		// Token: 0x040007C2 RID: 1986
		public static readonly Guid typeGuid = new Guid("061a00cf-d8c2-4f8d-8cb5-a15a010bc53e");

		// Token: 0x040007C3 RID: 1987
		public const int elementId_stickX = 0;

		// Token: 0x040007C4 RID: 1988
		public const int elementId_stickY = 1;

		// Token: 0x040007C5 RID: 1989
		public const int elementId_stickRotate = 2;

		// Token: 0x040007C6 RID: 1990
		public const int elementId_stickMiniStick1X = 78;

		// Token: 0x040007C7 RID: 1991
		public const int elementId_stickMiniStick1Y = 79;

		// Token: 0x040007C8 RID: 1992
		public const int elementId_stickMiniStick1Press = 80;

		// Token: 0x040007C9 RID: 1993
		public const int elementId_stickMiniStick2X = 81;

		// Token: 0x040007CA RID: 1994
		public const int elementId_stickMiniStick2Y = 82;

		// Token: 0x040007CB RID: 1995
		public const int elementId_stickMiniStick2Press = 83;

		// Token: 0x040007CC RID: 1996
		public const int elementId_stickTrigger = 3;

		// Token: 0x040007CD RID: 1997
		public const int elementId_stickTriggerStage2 = 4;

		// Token: 0x040007CE RID: 1998
		public const int elementId_stickPinkyButton = 5;

		// Token: 0x040007CF RID: 1999
		public const int elementId_stickPinkyTrigger = 154;

		// Token: 0x040007D0 RID: 2000
		public const int elementId_stickButton1 = 6;

		// Token: 0x040007D1 RID: 2001
		public const int elementId_stickButton2 = 7;

		// Token: 0x040007D2 RID: 2002
		public const int elementId_stickButton3 = 8;

		// Token: 0x040007D3 RID: 2003
		public const int elementId_stickButton4 = 9;

		// Token: 0x040007D4 RID: 2004
		public const int elementId_stickButton5 = 10;

		// Token: 0x040007D5 RID: 2005
		public const int elementId_stickButton6 = 11;

		// Token: 0x040007D6 RID: 2006
		public const int elementId_stickButton7 = 12;

		// Token: 0x040007D7 RID: 2007
		public const int elementId_stickButton8 = 13;

		// Token: 0x040007D8 RID: 2008
		public const int elementId_stickButton9 = 14;

		// Token: 0x040007D9 RID: 2009
		public const int elementId_stickButton10 = 15;

		// Token: 0x040007DA RID: 2010
		public const int elementId_stickBaseButton1 = 18;

		// Token: 0x040007DB RID: 2011
		public const int elementId_stickBaseButton2 = 19;

		// Token: 0x040007DC RID: 2012
		public const int elementId_stickBaseButton3 = 20;

		// Token: 0x040007DD RID: 2013
		public const int elementId_stickBaseButton4 = 21;

		// Token: 0x040007DE RID: 2014
		public const int elementId_stickBaseButton5 = 22;

		// Token: 0x040007DF RID: 2015
		public const int elementId_stickBaseButton6 = 23;

		// Token: 0x040007E0 RID: 2016
		public const int elementId_stickBaseButton7 = 24;

		// Token: 0x040007E1 RID: 2017
		public const int elementId_stickBaseButton8 = 25;

		// Token: 0x040007E2 RID: 2018
		public const int elementId_stickBaseButton9 = 26;

		// Token: 0x040007E3 RID: 2019
		public const int elementId_stickBaseButton10 = 27;

		// Token: 0x040007E4 RID: 2020
		public const int elementId_stickBaseButton11 = 161;

		// Token: 0x040007E5 RID: 2021
		public const int elementId_stickBaseButton12 = 162;

		// Token: 0x040007E6 RID: 2022
		public const int elementId_stickHat1Up = 28;

		// Token: 0x040007E7 RID: 2023
		public const int elementId_stickHat1UpRight = 29;

		// Token: 0x040007E8 RID: 2024
		public const int elementId_stickHat1Right = 30;

		// Token: 0x040007E9 RID: 2025
		public const int elementId_stickHat1DownRight = 31;

		// Token: 0x040007EA RID: 2026
		public const int elementId_stickHat1Down = 32;

		// Token: 0x040007EB RID: 2027
		public const int elementId_stickHat1DownLeft = 33;

		// Token: 0x040007EC RID: 2028
		public const int elementId_stickHat1Left = 34;

		// Token: 0x040007ED RID: 2029
		public const int elementId_stickHat1Up_Left = 35;

		// Token: 0x040007EE RID: 2030
		public const int elementId_stickHat2Up = 36;

		// Token: 0x040007EF RID: 2031
		public const int elementId_stickHat2Up_right = 37;

		// Token: 0x040007F0 RID: 2032
		public const int elementId_stickHat2Right = 38;

		// Token: 0x040007F1 RID: 2033
		public const int elementId_stickHat2Down_Right = 39;

		// Token: 0x040007F2 RID: 2034
		public const int elementId_stickHat2Down = 40;

		// Token: 0x040007F3 RID: 2035
		public const int elementId_stickHat2Down_Left = 41;

		// Token: 0x040007F4 RID: 2036
		public const int elementId_stickHat2Left = 42;

		// Token: 0x040007F5 RID: 2037
		public const int elementId_stickHat2Up_Left = 43;

		// Token: 0x040007F6 RID: 2038
		public const int elementId_stickHat3Up = 84;

		// Token: 0x040007F7 RID: 2039
		public const int elementId_stickHat3Up_Right = 85;

		// Token: 0x040007F8 RID: 2040
		public const int elementId_stickHat3Right = 86;

		// Token: 0x040007F9 RID: 2041
		public const int elementId_stickHat3Down_Right = 87;

		// Token: 0x040007FA RID: 2042
		public const int elementId_stickHat3Down = 88;

		// Token: 0x040007FB RID: 2043
		public const int elementId_stickHat3Down_Left = 89;

		// Token: 0x040007FC RID: 2044
		public const int elementId_stickHat3Left = 90;

		// Token: 0x040007FD RID: 2045
		public const int elementId_stickHat3Up_Left = 91;

		// Token: 0x040007FE RID: 2046
		public const int elementId_stickHat4Up = 92;

		// Token: 0x040007FF RID: 2047
		public const int elementId_stickHat4Up_Right = 93;

		// Token: 0x04000800 RID: 2048
		public const int elementId_stickHat4Right = 94;

		// Token: 0x04000801 RID: 2049
		public const int elementId_stickHat4Down_Right = 95;

		// Token: 0x04000802 RID: 2050
		public const int elementId_stickHat4Down = 96;

		// Token: 0x04000803 RID: 2051
		public const int elementId_stickHat4Down_Left = 97;

		// Token: 0x04000804 RID: 2052
		public const int elementId_stickHat4Left = 98;

		// Token: 0x04000805 RID: 2053
		public const int elementId_stickHat4Up_Left = 99;

		// Token: 0x04000806 RID: 2054
		public const int elementId_mode1 = 44;

		// Token: 0x04000807 RID: 2055
		public const int elementId_mode2 = 45;

		// Token: 0x04000808 RID: 2056
		public const int elementId_mode3 = 46;

		// Token: 0x04000809 RID: 2057
		public const int elementId_throttle1Axis = 49;

		// Token: 0x0400080A RID: 2058
		public const int elementId_throttle2Axis = 155;

		// Token: 0x0400080B RID: 2059
		public const int elementId_throttle1MinDetent = 166;

		// Token: 0x0400080C RID: 2060
		public const int elementId_throttle2MinDetent = 167;

		// Token: 0x0400080D RID: 2061
		public const int elementId_throttleButton1 = 50;

		// Token: 0x0400080E RID: 2062
		public const int elementId_throttleButton2 = 51;

		// Token: 0x0400080F RID: 2063
		public const int elementId_throttleButton3 = 52;

		// Token: 0x04000810 RID: 2064
		public const int elementId_throttleButton4 = 53;

		// Token: 0x04000811 RID: 2065
		public const int elementId_throttleButton5 = 54;

		// Token: 0x04000812 RID: 2066
		public const int elementId_throttleButton6 = 55;

		// Token: 0x04000813 RID: 2067
		public const int elementId_throttleButton7 = 56;

		// Token: 0x04000814 RID: 2068
		public const int elementId_throttleButton8 = 57;

		// Token: 0x04000815 RID: 2069
		public const int elementId_throttleButton9 = 58;

		// Token: 0x04000816 RID: 2070
		public const int elementId_throttleButton10 = 59;

		// Token: 0x04000817 RID: 2071
		public const int elementId_throttleBaseButton1 = 60;

		// Token: 0x04000818 RID: 2072
		public const int elementId_throttleBaseButton2 = 61;

		// Token: 0x04000819 RID: 2073
		public const int elementId_throttleBaseButton3 = 62;

		// Token: 0x0400081A RID: 2074
		public const int elementId_throttleBaseButton4 = 63;

		// Token: 0x0400081B RID: 2075
		public const int elementId_throttleBaseButton5 = 64;

		// Token: 0x0400081C RID: 2076
		public const int elementId_throttleBaseButton6 = 65;

		// Token: 0x0400081D RID: 2077
		public const int elementId_throttleBaseButton7 = 66;

		// Token: 0x0400081E RID: 2078
		public const int elementId_throttleBaseButton8 = 67;

		// Token: 0x0400081F RID: 2079
		public const int elementId_throttleBaseButton9 = 68;

		// Token: 0x04000820 RID: 2080
		public const int elementId_throttleBaseButton10 = 69;

		// Token: 0x04000821 RID: 2081
		public const int elementId_throttleBaseButton11 = 132;

		// Token: 0x04000822 RID: 2082
		public const int elementId_throttleBaseButton12 = 133;

		// Token: 0x04000823 RID: 2083
		public const int elementId_throttleBaseButton13 = 134;

		// Token: 0x04000824 RID: 2084
		public const int elementId_throttleBaseButton14 = 135;

		// Token: 0x04000825 RID: 2085
		public const int elementId_throttleBaseButton15 = 136;

		// Token: 0x04000826 RID: 2086
		public const int elementId_throttleSlider1 = 70;

		// Token: 0x04000827 RID: 2087
		public const int elementId_throttleSlider2 = 71;

		// Token: 0x04000828 RID: 2088
		public const int elementId_throttleSlider3 = 72;

		// Token: 0x04000829 RID: 2089
		public const int elementId_throttleSlider4 = 73;

		// Token: 0x0400082A RID: 2090
		public const int elementId_throttleDial1 = 74;

		// Token: 0x0400082B RID: 2091
		public const int elementId_throttleDial2 = 142;

		// Token: 0x0400082C RID: 2092
		public const int elementId_throttleDial3 = 143;

		// Token: 0x0400082D RID: 2093
		public const int elementId_throttleDial4 = 144;

		// Token: 0x0400082E RID: 2094
		public const int elementId_throttleMiniStickX = 75;

		// Token: 0x0400082F RID: 2095
		public const int elementId_throttleMiniStickY = 76;

		// Token: 0x04000830 RID: 2096
		public const int elementId_throttleMiniStickPress = 77;

		// Token: 0x04000831 RID: 2097
		public const int elementId_throttleWheel1Forward = 145;

		// Token: 0x04000832 RID: 2098
		public const int elementId_throttleWheel1Back = 146;

		// Token: 0x04000833 RID: 2099
		public const int elementId_throttleWheel1Press = 147;

		// Token: 0x04000834 RID: 2100
		public const int elementId_throttleWheel2Forward = 148;

		// Token: 0x04000835 RID: 2101
		public const int elementId_throttleWheel2Back = 149;

		// Token: 0x04000836 RID: 2102
		public const int elementId_throttleWheel2Press = 150;

		// Token: 0x04000837 RID: 2103
		public const int elementId_throttleWheel3Forward = 151;

		// Token: 0x04000838 RID: 2104
		public const int elementId_throttleWheel3Back = 152;

		// Token: 0x04000839 RID: 2105
		public const int elementId_throttleWheel3Press = 153;

		// Token: 0x0400083A RID: 2106
		public const int elementId_throttleHat1Up = 100;

		// Token: 0x0400083B RID: 2107
		public const int elementId_throttleHat1Up_Right = 101;

		// Token: 0x0400083C RID: 2108
		public const int elementId_throttleHat1Right = 102;

		// Token: 0x0400083D RID: 2109
		public const int elementId_throttleHat1Down_Right = 103;

		// Token: 0x0400083E RID: 2110
		public const int elementId_throttleHat1Down = 104;

		// Token: 0x0400083F RID: 2111
		public const int elementId_throttleHat1Down_Left = 105;

		// Token: 0x04000840 RID: 2112
		public const int elementId_throttleHat1Left = 106;

		// Token: 0x04000841 RID: 2113
		public const int elementId_throttleHat1Up_Left = 107;

		// Token: 0x04000842 RID: 2114
		public const int elementId_throttleHat2Up = 108;

		// Token: 0x04000843 RID: 2115
		public const int elementId_throttleHat2Up_Right = 109;

		// Token: 0x04000844 RID: 2116
		public const int elementId_throttleHat2Right = 110;

		// Token: 0x04000845 RID: 2117
		public const int elementId_throttleHat2Down_Right = 111;

		// Token: 0x04000846 RID: 2118
		public const int elementId_throttleHat2Down = 112;

		// Token: 0x04000847 RID: 2119
		public const int elementId_throttleHat2Down_Left = 113;

		// Token: 0x04000848 RID: 2120
		public const int elementId_throttleHat2Left = 114;

		// Token: 0x04000849 RID: 2121
		public const int elementId_throttleHat2Up_Left = 115;

		// Token: 0x0400084A RID: 2122
		public const int elementId_throttleHat3Up = 116;

		// Token: 0x0400084B RID: 2123
		public const int elementId_throttleHat3Up_Right = 117;

		// Token: 0x0400084C RID: 2124
		public const int elementId_throttleHat3Right = 118;

		// Token: 0x0400084D RID: 2125
		public const int elementId_throttleHat3Down_Right = 119;

		// Token: 0x0400084E RID: 2126
		public const int elementId_throttleHat3Down = 120;

		// Token: 0x0400084F RID: 2127
		public const int elementId_throttleHat3Down_Left = 121;

		// Token: 0x04000850 RID: 2128
		public const int elementId_throttleHat3Left = 122;

		// Token: 0x04000851 RID: 2129
		public const int elementId_throttleHat3Up_Left = 123;

		// Token: 0x04000852 RID: 2130
		public const int elementId_throttleHat4Up = 124;

		// Token: 0x04000853 RID: 2131
		public const int elementId_throttleHat4Up_Right = 125;

		// Token: 0x04000854 RID: 2132
		public const int elementId_throttleHat4Right = 126;

		// Token: 0x04000855 RID: 2133
		public const int elementId_throttleHat4Down_Right = 127;

		// Token: 0x04000856 RID: 2134
		public const int elementId_throttleHat4Down = 128;

		// Token: 0x04000857 RID: 2135
		public const int elementId_throttleHat4Down_Left = 129;

		// Token: 0x04000858 RID: 2136
		public const int elementId_throttleHat4Left = 130;

		// Token: 0x04000859 RID: 2137
		public const int elementId_throttleHat4Up_Left = 131;

		// Token: 0x0400085A RID: 2138
		public const int elementId_leftPedal = 168;

		// Token: 0x0400085B RID: 2139
		public const int elementId_rightPedal = 169;

		// Token: 0x0400085C RID: 2140
		public const int elementId_slidePedals = 170;

		// Token: 0x0400085D RID: 2141
		public const int elementId_stick = 171;

		// Token: 0x0400085E RID: 2142
		public const int elementId_stickMiniStick1 = 172;

		// Token: 0x0400085F RID: 2143
		public const int elementId_stickMiniStick2 = 173;

		// Token: 0x04000860 RID: 2144
		public const int elementId_stickHat1 = 174;

		// Token: 0x04000861 RID: 2145
		public const int elementId_stickHat2 = 175;

		// Token: 0x04000862 RID: 2146
		public const int elementId_stickHat3 = 176;

		// Token: 0x04000863 RID: 2147
		public const int elementId_stickHat4 = 177;

		// Token: 0x04000864 RID: 2148
		public const int elementId_throttle1 = 178;

		// Token: 0x04000865 RID: 2149
		public const int elementId_throttle2 = 179;

		// Token: 0x04000866 RID: 2150
		public const int elementId_throttleMiniStick = 180;

		// Token: 0x04000867 RID: 2151
		public const int elementId_throttleHat1 = 181;

		// Token: 0x04000868 RID: 2152
		public const int elementId_throttleHat2 = 182;

		// Token: 0x04000869 RID: 2153
		public const int elementId_throttleHat3 = 183;

		// Token: 0x0400086A RID: 2154
		public const int elementId_throttleHat4 = 184;
	}
}
