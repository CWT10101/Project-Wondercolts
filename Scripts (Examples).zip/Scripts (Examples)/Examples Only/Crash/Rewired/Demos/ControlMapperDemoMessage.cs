﻿using System;
using System.Collections;
using Rewired.UI.ControlMapper;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.Demos
{
	// Token: 0x0200019F RID: 415
	[AddComponentMenu("")]
	public class ControlMapperDemoMessage : MonoBehaviour
	{
		// Token: 0x0600104A RID: 4170 RVA: 0x00038F65 File Offset: 0x00037165
		private void Awake()
		{
			if (this.controlMapper != null)
			{
				this.controlMapper.ScreenClosedEvent += this.OnControlMapperClosed;
				this.controlMapper.ScreenOpenedEvent += this.OnControlMapperOpened;
			}
		}

		// Token: 0x0600104B RID: 4171 RVA: 0x00038FA3 File Offset: 0x000371A3
		private void Start()
		{
			this.SelectDefault();
		}

		// Token: 0x0600104C RID: 4172 RVA: 0x00038FAB File Offset: 0x000371AB
		private void OnControlMapperClosed()
		{
			base.gameObject.SetActive(true);
			base.StartCoroutine(this.SelectDefaultDeferred());
		}

		// Token: 0x0600104D RID: 4173 RVA: 0x00038FC6 File Offset: 0x000371C6
		private void OnControlMapperOpened()
		{
			base.gameObject.SetActive(false);
		}

		// Token: 0x0600104E RID: 4174 RVA: 0x00038FD4 File Offset: 0x000371D4
		private void SelectDefault()
		{
			if (EventSystem.current == null)
			{
				return;
			}
			if (this.defaultSelectable != null)
			{
				EventSystem.current.SetSelectedGameObject(this.defaultSelectable.gameObject);
			}
		}

		// Token: 0x0600104F RID: 4175 RVA: 0x00039007 File Offset: 0x00037207
		private IEnumerator SelectDefaultDeferred()
		{
			yield return null;
			this.SelectDefault();
			yield break;
		}

		// Token: 0x04000A8E RID: 2702
		public ControlMapper controlMapper;

		// Token: 0x04000A8F RID: 2703
		public Selectable defaultSelectable;
	}
}
