﻿using System;

namespace Rewired
{
	// Token: 0x02000174 RID: 372
	public sealed class GamepadTemplate : ControllerTemplate, IGamepadTemplate, IControllerTemplate
	{
		// Token: 0x17000228 RID: 552
		// (get) Token: 0x06000B61 RID: 2913 RVA: 0x000295AE File Offset: 0x000277AE
		IControllerTemplateButton IGamepadTemplate.actionBottomRow1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(4);
			}
		}

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x06000B62 RID: 2914 RVA: 0x000295B7 File Offset: 0x000277B7
		IControllerTemplateButton IGamepadTemplate.a
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(4);
			}
		}

		// Token: 0x1700022A RID: 554
		// (get) Token: 0x06000B63 RID: 2915 RVA: 0x000295C0 File Offset: 0x000277C0
		IControllerTemplateButton IGamepadTemplate.actionBottomRow2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(5);
			}
		}

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x06000B64 RID: 2916 RVA: 0x000295C9 File Offset: 0x000277C9
		IControllerTemplateButton IGamepadTemplate.b
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(5);
			}
		}

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x06000B65 RID: 2917 RVA: 0x000295D2 File Offset: 0x000277D2
		IControllerTemplateButton IGamepadTemplate.actionBottomRow3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(6);
			}
		}

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x06000B66 RID: 2918 RVA: 0x000295DB File Offset: 0x000277DB
		IControllerTemplateButton IGamepadTemplate.c
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(6);
			}
		}

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x06000B67 RID: 2919 RVA: 0x000295E4 File Offset: 0x000277E4
		IControllerTemplateButton IGamepadTemplate.actionTopRow1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(7);
			}
		}

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x06000B68 RID: 2920 RVA: 0x000295ED File Offset: 0x000277ED
		IControllerTemplateButton IGamepadTemplate.x
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(7);
			}
		}

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x06000B69 RID: 2921 RVA: 0x000295F6 File Offset: 0x000277F6
		IControllerTemplateButton IGamepadTemplate.actionTopRow2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(8);
			}
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06000B6A RID: 2922 RVA: 0x000295FF File Offset: 0x000277FF
		IControllerTemplateButton IGamepadTemplate.y
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(8);
			}
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x06000B6B RID: 2923 RVA: 0x00029608 File Offset: 0x00027808
		IControllerTemplateButton IGamepadTemplate.actionTopRow3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(9);
			}
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x06000B6C RID: 2924 RVA: 0x00029612 File Offset: 0x00027812
		IControllerTemplateButton IGamepadTemplate.z
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(9);
			}
		}

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x06000B6D RID: 2925 RVA: 0x0002961C File Offset: 0x0002781C
		IControllerTemplateButton IGamepadTemplate.leftShoulder1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(10);
			}
		}

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x06000B6E RID: 2926 RVA: 0x00029626 File Offset: 0x00027826
		IControllerTemplateButton IGamepadTemplate.leftBumper
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(10);
			}
		}

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x06000B6F RID: 2927 RVA: 0x00029630 File Offset: 0x00027830
		IControllerTemplateAxis IGamepadTemplate.leftShoulder2
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(11);
			}
		}

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x06000B70 RID: 2928 RVA: 0x0002963A File Offset: 0x0002783A
		IControllerTemplateAxis IGamepadTemplate.leftTrigger
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(11);
			}
		}

		// Token: 0x17000238 RID: 568
		// (get) Token: 0x06000B71 RID: 2929 RVA: 0x00029644 File Offset: 0x00027844
		IControllerTemplateButton IGamepadTemplate.rightShoulder1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(12);
			}
		}

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x06000B72 RID: 2930 RVA: 0x0002964E File Offset: 0x0002784E
		IControllerTemplateButton IGamepadTemplate.rightBumper
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(12);
			}
		}

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x06000B73 RID: 2931 RVA: 0x00029658 File Offset: 0x00027858
		IControllerTemplateAxis IGamepadTemplate.rightShoulder2
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(13);
			}
		}

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x06000B74 RID: 2932 RVA: 0x00029662 File Offset: 0x00027862
		IControllerTemplateAxis IGamepadTemplate.rightTrigger
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(13);
			}
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x06000B75 RID: 2933 RVA: 0x0002966C File Offset: 0x0002786C
		IControllerTemplateButton IGamepadTemplate.center1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(14);
			}
		}

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x06000B76 RID: 2934 RVA: 0x00029676 File Offset: 0x00027876
		IControllerTemplateButton IGamepadTemplate.back
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(14);
			}
		}

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x06000B77 RID: 2935 RVA: 0x00029680 File Offset: 0x00027880
		IControllerTemplateButton IGamepadTemplate.center2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(15);
			}
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x06000B78 RID: 2936 RVA: 0x0002968A File Offset: 0x0002788A
		IControllerTemplateButton IGamepadTemplate.start
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(15);
			}
		}

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x06000B79 RID: 2937 RVA: 0x00029694 File Offset: 0x00027894
		IControllerTemplateButton IGamepadTemplate.center3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(16);
			}
		}

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x06000B7A RID: 2938 RVA: 0x0002969E File Offset: 0x0002789E
		IControllerTemplateButton IGamepadTemplate.guide
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(16);
			}
		}

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x06000B7B RID: 2939 RVA: 0x000296A8 File Offset: 0x000278A8
		IControllerTemplateThumbStick IGamepadTemplate.leftStick
		{
			get
			{
				return base.GetElement<IControllerTemplateThumbStick>(23);
			}
		}

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x06000B7C RID: 2940 RVA: 0x000296B2 File Offset: 0x000278B2
		IControllerTemplateThumbStick IGamepadTemplate.rightStick
		{
			get
			{
				return base.GetElement<IControllerTemplateThumbStick>(24);
			}
		}

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x06000B7D RID: 2941 RVA: 0x000296BC File Offset: 0x000278BC
		IControllerTemplateDPad IGamepadTemplate.dPad
		{
			get
			{
				return base.GetElement<IControllerTemplateDPad>(25);
			}
		}

		// Token: 0x06000B7E RID: 2942 RVA: 0x000296C6 File Offset: 0x000278C6
		public GamepadTemplate(object payload) : base(payload)
		{
		}

		// Token: 0x0400076B RID: 1899
		public static readonly Guid typeGuid = new Guid("83b427e4-086f-47f3-bb06-be266abd1ca5");

		// Token: 0x0400076C RID: 1900
		public const int elementId_leftStickX = 0;

		// Token: 0x0400076D RID: 1901
		public const int elementId_leftStickY = 1;

		// Token: 0x0400076E RID: 1902
		public const int elementId_rightStickX = 2;

		// Token: 0x0400076F RID: 1903
		public const int elementId_rightStickY = 3;

		// Token: 0x04000770 RID: 1904
		public const int elementId_actionBottomRow1 = 4;

		// Token: 0x04000771 RID: 1905
		public const int elementId_a = 4;

		// Token: 0x04000772 RID: 1906
		public const int elementId_actionBottomRow2 = 5;

		// Token: 0x04000773 RID: 1907
		public const int elementId_b = 5;

		// Token: 0x04000774 RID: 1908
		public const int elementId_actionBottomRow3 = 6;

		// Token: 0x04000775 RID: 1909
		public const int elementId_c = 6;

		// Token: 0x04000776 RID: 1910
		public const int elementId_actionTopRow1 = 7;

		// Token: 0x04000777 RID: 1911
		public const int elementId_x = 7;

		// Token: 0x04000778 RID: 1912
		public const int elementId_actionTopRow2 = 8;

		// Token: 0x04000779 RID: 1913
		public const int elementId_y = 8;

		// Token: 0x0400077A RID: 1914
		public const int elementId_actionTopRow3 = 9;

		// Token: 0x0400077B RID: 1915
		public const int elementId_z = 9;

		// Token: 0x0400077C RID: 1916
		public const int elementId_leftShoulder1 = 10;

		// Token: 0x0400077D RID: 1917
		public const int elementId_leftBumper = 10;

		// Token: 0x0400077E RID: 1918
		public const int elementId_leftShoulder2 = 11;

		// Token: 0x0400077F RID: 1919
		public const int elementId_leftTrigger = 11;

		// Token: 0x04000780 RID: 1920
		public const int elementId_rightShoulder1 = 12;

		// Token: 0x04000781 RID: 1921
		public const int elementId_rightBumper = 12;

		// Token: 0x04000782 RID: 1922
		public const int elementId_rightShoulder2 = 13;

		// Token: 0x04000783 RID: 1923
		public const int elementId_rightTrigger = 13;

		// Token: 0x04000784 RID: 1924
		public const int elementId_center1 = 14;

		// Token: 0x04000785 RID: 1925
		public const int elementId_back = 14;

		// Token: 0x04000786 RID: 1926
		public const int elementId_center2 = 15;

		// Token: 0x04000787 RID: 1927
		public const int elementId_start = 15;

		// Token: 0x04000788 RID: 1928
		public const int elementId_center3 = 16;

		// Token: 0x04000789 RID: 1929
		public const int elementId_guide = 16;

		// Token: 0x0400078A RID: 1930
		public const int elementId_leftStickButton = 17;

		// Token: 0x0400078B RID: 1931
		public const int elementId_rightStickButton = 18;

		// Token: 0x0400078C RID: 1932
		public const int elementId_dPadUp = 19;

		// Token: 0x0400078D RID: 1933
		public const int elementId_dPadRight = 20;

		// Token: 0x0400078E RID: 1934
		public const int elementId_dPadDown = 21;

		// Token: 0x0400078F RID: 1935
		public const int elementId_dPadLeft = 22;

		// Token: 0x04000790 RID: 1936
		public const int elementId_leftStick = 23;

		// Token: 0x04000791 RID: 1937
		public const int elementId_rightStick = 24;

		// Token: 0x04000792 RID: 1938
		public const int elementId_dPad = 25;
	}
}
