﻿using System;

namespace Rewired
{
	// Token: 0x02000178 RID: 376
	public sealed class FlightPedalsTemplate : ControllerTemplate, IFlightPedalsTemplate, IControllerTemplate
	{
		// Token: 0x170002F8 RID: 760
		// (get) Token: 0x06000C39 RID: 3129 RVA: 0x00029E8A File Offset: 0x0002808A
		IControllerTemplateAxis IFlightPedalsTemplate.leftPedal
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(0);
			}
		}

		// Token: 0x170002F9 RID: 761
		// (get) Token: 0x06000C3A RID: 3130 RVA: 0x00029E93 File Offset: 0x00028093
		IControllerTemplateAxis IFlightPedalsTemplate.rightPedal
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(1);
			}
		}

		// Token: 0x170002FA RID: 762
		// (get) Token: 0x06000C3B RID: 3131 RVA: 0x00029E9C File Offset: 0x0002809C
		IControllerTemplateAxis IFlightPedalsTemplate.slide
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(2);
			}
		}

		// Token: 0x06000C3C RID: 3132 RVA: 0x00029EA5 File Offset: 0x000280A5
		public FlightPedalsTemplate(object payload) : base(payload)
		{
		}

		// Token: 0x040008B9 RID: 2233
		public static readonly Guid typeGuid = new Guid("f6fe76f8-be2a-4db2-b853-9e3652075913");

		// Token: 0x040008BA RID: 2234
		public const int elementId_leftPedal = 0;

		// Token: 0x040008BB RID: 2235
		public const int elementId_rightPedal = 1;

		// Token: 0x040008BC RID: 2236
		public const int elementId_slide = 2;
	}
}
