﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Rewired.Internal;
using Rewired.Internal.Windows;
using Rewired.Utils.Interfaces;
using Rewired.Utils.Platforms.Windows;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.Utils
{
	// Token: 0x0200017B RID: 379
	[EditorBrowsable(EditorBrowsableState.Never)]
	public class ExternalTools : IExternalTools
	{
		// Token: 0x17000324 RID: 804
		// (get) Token: 0x06000C73 RID: 3187 RVA: 0x0002A145 File Offset: 0x00028345
		// (set) Token: 0x06000C74 RID: 3188 RVA: 0x0002A14C File Offset: 0x0002834C
		public static Func<object> getPlatformInitializerDelegate
		{
			get
			{
				return ExternalTools._getPlatformInitializerDelegate;
			}
			set
			{
				ExternalTools._getPlatformInitializerDelegate = value;
			}
		}

		// Token: 0x06000C76 RID: 3190 RVA: 0x0002A15C File Offset: 0x0002835C
		public void Destroy()
		{
		}

		// Token: 0x17000325 RID: 805
		// (get) Token: 0x06000C77 RID: 3191 RVA: 0x0002A15E File Offset: 0x0002835E
		public bool isEditorPaused
		{
			get
			{
				return this._isEditorPaused;
			}
		}

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x06000C78 RID: 3192 RVA: 0x0002A166 File Offset: 0x00028366
		// (remove) Token: 0x06000C79 RID: 3193 RVA: 0x0002A17F File Offset: 0x0002837F
		public event Action<bool> EditorPausedStateChangedEvent
		{
			add
			{
				this._EditorPausedStateChangedEvent = (Action<bool>)Delegate.Combine(this._EditorPausedStateChangedEvent, value);
			}
			remove
			{
				this._EditorPausedStateChangedEvent = (Action<bool>)Delegate.Remove(this._EditorPausedStateChangedEvent, value);
			}
		}

		// Token: 0x06000C7A RID: 3194 RVA: 0x0002A198 File Offset: 0x00028398
		public object GetPlatformInitializer()
		{
			return Main.GetPlatformInitializer();
		}

		// Token: 0x06000C7B RID: 3195 RVA: 0x0002A19F File Offset: 0x0002839F
		public string GetFocusedEditorWindowTitle()
		{
			return string.Empty;
		}

		// Token: 0x06000C7C RID: 3196 RVA: 0x0002A1A6 File Offset: 0x000283A6
		public bool IsEditorSceneViewFocused()
		{
			return false;
		}

		// Token: 0x06000C7D RID: 3197 RVA: 0x0002A1A9 File Offset: 0x000283A9
		public bool LinuxInput_IsJoystickPreconfigured(string name)
		{
			return false;
		}

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x06000C7E RID: 3198 RVA: 0x0002A1AC File Offset: 0x000283AC
		// (remove) Token: 0x06000C7F RID: 3199 RVA: 0x0002A1E4 File Offset: 0x000283E4
		public event Action<uint, bool> XboxOneInput_OnGamepadStateChange;

		// Token: 0x06000C80 RID: 3200 RVA: 0x0002A219 File Offset: 0x00028419
		public int XboxOneInput_GetUserIdForGamepad(uint id)
		{
			return 0;
		}

		// Token: 0x06000C81 RID: 3201 RVA: 0x0002A21C File Offset: 0x0002841C
		public ulong XboxOneInput_GetControllerId(uint unityJoystickId)
		{
			return 0UL;
		}

		// Token: 0x06000C82 RID: 3202 RVA: 0x0002A220 File Offset: 0x00028420
		public bool XboxOneInput_IsGamepadActive(uint unityJoystickId)
		{
			return false;
		}

		// Token: 0x06000C83 RID: 3203 RVA: 0x0002A223 File Offset: 0x00028423
		public string XboxOneInput_GetControllerType(ulong xboxControllerId)
		{
			return string.Empty;
		}

		// Token: 0x06000C84 RID: 3204 RVA: 0x0002A22A File Offset: 0x0002842A
		public uint XboxOneInput_GetJoystickId(ulong xboxControllerId)
		{
			return 0U;
		}

		// Token: 0x06000C85 RID: 3205 RVA: 0x0002A22D File Offset: 0x0002842D
		public void XboxOne_Gamepad_UpdatePlugin()
		{
		}

		// Token: 0x06000C86 RID: 3206 RVA: 0x0002A22F File Offset: 0x0002842F
		public bool XboxOne_Gamepad_SetGamepadVibration(ulong xboxOneJoystickId, float leftMotor, float rightMotor, float leftTriggerLevel, float rightTriggerLevel)
		{
			return false;
		}

		// Token: 0x06000C87 RID: 3207 RVA: 0x0002A232 File Offset: 0x00028432
		public void XboxOne_Gamepad_PulseVibrateMotor(ulong xboxOneJoystickId, int motorInt, float startLevel, float endLevel, ulong durationMS)
		{
		}

		// Token: 0x06000C88 RID: 3208 RVA: 0x0002A234 File Offset: 0x00028434
		public void GetDeviceVIDPIDs(out List<int> vids, out List<int> pids)
		{
			vids = new List<int>();
			pids = new List<int>();
		}

		// Token: 0x06000C89 RID: 3209 RVA: 0x0002A244 File Offset: 0x00028444
		public int GetAndroidAPILevel()
		{
			return -1;
		}

		// Token: 0x06000C8A RID: 3210 RVA: 0x0002A247 File Offset: 0x00028447
		public void WindowsStandalone_ForwardRawInput(IntPtr rawInputHeaderIndices, IntPtr rawInputDataIndices, uint indicesCount, IntPtr rawInputData, uint rawInputDataSize)
		{
			Functions.ForwardRawInput(rawInputHeaderIndices, rawInputDataIndices, indicesCount, rawInputData, rawInputDataSize);
		}

		// Token: 0x06000C8B RID: 3211 RVA: 0x0002A255 File Offset: 0x00028455
		public bool UnityUI_Graphic_GetRaycastTarget(object graphic)
		{
			return !(graphic as Graphic == null) && (graphic as Graphic).raycastTarget;
		}

		// Token: 0x06000C8C RID: 3212 RVA: 0x0002A272 File Offset: 0x00028472
		public void UnityUI_Graphic_SetRaycastTarget(object graphic, bool value)
		{
			if (graphic as Graphic == null)
			{
				return;
			}
			(graphic as Graphic).raycastTarget = value;
		}

		// Token: 0x17000326 RID: 806
		// (get) Token: 0x06000C8D RID: 3213 RVA: 0x0002A28F File Offset: 0x0002848F
		public bool UnityInput_IsTouchPressureSupported
		{
			get
			{
				return Input.touchPressureSupported;
			}
		}

		// Token: 0x06000C8E RID: 3214 RVA: 0x0002A296 File Offset: 0x00028496
		public float UnityInput_GetTouchPressure(ref Touch touch)
		{
			return touch.pressure;
		}

		// Token: 0x06000C8F RID: 3215 RVA: 0x0002A29E File Offset: 0x0002849E
		public float UnityInput_GetTouchMaximumPossiblePressure(ref Touch touch)
		{
			return touch.maximumPossiblePressure;
		}

		// Token: 0x06000C90 RID: 3216 RVA: 0x0002A2A6 File Offset: 0x000284A6
		public IControllerTemplate CreateControllerTemplate(Guid typeGuid, object payload)
		{
			return ControllerTemplateFactory.Create(typeGuid, payload);
		}

		// Token: 0x06000C91 RID: 3217 RVA: 0x0002A2AF File Offset: 0x000284AF
		public Type[] GetControllerTemplateTypes()
		{
			return ControllerTemplateFactory.templateTypes;
		}

		// Token: 0x06000C92 RID: 3218 RVA: 0x0002A2B6 File Offset: 0x000284B6
		public Type[] GetControllerTemplateInterfaceTypes()
		{
			return ControllerTemplateFactory.templateInterfaceTypes;
		}

		// Token: 0x04000902 RID: 2306
		private static Func<object> _getPlatformInitializerDelegate;

		// Token: 0x04000903 RID: 2307
		private bool _isEditorPaused;

		// Token: 0x04000904 RID: 2308
		private Action<bool> _EditorPausedStateChangedEvent;
	}
}
