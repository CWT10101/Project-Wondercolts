﻿using System;

namespace Rewired
{
	// Token: 0x02000175 RID: 373
	public sealed class RacingWheelTemplate : ControllerTemplate, IRacingWheelTemplate, IControllerTemplate
	{
		// Token: 0x17000245 RID: 581
		// (get) Token: 0x06000B80 RID: 2944 RVA: 0x000296E0 File Offset: 0x000278E0
		IControllerTemplateAxis IRacingWheelTemplate.wheel
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(0);
			}
		}

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x06000B81 RID: 2945 RVA: 0x000296E9 File Offset: 0x000278E9
		IControllerTemplateAxis IRacingWheelTemplate.accelerator
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(1);
			}
		}

		// Token: 0x17000247 RID: 583
		// (get) Token: 0x06000B82 RID: 2946 RVA: 0x000296F2 File Offset: 0x000278F2
		IControllerTemplateAxis IRacingWheelTemplate.brake
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(2);
			}
		}

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x06000B83 RID: 2947 RVA: 0x000296FB File Offset: 0x000278FB
		IControllerTemplateAxis IRacingWheelTemplate.clutch
		{
			get
			{
				return base.GetElement<IControllerTemplateAxis>(3);
			}
		}

		// Token: 0x17000249 RID: 585
		// (get) Token: 0x06000B84 RID: 2948 RVA: 0x00029704 File Offset: 0x00027904
		IControllerTemplateButton IRacingWheelTemplate.shiftDown
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(4);
			}
		}

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x06000B85 RID: 2949 RVA: 0x0002970D File Offset: 0x0002790D
		IControllerTemplateButton IRacingWheelTemplate.shiftUp
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(5);
			}
		}

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x06000B86 RID: 2950 RVA: 0x00029716 File Offset: 0x00027916
		IControllerTemplateButton IRacingWheelTemplate.wheelButton1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(6);
			}
		}

		// Token: 0x1700024C RID: 588
		// (get) Token: 0x06000B87 RID: 2951 RVA: 0x0002971F File Offset: 0x0002791F
		IControllerTemplateButton IRacingWheelTemplate.wheelButton2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(7);
			}
		}

		// Token: 0x1700024D RID: 589
		// (get) Token: 0x06000B88 RID: 2952 RVA: 0x00029728 File Offset: 0x00027928
		IControllerTemplateButton IRacingWheelTemplate.wheelButton3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(8);
			}
		}

		// Token: 0x1700024E RID: 590
		// (get) Token: 0x06000B89 RID: 2953 RVA: 0x00029731 File Offset: 0x00027931
		IControllerTemplateButton IRacingWheelTemplate.wheelButton4
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(9);
			}
		}

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x06000B8A RID: 2954 RVA: 0x0002973B File Offset: 0x0002793B
		IControllerTemplateButton IRacingWheelTemplate.wheelButton5
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(10);
			}
		}

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x06000B8B RID: 2955 RVA: 0x00029745 File Offset: 0x00027945
		IControllerTemplateButton IRacingWheelTemplate.wheelButton6
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(11);
			}
		}

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x06000B8C RID: 2956 RVA: 0x0002974F File Offset: 0x0002794F
		IControllerTemplateButton IRacingWheelTemplate.wheelButton7
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(12);
			}
		}

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x06000B8D RID: 2957 RVA: 0x00029759 File Offset: 0x00027959
		IControllerTemplateButton IRacingWheelTemplate.wheelButton8
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(13);
			}
		}

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x06000B8E RID: 2958 RVA: 0x00029763 File Offset: 0x00027963
		IControllerTemplateButton IRacingWheelTemplate.wheelButton9
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(14);
			}
		}

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x06000B8F RID: 2959 RVA: 0x0002976D File Offset: 0x0002796D
		IControllerTemplateButton IRacingWheelTemplate.wheelButton10
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(15);
			}
		}

		// Token: 0x17000255 RID: 597
		// (get) Token: 0x06000B90 RID: 2960 RVA: 0x00029777 File Offset: 0x00027977
		IControllerTemplateButton IRacingWheelTemplate.consoleButton1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(16);
			}
		}

		// Token: 0x17000256 RID: 598
		// (get) Token: 0x06000B91 RID: 2961 RVA: 0x00029781 File Offset: 0x00027981
		IControllerTemplateButton IRacingWheelTemplate.consoleButton2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(17);
			}
		}

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x06000B92 RID: 2962 RVA: 0x0002978B File Offset: 0x0002798B
		IControllerTemplateButton IRacingWheelTemplate.consoleButton3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(18);
			}
		}

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x06000B93 RID: 2963 RVA: 0x00029795 File Offset: 0x00027995
		IControllerTemplateButton IRacingWheelTemplate.consoleButton4
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(19);
			}
		}

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x06000B94 RID: 2964 RVA: 0x0002979F File Offset: 0x0002799F
		IControllerTemplateButton IRacingWheelTemplate.consoleButton5
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(20);
			}
		}

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x06000B95 RID: 2965 RVA: 0x000297A9 File Offset: 0x000279A9
		IControllerTemplateButton IRacingWheelTemplate.consoleButton6
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(21);
			}
		}

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x06000B96 RID: 2966 RVA: 0x000297B3 File Offset: 0x000279B3
		IControllerTemplateButton IRacingWheelTemplate.consoleButton7
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(22);
			}
		}

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x06000B97 RID: 2967 RVA: 0x000297BD File Offset: 0x000279BD
		IControllerTemplateButton IRacingWheelTemplate.consoleButton8
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(23);
			}
		}

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x06000B98 RID: 2968 RVA: 0x000297C7 File Offset: 0x000279C7
		IControllerTemplateButton IRacingWheelTemplate.consoleButton9
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(24);
			}
		}

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x06000B99 RID: 2969 RVA: 0x000297D1 File Offset: 0x000279D1
		IControllerTemplateButton IRacingWheelTemplate.consoleButton10
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(25);
			}
		}

		// Token: 0x1700025F RID: 607
		// (get) Token: 0x06000B9A RID: 2970 RVA: 0x000297DB File Offset: 0x000279DB
		IControllerTemplateButton IRacingWheelTemplate.shifter1
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(26);
			}
		}

		// Token: 0x17000260 RID: 608
		// (get) Token: 0x06000B9B RID: 2971 RVA: 0x000297E5 File Offset: 0x000279E5
		IControllerTemplateButton IRacingWheelTemplate.shifter2
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(27);
			}
		}

		// Token: 0x17000261 RID: 609
		// (get) Token: 0x06000B9C RID: 2972 RVA: 0x000297EF File Offset: 0x000279EF
		IControllerTemplateButton IRacingWheelTemplate.shifter3
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(28);
			}
		}

		// Token: 0x17000262 RID: 610
		// (get) Token: 0x06000B9D RID: 2973 RVA: 0x000297F9 File Offset: 0x000279F9
		IControllerTemplateButton IRacingWheelTemplate.shifter4
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(29);
			}
		}

		// Token: 0x17000263 RID: 611
		// (get) Token: 0x06000B9E RID: 2974 RVA: 0x00029803 File Offset: 0x00027A03
		IControllerTemplateButton IRacingWheelTemplate.shifter5
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(30);
			}
		}

		// Token: 0x17000264 RID: 612
		// (get) Token: 0x06000B9F RID: 2975 RVA: 0x0002980D File Offset: 0x00027A0D
		IControllerTemplateButton IRacingWheelTemplate.shifter6
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(31);
			}
		}

		// Token: 0x17000265 RID: 613
		// (get) Token: 0x06000BA0 RID: 2976 RVA: 0x00029817 File Offset: 0x00027A17
		IControllerTemplateButton IRacingWheelTemplate.shifter7
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(32);
			}
		}

		// Token: 0x17000266 RID: 614
		// (get) Token: 0x06000BA1 RID: 2977 RVA: 0x00029821 File Offset: 0x00027A21
		IControllerTemplateButton IRacingWheelTemplate.shifter8
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(33);
			}
		}

		// Token: 0x17000267 RID: 615
		// (get) Token: 0x06000BA2 RID: 2978 RVA: 0x0002982B File Offset: 0x00027A2B
		IControllerTemplateButton IRacingWheelTemplate.shifter9
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(34);
			}
		}

		// Token: 0x17000268 RID: 616
		// (get) Token: 0x06000BA3 RID: 2979 RVA: 0x00029835 File Offset: 0x00027A35
		IControllerTemplateButton IRacingWheelTemplate.shifter10
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(35);
			}
		}

		// Token: 0x17000269 RID: 617
		// (get) Token: 0x06000BA4 RID: 2980 RVA: 0x0002983F File Offset: 0x00027A3F
		IControllerTemplateButton IRacingWheelTemplate.reverseGear
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(44);
			}
		}

		// Token: 0x1700026A RID: 618
		// (get) Token: 0x06000BA5 RID: 2981 RVA: 0x00029849 File Offset: 0x00027A49
		IControllerTemplateButton IRacingWheelTemplate.select
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(36);
			}
		}

		// Token: 0x1700026B RID: 619
		// (get) Token: 0x06000BA6 RID: 2982 RVA: 0x00029853 File Offset: 0x00027A53
		IControllerTemplateButton IRacingWheelTemplate.start
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(37);
			}
		}

		// Token: 0x1700026C RID: 620
		// (get) Token: 0x06000BA7 RID: 2983 RVA: 0x0002985D File Offset: 0x00027A5D
		IControllerTemplateButton IRacingWheelTemplate.systemButton
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(38);
			}
		}

		// Token: 0x1700026D RID: 621
		// (get) Token: 0x06000BA8 RID: 2984 RVA: 0x00029867 File Offset: 0x00027A67
		IControllerTemplateButton IRacingWheelTemplate.horn
		{
			get
			{
				return base.GetElement<IControllerTemplateButton>(43);
			}
		}

		// Token: 0x1700026E RID: 622
		// (get) Token: 0x06000BA9 RID: 2985 RVA: 0x00029871 File Offset: 0x00027A71
		IControllerTemplateDPad IRacingWheelTemplate.dPad
		{
			get
			{
				return base.GetElement<IControllerTemplateDPad>(45);
			}
		}

		// Token: 0x06000BAA RID: 2986 RVA: 0x0002987B File Offset: 0x00027A7B
		public RacingWheelTemplate(object payload) : base(payload)
		{
		}

		// Token: 0x04000793 RID: 1939
		public static readonly Guid typeGuid = new Guid("104e31d8-9115-4dd5-a398-2e54d35e6c83");

		// Token: 0x04000794 RID: 1940
		public const int elementId_wheel = 0;

		// Token: 0x04000795 RID: 1941
		public const int elementId_accelerator = 1;

		// Token: 0x04000796 RID: 1942
		public const int elementId_brake = 2;

		// Token: 0x04000797 RID: 1943
		public const int elementId_clutch = 3;

		// Token: 0x04000798 RID: 1944
		public const int elementId_shiftDown = 4;

		// Token: 0x04000799 RID: 1945
		public const int elementId_shiftUp = 5;

		// Token: 0x0400079A RID: 1946
		public const int elementId_wheelButton1 = 6;

		// Token: 0x0400079B RID: 1947
		public const int elementId_wheelButton2 = 7;

		// Token: 0x0400079C RID: 1948
		public const int elementId_wheelButton3 = 8;

		// Token: 0x0400079D RID: 1949
		public const int elementId_wheelButton4 = 9;

		// Token: 0x0400079E RID: 1950
		public const int elementId_wheelButton5 = 10;

		// Token: 0x0400079F RID: 1951
		public const int elementId_wheelButton6 = 11;

		// Token: 0x040007A0 RID: 1952
		public const int elementId_wheelButton7 = 12;

		// Token: 0x040007A1 RID: 1953
		public const int elementId_wheelButton8 = 13;

		// Token: 0x040007A2 RID: 1954
		public const int elementId_wheelButton9 = 14;

		// Token: 0x040007A3 RID: 1955
		public const int elementId_wheelButton10 = 15;

		// Token: 0x040007A4 RID: 1956
		public const int elementId_consoleButton1 = 16;

		// Token: 0x040007A5 RID: 1957
		public const int elementId_consoleButton2 = 17;

		// Token: 0x040007A6 RID: 1958
		public const int elementId_consoleButton3 = 18;

		// Token: 0x040007A7 RID: 1959
		public const int elementId_consoleButton4 = 19;

		// Token: 0x040007A8 RID: 1960
		public const int elementId_consoleButton5 = 20;

		// Token: 0x040007A9 RID: 1961
		public const int elementId_consoleButton6 = 21;

		// Token: 0x040007AA RID: 1962
		public const int elementId_consoleButton7 = 22;

		// Token: 0x040007AB RID: 1963
		public const int elementId_consoleButton8 = 23;

		// Token: 0x040007AC RID: 1964
		public const int elementId_consoleButton9 = 24;

		// Token: 0x040007AD RID: 1965
		public const int elementId_consoleButton10 = 25;

		// Token: 0x040007AE RID: 1966
		public const int elementId_shifter1 = 26;

		// Token: 0x040007AF RID: 1967
		public const int elementId_shifter2 = 27;

		// Token: 0x040007B0 RID: 1968
		public const int elementId_shifter3 = 28;

		// Token: 0x040007B1 RID: 1969
		public const int elementId_shifter4 = 29;

		// Token: 0x040007B2 RID: 1970
		public const int elementId_shifter5 = 30;

		// Token: 0x040007B3 RID: 1971
		public const int elementId_shifter6 = 31;

		// Token: 0x040007B4 RID: 1972
		public const int elementId_shifter7 = 32;

		// Token: 0x040007B5 RID: 1973
		public const int elementId_shifter8 = 33;

		// Token: 0x040007B6 RID: 1974
		public const int elementId_shifter9 = 34;

		// Token: 0x040007B7 RID: 1975
		public const int elementId_shifter10 = 35;

		// Token: 0x040007B8 RID: 1976
		public const int elementId_reverseGear = 44;

		// Token: 0x040007B9 RID: 1977
		public const int elementId_select = 36;

		// Token: 0x040007BA RID: 1978
		public const int elementId_start = 37;

		// Token: 0x040007BB RID: 1979
		public const int elementId_systemButton = 38;

		// Token: 0x040007BC RID: 1980
		public const int elementId_horn = 43;

		// Token: 0x040007BD RID: 1981
		public const int elementId_dPadUp = 39;

		// Token: 0x040007BE RID: 1982
		public const int elementId_dPadRight = 40;

		// Token: 0x040007BF RID: 1983
		public const int elementId_dPadDown = 41;

		// Token: 0x040007C0 RID: 1984
		public const int elementId_dPadLeft = 42;

		// Token: 0x040007C1 RID: 1985
		public const int elementId_dPad = 45;
	}
}
