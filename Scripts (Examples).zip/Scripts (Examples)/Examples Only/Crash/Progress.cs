﻿using System;

// Token: 0x02000100 RID: 256
public static class Progress
{
}
