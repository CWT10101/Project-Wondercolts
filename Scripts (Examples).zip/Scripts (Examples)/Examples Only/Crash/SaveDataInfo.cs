﻿using System;
using System.Linq;

// Token: 0x0200010B RID: 267
public class SaveDataInfo
{
	// Token: 0x1700010B RID: 267
	// (get) Token: 0x06000834 RID: 2100 RVA: 0x0002296C File Offset: 0x00020B6C
	public float Progress
	{
		get
		{
			return (float)(this.lvlAllCrates.CountNotDefault<bool>() * 10 + this.lvlTapes.CountNotDefault<bool>() * 10 + this.lvlTrials.CountNotDefault<bool>() * 10 + this.lvlSpecialGems.CountNotDefault<bool>() * 10 + this.tapeMedals.Sum((byte b) => (int)b) + this.trialMedals.Sum((byte b) => (int)b)) / 345f;
		}
	}

	// Token: 0x040005EC RID: 1516
	public string name = "Crash B.";

	// Token: 0x040005ED RID: 1517
	public byte lives = 5;

	// Token: 0x040005EE RID: 1518
	public byte wumpa;

	// Token: 0x040005EF RID: 1519
	public readonly bool[] lvlAllCrates = new bool[10];

	// Token: 0x040005F0 RID: 1520
	public readonly bool[] lvlTapes = new bool[10];

	// Token: 0x040005F1 RID: 1521
	public readonly bool[] lvlTrials = new bool[5];

	// Token: 0x040005F2 RID: 1522
	public readonly bool[] lvlSpecialGems = new bool[5];

	// Token: 0x040005F3 RID: 1523
	public readonly byte[] tapeMedals = new byte[10];

	// Token: 0x040005F4 RID: 1524
	public readonly byte[] trialMedals = new byte[5];

	// Token: 0x040005F5 RID: 1525
	public bool visitedCreator;

	// Token: 0x040005F6 RID: 1526
	public bool receivedTrialInvite;

	// Token: 0x040005F7 RID: 1527
	public bool useAutosave = true;
}
