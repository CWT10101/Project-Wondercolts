﻿using System;
using UnityEngine;

// Token: 0x0200007E RID: 126
public class CameraOrbit : MonoBehaviour
{
	// Token: 0x06000385 RID: 901 RVA: 0x0000F360 File Offset: 0x0000D560
	private void LateUpdate()
	{
		Vector3 vector = this.origin.position - this.focus.position;
		vector = Vector3.ProjectOnPlane(vector, this.normal);
		vector.Normalize();
		base.transform.position = this.origin.position - vector * this.radius;
		base.transform.rotation = Quaternion.LookRotation(vector, this.normal);
	}

	// Token: 0x06000386 RID: 902 RVA: 0x0000F3DB File Offset: 0x0000D5DB
	private void OnDrawGizmos()
	{
		Gizmos.DrawWireSphere(this.origin.position, this.radius);
	}

	// Token: 0x04000257 RID: 599
	public Transform origin;

	// Token: 0x04000258 RID: 600
	public Transform focus;

	// Token: 0x04000259 RID: 601
	public float radius = 10f;

	// Token: 0x0400025A RID: 602
	public Vector3 normal = Vector3.up;
}
