﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using LevelEditor;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020000A3 RID: 163
public class DynamicResultsScreen : MonoBehaviour
{
	// Token: 0x060004EC RID: 1260 RVA: 0x00015B04 File Offset: 0x00013D04
	private void OnEnable()
	{
		this.Init();
		if (!string.IsNullOrEmpty(LevelInterfaceManager.instance.levelStats.levelNameStatText.text))
		{
			this.resultTitleText.text = LevelInterfaceManager.instance.levelStats.levelNameStatText.text;
		}
		else
		{
			this.resultTitleText.text = "Results";
		}
		base.StartCoroutine(this.<OnEnable>g__Routine|23_0());
	}

	// Token: 0x060004ED RID: 1261 RVA: 0x00015B70 File Offset: 0x00013D70
	private void Init()
	{
		this.nothingObj.SetActive(true);
		this.gemsHolderObj.SetActive(false);
		this.boxesObj.SetActive(false);
		this.barFill.fillAmount = 0f;
		this.boxesText.text = string.Format("0/{0}", LevelInterfaceManager.instance.maxBoxCount);
		bool flag;
		if (this.LevelHasAllCratesGem(out flag))
		{
			if (flag)
			{
				this.allcratesGemFill.SetActive(true);
			}
			this.gemsHolderObj.SetActive(true);
			this.allCratesObj.SetActive(true);
			this.nothingObj.SetActive(false);
		}
		bool flag2;
		if (this.LevelHasCrystal(out flag2))
		{
			if (flag2)
			{
				this.crystalFill.SetActive(true);
			}
			this.gemsHolderObj.SetActive(true);
			this.crystalObj.SetActive(true);
			this.nothingObj.SetActive(false);
		}
		bool flag3;
		if (this.LevelHasNoCratesGem(out flag3))
		{
			if (flag3)
			{
				this.noCratesGemFill.SetActive(true);
			}
			this.gemsHolderObj.SetActive(true);
			this.noCratesObj.SetActive(true);
			this.nothingObj.SetActive(false);
		}
		bool flag4;
		if (this.LevelHasHiddenGem(out flag4))
		{
			if (flag4)
			{
				this.hiddenGemFill.SetActive(true);
			}
			this.gemsHolderObj.SetActive(true);
			this.hiddenGemObj.SetActive(true);
			this.nothingObj.SetActive(false);
		}
		bool flag5;
		if (this.LevelHasClearGem(out flag5))
		{
			if (flag5)
			{
				this.clearGemFill.SetActive(true);
			}
			this.gemsHolderObj.SetActive(true);
			this.clearGemObj.SetActive(true);
			this.nothingObj.SetActive(false);
		}
		bool flag6;
		if (this.LevelHasNoDeathGem(out flag6))
		{
			if (flag6)
			{
				this.deathlessGemFill.SetActive(true);
			}
			this.gemsHolderObj.SetActive(true);
			this.deathlessObj.SetActive(true);
			this.nothingObj.SetActive(false);
		}
		bool flag7;
		if (this.LevelHasAllKillsGem(out flag7))
		{
			if (flag7)
			{
				this.killAllGemFill.SetActive(true);
			}
			this.gemsHolderObj.SetActive(true);
			this.killAllObj.SetActive(true);
			this.nothingObj.SetActive(false);
		}
		bool flag8;
		if (this.LevelHasNoKillsGem(out flag8))
		{
			if (flag8)
			{
				this.pacifistGemFill.SetActive(true);
			}
			this.gemsHolderObj.SetActive(true);
			this.pacifistObj.SetActive(true);
			this.nothingObj.SetActive(false);
		}
		if (LevelInterfaceManager.instance.maxBoxCount > 0)
		{
			this.boxesObj.SetActive(true);
			this.nothingObj.SetActive(false);
			return;
		}
		this.boxesObj.SetActive(false);
	}

	// Token: 0x060004EE RID: 1262 RVA: 0x00015DF4 File Offset: 0x00013FF4
	private bool LevelHasAllCratesGem(out bool collected)
	{
		AllCratesGemSetter allCratesGemSetter = Object.FindObjectOfType<AllCratesGemSetter>();
		if (allCratesGemSetter)
		{
			collected = allCratesGemSetter.Collected;
			return true;
		}
		collected = false;
		return false;
	}

	// Token: 0x060004EF RID: 1263 RVA: 0x00015E20 File Offset: 0x00014020
	private bool LevelHasNoCratesGem(out bool collected)
	{
		NoCratesGemSetter noCratesGemSetter = Object.FindObjectOfType<NoCratesGemSetter>();
		if (noCratesGemSetter)
		{
			collected = noCratesGemSetter.Collected;
			return true;
		}
		collected = false;
		return false;
	}

	// Token: 0x060004F0 RID: 1264 RVA: 0x00015E4C File Offset: 0x0001404C
	private bool LevelHasClearGem(out bool collected)
	{
		ClearGemSetter clearGemSetter = Object.FindObjectOfType<ClearGemSetter>();
		if (clearGemSetter)
		{
			collected = clearGemSetter.Collected;
			return true;
		}
		collected = false;
		return false;
	}

	// Token: 0x060004F1 RID: 1265 RVA: 0x00015E78 File Offset: 0x00014078
	private bool LevelHasHiddenGem(out bool collected)
	{
		HiddenGem hiddenGem = this.TryGetGem<HiddenGem>();
		if (hiddenGem)
		{
			collected = hiddenGem.Collected;
			return true;
		}
		collected = false;
		return false;
	}

	// Token: 0x060004F2 RID: 1266 RVA: 0x00015EA4 File Offset: 0x000140A4
	private bool LevelHasNoDeathGem(out bool collected)
	{
		NoDeathGem noDeathGem = this.TryGetGem<NoDeathGem>();
		if (noDeathGem)
		{
			collected = noDeathGem.Collected;
			return true;
		}
		collected = false;
		return false;
	}

	// Token: 0x060004F3 RID: 1267 RVA: 0x00015ED0 File Offset: 0x000140D0
	private bool LevelHasAllKillsGem(out bool collected)
	{
		AllKillsGem allKillsGem = this.TryGetGem<AllKillsGem>();
		if (allKillsGem)
		{
			collected = allKillsGem.Collected;
			return true;
		}
		collected = false;
		return false;
	}

	// Token: 0x060004F4 RID: 1268 RVA: 0x00015EFC File Offset: 0x000140FC
	private bool LevelHasNoKillsGem(out bool collected)
	{
		NoKillsGem noKillsGem = this.TryGetGem<NoKillsGem>();
		if (noKillsGem)
		{
			collected = noKillsGem.Collected;
			return true;
		}
		collected = false;
		return false;
	}

	// Token: 0x060004F5 RID: 1269 RVA: 0x00015F28 File Offset: 0x00014128
	private bool LevelHasCrystal(out bool collected)
	{
		CrystalSetter crystalSetter = Object.FindObjectOfType<CrystalSetter>();
		if (crystalSetter)
		{
			collected = crystalSetter.Collected;
			return true;
		}
		collected = false;
		return false;
	}

	// Token: 0x060004F6 RID: 1270 RVA: 0x00015F54 File Offset: 0x00014154
	private T TryGetGem<T>() where T : SpecialGem
	{
		if (Level.instance)
		{
			T t = Level.instance.specialGem as T;
			if (t != null)
			{
				return t;
			}
		}
		if (LevelInterfaceManager.instance)
		{
			T t2 = LevelInterfaceManager.instance.GetSpecialGem() as T;
			if (t2 != null)
			{
				return t2;
			}
		}
		return default(T);
	}

	// Token: 0x060004F7 RID: 1271 RVA: 0x00015FC0 File Offset: 0x000141C0
	public void RetryLevel()
	{
		UIScreen.Focus(InterfaceManager.instance.HUD);
		CrashController.instance.enabled = true;
		LevelManager.instance.LoadToPlay(LevelSerializer.activeFolder, LevelSerializer.instance.loadOnPlayString);
	}

	// Token: 0x060004F8 RID: 1272 RVA: 0x00015FF5 File Offset: 0x000141F5
	public void Continue()
	{
		LevelManager.instance.LoadWarpRoom();
	}

	// Token: 0x060004FA RID: 1274 RVA: 0x00016014 File Offset: 0x00014214
	[CompilerGenerated]
	private IEnumerator <OnEnable>g__Routine|23_0()
	{
		yield return new WaitForSeconds(0.5f);
		if (this.boxesObj.activeSelf)
		{
			float completion = (float)LevelInterfaceManager.instance.boxesCollected / (float)LevelInterfaceManager.instance.maxBoxCount;
			float d = completion * this.maxAnimationTime;
			float t = 0f;
			while (t < completion)
			{
				float num = Time.deltaTime / d;
				this.barFill.fillAmount = t;
				this.boxesText.text = string.Format("{0}/{1}", (int)(t * (float)LevelInterfaceManager.instance.maxBoxCount), LevelInterfaceManager.instance.maxBoxCount);
				t += num;
				yield return new WaitForEndOfFrame();
			}
			this.barFill.fillAmount = completion;
			this.boxesText.text = string.Format("{0}/{1}", LevelInterfaceManager.instance.boxesCollected, LevelInterfaceManager.instance.maxBoxCount);
		}
		yield break;
	}

	// Token: 0x0400036B RID: 875
	public TMP_Text boxesText;

	// Token: 0x0400036C RID: 876
	public TMP_Text resultTitleText;

	// Token: 0x0400036D RID: 877
	public Image barFill;

	// Token: 0x0400036E RID: 878
	public float maxAnimationTime = 3f;

	// Token: 0x0400036F RID: 879
	public GameObject allCratesObj;

	// Token: 0x04000370 RID: 880
	public GameObject boxesObj;

	// Token: 0x04000371 RID: 881
	public GameObject noCratesObj;

	// Token: 0x04000372 RID: 882
	public GameObject gemsHolderObj;

	// Token: 0x04000373 RID: 883
	public GameObject nothingObj;

	// Token: 0x04000374 RID: 884
	public GameObject crystalObj;

	// Token: 0x04000375 RID: 885
	public GameObject deathlessObj;

	// Token: 0x04000376 RID: 886
	public GameObject killAllObj;

	// Token: 0x04000377 RID: 887
	public GameObject pacifistObj;

	// Token: 0x04000378 RID: 888
	public GameObject hiddenGemObj;

	// Token: 0x04000379 RID: 889
	public GameObject clearGemObj;

	// Token: 0x0400037A RID: 890
	public GameObject noCratesGemFill;

	// Token: 0x0400037B RID: 891
	public GameObject allcratesGemFill;

	// Token: 0x0400037C RID: 892
	public GameObject crystalFill;

	// Token: 0x0400037D RID: 893
	public GameObject killAllGemFill;

	// Token: 0x0400037E RID: 894
	public GameObject pacifistGemFill;

	// Token: 0x0400037F RID: 895
	public GameObject hiddenGemFill;

	// Token: 0x04000380 RID: 896
	public GameObject deathlessGemFill;

	// Token: 0x04000381 RID: 897
	public GameObject clearGemFill;
}
