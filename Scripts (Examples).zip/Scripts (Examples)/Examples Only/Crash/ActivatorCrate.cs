﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using LevelEditor;
using UnityEngine;

// Token: 0x02000048 RID: 72
public class ActivatorCrate : Crate, IFallOn, ITouchBottom, ISpin, ISlam, ISlide, IMetadataReceiver<ConnectionsMetadata>
{
	// Token: 0x17000066 RID: 102
	// (get) Token: 0x060001E7 RID: 487 RVA: 0x00008D27 File Offset: 0x00006F27
	public override bool AddsToBoxCount
	{
		get
		{
			return false;
		}
	}

	// Token: 0x060001E8 RID: 488 RVA: 0x00008D2A File Offset: 0x00006F2A
	public void FallOn(CrashController crash)
	{
		if (this.activated)
		{
			return;
		}
		crash.Bounce();
		this.Activate();
	}

	// Token: 0x060001E9 RID: 489 RVA: 0x00008D41 File Offset: 0x00006F41
	public void Slam(CrashController crash)
	{
		this.Activate();
	}

	// Token: 0x060001EA RID: 490 RVA: 0x00008D49 File Offset: 0x00006F49
	public void Spin(CrashController crash)
	{
		this.Activate();
	}

	// Token: 0x060001EB RID: 491 RVA: 0x00008D51 File Offset: 0x00006F51
	public void TouchBottom(CrashController crash)
	{
		this.Activate();
	}

	// Token: 0x060001EC RID: 492 RVA: 0x00008D59 File Offset: 0x00006F59
	public void Slide(CrashController crash)
	{
		if (!base.IsAbove(crash))
		{
			this.Activate();
		}
	}

	// Token: 0x060001ED RID: 493 RVA: 0x00008D6A File Offset: 0x00006F6A
	public override void Break()
	{
		this.Activate();
	}

	// Token: 0x060001EE RID: 494 RVA: 0x00008D72 File Offset: 0x00006F72
	public override void ForceBreak()
	{
	}

	// Token: 0x060001EF RID: 495 RVA: 0x00008D74 File Offset: 0x00006F74
	public override void Fall(float withVelocity = 0f)
	{
	}

	// Token: 0x060001F0 RID: 496 RVA: 0x00008D78 File Offset: 0x00006F78
	protected override void OnEnable()
	{
		base.OnEnable();
		foreach (Crate crate in this.crates)
		{
			crate.SetOutlineColor(Color.white);
		}
		if (this.activated)
		{
			if (this.iconAnimator)
			{
				this.iconAnimator.SetTrigger("Activate");
			}
			using (List<Crate>.Enumerator enumerator = this.crates.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					Crate crate2 = enumerator.Current;
					if (!crate2.isBroken)
					{
						crate2.SetTangibleMode();
					}
				}
				return;
			}
		}
		foreach (Crate crate3 in this.crates)
		{
			if (!crate3.isBroken)
			{
				crate3.SetOutlineMode();
			}
		}
	}

	// Token: 0x060001F1 RID: 497 RVA: 0x00008E8C File Offset: 0x0000708C
	public override void ResetEntity()
	{
		this.activated = false;
		foreach (Crate crate in this.crates)
		{
			crate.SetOutlineMode();
		}
		if (this.iconAnimator)
		{
			this.iconAnimator.SetTrigger("Reset");
		}
	}

	// Token: 0x060001F2 RID: 498 RVA: 0x00008F00 File Offset: 0x00007100
	protected virtual void Activate()
	{
		if (this.activated)
		{
			return;
		}
		this.TryPushToStack();
		this.activated = true;
		AudioManager.Play("SFX_ActivatorCrate", new Vector3?(base.transform.position), null);
		if (this.iconAnimator)
		{
			this.iconAnimator.SetTrigger("Activate");
		}
		base.StartCoroutine(this.ActivateRoutine());
	}

	// Token: 0x060001F3 RID: 499 RVA: 0x00008F71 File Offset: 0x00007171
	protected virtual IEnumerator ActivateRoutine()
	{
		foreach (Crate crate in this.crates)
		{
			if (!crate.isBroken && crate.outlineVis.activeSelf)
			{
				crate.SetTangibleMode();
				yield return new WaitForSeconds(this.waitTime);
			}
		}
		List<Crate>.Enumerator enumerator = default(List<Crate>.Enumerator);
		yield break;
		yield break;
	}

	// Token: 0x060001F4 RID: 500 RVA: 0x00008F80 File Offset: 0x00007180
	public virtual void ProcessMetadata(ConnectionsMetadata meta)
	{
		this.crates.Clear();
		this.crates.AddRange(from c in meta.Connections
		select c.GetComponentInChildren<Crate>(true));
		this.crates.ForEach(delegate(Crate c)
		{
			c.startAsOutlineCrate = true;
		});
	}

	// Token: 0x04000105 RID: 261
	public Animator iconAnimator;

	// Token: 0x04000106 RID: 262
	public List<Crate> crates;

	// Token: 0x04000107 RID: 263
	public float waitTime = 0.25f;

	// Token: 0x04000108 RID: 264
	protected bool activated;
}
