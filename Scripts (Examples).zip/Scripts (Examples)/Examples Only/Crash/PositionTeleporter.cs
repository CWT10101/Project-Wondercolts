﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x02000039 RID: 57
public class PositionTeleporter : Entity, IMetadataReceiver<EndpointMetadata>, IMetadataReceiver<BonusUIMetadata>, IPlayModeCallback
{
	// Token: 0x0600017C RID: 380 RVA: 0x00006C52 File Offset: 0x00004E52
	private void OnEnable()
	{
		this.SetBonusColour(this.setsBonusUI);
		this.SetEndPointParticles(this.endPoint != null && !this.wasTriggered);
	}

	// Token: 0x0600017D RID: 381 RVA: 0x00006C80 File Offset: 0x00004E80
	private void SetEndPointParticles(bool value)
	{
		for (int i = 0; i < this.teleporterFX.Length; i++)
		{
			this.teleporterFX[i].SetActive(value);
		}
	}

	// Token: 0x0600017E RID: 382 RVA: 0x00006CB0 File Offset: 0x00004EB0
	private void OnTriggerEnter(Collider other)
	{
		if (this.endPoint != null && !this.wasTriggered)
		{
			CrashController crashController;
			if (other.TryGetComponent<CrashController>(out crashController))
			{
				crashController.enabled = false;
				if (!string.IsNullOrEmpty(this.crashAnimState))
				{
					Transform transform = crashController.animator.transform.GetChild(0).Find(this.crashAnimState);
					if (transform)
					{
						Debug.Log(transform, transform);
						crashController.animator.SetState(transform.gameObject, false);
						if (this.setCrashOrientation)
						{
							transform.rotation = Quaternion.LookRotation(base.transform.position - (crashController.transform.position + Vector3.up * this.orientationOffset));
						}
					}
					else
					{
						Debug.LogWarning("Didn't find " + this.crashAnimState);
					}
				}
				this.Trigger();
				return;
			}
		}
		else
		{
			Debug.LogWarning("Endpoint is null!");
			AudioManager.Play("SFX_UkaJumpZap", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		}
	}

	// Token: 0x0600017F RID: 383 RVA: 0x00006DCC File Offset: 0x00004FCC
	public void Trigger()
	{
		AudioManager.Play("SFX_WarpAreaTriggered", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		base.StartCoroutine(this.<Trigger>g__TeleportRoutine|18_0());
		if (this.setsBonusUI)
		{
			this.wasTriggered = true;
			this.SetEndPointParticles(false);
		}
		this.TryPushToStack();
	}

	// Token: 0x06000180 RID: 384 RVA: 0x00006E28 File Offset: 0x00005028
	public void SetBonusColour(bool isBonusStart)
	{
		if (isBonusStart)
		{
			this.lineRenderer.colorGradient = this.bonusGradient;
		}
		else
		{
			this.lineRenderer.colorGradient = this.defaultGradient;
		}
		for (int i = 0; i < this.circles.Length; i++)
		{
			this.circles[i].color = (isBonusStart ? this.bonusColour : this.defaultColour);
		}
		this.bonusPlatformVis.SetActive(isBonusStart);
	}

	// Token: 0x06000181 RID: 385 RVA: 0x00006E9C File Offset: 0x0000509C
	public void SetBonusMode(bool setBonus)
	{
		if (BonusManager.instance.bonusComplete)
		{
			return;
		}
		if (setBonus)
		{
			if (BonusManager.instance.inBonus)
			{
				PositionTeleporter.<SetBonusMode>g__FinishBonus|20_0();
			}
			else
			{
				PositionTeleporter.<SetBonusMode>g__StartBonus|20_1();
			}
		}
		else if (BonusManager.instance.inBonus)
		{
			PositionTeleporter.<SetBonusMode>g__FinishBonus|20_0();
		}
		Debug.Log(string.Format("Set Bonus UI Called ({0} was passed in), the result was:{1}", setBonus, InterfaceManager.instance.bonusUI.activeSelf));
	}

	// Token: 0x06000182 RID: 386 RVA: 0x00006F10 File Offset: 0x00005110
	public void ProcessMetadata(EndpointMetadata meta)
	{
		if (meta.HasData)
		{
			if (this.endPoint == null)
			{
				this.endPoint = new GameObject("Endpoint").transform;
				this.endPoint.SetParent(base.transform);
				this.endPoint.localEulerAngles = new Vector3(0f, 180f, 0f);
			}
			this.endPoint.position = meta.Position;
			return;
		}
		if (this.endPoint != null)
		{
			Object.Destroy(this.endPoint.gameObject);
			this.endPoint = null;
		}
	}

	// Token: 0x06000183 RID: 387 RVA: 0x00006FB9 File Offset: 0x000051B9
	public void ProcessMetadata(BonusUIMetadata meta)
	{
		this.setsBonusUI = meta.value;
		this.SetBonusColour(this.setsBonusUI);
	}

	// Token: 0x06000184 RID: 388 RVA: 0x00006FD3 File Offset: 0x000051D3
	public override void ResetEntity()
	{
		BonusManager.instance.bonusComplete = false;
		this.wasTriggered = false;
		base.ResetEntity();
	}

	// Token: 0x06000185 RID: 389 RVA: 0x00006FED File Offset: 0x000051ED
	public void PlayModeChanged(bool isPlaying)
	{
		if (!isPlaying)
		{
			BonusManager.instance.ShowBonusUI(false);
		}
		BonusManager.instance.bonusComplete = false;
	}

	// Token: 0x06000187 RID: 391 RVA: 0x00007026 File Offset: 0x00005226
	[CompilerGenerated]
	private IEnumerator <Trigger>g__TeleportRoutine|18_0()
	{
		CrashController.instance.enabled = false;
		yield return new WaitForSeconds(this.waitTime / 3f);
		InterfaceManager.instance.fadeScreen.FadeToColour(Color.black);
		yield return new WaitForSeconds(this.waitTime / 3f);
		CrashSpawner.instance.MoveToSpawn(CrashController.instance, this.endPoint);
		yield return new WaitForSeconds(this.waitTime / 3f);
		this.SetBonusMode(this.setsBonusUI);
		CrashController.instance.animator.SetState(CrashController.instance.animator.warpInObj, false);
		CrashController.instance.enabled = true;
		InterfaceManager.instance.fadeScreen.FadeToAlpha();
		yield break;
	}

	// Token: 0x06000188 RID: 392 RVA: 0x00007035 File Offset: 0x00005235
	[CompilerGenerated]
	internal static void <SetBonusMode>g__FinishBonus|20_0()
	{
		BonusManager.instance.inBonus = false;
		CrashController.instance.inBonus = false;
		PickupHandler pickupHandler = CrashController.instance.pickupHandler;
		BonusManager.instance.AwardBonusPickups(0.1f);
		BonusManager.instance.bonusComplete = true;
	}

	// Token: 0x06000189 RID: 393 RVA: 0x00007072 File Offset: 0x00005272
	[CompilerGenerated]
	internal static void <SetBonusMode>g__StartBonus|20_1()
	{
		BonusManager.instance.ResetBonusCrates();
		BonusManager.instance.inBonus = true;
		CrashController.instance.inBonus = true;
		BonusManager.instance.ShowBonusUI(true);
	}

	// Token: 0x040000A7 RID: 167
	public float waitTime = 1.5f;

	// Token: 0x040000A8 RID: 168
	public string crashAnimState = "WarpOut";

	// Token: 0x040000A9 RID: 169
	public bool setCrashOrientation;

	// Token: 0x040000AA RID: 170
	public float orientationOffset;

	// Token: 0x040000AB RID: 171
	private bool wasTriggered;

	// Token: 0x040000AC RID: 172
	public Transform endPoint;

	// Token: 0x040000AD RID: 173
	public bool setsBonusUI;

	// Token: 0x040000AE RID: 174
	public LineRenderer lineRenderer;

	// Token: 0x040000AF RID: 175
	public Gradient defaultGradient;

	// Token: 0x040000B0 RID: 176
	public Gradient bonusGradient;

	// Token: 0x040000B1 RID: 177
	public Color defaultColour;

	// Token: 0x040000B2 RID: 178
	public Color bonusColour;

	// Token: 0x040000B3 RID: 179
	public SpriteRenderer[] circles;

	// Token: 0x040000B4 RID: 180
	public GameObject bonusPlatformVis;

	// Token: 0x040000B5 RID: 181
	public GameObject[] teleporterFX;
}
