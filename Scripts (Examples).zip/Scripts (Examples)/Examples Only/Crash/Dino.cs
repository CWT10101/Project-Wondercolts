﻿using System;
using Rewired;
using UnityEngine;

// Token: 0x0200009E RID: 158
public class Dino : Entity, ISpin, IFallOn
{
	// Token: 0x170000C9 RID: 201
	// (get) Token: 0x060004BD RID: 1213 RVA: 0x00015224 File Offset: 0x00013424
	// (set) Token: 0x060004BE RID: 1214 RVA: 0x0001522C File Offset: 0x0001342C
	public CharacterController Controller { get; private set; }

	// Token: 0x170000CA RID: 202
	// (get) Token: 0x060004BF RID: 1215 RVA: 0x00015235 File Offset: 0x00013435
	// (set) Token: 0x060004C0 RID: 1216 RVA: 0x0001523D File Offset: 0x0001343D
	public Animator Animator { get; private set; }

	// Token: 0x170000CB RID: 203
	// (get) Token: 0x060004C1 RID: 1217 RVA: 0x00015246 File Offset: 0x00013446
	// (set) Token: 0x060004C2 RID: 1218 RVA: 0x0001524E File Offset: 0x0001344E
	public Collider MountCollider { get; private set; }

	// Token: 0x170000CC RID: 204
	// (get) Token: 0x060004C3 RID: 1219 RVA: 0x00015257 File Offset: 0x00013457
	// (set) Token: 0x060004C4 RID: 1220 RVA: 0x0001525F File Offset: 0x0001345F
	public Transform MountTransform { get; private set; }

	// Token: 0x170000CD RID: 205
	// (get) Token: 0x060004C5 RID: 1221 RVA: 0x00015268 File Offset: 0x00013468
	// (set) Token: 0x060004C6 RID: 1222 RVA: 0x00015270 File Offset: 0x00013470
	public bool IsGrounded { get; private set; }

	// Token: 0x170000CE RID: 206
	// (get) Token: 0x060004C7 RID: 1223 RVA: 0x00015279 File Offset: 0x00013479
	private float TimeSinceGrounded
	{
		get
		{
			if (this.timeLastGrounded != -1f)
			{
				return Time.timeSinceLevelLoad - this.timeLastGrounded;
			}
			return float.PositiveInfinity;
		}
	}

	// Token: 0x170000CF RID: 207
	// (get) Token: 0x060004C8 RID: 1224 RVA: 0x0001529A File Offset: 0x0001349A
	public bool IsPlayerControlled
	{
		get
		{
			return this.state == Dino.State.Riding;
		}
	}

	// Token: 0x060004C9 RID: 1225 RVA: 0x000152A5 File Offset: 0x000134A5
	private float GetAxis(Player rw, int id)
	{
		if (CrashController.instance.isPaused)
		{
			return 0f;
		}
		return rw.GetAxisRaw(id);
	}

	// Token: 0x060004CA RID: 1226 RVA: 0x000152C0 File Offset: 0x000134C0
	private Vector2 GetAxis2D(Player rw, int idX, int idY, float sqDeadzone = 0f)
	{
		Vector2 vector = new Vector2(this.GetAxis(rw, idX), this.GetAxis(rw, idY));
		if (sqDeadzone > 0f && vector.sqrMagnitude <= sqDeadzone)
		{
			return Vector2.zero;
		}
		return Vector2.ClampMagnitude(vector, 1f);
	}

	// Token: 0x060004CB RID: 1227 RVA: 0x00015309 File Offset: 0x00013509
	private bool GetButton(Player rw, int id)
	{
		return !CrashController.instance.isPaused && rw.GetButton(id);
	}

	// Token: 0x060004CC RID: 1228 RVA: 0x00015320 File Offset: 0x00013520
	private bool GetButton(Player rw, int id, float graceTime)
	{
		return !CrashController.instance.isPaused && rw.GetButtonTimeUnpressed(id) <= (double)graceTime;
	}

	// Token: 0x060004CD RID: 1229 RVA: 0x0001533E File Offset: 0x0001353E
	private bool GetButtonDown(Player rw, int id)
	{
		return !CrashController.instance.isPaused && rw.GetButtonDown(id);
	}

	// Token: 0x060004CE RID: 1230 RVA: 0x00015355 File Offset: 0x00013555
	private bool GetButtonUp(Player rw, int id)
	{
		return !CrashController.instance.isPaused && rw.GetButtonUp(id);
	}

	// Token: 0x060004CF RID: 1231 RVA: 0x0001536C File Offset: 0x0001356C
	public void OnControllerColliderHit(ControllerColliderHit hit)
	{
		if (!this.IsPlayerControlled)
		{
			return;
		}
		Vector3 normal = hit.normal;
		RaycastHit raycastHit;
		if (hit.collider.Raycast(new Ray(hit.point - hit.moveDirection * hit.moveLength, hit.moveDirection), out raycastHit, hit.moveLength + 0.1f))
		{
			normal = raycastHit.normal;
		}
		float num = Vector3.Angle(Vector3.up, normal);
		CharacterController characterController;
		if (!this.IsGrounded && hit.collider.TryGetComponent<CharacterController>(out characterController))
		{
			num = (float)((num < 90f) ? 0 : 180);
		}
		if (num < 90f && hit.collider.gameObject.layer != LayerMask.NameToLayer("InvisibleWall"))
		{
			this.surfaceNormal = normal;
			if (hit.collider.sharedMaterial && hit.collider.sharedMaterial.dynamicFriction == 0f)
			{
				float a = Vector3.Angle(this.surfaceNormal, Vector3.up);
				Vector3 axis = Vector3.Cross(Vector3.up, this.surfaceNormal);
				Quaternion rotation = Quaternion.AngleAxis(Mathf.Lerp(a, 90f, 0.5f), axis);
				this.surfaceNormal = rotation * Vector3.up;
			}
			this.surfacePoint = hit.point;
		}
		if (num < 70f)
		{
			IFallOn fallOn;
			if (this.wasGrounded)
			{
				ITouchTop touchTop;
				if (hit.collider.TryGetComponent<ITouchTop>(out touchTop))
				{
					touchTop.TouchTop(CrashController.instance);
				}
			}
			else if (hit.collider.TryGetComponent<IFallOn>(out fallOn))
			{
				fallOn.FallOn(CrashController.instance);
			}
			IPlatform componentInParent = hit.collider.GetComponentInParent<IPlatform>();
			if (componentInParent != null)
			{
				this.platform = componentInParent;
			}
			this.IsGrounded = true;
			return;
		}
		ITouchSide touchSide;
		if (num > 90f)
		{
			if (this.velocity > 0f)
			{
				this.velocity = 0f;
				ITouchBottom touchBottom;
				if (hit.collider.TryGetComponent<ITouchBottom>(out touchBottom))
				{
					touchBottom.TouchBottom(CrashController.instance);
					return;
				}
			}
		}
		else if (hit.collider.TryGetComponent<ITouchSide>(out touchSide))
		{
			touchSide.TouchSide(CrashController.instance);
		}
	}

	// Token: 0x060004D0 RID: 1232 RVA: 0x0001557A File Offset: 0x0001377A
	private void FixedUpdate()
	{
		this.GroundCheck();
		this.UpdateRotation();
		this.UpdateMovement();
		this.ApplyGravity();
		this.DriveController();
		this.wasGrounded = this.IsGrounded;
	}

	// Token: 0x060004D1 RID: 1233 RVA: 0x000155A8 File Offset: 0x000137A8
	private void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (other.gameObject.TryGetComponent<CrashController>(out crashController))
		{
			this.MountCollider.enabled = false;
			crashController.Mount(this.MountTransform);
			this.Mount();
		}
	}

	// Token: 0x060004D2 RID: 1234 RVA: 0x000155E2 File Offset: 0x000137E2
	public override void ResetEntity()
	{
		base.ResetEntity();
		this.state = Dino.State.Egg;
		this.velocity = 0f;
	}

	// Token: 0x060004D3 RID: 1235 RVA: 0x000155FC File Offset: 0x000137FC
	private void GroundCheck()
	{
		this.IsGrounded = false;
		RaycastHit raycastHit;
		if (this.velocity <= 0f && Physics.SphereCast(base.transform.position + 2f * this.Controller.radius * Vector3.up, this.Controller.radius, Vector3.down, out raycastHit, this.Controller.radius + this.Controller.skinWidth + 0.05f, CrashController.HitMask, QueryTriggerInteraction.Ignore))
		{
			this.IsGrounded = true;
			IPlatform componentInParent = raycastHit.collider.GetComponentInParent<IPlatform>();
			if (componentInParent != null)
			{
				this.platform = componentInParent;
				return;
			}
			this.platform = null;
		}
	}

	// Token: 0x060004D4 RID: 1236 RVA: 0x000156AD File Offset: 0x000138AD
	public void SetMountable()
	{
		this.MountCollider.enabled = true;
	}

	// Token: 0x060004D5 RID: 1237 RVA: 0x000156BB File Offset: 0x000138BB
	public void Mount()
	{
		this.Animator.SetTrigger("Mount");
		this.state = Dino.State.Riding;
	}

	// Token: 0x060004D6 RID: 1238 RVA: 0x000156D4 File Offset: 0x000138D4
	public void Dismount(bool shouldRun)
	{
		this.Animator.SetTrigger("Dismount");
		this.state = (shouldRun ? Dino.State.Running : Dino.State.Idle);
	}

	// Token: 0x060004D7 RID: 1239 RVA: 0x000156F3 File Offset: 0x000138F3
	public void Spin(CrashController crash)
	{
		this.Hatch();
	}

	// Token: 0x060004D8 RID: 1240 RVA: 0x000156FC File Offset: 0x000138FC
	public void FallOn(CrashController crash)
	{
		if (this.Hatch())
		{
			crash.Bounce();
		}
	}

	// Token: 0x060004D9 RID: 1241 RVA: 0x0001570C File Offset: 0x0001390C
	private bool Hatch()
	{
		if (this.state == Dino.State.Egg)
		{
			this.Animator.SetTrigger("Hatch");
			return true;
		}
		return false;
	}

	// Token: 0x060004DA RID: 1242 RVA: 0x0001572C File Offset: 0x0001392C
	private void UpdateRotation()
	{
		Vector3 vector = Vector3.Scale(this.direction, new Vector3(1f, 0f, 1f));
		if (vector.sqrMagnitude == 0f)
		{
			return;
		}
		base.transform.rotation = Quaternion.RotateTowards(base.transform.rotation, Quaternion.LookRotation(vector.normalized), this.rotationSpeed * Time.deltaTime);
	}

	// Token: 0x060004DB RID: 1243 RVA: 0x0001579C File Offset: 0x0001399C
	private void UpdateMovement()
	{
		if (this.IsPlayerControlled)
		{
			Player rwInput = CrashController.instance.rwInput;
			Vector2 axis2D = this.GetAxis2D(rwInput, CrashController.Horizontal, CrashController.Vertical, 0.05f);
			bool buttonDown = this.GetButtonDown(rwInput, CrashController.JumpInput);
			if (this.IsGrounded && buttonDown)
			{
				this.velocity = this.jumpForce;
			}
			this.direction = new Vector3(axis2D.x, this.velocity, axis2D.y);
			return;
		}
		if (this.state == Dino.State.Idle)
		{
			this.direction = new Vector3(0f, this.velocity, 0f);
			return;
		}
		if (this.state == Dino.State.Running)
		{
			Vector3 forward = base.transform.forward;
			this.direction = new Vector3(forward.x, this.velocity, forward.z);
		}
	}

	// Token: 0x060004DC RID: 1244 RVA: 0x0001586C File Offset: 0x00013A6C
	private void ApplyGravity()
	{
		if (this.Controller.isGrounded && this.velocity < 0f)
		{
			this.velocity = this.groundingForce;
			return;
		}
		this.velocity += this.gravity * Time.fixedDeltaTime;
	}

	// Token: 0x060004DD RID: 1245 RVA: 0x000158B9 File Offset: 0x00013AB9
	private void DriveController()
	{
		this.Controller.Move(this.direction * this.speed * Time.fixedDeltaTime);
	}

	// Token: 0x0400034F RID: 847
	public float speed = 1f;

	// Token: 0x04000350 RID: 848
	public float jumpForce = 10f;

	// Token: 0x04000351 RID: 849
	public float rotationSpeed = 180f;

	// Token: 0x04000352 RID: 850
	public float gravity = -1f;

	// Token: 0x04000353 RID: 851
	public float groundingForce = -1f;

	// Token: 0x04000355 RID: 853
	private bool wasGrounded = true;

	// Token: 0x04000356 RID: 854
	private float timeLastGrounded = -1f;

	// Token: 0x04000357 RID: 855
	private Vector3 surfaceNormal = Vector3.zero;

	// Token: 0x04000358 RID: 856
	private Vector3 surfacePoint;

	// Token: 0x04000359 RID: 857
	private IPlatform platform;

	// Token: 0x0400035A RID: 858
	public Dino.State state;

	// Token: 0x0400035B RID: 859
	private float velocity;

	// Token: 0x0400035C RID: 860
	private Vector3 direction = Vector3.zero;

	// Token: 0x02000207 RID: 519
	public enum State
	{
		// Token: 0x04000CCB RID: 3275
		Egg,
		// Token: 0x04000CCC RID: 3276
		Hatching,
		// Token: 0x04000CCD RID: 3277
		Idle,
		// Token: 0x04000CCE RID: 3278
		Running,
		// Token: 0x04000CCF RID: 3279
		Riding
	}
}
