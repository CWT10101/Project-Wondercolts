﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000021 RID: 33
public class LevelStats : MonoBehaviour
{
	// Token: 0x060000AD RID: 173 RVA: 0x000058F9 File Offset: 0x00003AF9
	public void PopulateStats(LevelSerializer.LevelSaveable levelSaveable)
	{
		this.levelNameStatText.text = levelSaveable.levelNameString;
		this.levelAuthorStatText.text = levelSaveable.authorString;
	}

	// Token: 0x060000AE RID: 174 RVA: 0x0000591D File Offset: 0x00003B1D
	public void ClearStats()
	{
		this.levelNameStatText.text = "";
		this.levelAuthorStatText.text = "";
	}

	// Token: 0x0400007C RID: 124
	public GameObject visual;

	// Token: 0x0400007D RID: 125
	public TMP_Text levelNameStatText;

	// Token: 0x0400007E RID: 126
	public TMP_Text levelAuthorStatText;
}
