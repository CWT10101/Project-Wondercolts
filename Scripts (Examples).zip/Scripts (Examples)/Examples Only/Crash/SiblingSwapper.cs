﻿using System;
using UnityEngine;

// Token: 0x02000117 RID: 279
public class SiblingSwapper : MonoBehaviour
{
	// Token: 0x06000887 RID: 2183 RVA: 0x00023D25 File Offset: 0x00021F25
	private void Awake()
	{
		this.SetSkin(CrashAnimator.Skin);
	}

	// Token: 0x06000888 RID: 2184 RVA: 0x00023D34 File Offset: 0x00021F34
	private void OnTriggerStay(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController) && crashController.animator.currentState == crashController.animator.spinObj && crashController.animator.TimeSinceStateChanged < Time.fixedDeltaTime / 2f)
		{
			this.SetSkin(this.bandicoots[0].activeSelf ? 0 : 1);
		}
	}

	// Token: 0x06000889 RID: 2185 RVA: 0x00023D99 File Offset: 0x00021F99
	public void RotateToFacePlayer()
	{
	}

	// Token: 0x0600088A RID: 2186 RVA: 0x00023D9C File Offset: 0x00021F9C
	public void SetSkin(int index)
	{
		GameObject[] array = this.bandicoots;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(true);
		}
		this.bandicoots[index].SetActive(false);
		CrashAnimator.Skin = index;
		InterfaceManager.instance.hudTrack.SetLifeIcon(index);
	}

	// Token: 0x04000649 RID: 1609
	public GameObject[] bandicoots;

	// Token: 0x0400064A RID: 1610
	public Vector3 initialLookDir;
}
