﻿using System;
using UnityEngine;

// Token: 0x020000FA RID: 250
public class PlantEnemy : Enemy
{
	// Token: 0x060007BC RID: 1980 RVA: 0x00020B89 File Offset: 0x0001ED89
	protected override void OnEnable()
	{
		base.OnEnable();
		this.startPos = base.transform.position;
	}

	// Token: 0x060007BD RID: 1981 RVA: 0x00020BA2 File Offset: 0x0001EDA2
	private void OnDisable()
	{
		base.transform.position = this.startPos;
	}

	// Token: 0x060007BE RID: 1982 RVA: 0x00020BB8 File Offset: 0x0001EDB8
	protected override void FixedUpdate()
	{
		if (this.isDead)
		{
			return;
		}
		base.FixedUpdate();
		if (!this.isAttacking)
		{
			Vector3 position = CrashController.instance.transform.position;
			position.y = base.transform.position.y;
			base.transform.LookAt(position);
			this.TryAttack();
		}
	}

	// Token: 0x060007BF RID: 1983 RVA: 0x00020C15 File Offset: 0x0001EE15
	public void ResetAttack()
	{
		this.isAttacking = false;
	}

	// Token: 0x060007C0 RID: 1984 RVA: 0x00020C20 File Offset: 0x0001EE20
	private void TryAttack()
	{
		if (!MathUtil.InRange(this.collider.bounds.center, CrashController.instance.transform.position, this.attackRange))
		{
			return;
		}
		foreach (Collider collider in Physics.OverlapSphere(this.collider.bounds.center, this.attackRange, LayerMask.GetMask(new string[]
		{
			"Player"
		})))
		{
			CrashController crashController;
			if (collider.TryGetComponent<CrashController>(out crashController))
			{
				Debug.DrawLine(this.collider.bounds.center, collider.bounds.center, new Color(0f, 1f, 0f), Time.fixedDeltaTime);
				Vector3 normalized = (collider.bounds.center - this.collider.bounds.center).normalized;
				RaycastHit raycastHit;
				if (Physics.Raycast(this.collider.bounds.center, normalized, out raycastHit, this.attackRange))
				{
					Debug.DrawLine(this.collider.bounds.center, raycastHit.point, new Color(1f, 0f, 0f), Time.fixedDeltaTime);
					if (raycastHit.collider == collider)
					{
						this.animator.SetTrigger("Attack");
						this.isAttacking = true;
						AudioManager.Play("SFX_PlantAttack", new Vector3?(base.transform.position), null);
						return;
					}
				}
			}
		}
	}

	// Token: 0x040005B4 RID: 1460
	public float attackRange = 3f;

	// Token: 0x040005B5 RID: 1461
	private bool isAttacking;

	// Token: 0x040005B6 RID: 1462
	private Vector3 startPos;
}
