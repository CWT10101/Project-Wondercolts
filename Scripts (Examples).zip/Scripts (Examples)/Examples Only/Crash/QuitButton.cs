﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

// Token: 0x02000154 RID: 340
[RequireComponent(typeof(Button))]
public class QuitButton : MonoBehaviour
{
	// Token: 0x060009EC RID: 2540 RVA: 0x00027D60 File Offset: 0x00025F60
	private void Awake()
	{
		this.button = base.GetComponent<Button>();
		this.button.onClick.AddListener(new UnityAction(this.Quit));
	}

	// Token: 0x060009ED RID: 2541 RVA: 0x00027D8A File Offset: 0x00025F8A
	public void Quit()
	{
		Application.Quit();
	}

	// Token: 0x0400071E RID: 1822
	private Button button;
}
