﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x020000D8 RID: 216
public class Lion : BasicEnemy
{
	// Token: 0x0600064F RID: 1615 RVA: 0x0001B6E0 File Offset: 0x000198E0
	protected override void FixedUpdate()
	{
		if (this.isDead)
		{
			return;
		}
		base.FixedUpdate();
		if (this.isTriggered)
		{
			this.timer -= Time.deltaTime;
			if (this.timer <= 0f)
			{
				this.timer = 0f;
				this.CalmDown();
			}
			else if (MathUtil.InRange(this.collider.bounds.center, CrashController.instance.controller.bounds.center, this.biteDistance) && !this.isbiting)
			{
				this.timer = 1.65f;
				this.isbiting = true;
				this.animator.SetTrigger("isBiting");
				AudioManager.Play(this.growlSFX, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
				this.speed = 0f;
			}
		}
		else
		{
			this.SightCheck();
		}
		base.FixedUpdate();
	}

	// Token: 0x06000650 RID: 1616 RVA: 0x0001B7DC File Offset: 0x000199DC
	public override void ResetEntity()
	{
		this.isTriggered = false;
		this.isbiting = false;
		this.timer = 0f;
		this.animator.SetTrigger("Reset");
		this.speed = 0f;
		base.ResetEntity();
	}

	// Token: 0x06000651 RID: 1617 RVA: 0x0001B818 File Offset: 0x00019A18
	public virtual void SightCheck()
	{
		Vector3 center = this.collider.bounds.center;
		Vector3 center2 = CrashController.instance.controller.bounds.center;
		if (!MathUtil.InRange(center, center2, this.sightDistance))
		{
			return;
		}
		if (Vector3.Angle((center2 - center).normalized, this._dir.normalized) > 45f)
		{
			return;
		}
		if (MathUtil.HasLineOfSight(center, center2, base.transform, CrashController.instance.transform, this.sightDistance, ResourceManager.instance.visionMask, QueryTriggerInteraction.Ignore))
		{
			this.BeginChase();
		}
	}

	// Token: 0x06000652 RID: 1618 RVA: 0x0001B8B8 File Offset: 0x00019AB8
	public void PlayRunSFX()
	{
		if (this.isDead)
		{
			return;
		}
		AudioManager.Play(this.runSFX, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
	}

	// Token: 0x06000653 RID: 1619 RVA: 0x0001B8F4 File Offset: 0x00019AF4
	public virtual void BeginChase()
	{
		if (!this.isDead)
		{
			Debug.Log("Chase");
			this.isTriggered = true;
			this.timer = 10f;
			this.animator.SetTrigger("isTriggered");
			AudioManager.Play(this.growlSFX, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
			base.StartCoroutine(this.<BeginChase>g__PanicRoutine|12_0());
		}
	}

	// Token: 0x06000654 RID: 1620 RVA: 0x0001B968 File Offset: 0x00019B68
	public virtual void CalmDown()
	{
		this.isTriggered = false;
		this.speed = 0f;
		this.animator.SetTrigger("Calm");
		base.transform.rotation = Quaternion.LookRotation(this._dir);
		this.isbiting = false;
	}

	// Token: 0x06000656 RID: 1622 RVA: 0x0001B9F3 File Offset: 0x00019BF3
	[CompilerGenerated]
	private IEnumerator <BeginChase>g__PanicRoutine|12_0()
	{
		yield return new WaitForSeconds(0.5f);
		this.speed = this.chaseSpeed;
		yield break;
	}

	// Token: 0x040004A4 RID: 1188
	public string growlSFX = "SFX_LionGrowl";

	// Token: 0x040004A5 RID: 1189
	public string runSFX = "SFX_RunGrowl";

	// Token: 0x040004A6 RID: 1190
	public float chaseSpeed = 2f;

	// Token: 0x040004A7 RID: 1191
	public float sightDistance = 5f;

	// Token: 0x040004A8 RID: 1192
	public float biteDistance = 1f;

	// Token: 0x040004A9 RID: 1193
	public bool isTriggered;

	// Token: 0x040004AA RID: 1194
	private bool isbiting;

	// Token: 0x040004AB RID: 1195
	[ReadOnly]
	public float timer;
}
