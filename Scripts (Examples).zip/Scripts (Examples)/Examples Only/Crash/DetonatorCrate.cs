﻿using System;
using System.Collections.Generic;
using System.Linq;
using LevelEditor;
using UnityEngine;

// Token: 0x0200009D RID: 157
public class DetonatorCrate : Crate, IFallOn, ISpin, ISlide, ISlam, ITouchBottom, IMetadataReceiver<DetonatorLinkMetadata>
{
	// Token: 0x170000C8 RID: 200
	// (get) Token: 0x060004AF RID: 1199 RVA: 0x00014FFB File Offset: 0x000131FB
	public override bool AddsToBoxCount
	{
		get
		{
			return false;
		}
	}

	// Token: 0x060004B0 RID: 1200 RVA: 0x00014FFE File Offset: 0x000131FE
	protected override void OnEnable()
	{
		base.OnEnable();
		if (this._triggered)
		{
			this.animator.SetTrigger("Squash");
		}
	}

	// Token: 0x060004B1 RID: 1201 RVA: 0x00015020 File Offset: 0x00013220
	public void SquashResponse()
	{
		if (this._triggered)
		{
			return;
		}
		this._triggered = true;
		this.animator.SetTrigger("Squash");
		AudioManager.Play("SFX_ExclamationCrate", AudioManager.MixerTarget.SFX, null, null);
	}

	// Token: 0x060004B2 RID: 1202 RVA: 0x0001506C File Offset: 0x0001326C
	public void SpinResponse()
	{
		if (this._triggered)
		{
			return;
		}
		this._triggered = true;
		this.animator.SetTrigger("Spin");
		AudioManager.Play("SFX_SpinningPlatformHit", AudioManager.MixerTarget.SFX, null, null);
	}

	// Token: 0x060004B3 RID: 1203 RVA: 0x000150B8 File Offset: 0x000132B8
	public void Detonate()
	{
		foreach (TNTCrate tntcrate in this.crates)
		{
			if (tntcrate.collider.enabled)
			{
				tntcrate.Break();
			}
		}
		this.TryPushToStack();
	}

	// Token: 0x060004B4 RID: 1204 RVA: 0x00015120 File Offset: 0x00013320
	public void FallOn(CrashController crash)
	{
		this.SquashResponse();
	}

	// Token: 0x060004B5 RID: 1205 RVA: 0x00015128 File Offset: 0x00013328
	public void Slam(CrashController crash)
	{
		this.SquashResponse();
	}

	// Token: 0x060004B6 RID: 1206 RVA: 0x00015130 File Offset: 0x00013330
	public void Slide(CrashController crash)
	{
		if (this._triggered)
		{
			return;
		}
		if (base.IsAbove(crash))
		{
			return;
		}
		if (this.animator.GetCurrentAnimatorStateInfo(0).IsTag("Idle"))
		{
			this.animator.SetTrigger("Slide");
			AudioManager.Play("SFX_HitEnemy", AudioManager.MixerTarget.SFX, null, null);
		}
	}

	// Token: 0x060004B7 RID: 1207 RVA: 0x00015199 File Offset: 0x00013399
	public void Spin(CrashController crash)
	{
		this.SpinResponse();
	}

	// Token: 0x060004B8 RID: 1208 RVA: 0x000151A1 File Offset: 0x000133A1
	public void TouchBottom(CrashController crash)
	{
	}

	// Token: 0x060004B9 RID: 1209 RVA: 0x000151A3 File Offset: 0x000133A3
	public override void Break()
	{
	}

	// Token: 0x060004BA RID: 1210 RVA: 0x000151A5 File Offset: 0x000133A5
	public override void ResetEntity()
	{
		this.animator.SetTrigger("Reset");
		base.ResetEntity();
		this._triggered = false;
	}

	// Token: 0x060004BB RID: 1211 RVA: 0x000151C4 File Offset: 0x000133C4
	public void ProcessMetadata(DetonatorLinkMetadata meta)
	{
		this.crates.Clear();
		this.crates.UnionWith(from o in meta.Connections
		select o.GetComponentInChildren<TNTCrate>(true));
	}

	// Token: 0x04000348 RID: 840
	public Animator animator;

	// Token: 0x04000349 RID: 841
	private readonly HashSet<TNTCrate> crates = new HashSet<TNTCrate>();

	// Token: 0x0400034A RID: 842
	private bool _triggered;
}
