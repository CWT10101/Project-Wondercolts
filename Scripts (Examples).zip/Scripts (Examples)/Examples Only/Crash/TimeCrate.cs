﻿using System;
using LevelEditor;

// Token: 0x02000137 RID: 311
public class TimeCrate : BasicCrate
{
	// Token: 0x06000941 RID: 2369 RVA: 0x00025DF1 File Offset: 0x00023FF1
	public override void Break()
	{
		if (!this.isBroken && LevelInterfaceManager.instance)
		{
			LevelInterfaceManager.instance.PauseTimeTrial(this.timeAmount);
		}
		base.Break();
	}

	// Token: 0x040006C5 RID: 1733
	public int timeAmount = 1;
}
