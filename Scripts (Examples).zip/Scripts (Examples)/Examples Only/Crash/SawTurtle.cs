﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200010E RID: 270
public class SawTurtle : BasicEnemy
{
	// Token: 0x06000845 RID: 2117 RVA: 0x00022F25 File Offset: 0x00021125
	protected override void Start()
	{
		if (this.speedRef == null)
		{
			this.speedRef = new float?(this.speed);
		}
		base.Start();
	}

	// Token: 0x06000846 RID: 2118 RVA: 0x00022F4B File Offset: 0x0002114B
	public override void TouchTop(CrashController crash)
	{
		if (this.isFlipped)
		{
			crash.Bounce();
			return;
		}
		base.TouchTop(crash);
	}

	// Token: 0x06000847 RID: 2119 RVA: 0x00022F63 File Offset: 0x00021163
	public override void Spin(CrashController crash)
	{
		if (!base.IsAbove(crash))
		{
			this.SpinDeath(crash.transform);
			return;
		}
		if (this.isFlipped)
		{
			this.SpinDeath(crash.transform);
			return;
		}
		crash.TakeDamage(0);
	}

	// Token: 0x06000848 RID: 2120 RVA: 0x00022F98 File Offset: 0x00021198
	public override void ResetEntity()
	{
		if (this.speedRef == null)
		{
			this.speedRef = new float?(this.speed);
		}
		this.isFlipped = false;
		this.animator.SetTrigger("Reset");
		this.speed = this.speedRef.Value;
		base.ResetEntity();
	}

	// Token: 0x06000849 RID: 2121 RVA: 0x00022FF4 File Offset: 0x000211F4
	public override void Slide(CrashController crash)
	{
		if (!this.isFlipped)
		{
			this.controller.enabled = false;
			base.StartCoroutine(this.EnableControllerAfter(0.5f));
			this.isFlipped = true;
			this.speed = 0f;
			this.animator.SetTrigger("Flip");
			AudioManager.Play("SFX_FlipTurtle", new Vector3?(base.transform.position), null);
			return;
		}
		base.Slide(crash);
	}

	// Token: 0x0600084A RID: 2122 RVA: 0x00023075 File Offset: 0x00021275
	public override void TouchSide(CrashController crash)
	{
		if (this.isFlipped)
		{
			return;
		}
		base.TouchSide(crash);
	}

	// Token: 0x0600084B RID: 2123 RVA: 0x00023087 File Offset: 0x00021287
	public override void TouchBottom(CrashController crash)
	{
		if (this.isFlipped)
		{
			return;
		}
		base.TouchBottom(crash);
	}

	// Token: 0x0600084C RID: 2124 RVA: 0x00023099 File Offset: 0x00021299
	public override void Slam(CrashController crash)
	{
		if (this.isFlipped)
		{
			this.Die(true);
			return;
		}
		base.Slam(crash);
	}

	// Token: 0x0600084D RID: 2125 RVA: 0x000230B2 File Offset: 0x000212B2
	private IEnumerator EnableControllerAfter(float secs)
	{
		yield return new WaitForSeconds(secs);
		this.controller.enabled = true;
		yield break;
	}

	// Token: 0x0400060D RID: 1549
	public bool isFlipped;

	// Token: 0x0400060E RID: 1550
	private float? speedRef;
}
