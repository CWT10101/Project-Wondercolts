﻿using System;
using UnityEngine;

// Token: 0x0200003F RID: 63
public class DemoInfo : MonoBehaviour
{
	// Token: 0x040000C5 RID: 197
	public string info;
}
