﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x0200010F RID: 271
public class SceneryBird : Entity
{
	// Token: 0x0600084F RID: 2127 RVA: 0x000230D0 File Offset: 0x000212D0
	private void OnTriggerEnter(Collider other)
	{
		if (this.visual.activeSelf)
		{
			this.PlaySFX();
			this.FlyAway();
		}
	}

	// Token: 0x06000850 RID: 2128 RVA: 0x000230EB File Offset: 0x000212EB
	public void PlaySFX()
	{
		this.audioSource.clip = this.birdSFX[Random.Range(0, this.birdSFX.Length)];
		this.audioSource.Play();
	}

	// Token: 0x06000851 RID: 2129 RVA: 0x00023118 File Offset: 0x00021318
	public void FlyAway()
	{
		this.animator.SetBool("IsFlying", true);
		base.StartCoroutine(this.<FlyAway>g__Routine|7_0());
	}

	// Token: 0x06000852 RID: 2130 RVA: 0x00023138 File Offset: 0x00021338
	public override void ResetEntity()
	{
		this.animator.SetBool("IsFlying", false);
		this.visual.transform.localPosition = Vector3.zero;
		this.visual.SetActive(true);
		base.ResetEntity();
	}

	// Token: 0x06000854 RID: 2132 RVA: 0x00023190 File Offset: 0x00021390
	[CompilerGenerated]
	private IEnumerator <FlyAway>g__Routine|7_0()
	{
		Vector3 trajectory = (Random.insideUnitSphere + Vector3.up).normalized;
		Vector3 target = (Random.insideUnitSphere + Vector3.up).normalized;
		float speedMod = Random.Range(1f, 1.5f);
		float t = Time.timeSinceLevelLoad;
		while (Time.timeSinceLevelLoad - t < this.flyDuration)
		{
			this.visual.transform.Translate(trajectory * this.flySpeed * speedMod * Time.deltaTime, Space.World);
			trajectory = Vector3.MoveTowards(trajectory, target, Time.deltaTime);
			this.visual.transform.rotation = Quaternion.LookRotation(Vector3.ProjectOnPlane(trajectory, Vector3.up).normalized);
			yield return new WaitForEndOfFrame();
		}
		this.visual.SetActive(false);
		this.TryPushToStack();
		yield break;
	}

	// Token: 0x0400060F RID: 1551
	public Animator animator;

	// Token: 0x04000610 RID: 1552
	public AudioSource audioSource;

	// Token: 0x04000611 RID: 1553
	public AudioClip[] birdSFX;

	// Token: 0x04000612 RID: 1554
	public float flySpeed = 3f;

	// Token: 0x04000613 RID: 1555
	public float flyDuration = 5f;
}
