﻿using System;
using UnityEngine;

// Token: 0x02000134 RID: 308
public class TapePickup : Pickup
{
	// Token: 0x0600092D RID: 2349 RVA: 0x000259DB File Offset: 0x00023BDB
	protected override void Start()
	{
		base.Start();
		if (Level.instance && SaveData.Info.lvlTapes[Level.instance.index])
		{
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x0600092E RID: 2350 RVA: 0x00025A14 File Offset: 0x00023C14
	public override void OnTriggerEnter(Collider other)
	{
		PickupHandler pickupHandler;
		if (other.TryGetComponent<PickupHandler>(out pickupHandler))
		{
			this.CollectTape();
			this.Despawn();
		}
	}

	// Token: 0x0600092F RID: 2351 RVA: 0x00025A37 File Offset: 0x00023C37
	public override void TryPushToStack()
	{
	}

	// Token: 0x06000930 RID: 2352 RVA: 0x00025A3C File Offset: 0x00023C3C
	public void SetTangible(bool tangible)
	{
		if (tangible)
		{
			this.renderer.sharedMaterial = this.defaultMat;
			this.outline.OutlineColor = this.defaultOutlineCol;
		}
		else
		{
			this.renderer.sharedMaterial = this.intangibleMat;
			this.outline.OutlineColor = this.intangibleOutlineCol;
		}
		this.collider.enabled = tangible;
	}

	// Token: 0x06000931 RID: 2353 RVA: 0x00025AA8 File Offset: 0x00023CA8
	public void CollectTape()
	{
		if (Level.instance)
		{
			Level.instance.collectedTape = true;
			InterfaceManager.instance.hudTrack.flashbackTapeIconGO.SetActive(true);
			InterfaceManager.instance.hudTrack.ShowGems();
		}
	}

	// Token: 0x06000932 RID: 2354 RVA: 0x00025AE5 File Offset: 0x00023CE5
	public override void Spin(CrashController crash)
	{
	}

	// Token: 0x040006B5 RID: 1717
	public MeshRenderer renderer;

	// Token: 0x040006B6 RID: 1718
	public Outline outline;

	// Token: 0x040006B7 RID: 1719
	public Material defaultMat;

	// Token: 0x040006B8 RID: 1720
	public Material intangibleMat;

	// Token: 0x040006B9 RID: 1721
	public Color32 defaultOutlineCol;

	// Token: 0x040006BA RID: 1722
	public Color32 intangibleOutlineCol = new Color32(163, 185, 192, 85);
}
