﻿using System;
using System.Collections;
using System.Collections.Generic;
using LevelEditor;
using UnityEngine;
using UnityEngine.EventSystems;

// Token: 0x0200001E RID: 30
public class LevelManager : MonoBehaviour
{
	// Token: 0x06000077 RID: 119 RVA: 0x00003F69 File Offset: 0x00002169
	private void Awake()
	{
		LevelManager.instance = this;
	}

	// Token: 0x06000078 RID: 120 RVA: 0x00003F71 File Offset: 0x00002171
	private IEnumerator Start()
	{
		yield return null;
		this.LoadToPlayCheck();
		yield break;
	}

	// Token: 0x06000079 RID: 121 RVA: 0x00003F80 File Offset: 0x00002180
	public void FirstTimeHereCheck()
	{
		if (!SaveData.Info.visitedCreator)
		{
			UIScreen.Focus(LevelInterfaceManager.instance.welcomeScreen);
			SaveData.Info.visitedCreator = true;
			SaveData.Autosave();
		}
	}

	// Token: 0x0600007A RID: 122 RVA: 0x00003FAD File Offset: 0x000021AD
	public void SetLevelMusic(int index)
	{
		this.musicToPlay = LevelResourcesManager.instance.backgroundSongs[index];
	}

	// Token: 0x0600007B RID: 123 RVA: 0x00003FC8 File Offset: 0x000021C8
	public void PlayLevelMusic()
	{
		if (string.IsNullOrEmpty(this.musicToPlay) || this.musicToPlay == "None")
		{
			AudioManager.StopMusic();
			Debug.Log("This level has no music assigned!");
			return;
		}
		AudioManager.PlayMusic(this.musicToPlay, 1f);
	}

	// Token: 0x0600007C RID: 124 RVA: 0x00004014 File Offset: 0x00002214
	public void SetLevelType(int type)
	{
		LevelInterfaceManager.instance.currentLevelType = type;
	}

	// Token: 0x0600007D RID: 125 RVA: 0x00004024 File Offset: 0x00002224
	public void LoadBeginnerMap()
	{
		LevelSerializer.instance.LoadLevel("internal", "StartingLevel");
		LevelInterfaceManager.instance.levelStats.ClearStats();
		LevelInterfaceManager.instance.saveInputField.text = "";
		LevelInterfaceManager.instance.levelAuthorInputField.text = "";
	}

	// Token: 0x0600007E RID: 126 RVA: 0x00004080 File Offset: 0x00002280
	public void LoadToPlayCheck()
	{
		if (!string.IsNullOrEmpty(LevelSerializer.instance.loadOnPlayString))
		{
			this.LoadToPlay(LevelSerializer.activeFolder, LevelSerializer.instance.loadOnPlayString);
			return;
		}
		this.FirstTimeHereCheck();
		this.LoadBeginnerMap();
		LevelInterfaceManager.instance.SetActiveFolder("User-Created");
		int num = Random.Range(0, this.crashCreatorSongs.Length);
		AudioManager.PlayMusic(this.crashCreatorSongs[num], 1f);
	}

	// Token: 0x0600007F RID: 127 RVA: 0x000040F0 File Offset: 0x000022F0
	public void LoadToPlay(string folderToCheck, string levelToLoad)
	{
		LevelInterfaceManager.instance.editorOverlay.SetActive(false);
		LevelSerializer.instance.LoadLevel(folderToCheck, levelToLoad);
		this.SetPlayMode();
	}

	// Token: 0x06000080 RID: 128 RVA: 0x00004115 File Offset: 0x00002315
	public void ReloadLevel()
	{
		this.LoadToPlay(LevelSerializer.activeFolder, LevelSerializer.instance.loadOnPlayString);
	}

	// Token: 0x06000081 RID: 129 RVA: 0x0000412C File Offset: 0x0000232C
	public void LoadWarpRoom()
	{
		InterfaceManager.instance.LoadWarpRoom();
	}

	// Token: 0x06000082 RID: 130 RVA: 0x00004138 File Offset: 0x00002338
	private void InitLevelObjects()
	{
		if (this.inSceneLevelObjects.Count > 0)
		{
			for (int i = 0; i < this.inSceneLevelObjects.Count; i++)
			{
				this.inSceneLevelObjects[i].GetComponent<LevelObj>().UpdateTile(GridManager.instance.grid);
			}
		}
	}

	// Token: 0x06000083 RID: 131 RVA: 0x0000418C File Offset: 0x0000238C
	public void SetEditorMode()
	{
		if (LevelCreator.instance)
		{
			EditorTool activeTool = LevelCreator.instance.ActiveTool;
			if (activeTool != null)
			{
				activeTool.OnToolEnabled();
			}
		}
		GridManager.instance.gridHolder.gameObject.SetActive(true);
		LevelEditorCamera.instance.ToggleOrthographicCam(true);
		LevelInterfaceManager.instance.editorIconGO.SetActive(false);
		LevelInterfaceManager.instance.playIconGO.SetActive(true);
		LevelEditorCamera.instance.editorCam.Priority = 2;
		LevelEditorCamera.instance.playCam.Priority = 1;
		this.inEditorMode = true;
		LevelInterfaceManager.instance.SetOverlayButtons();
		this.SetLevelObjects(false);
		UnityUtil.GetAllComponentsInScene<IPlayModeCallback>(false).ForEach(delegate(IPlayModeCallback i)
		{
			i.PlayModeChanged(false);
		});
		UIScreen.Focus(LevelInterfaceManager.instance.editorHUD);
		LevelInterfaceManager.instance.SetBoxCollectionObject(false);
		LevelInterfaceManager.instance.SetTimeTrialObject(false);
		LevelInterfaceManager.instance.ResetTimeTrial();
		LevelInterfaceManager.instance.ResetWeather();
		LevelInterfaceManager.instance.ResetMusic();
		InterfaceManager.instance.bossUIHolder.SetActive(false);
		BonusManager.instance.ResetBonusCrates();
		BonusManager.instance.inBonus = false;
		BonusManager.instance.ShowBonusUI(false);
		CrashController.instance.inBonus = false;
		this.crashController.pickupHandler.LoseMask(true);
		this.crashController.enabled = false;
		this.crashController.gameObject.SetActive(false);
		this.gameplayElements.SetActive(false);
		this.ClearSpawnedPickupItems();
		this.ClearProjectiles();
	}

	// Token: 0x06000084 RID: 132 RVA: 0x00004320 File Offset: 0x00002520
	public void SetPlayMode()
	{
		Clock.SetCrashSpawnTime();
		SwitchCrate.DefaultSwitchState();
		DeathRoutePlatform.RestoreDefault();
		RedGemPlatform.RestoreDefault();
		GemLockBlock.RestoreDefault();
		LevelInterfaceManager.instance.ResetWeather();
		if (LevelCreator.instance)
		{
			EditorTool activeTool = LevelCreator.instance.ActiveTool;
			if (activeTool != null)
			{
				activeTool.OnToolDisabled();
			}
		}
		EntityTracker.Dump();
		LevelInterfaceManager.instance.ClearCache();
		GridManager.instance.gridHolder.gameObject.SetActive(false);
		LevelEditorCamera.instance.ToggleOrthographicCam(false);
		LevelInterfaceManager.instance.editorIconGO.SetActive(true);
		LevelInterfaceManager.instance.playIconGO.SetActive(false);
		this.inEditorMode = false;
		LevelInterfaceManager.instance.ResetMusic();
		LevelInterfaceManager.instance.SetOverlayButtons();
		UIScreen.Focus(InterfaceManager.instance.HUD);
		this.SetLevelObjects(true);
		UnityUtil.GetAllComponentsInScene<IPlayModeCallback>(false).ForEach(delegate(IPlayModeCallback i)
		{
			i.PlayModeChanged(true);
		});
		Physics.SyncTransforms();
		if (this.FoundCrashSpawnObj())
		{
			CrashSpawner.instance.MoveToSpawn(this.crashController, null);
			this.crashController.gameObject.SetActive(true);
			this.crashController.animator.SetState(this.crashController.animator.warpInObj, false);
			this.crashController.enabled = true;
			LevelEditorCamera.instance.editorCam.Priority = 1;
			LevelEditorCamera.instance.playCam.Priority = 2;
		}
		this.gameplayElements.SetActive(true);
		foreach (GameObject gameObject in this.inSceneLevelObjects)
		{
			IPostEnable[] componentsInChildren = gameObject.GetComponentsInChildren<IPostEnable>();
			if (componentsInChildren != null)
			{
				IPostEnable[] array = componentsInChildren;
				for (int j = 0; j < array.Length; j++)
				{
					array[j].OnPostEnable();
				}
			}
		}
		CrashController.instance.pickupHandler.deaths = 0;
		InterfaceManager.instance.hudTrack.ShowLives();
		InterfaceManager.instance.hudTrack.ShowWumpa();
		InterfaceManager.instance.hudTrack.ClearGems();
		LevelInterfaceManager.instance.SetBoxCollectionObject(LevelInterfaceManager.instance.currentLevelType != 2);
		LevelInterfaceManager.instance.SetTimeTrialObject(LevelInterfaceManager.instance.currentLevelType == 2);
		LevelCreator.instance.ClearCloneObj();
		InterfaceManager.instance.hudTrack.SetKillsText();
		InterfaceManager.instance.hudTrack.SetDeathsText();
	}

	// Token: 0x06000085 RID: 133 RVA: 0x0000459C File Offset: 0x0000279C
	public void ClearProjectiles()
	{
		this.projectileHolder.DestroyChildren();
	}

	// Token: 0x06000086 RID: 134 RVA: 0x000045AC File Offset: 0x000027AC
	public bool FoundCrashSpawnObj()
	{
		bool result = false;
		foreach (LevelObj levelObj in Object.FindObjectsOfType<LevelObj>())
		{
			if (levelObj.obj_ID == "Obj_CrashSpawnPoint" && levelObj.gameObject != LevelCreator.instance.cloneObj)
			{
				CrashSpawner.instance.crashSpawnPoint.transform.position = levelObj.gameplayVis.transform.position;
				result = true;
				break;
			}
			result = false;
		}
		return result;
	}

	// Token: 0x06000087 RID: 135 RVA: 0x00004627 File Offset: 0x00002827
	public void TogglePlayMode()
	{
		if (this.inEditorMode)
		{
			this.SetPlayMode();
		}
		else
		{
			this.SetEditorMode();
		}
		EventSystem.current.SetSelectedGameObject(null);
		Physics.SyncTransforms();
	}

	// Token: 0x06000088 RID: 136 RVA: 0x00004650 File Offset: 0x00002850
	public void SetLevelObjects(bool forPlay)
	{
		for (int i = 0; i < this.inSceneLevelObjects.Count; i++)
		{
			this.inSceneLevelObjects[i].GetComponent<LevelObj>().SetPlayMode(forPlay);
		}
	}

	// Token: 0x06000089 RID: 137 RVA: 0x0000468C File Offset: 0x0000288C
	public void ClearSceneObjects()
	{
		LevelCreator levelCreator = LevelCreator.instance;
		SelectTool selectTool = ((levelCreator != null) ? levelCreator.ActiveTool : null) as SelectTool;
		if (selectTool != null)
		{
			selectTool.OnToolDisabled();
		}
		foreach (GameObject obj in this.inSceneLevelObjects)
		{
			Object.Destroy(obj);
		}
		this.inSceneLevelObjects.Clear();
		EntityTracker.Dump();
	}

	// Token: 0x0600008A RID: 138 RVA: 0x0000470C File Offset: 0x0000290C
	public void ClearSpawnedPickupItems()
	{
		Pickup[] array = Object.FindObjectsOfType<Pickup>();
		for (int i = 0; i < array.Length; i++)
		{
			Object.Destroy(array[i].gameObject);
		}
	}

	// Token: 0x0400005F RID: 95
	public string warpRoomString = "WarpRoom";

	// Token: 0x04000060 RID: 96
	public static LevelManager instance;

	// Token: 0x04000061 RID: 97
	public List<GameObject> inSceneLevelObjects = new List<GameObject>();

	// Token: 0x04000062 RID: 98
	public CrashController crashController;

	// Token: 0x04000063 RID: 99
	public GameObject gameplayElements;

	// Token: 0x04000064 RID: 100
	public Transform projectileHolder;

	// Token: 0x04000065 RID: 101
	public Transform levelObjectsHolder;

	// Token: 0x04000066 RID: 102
	public bool inEditorMode = true;

	// Token: 0x04000067 RID: 103
	public string musicToPlay = "";

	// Token: 0x04000068 RID: 104
	public string[] crashCreatorSongs;
}
