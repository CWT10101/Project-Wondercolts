﻿using System;
using UnityEngine;

// Token: 0x0200003D RID: 61
public class CameraFlythrough : MonoBehaviour
{
	// Token: 0x06000192 RID: 402 RVA: 0x00007183 File Offset: 0x00005383
	private void Start()
	{
		Cursor.lockState = CursorLockMode.Locked;
		Cursor.visible = false;
	}

	// Token: 0x06000193 RID: 403 RVA: 0x00007194 File Offset: 0x00005394
	private void Update()
	{
		if (!Cursor.visible)
		{
			this.yaw += Input.GetAxis("Mouse X") * this.sensitivity;
			this.pitch -= Input.GetAxis("Mouse Y") * this.sensitivity;
			this.camSpeed += Input.GetAxisRaw("Mouse ScrollWheel") * 50f;
		}
		base.transform.eulerAngles = new Vector3(this.pitch, this.yaw, 0f);
		base.transform.Translate(this.camSpeed * Time.deltaTime * Vector3.forward * Input.GetAxis("Vertical"));
		base.transform.Translate(this.camSpeed * Time.deltaTime * Vector3.right * Input.GetAxis("Horizontal"));
	}

	// Token: 0x06000194 RID: 404 RVA: 0x00007282 File Offset: 0x00005482
	public void LockCursor(bool lockIt)
	{
		if (lockIt)
		{
			Cursor.lockState = CursorLockMode.Locked;
		}
		else
		{
			Cursor.lockState = CursorLockMode.None;
		}
		Cursor.visible = !lockIt;
	}

	// Token: 0x040000BC RID: 188
	public float sensitivity = 2f;

	// Token: 0x040000BD RID: 189
	public float camSpeed = 10f;

	// Token: 0x040000BE RID: 190
	private float yaw;

	// Token: 0x040000BF RID: 191
	private float pitch;
}
