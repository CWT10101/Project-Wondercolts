﻿using System;
using UnityEngine;

// Token: 0x02000017 RID: 23
public class ConveyorEditorVisual : MonoBehaviour, IMetadataReceiver<SpeedMetadata>
{
	// Token: 0x0600005A RID: 90 RVA: 0x000039B4 File Offset: 0x00001BB4
	public void ProcessMetadata(SpeedMetadata meta)
	{
		Material[] sharedMaterials = this.ren.sharedMaterials;
		sharedMaterials[this.beltMatIndex] = ResourceManager.instance.conveyorBeltMatsGreen[(int)meta.speed];
		this.ren.sharedMaterials = sharedMaterials;
	}

	// Token: 0x04000045 RID: 69
	[SerializeField]
	private Renderer ren;

	// Token: 0x04000046 RID: 70
	[SerializeField]
	private int beltMatIndex;
}
