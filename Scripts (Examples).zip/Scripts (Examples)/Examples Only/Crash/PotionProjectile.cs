﻿using System;
using UnityEngine;

// Token: 0x020000FC RID: 252
public class PotionProjectile : Projectile
{
	// Token: 0x060007CB RID: 1995 RVA: 0x000211D4 File Offset: 0x0001F3D4
	protected override void FixedUpdate()
	{
		this._t += Time.deltaTime;
		if (this._t >= this.maxFlightDuration)
		{
			Object.Destroy(base.gameObject);
			return;
		}
		base.transform.Translate(Time.fixedDeltaTime * (this.flightSpeed * base.transform.forward + this.gravity * this._t * Vector3.down), Space.World);
	}

	// Token: 0x060007CC RID: 1996 RVA: 0x00021258 File Offset: 0x0001F458
	protected override void OnTriggerEnter(Collider other)
	{
		DeathTrigger deathTrigger;
		if (other.TryGetComponent<DeathTrigger>(out deathTrigger))
		{
			Object.Destroy(base.gameObject);
			return;
		}
		if (other.isTrigger)
		{
			return;
		}
		Projectile projectile;
		if (!other.TryGetComponent<Projectile>(out projectile))
		{
			Entity entity;
			if (other.GetComponentInParent<CrashController>() != null || other.TryGetComponent<Entity>(out entity))
			{
				this.Break();
				SwitchCrate component = other.GetComponent<SwitchCrate>();
				if (component != null)
				{
					component.ToggleSwitchState();
					return;
				}
			}
			else
			{
				this.Break();
			}
		}
	}

	// Token: 0x040005BC RID: 1468
	public float gravity = 2f;

	// Token: 0x040005BD RID: 1469
	public float maxFlightDuration = 5f;

	// Token: 0x040005BE RID: 1470
	private float _t;
}
