﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000084 RID: 132
public class CocoLaptop : MonoBehaviour, ISpin
{
	// Token: 0x060003A8 RID: 936 RVA: 0x0000F7F2 File Offset: 0x0000D9F2
	public void Spin(CrashController crash)
	{
		if (!this.interacted)
		{
			this.Interact();
		}
	}

	// Token: 0x060003A9 RID: 937 RVA: 0x0000F804 File Offset: 0x0000DA04
	private void Interact()
	{
		this.interacted = true;
		CrashController.instance.controller.enabled = false;
		this.animator.SetTrigger("Open");
		InterfaceManager.instance.saveLoadScreen.screen.onDefocused.AddListener(new UnityAction(this.Uninteract));
		base.StartCoroutine(CocoLaptop.<Interact>g__Routine|3_0());
	}

	// Token: 0x060003AA RID: 938 RVA: 0x0000F86C File Offset: 0x0000DA6C
	public void Uninteract()
	{
		InterfaceManager.instance.saveLoadScreen.screen.onDefocused.RemoveListener(new UnityAction(this.Uninteract));
		this.interacted = false;
		this.animator.SetTrigger("Close");
		CrashController.instance.enabled = true;
		CrashController.instance.controller.enabled = true;
	}

	// Token: 0x060003AC RID: 940 RVA: 0x0000F8D8 File Offset: 0x0000DAD8
	[CompilerGenerated]
	internal static IEnumerator <Interact>g__Routine|3_0()
	{
		yield return new WaitForSeconds(1f);
		UIScreen.Focus(InterfaceManager.instance.saveLoadScreen.screen);
		CrashController.instance.enabled = false;
		yield break;
	}

	// Token: 0x0400026D RID: 621
	public Animator animator;

	// Token: 0x0400026E RID: 622
	private bool interacted;
}
