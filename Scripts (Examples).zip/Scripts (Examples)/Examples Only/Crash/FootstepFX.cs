﻿using System;
using UnityEngine;

// Token: 0x02000050 RID: 80
public class FootstepFX : PlaySound
{
	// Token: 0x06000212 RID: 530 RVA: 0x0000950B File Offset: 0x0000770B
	private void OnEnable()
	{
		this.firstTimeStepping = true;
	}

	// Token: 0x06000213 RID: 531 RVA: 0x00009514 File Offset: 0x00007714
	public override void Play(string clip)
	{
		if (this.firstTimeStepping)
		{
			if (this.stepParticleEffect)
			{
				Object.Instantiate<GameObject>(this.stepParticleEffect, base.transform.position, Quaternion.identity);
			}
			this.firstTimeStepping = false;
			return;
		}
		if (this.crash.SurfaceType == Surface.Material.Generic)
		{
			clip = this.genericStepSFX;
		}
		else if (this.crash.SurfaceType == Surface.Material.Snow)
		{
			clip = this.snowStepSFX;
		}
		else if (this.crash.SurfaceType == Surface.Material.Stone)
		{
			clip = this.stoneStepSFX;
		}
		else if (this.crash.SurfaceType == Surface.Material.Metal)
		{
			clip = this.metalStepSFX;
		}
		else
		{
			clip = this.genericStepSFX;
		}
		AudioManager.Play(clip, AudioManager.MixerTarget.SFX, null, null);
	}

	// Token: 0x06000214 RID: 532 RVA: 0x000095DC File Offset: 0x000077DC
	public void CheckForTransitionToIdle()
	{
		float sqrMagnitude = this.crash.input.sqrMagnitude;
		if (sqrMagnitude <= this.crash.SqrDeadzone)
		{
			this.crash.animator.SetState(this.crash.animator.idleObj, false);
			return;
		}
		if (sqrMagnitude < 0.5f)
		{
			this.crash.animator.SetState(this.crash.animator.walkObj, false);
			return;
		}
		this.crash.animator.SetState(this.crash.animator.RunObj, false);
	}

	// Token: 0x04000122 RID: 290
	public GameObject stepParticleEffect;

	// Token: 0x04000123 RID: 291
	public CrashController crash;

	// Token: 0x04000124 RID: 292
	public bool firstTimeStepping = true;

	// Token: 0x04000125 RID: 293
	public string genericStepSFX = "SFX_CrashFootstep";

	// Token: 0x04000126 RID: 294
	public string snowStepSFX = "SFX_CrashFootstepSnow";

	// Token: 0x04000127 RID: 295
	public string stoneStepSFX = "SFX_CrashFootstepStone";

	// Token: 0x04000128 RID: 296
	public string metalStepSFX = "SFX_CrashFootstepMetal";
}
