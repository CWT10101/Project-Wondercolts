﻿using System;
using System.Collections;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x0200011B RID: 283
public class SlotCrate : BasicCrate, IMetadataReceiver<SlotCrateMetadata>
{
	// Token: 0x1700010E RID: 270
	// (get) Token: 0x0600089A RID: 2202 RVA: 0x00023E9E File Offset: 0x0002209E
	public Crate CurrentCrate
	{
		get
		{
			if (this.currentIndex >= 0)
			{
				return this.selectedOutcomeCrates[this.currentIndex];
			}
			if (!this.becomesMetal)
			{
				return this.outcomeCrates[0];
			}
			return this.metalCrate;
		}
	}

	// Token: 0x1700010F RID: 271
	// (get) Token: 0x0600089B RID: 2203 RVA: 0x00023ECE File Offset: 0x000220CE
	public override bool AddsToBoxCount
	{
		get
		{
			return false;
		}
	}

	// Token: 0x17000110 RID: 272
	// (get) Token: 0x0600089C RID: 2204 RVA: 0x00023ED1 File Offset: 0x000220D1
	private bool IsCycling
	{
		get
		{
			return this.tStart > 0f;
		}
	}

	// Token: 0x0600089D RID: 2205 RVA: 0x00023EE0 File Offset: 0x000220E0
	private void Awake()
	{
		foreach (Crate crate in this.outcomeCrates)
		{
			crate.onPushedToStack += this.SubCratePushedToStack;
			crate.onBreak += this.SubCrateBreak;
		}
	}

	// Token: 0x0600089E RID: 2206 RVA: 0x00023F28 File Offset: 0x00022128
	private void SubCratePushedToStack()
	{
		this.TryPushToStack();
	}

	// Token: 0x0600089F RID: 2207 RVA: 0x00023F30 File Offset: 0x00022130
	private void SubCrateBreak()
	{
		this.isBroken = true;
		this.intermediaryCrate.SetActive(false);
	}

	// Token: 0x060008A0 RID: 2208 RVA: 0x00023F45 File Offset: 0x00022145
	protected override void OnEnable()
	{
		base.OnEnable();
	}

	// Token: 0x060008A1 RID: 2209 RVA: 0x00023F50 File Offset: 0x00022150
	protected override void FixedUpdate()
	{
		base.FixedUpdate();
		if (this.isBroken)
		{
			return;
		}
		if (this.outlineVis.activeSelf)
		{
			return;
		}
		if (this.currentIndex < 0)
		{
			return;
		}
		if (!this.IsCycling)
		{
			if (!this.startedCycling)
			{
				foreach (Collider collider in Physics.OverlapSphere(this.collider.bounds.center, this.triggerRadius))
				{
					Debug.DrawLine(this.collider.bounds.center, collider.bounds.center, new Color(0f, 1f, 0f, 0.1f), Time.fixedDeltaTime);
					CrashController crashController;
					if (collider.TryGetComponent<CrashController>(out crashController))
					{
						Debug.DrawLine(this.collider.bounds.center, collider.bounds.center, new Color(0f, 1f, 0f), Time.fixedDeltaTime);
						RaycastHit raycastHit = (from h in Physics.RaycastAll(this.collider.bounds.center, collider.bounds.center - base.ColliderCenter, this.triggerRadius, -1, QueryTriggerInteraction.Ignore)
						orderby h.distance
						where h.collider.gameObject != base.gameObject
						select h).FirstOrDefault<RaycastHit>();
						if (raycastHit.collider == collider)
						{
							Debug.DrawLine(this.collider.bounds.center, raycastHit.point, new Color(1f, 0f, 0f), 1f);
							this.tStart = Clock.SynchronizedTime;
							this.tPrev = 1f;
							this.startedCycling = true;
							return;
						}
					}
				}
			}
			return;
		}
		float num = Clock.SynchronizedTime - this.tStart;
		float num2 = this.baseDuration - num * this.rampingRate;
		if (num2 <= this.criticalDuration)
		{
			this.tStart = -1f;
			this.currentIndex = -1;
			Crate[] array2 = this.selectedOutcomeCrates;
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i].gameObject.SetActive(false);
			}
			this.CurrentCrate.gameObject.SetActive(true);
			this.TryPushToStack();
			return;
		}
		float num3 = num % num2;
		if (this.tPrev > num3)
		{
			this.audioSrc.Play();
			this.CycleCrates();
		}
		this.tPrev = num3;
	}

	// Token: 0x060008A2 RID: 2210 RVA: 0x000241E8 File Offset: 0x000223E8
	public void CycleCrates()
	{
		base.StartCoroutine(this.<CycleCrates>g__Routine|25_0());
	}

	// Token: 0x060008A3 RID: 2211 RVA: 0x000241F7 File Offset: 0x000223F7
	public override void Break()
	{
		base.Break();
	}

	// Token: 0x060008A4 RID: 2212 RVA: 0x000241FF File Offset: 0x000223FF
	public override void ForceBreak()
	{
		if (this.isBroken)
		{
			Debug.LogWarning("Trying to break a broken box", this);
			return;
		}
		this.CurrentCrate.Break();
		this.intermediaryCrate.SetActive(false);
		base.OnBreak();
	}

	// Token: 0x060008A5 RID: 2213 RVA: 0x00024234 File Offset: 0x00022434
	public override void ResetEntity()
	{
		if (this.selectedOutcomeCrates == null)
		{
			this.selectedOutcomeCrates = this.outcomeCrates;
		}
		this.CurrentCrate.ResetEntity();
		this.tStart = -1f;
		this.currentIndex = 0;
		this.startedCycling = false;
		foreach (Crate crate in this.selectedOutcomeCrates)
		{
			crate.gameObject.SetActive(false);
			crate.visual.SetActive(true);
		}
		this.metalCrate.gameObject.SetActive(false);
		this.intermediaryCrate.SetActive(false);
		this.selectedOutcomeCrates[0].gameObject.SetActive(!this.startAsOutlineCrate);
		base.ResetEntity();
	}

	// Token: 0x060008A6 RID: 2214 RVA: 0x000242E6 File Offset: 0x000224E6
	public override void SetOutlineMode()
	{
		base.SetOutlineMode();
		this.tStart = -1f;
		this.startedCycling = false;
		this.intermediaryCrate.SetActive(false);
		if (base.isActiveAndEnabled)
		{
			this.CurrentCrate.gameObject.SetActive(false);
		}
	}

	// Token: 0x060008A7 RID: 2215 RVA: 0x00024325 File Offset: 0x00022525
	public override void SetTangibleMode()
	{
		base.SetTangibleMode();
		this.intermediaryCrate.SetActive(false);
		if (base.isActiveAndEnabled)
		{
			this.CurrentCrate.gameObject.SetActive(true);
		}
	}

	// Token: 0x060008A8 RID: 2216 RVA: 0x00024352 File Offset: 0x00022552
	public override void FallOn(CrashController crash)
	{
		IFallOn component = this.CurrentCrate.GetComponent<IFallOn>();
		if (component != null)
		{
			component.FallOn(crash);
		}
		this.EvalulateStatus();
	}

	// Token: 0x060008A9 RID: 2217 RVA: 0x00024371 File Offset: 0x00022571
	public override void Slam(CrashController crash)
	{
		ISlam component = this.CurrentCrate.GetComponent<ISlam>();
		if (component != null)
		{
			component.Slam(crash);
		}
		this.EvalulateStatus();
	}

	// Token: 0x060008AA RID: 2218 RVA: 0x00024390 File Offset: 0x00022590
	public override void Slide(CrashController crash)
	{
		ISlide component = this.CurrentCrate.GetComponent<ISlide>();
		if (component != null)
		{
			component.Slide(crash);
		}
		this.EvalulateStatus();
	}

	// Token: 0x060008AB RID: 2219 RVA: 0x000243AF File Offset: 0x000225AF
	public override void Spin(CrashController crash)
	{
		ISpin component = this.CurrentCrate.GetComponent<ISpin>();
		if (component != null)
		{
			component.Spin(crash);
		}
		this.EvalulateStatus();
	}

	// Token: 0x060008AC RID: 2220 RVA: 0x000243CE File Offset: 0x000225CE
	public override void TouchBottom(CrashController crash)
	{
		ITouchBottom component = this.CurrentCrate.GetComponent<ITouchBottom>();
		if (component != null)
		{
			component.TouchBottom(crash);
		}
		this.EvalulateStatus();
	}

	// Token: 0x060008AD RID: 2221 RVA: 0x000243F0 File Offset: 0x000225F0
	private void EvalulateStatus()
	{
		if (!this.isBroken && this.CurrentCrate.isBroken)
		{
			this.tStart = -1f;
			this.Break();
			return;
		}
		TNTCrate tntcrate = this.CurrentCrate as TNTCrate;
		if (tntcrate != null && tntcrate.lit)
		{
			this.intermediaryCrate.SetActive(false);
			this.CurrentCrate.visual.SetActive(true);
			this.tStart = -1f;
		}
	}

	// Token: 0x060008AE RID: 2222 RVA: 0x00024464 File Offset: 0x00022664
	public void ProcessMetadata(SlotCrateMetadata meta)
	{
		Crate[] array = this.outcomeCrates;
		for (int j = 0; j < array.Length; j++)
		{
			array[j].gameObject.SetActive(false);
		}
		this.selectedOutcomeCrates = (from c in meta.Values.Select(delegate(bool v, int i)
		{
			if (!v)
			{
				return null;
			}
			return this.outcomeCrates[i];
		})
		where c != null
		select c).ToArray<Crate>();
		this.becomesMetal = meta.BecomesMetal;
	}

	// Token: 0x060008B1 RID: 2225 RVA: 0x00024552 File Offset: 0x00022752
	[CompilerGenerated]
	private IEnumerator <CycleCrates>g__Routine|25_0()
	{
		this.CurrentCrate.visual.SetActive(false);
		this.intermediaryCrate.SetActive(true);
		yield return new WaitForSeconds((this.baseDuration - (Clock.SynchronizedTime - this.tStart) * this.rampingRate) * 0.2f);
		if (this.isBroken || !this.IsCycling)
		{
			yield break;
		}
		this.intermediaryCrate.SetActive(false);
		this.CurrentCrate.visual.SetActive(true);
		if (this.currentIndex < this.selectedOutcomeCrates.Length - 1)
		{
			this.currentIndex++;
		}
		else
		{
			this.currentIndex = 0;
		}
		Crate[] array = this.selectedOutcomeCrates;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].gameObject.SetActive(false);
		}
		this.selectedOutcomeCrates[this.currentIndex].gameObject.SetActive(true);
		yield break;
	}

	// Token: 0x0400064C RID: 1612
	public AudioSource audioSrc;

	// Token: 0x0400064D RID: 1613
	public float triggerRadius = 7f;

	// Token: 0x0400064E RID: 1614
	public float baseDuration = 1f;

	// Token: 0x0400064F RID: 1615
	public float rampingRate = 0.1f;

	// Token: 0x04000650 RID: 1616
	public float criticalDuration = 0.2f;

	// Token: 0x04000651 RID: 1617
	public GameObject intermediaryCrate;

	// Token: 0x04000652 RID: 1618
	public Crate metalCrate;

	// Token: 0x04000653 RID: 1619
	public Crate[] outcomeCrates;

	// Token: 0x04000654 RID: 1620
	private int currentIndex;

	// Token: 0x04000655 RID: 1621
	private Crate[] selectedOutcomeCrates;

	// Token: 0x04000656 RID: 1622
	[SerializeField]
	private bool becomesMetal = true;

	// Token: 0x04000657 RID: 1623
	private float tStart = -1f;

	// Token: 0x04000658 RID: 1624
	private bool startedCycling;

	// Token: 0x04000659 RID: 1625
	private float tPrev;
}
