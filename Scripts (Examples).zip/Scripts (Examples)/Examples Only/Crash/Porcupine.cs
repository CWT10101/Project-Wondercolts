﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x020000FB RID: 251
public class Porcupine : BasicEnemy
{
	// Token: 0x060007C2 RID: 1986 RVA: 0x00020DE4 File Offset: 0x0001EFE4
	protected override void FixedUpdate()
	{
		if (this.isDead)
		{
			return;
		}
		base.FixedUpdate();
		if (this.isTriggered)
		{
			this.timer -= Time.deltaTime;
			if (this.timer <= 0f)
			{
				this.timer = 0f;
				this.CalmDown();
			}
		}
		else
		{
			this.SightCheck();
		}
		base.FixedUpdate();
	}

	// Token: 0x060007C3 RID: 1987 RVA: 0x00020E46 File Offset: 0x0001F046
	public override void ResetEntity()
	{
		this.isTriggered = false;
		this.timer = 0f;
		this.animator.SetTrigger("Reset");
		this.speed = 0f;
		base.ResetEntity();
	}

	// Token: 0x060007C4 RID: 1988 RVA: 0x00020E7C File Offset: 0x0001F07C
	public virtual void SightCheck()
	{
		if (!MathUtil.InRange(this.collider.bounds.center, CrashController.instance.transform.position, this.sightDistance))
		{
			return;
		}
		foreach (Collider collider in Physics.OverlapSphere(this.collider.bounds.center, this.sightDistance))
		{
			Debug.DrawLine(this.collider.bounds.center, collider.bounds.center, new Color(0f, 1f, 0f, 0.1f), Time.fixedDeltaTime);
			CrashController crashController;
			if (collider.TryGetComponent<CrashController>(out crashController))
			{
				Debug.DrawLine(this.collider.bounds.center, collider.bounds.center, new Color(0f, 1f, 0f), Time.fixedDeltaTime);
				Vector3 normalized = (collider.bounds.center - this.collider.bounds.center).normalized;
				if (Vector3.Dot(normalized, this._dir.normalized) > 0.5f)
				{
					Debug.DrawLine(this.collider.bounds.center, collider.bounds.center, new Color(1f, 1f, 0f), Time.fixedDeltaTime);
					RaycastHit raycastHit;
					if (Physics.Raycast(this.collider.bounds.center, normalized, out raycastHit, this.sightDistance))
					{
						Debug.DrawLine(this.collider.bounds.center, raycastHit.point, new Color(1f, 0f, 0f), Time.fixedDeltaTime);
						if (raycastHit.collider == collider)
						{
							this.Panic();
							return;
						}
					}
				}
			}
		}
	}

	// Token: 0x060007C5 RID: 1989 RVA: 0x00021080 File Offset: 0x0001F280
	public override void TouchTop(CrashController crash)
	{
		if (this.isTriggered)
		{
			if (!crash.TakeDamage(0))
			{
				Aku aku = crash.pickupHandler.currentMask as Aku;
				if (aku != null && aku.invincibileMode)
				{
					this.SpinDeath(crash.transform);
					return;
				}
				this.Die(true);
				return;
			}
		}
		else
		{
			base.TouchTop(crash);
		}
	}

	// Token: 0x060007C6 RID: 1990 RVA: 0x000210D6 File Offset: 0x0001F2D6
	public override void Slam(CrashController crash)
	{
		if (this.isTriggered)
		{
			if (!crash.TakeDamage(0))
			{
				this.Die(true);
				return;
			}
		}
		else
		{
			base.Slam(crash);
		}
	}

	// Token: 0x060007C7 RID: 1991 RVA: 0x000210F8 File Offset: 0x0001F2F8
	public virtual void Panic()
	{
		if (!this.isDead)
		{
			this.isTriggered = true;
			this.timer = 5f;
			this.animator.SetTrigger("Panic");
			AudioManager.Play(this.sfxClip, new Vector3?(base.transform.position), null);
			base.StartCoroutine(this.<Panic>g__PanicRoutine|10_0());
		}
	}

	// Token: 0x060007C8 RID: 1992 RVA: 0x00021161 File Offset: 0x0001F361
	public virtual void CalmDown()
	{
		this.isTriggered = false;
		this.speed = 0f;
		this.animator.SetTrigger("Calm");
		base.transform.rotation = Quaternion.LookRotation(this._dir);
	}

	// Token: 0x060007CA RID: 1994 RVA: 0x000211C4 File Offset: 0x0001F3C4
	[CompilerGenerated]
	private IEnumerator <Panic>g__PanicRoutine|10_0()
	{
		yield return new WaitForSeconds(0.667f);
		this.speed = this.panicSpeed;
		yield break;
	}

	// Token: 0x040005B7 RID: 1463
	public float panicSpeed = 2f;

	// Token: 0x040005B8 RID: 1464
	public float sightDistance = 5f;

	// Token: 0x040005B9 RID: 1465
	public bool isTriggered;

	// Token: 0x040005BA RID: 1466
	[HideInInspector]
	public float timer;

	// Token: 0x040005BB RID: 1467
	public string sfxClip = "SFX_PorcupineTrigger";
}
