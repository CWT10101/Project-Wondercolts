﻿using System;

namespace System.Runtime.CompilerServices
{
	// Token: 0x0200016D RID: 365
	internal class IsExternalInit
	{
	}
}
