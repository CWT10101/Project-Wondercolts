﻿using System;
using System.IO;
using LevelEditor;

// Token: 0x02000023 RID: 35
public class AggressionMetadata : ObjectMetadata
{
	// Token: 0x17000012 RID: 18
	// (get) Token: 0x060000B2 RID: 178 RVA: 0x00005975 File Offset: 0x00003B75
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x060000B3 RID: 179 RVA: 0x00005978 File Offset: 0x00003B78
	public override int Signature
	{
		get
		{
			return "AggressionMetadata".GetHashCode();
		}
	}

	// Token: 0x17000014 RID: 20
	// (get) Token: 0x060000B4 RID: 180 RVA: 0x00005984 File Offset: 0x00003B84
	public override int ValueHash
	{
		get
		{
			return (int)this.aggressionLevel;
		}
	}

	// Token: 0x060000B5 RID: 181 RVA: 0x0000598C File Offset: 0x00003B8C
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.aggressionLevel);
	}

	// Token: 0x060000B6 RID: 182 RVA: 0x0000599A File Offset: 0x00003B9A
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.aggressionLevel = br.ReadByte();
	}

	// Token: 0x060000B7 RID: 183 RVA: 0x000059A8 File Offset: 0x00003BA8
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<AggressionMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<AggressionMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x04000081 RID: 129
	public byte aggressionLevel;
}
