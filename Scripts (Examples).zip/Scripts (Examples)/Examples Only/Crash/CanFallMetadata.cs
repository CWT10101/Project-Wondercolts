﻿using System;
using System.IO;
using LevelEditor;

// Token: 0x02000025 RID: 37
public class CanFallMetadata : ObjectMetadata
{
	// Token: 0x17000018 RID: 24
	// (get) Token: 0x060000C0 RID: 192 RVA: 0x00005A48 File Offset: 0x00003C48
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x060000C1 RID: 193 RVA: 0x00005A4B File Offset: 0x00003C4B
	public override int Signature
	{
		get
		{
			return "CanFallMetadata".GetHashCode();
		}
	}

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x060000C2 RID: 194 RVA: 0x00005A57 File Offset: 0x00003C57
	public override int ValueHash
	{
		get
		{
			if (!this.value)
			{
				return -1;
			}
			return 1;
		}
	}

	// Token: 0x060000C3 RID: 195 RVA: 0x00005A64 File Offset: 0x00003C64
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<CanFallMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<CanFallMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x060000C4 RID: 196 RVA: 0x00005A90 File Offset: 0x00003C90
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.value = br.ReadBoolean();
	}

	// Token: 0x060000C5 RID: 197 RVA: 0x00005A9E File Offset: 0x00003C9E
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.value);
	}

	// Token: 0x04000083 RID: 131
	public bool value;
}
