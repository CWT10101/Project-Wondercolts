﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x020000ED RID: 237
public class NitroActivatorCrate : Crate, IFallOn, ITouchBottom, ISpin, ISlam, ISlide
{
	// Token: 0x170000F4 RID: 244
	// (get) Token: 0x06000734 RID: 1844 RVA: 0x0001E9C6 File Offset: 0x0001CBC6
	public override bool AddsToBoxCount
	{
		get
		{
			return false;
		}
	}

	// Token: 0x06000735 RID: 1845 RVA: 0x0001E9C9 File Offset: 0x0001CBC9
	public void FallOn(CrashController crash)
	{
		if (this.activated)
		{
			return;
		}
		crash.Bounce();
		this.Activate();
	}

	// Token: 0x06000736 RID: 1846 RVA: 0x0001E9E0 File Offset: 0x0001CBE0
	public void Slam(CrashController crash)
	{
		this.Activate();
	}

	// Token: 0x06000737 RID: 1847 RVA: 0x0001E9E8 File Offset: 0x0001CBE8
	public void Spin(CrashController crash)
	{
		this.Activate();
	}

	// Token: 0x06000738 RID: 1848 RVA: 0x0001E9F0 File Offset: 0x0001CBF0
	public void TouchBottom(CrashController crash)
	{
		this.Activate();
	}

	// Token: 0x06000739 RID: 1849 RVA: 0x0001E9F8 File Offset: 0x0001CBF8
	public void Slide(CrashController crash)
	{
		if (!base.IsAbove(crash))
		{
			this.Activate();
		}
	}

	// Token: 0x0600073A RID: 1850 RVA: 0x0001EA09 File Offset: 0x0001CC09
	public override void Break()
	{
		this.Activate();
	}

	// Token: 0x0600073B RID: 1851 RVA: 0x0001EA11 File Offset: 0x0001CC11
	public override void ForceBreak()
	{
	}

	// Token: 0x0600073C RID: 1852 RVA: 0x0001EA13 File Offset: 0x0001CC13
	public override void Fall(float withVelocity = 0f)
	{
	}

	// Token: 0x0600073D RID: 1853 RVA: 0x0001EA15 File Offset: 0x0001CC15
	public override void ResetEntity()
	{
		this.activated = false;
		if (this.iconAnimator)
		{
			this.iconAnimator.SetTrigger("Reset");
		}
	}

	// Token: 0x0600073E RID: 1854 RVA: 0x0001EA3B File Offset: 0x0001CC3B
	protected override void OnEnable()
	{
		if (this.iconAnimator && this.activated)
		{
			this.iconAnimator.SetTrigger("Activate");
		}
		base.OnEnable();
	}

	// Token: 0x0600073F RID: 1855 RVA: 0x0001EA68 File Offset: 0x0001CC68
	private void Activate()
	{
		if (this.activated)
		{
			return;
		}
		this.TryPushToStack();
		this.activated = true;
		AudioManager.Play("SFX_ActivatorCrate", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		if (this.iconAnimator)
		{
			this.iconAnimator.SetTrigger("Activate");
		}
		base.StartCoroutine(NitroActivatorCrate.<Activate>g__ActivateRoutine|15_0());
	}

	// Token: 0x06000741 RID: 1857 RVA: 0x0001EAEC File Offset: 0x0001CCEC
	[CompilerGenerated]
	internal static IEnumerator <Activate>g__ActivateRoutine|15_0()
	{
		foreach (NitroCrate nitroCrate in NitroCrate.Crates)
		{
			if (!nitroCrate.isBroken && !nitroCrate.outlineVis.activeSelf)
			{
				nitroCrate.Explode();
				yield return new WaitForFixedUpdate();
			}
		}
		HashSet<NitroCrate>.Enumerator enumerator = default(HashSet<NitroCrate>.Enumerator);
		yield break;
		yield break;
	}

	// Token: 0x0400055E RID: 1374
	public Animator iconAnimator;

	// Token: 0x0400055F RID: 1375
	public float waitTime = 0.25f;

	// Token: 0x04000560 RID: 1376
	private bool activated;
}
