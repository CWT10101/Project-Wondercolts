﻿using System;
using Cinemachine;
using UnityEngine;

// Token: 0x0200007C RID: 124
public class CameraMixByDistance : MonoBehaviour
{
	// Token: 0x0600037E RID: 894 RVA: 0x0000F0F0 File Offset: 0x0000D2F0
	private void LateUpdate()
	{
		Transform transform = this.targetTfs[0];
		float num = Vector3.SqrMagnitude(transform.position - this.sourceTf.position);
		for (int i = 1; i < this.targetTfs.Length; i++)
		{
			float num2 = Vector3.SqrMagnitude(this.targetTfs[i].position - this.sourceTf.position);
			if (num2 < num)
			{
				num = num2;
				transform = this.targetTfs[i];
			}
		}
		float value = Vector3.Distance(this.sourceTf.position, transform.position);
		float num3 = Mathf.InverseLerp(this.minDist, this.maxDist, value);
		this.mixCam.SetWeight(0, Mathf.Clamp01(num3));
		this.mixCam.SetWeight(1, Mathf.Clamp01(1f - num3));
	}

	// Token: 0x0600037F RID: 895 RVA: 0x0000F1C4 File Offset: 0x0000D3C4
	private void OnValidate()
	{
		if (this.targetTfs == null || this.targetTfs.Length == 0)
		{
			Debug.LogWarning(base.gameObject.name + " (" + base.gameObject.scene.name + ") needs a target assigned", this);
		}
	}

	// Token: 0x0400024C RID: 588
	public CinemachineMixingCamera mixCam;

	// Token: 0x0400024D RID: 589
	public Transform sourceTf;

	// Token: 0x0400024E RID: 590
	public Transform targetTf;

	// Token: 0x0400024F RID: 591
	public Transform[] targetTfs;

	// Token: 0x04000250 RID: 592
	public float minDist;

	// Token: 0x04000251 RID: 593
	public float maxDist;
}
