﻿using System;
using System.IO;
using LevelEditor;

// Token: 0x0200002B RID: 43
public class MaxHPMetadata : ObjectMetadata
{
	// Token: 0x1700002E RID: 46
	// (get) Token: 0x06000102 RID: 258 RVA: 0x00006348 File Offset: 0x00004548
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x1700002F RID: 47
	// (get) Token: 0x06000103 RID: 259 RVA: 0x0000634B File Offset: 0x0000454B
	public override int Signature
	{
		get
		{
			return "MaxHPMetadata".GetHashCode();
		}
	}

	// Token: 0x17000030 RID: 48
	// (get) Token: 0x06000104 RID: 260 RVA: 0x00006357 File Offset: 0x00004557
	public override int ValueHash
	{
		get
		{
			return (int)this.maxHP;
		}
	}

	// Token: 0x06000105 RID: 261 RVA: 0x0000635F File Offset: 0x0000455F
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.maxHP);
	}

	// Token: 0x06000106 RID: 262 RVA: 0x0000636D File Offset: 0x0000456D
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.maxHP = br.ReadByte();
	}

	// Token: 0x06000107 RID: 263 RVA: 0x0000637C File Offset: 0x0000457C
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<MaxHPMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<MaxHPMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x0400008F RID: 143
	public byte maxHP;
}
