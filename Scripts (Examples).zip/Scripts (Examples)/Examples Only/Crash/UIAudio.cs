﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Token: 0x02000158 RID: 344
public class UIAudio : MonoBehaviour, ISelectHandler, IEventSystemHandler, IPointerEnterHandler
{
	// Token: 0x060009F7 RID: 2551 RVA: 0x00027F19 File Offset: 0x00026119
	private void Awake()
	{
		if (base.TryGetComponent<Button>(out this.btn))
		{
			this.btn.onClick.AddListener(delegate()
			{
				AudioManager.Play("clickUI", AudioManager.MixerTarget.UI, null, null);
			});
		}
	}

	// Token: 0x060009F8 RID: 2552 RVA: 0x00027F58 File Offset: 0x00026158
	public void OnPointerEnter(PointerEventData eventData)
	{
		if (!this.btn || this.btn.interactable)
		{
			if (base.GetComponentInParent<CanvasGroup>())
			{
				if (base.GetComponentInParent<CanvasGroup>().interactable)
				{
					AudioManager.Play("hoverUI", AudioManager.MixerTarget.UI, null, null);
					return;
				}
			}
			else
			{
				AudioManager.Play("hoverUI", AudioManager.MixerTarget.UI, null, null);
			}
		}
	}

	// Token: 0x060009F9 RID: 2553 RVA: 0x00027FD8 File Offset: 0x000261D8
	public void OnSelect(BaseEventData eventData)
	{
		if (eventData is PointerEventData)
		{
			return;
		}
		if (!this.btn || this.btn.interactable)
		{
			AudioManager.Play("hoverUI", AudioManager.MixerTarget.UI, null, null);
		}
	}

	// Token: 0x060009FA RID: 2554 RVA: 0x00028028 File Offset: 0x00026228
	public void PlayClickSound()
	{
		AudioManager.Play("clickUI", null, null);
	}

	// Token: 0x0400072C RID: 1836
	private Button btn;
}
