﻿using System;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200010D RID: 269
public class SaveSlotUI : MonoBehaviour
{
	// Token: 0x06000840 RID: 2112 RVA: 0x00022C24 File Offset: 0x00020E24
	public void Refresh()
	{
		this.border.SetActive(this.slotIndex != -1 && this.slotIndex == (int)SaveData.ActiveSlot);
		SaveDataInfo info;
		if ((this.slotIndex == -1 && (info = SaveData.Info) != null) || SaveData.GetSlotInfo((byte)this.slotIndex, out info))
		{
			this.mainContent.SetActive(true);
			this.emptyContent.SetActive(false);
			this.saveTitleText.text = info.name;
			this.savePercentText.text = string.Format("{0}%", Mathf.FloorToInt(info.Progress * 100f));
			this.lifeCountText.text = string.Format("{0}", info.lives);
			this.gemCountText.text = string.Format("{0}", info.lvlAllCrates.CountNotDefault<bool>());
			this.tapeCountText.text = string.Format("{0}", info.lvlTapes.CountNotDefault<bool>());
			this.autoSaveTickObj.SetActive(info.useAutosave);
			return;
		}
		this.mainContent.SetActive(false);
		this.emptyContent.SetActive(true);
	}

	// Token: 0x06000841 RID: 2113 RVA: 0x00022D64 File Offset: 0x00020F64
	public void LoadSaveButtonHook()
	{
		if (this.context != SaveSlotUI.Context.Save)
		{
			if (this.context == SaveSlotUI.Context.Load)
			{
				if (SaveData.SlotExists((sbyte)this.slotIndex))
				{
					SaveData.ActiveSlot = (SaveData.ContinueSlot = (sbyte)this.slotIndex);
					SaveData.Load();
					InterfaceManager.instance.saveLoadScreen.activeSlot.Refresh();
					InterfaceManager.instance.saveLoadScreen.SetSlots();
					WarpRoom.instance.UpdateWarpDoors();
					InterfaceManager.instance.hudTrack.SetLivesText();
					InterfaceManager.instance.hudTrack.SetWumpaText((int)SaveData.Info.wumpa);
					ScreenCanvas.instance.CheckVisitedCreator();
					return;
				}
			}
			else if (this.context == SaveSlotUI.Context.Delete)
			{
				InterfaceManager.instance.dynamicConfirmScreen.DisplayMessage("DELETE?", "You are about to permanently delete save slot \"" + this.saveTitleText.text + "\". Are you sure?", true, new Action(this.<LoadSaveButtonHook>g__DoDelete|14_1), null);
			}
			return;
		}
		if (SaveData.SlotExists((sbyte)this.slotIndex))
		{
			InterfaceManager.instance.dynamicConfirmScreen.DisplayMessage("OVERWRITE?", "You are about to overwrite save slot \"" + this.saveTitleText.text + "\". Are you sure?", true, new Action(this.<LoadSaveButtonHook>g__DoSave|14_0), null);
			return;
		}
		InterfaceManager.instance.confirmSaveScreen.Open(new Action(this.<LoadSaveButtonHook>g__DoSave|14_0));
	}

	// Token: 0x06000843 RID: 2115 RVA: 0x00022EC1 File Offset: 0x000210C1
	[CompilerGenerated]
	private void <LoadSaveButtonHook>g__DoSave|14_0()
	{
		SaveData.ActiveSlot = (SaveData.ContinueSlot = (sbyte)this.slotIndex);
		SaveData.Save();
		InterfaceManager.instance.saveLoadScreen.activeSlot.Refresh();
		InterfaceManager.instance.saveLoadScreen.SetSlots();
	}

	// Token: 0x06000844 RID: 2116 RVA: 0x00022EFD File Offset: 0x000210FD
	[CompilerGenerated]
	private void <LoadSaveButtonHook>g__DoDelete|14_1()
	{
		if (SaveData.ContinueSlot == (sbyte)this.slotIndex)
		{
			SaveData.ContinueSlot = -1;
		}
		SaveData.Delete((byte)this.slotIndex);
		this.Refresh();
	}

	// Token: 0x04000601 RID: 1537
	[SerializeField]
	private int slotIndex;

	// Token: 0x04000602 RID: 1538
	public TMP_Text saveTitleText;

	// Token: 0x04000603 RID: 1539
	public TMP_Text savePercentText;

	// Token: 0x04000604 RID: 1540
	public Image saveIcon;

	// Token: 0x04000605 RID: 1541
	public TMP_Text lifeCountText;

	// Token: 0x04000606 RID: 1542
	public TMP_Text gemCountText;

	// Token: 0x04000607 RID: 1543
	public TMP_Text tapeCountText;

	// Token: 0x04000608 RID: 1544
	public GameObject mainContent;

	// Token: 0x04000609 RID: 1545
	public GameObject emptyContent;

	// Token: 0x0400060A RID: 1546
	public GameObject autoSaveTickObj;

	// Token: 0x0400060B RID: 1547
	public GameObject border;

	// Token: 0x0400060C RID: 1548
	public SaveSlotUI.Context context;

	// Token: 0x0200022F RID: 559
	public enum Context
	{
		// Token: 0x04000D5D RID: 3421
		Save,
		// Token: 0x04000D5E RID: 3422
		Load,
		// Token: 0x04000D5F RID: 3423
		Delete
	}
}
