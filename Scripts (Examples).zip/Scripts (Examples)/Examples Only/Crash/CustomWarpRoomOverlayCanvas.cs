﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000095 RID: 149
public class CustomWarpRoomOverlayCanvas : MonoBehaviour
{
	// Token: 0x06000485 RID: 1157 RVA: 0x0001485B File Offset: 0x00012A5B
	private void Update()
	{
		if (this.timer > 0f)
		{
			this.timer -= Time.deltaTime;
			return;
		}
		this.screen.SetActive(false);
	}

	// Token: 0x06000486 RID: 1158 RVA: 0x00014889 File Offset: 0x00012A89
	public void ShowScreen(int time, string levelName = "", string levelAuthor = "")
	{
		this.screen.SetActive(true);
		this.levelNameText.text = levelName;
		this.levelAuthorText.text = levelAuthor;
		this.timer = (float)time;
	}

	// Token: 0x06000487 RID: 1159 RVA: 0x000148B8 File Offset: 0x00012AB8
	public void ShowScreen(int time, LevelSerializer.LevelHeader header)
	{
		this.timer = (float)time;
		this.screen.SetActive(true);
		this.levelNameText.text = header.Title;
		this.levelAuthorText.text = header.Author;
		this.levelTypeText.text = ResourceManager.LevelTypeNames[header.LevelType];
		GameObject[] array = this.panels;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(false);
		}
		this.panels[header.LevelType].SetActive(true);
	}

	// Token: 0x04000328 RID: 808
	public GameObject screen;

	// Token: 0x04000329 RID: 809
	public TMP_Text levelNameText;

	// Token: 0x0400032A RID: 810
	public TMP_Text levelAuthorText;

	// Token: 0x0400032B RID: 811
	public TMP_Text levelTypeText;

	// Token: 0x0400032C RID: 812
	public Animator animator;

	// Token: 0x0400032D RID: 813
	[HideInInspector]
	public float timer;

	// Token: 0x0400032E RID: 814
	public GameObject[] panels;

	// Token: 0x0400032F RID: 815
	[Header("Adventure Panel")]
	public GameObject allCratesObj;

	// Token: 0x04000330 RID: 816
	public GameObject crystalObj;

	// Token: 0x04000331 RID: 817
	public GameObject noCratesObj;

	// Token: 0x04000332 RID: 818
	public GameObject allCratesFill;

	// Token: 0x04000333 RID: 819
	public GameObject crystalFill;

	// Token: 0x04000334 RID: 820
	public GameObject noCratesFill;
}
