﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200005E RID: 94
public class BasicCrate : Crate, IFallOn, ISpin, ISlide, ISlam, ITouchBottom
{
	// Token: 0x1700006A RID: 106
	// (get) Token: 0x06000238 RID: 568 RVA: 0x00009CBB File Offset: 0x00007EBB
	public override bool AddsToBoxCount
	{
		get
		{
			return true;
		}
	}

	// Token: 0x06000239 RID: 569 RVA: 0x00009CBE File Offset: 0x00007EBE
	public override void Break()
	{
		this.SpawnPickups();
		base.Break();
	}

	// Token: 0x0600023A RID: 570 RVA: 0x00009CCC File Offset: 0x00007ECC
	protected void SpawnPickups()
	{
		if (this.spawnOnBreak)
		{
			if (this.pickups.Length > 1)
			{
				int num = Random.Range(0, this.pickups.Length);
				if (num < 20)
				{
					for (int i = 0; i < this.spawnPoints.Length; i++)
					{
						this.spawnedPickups.Add(Object.Instantiate<Pickup>(this.pickups[0], this.spawnPoints[i].position, Quaternion.identity));
					}
					return;
				}
				this.spawnedPickups.Add(Object.Instantiate<Pickup>(this.pickups[num], this.spawnPoints[0].position, Quaternion.identity));
				return;
			}
			else
			{
				if (this.spawnPoints.Length > 1)
				{
					Debug.Log("Spawning multiple " + this.pickups[0].name + " due to multiple spawn points being set");
					for (int j = 0; j < this.spawnPoints.Length; j++)
					{
						this.spawnedPickups.Add(Object.Instantiate<Pickup>(this.pickups[0], this.spawnPoints[j].position, Quaternion.identity));
					}
					return;
				}
				this.spawnedPickups.Add(Object.Instantiate<Pickup>(this.pickups[0], this.spawnPoints[0].position, Quaternion.identity));
			}
		}
	}

	// Token: 0x0600023B RID: 571 RVA: 0x00009E00 File Offset: 0x00008000
	public override void ResetEntity()
	{
		this.CleanupSpawnedPickups();
		base.ResetEntity();
	}

	// Token: 0x0600023C RID: 572 RVA: 0x00009E10 File Offset: 0x00008010
	protected virtual void OnDestroy()
	{
		if (base.gameObject.scene.isLoaded)
		{
			this.CleanupSpawnedPickups();
		}
	}

	// Token: 0x0600023D RID: 573 RVA: 0x00009E38 File Offset: 0x00008038
	protected void CleanupSpawnedPickups()
	{
		this.spawnedPickups.RemoveAll((Pickup p) => !p);
		this.spawnedPickups.ForEach(delegate(Pickup p)
		{
			Object.Destroy(p.gameObject);
		});
		this.spawnedPickups.Clear();
	}

	// Token: 0x0600023E RID: 574 RVA: 0x00009EA5 File Offset: 0x000080A5
	public virtual void FallOn(CrashController crash)
	{
		this.Break();
		crash.Bounce();
	}

	// Token: 0x0600023F RID: 575 RVA: 0x00009EB3 File Offset: 0x000080B3
	public virtual void Slam(CrashController crash)
	{
		this.Break();
	}

	// Token: 0x06000240 RID: 576 RVA: 0x00009EBB File Offset: 0x000080BB
	public virtual void Slide(CrashController crash)
	{
		if (!base.IsAbove(crash))
		{
			this.Break();
			return;
		}
		if (base.CheckGap(crash))
		{
			this.FallOn(crash);
		}
	}

	// Token: 0x06000241 RID: 577 RVA: 0x00009EDD File Offset: 0x000080DD
	public virtual void Spin(CrashController crash)
	{
		if (base.IsAbove(crash))
		{
			crash.PseudoLand();
		}
		this.Break();
	}

	// Token: 0x06000242 RID: 578 RVA: 0x00009EF4 File Offset: 0x000080F4
	public virtual void TouchBottom(CrashController crash)
	{
		this.Break();
		crash.StopAscent();
	}

	// Token: 0x04000142 RID: 322
	public Transform[] spawnPoints;

	// Token: 0x04000143 RID: 323
	public Pickup[] pickups;

	// Token: 0x04000144 RID: 324
	public bool spawnOnBreak = true;

	// Token: 0x04000145 RID: 325
	protected readonly List<Pickup> spawnedPickups = new List<Pickup>();
}
