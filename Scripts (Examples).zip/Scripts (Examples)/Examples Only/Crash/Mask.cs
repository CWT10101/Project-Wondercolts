﻿using System;
using UnityEngine;

// Token: 0x020000E0 RID: 224
public abstract class Mask : Pickup
{
	// Token: 0x060006E1 RID: 1761 RVA: 0x0001D632 File Offset: 0x0001B832
	public virtual void SetTarget(Transform targ)
	{
		this.target = targ;
	}

	// Token: 0x060006E2 RID: 1762 RVA: 0x0001D63C File Offset: 0x0001B83C
	public override void OnTriggerEnter(Collider other)
	{
		PickupHandler pickupHandler;
		if (other.TryGetComponent<PickupHandler>(out pickupHandler))
		{
			ObjectDispenser componentInParent = base.GetComponentInParent<ObjectDispenser>();
			if (componentInParent != null)
			{
				componentInParent.TryPushToStack();
			}
			this.SetTarget(pickupHandler.transform);
			this.collider.enabled = false;
			AudioManager.Play(this.pickupSFX, AudioManager.MixerTarget.SFX, null, null);
			if (this.collectEffect)
			{
				Object.Instantiate<GameObject>(this.collectEffect, base.transform.position, Quaternion.identity);
			}
		}
	}

	// Token: 0x060006E3 RID: 1763 RVA: 0x0001D6C4 File Offset: 0x0001B8C4
	protected virtual void LateUpdate()
	{
		if (this.target)
		{
			Vector3 localPosition = Vector3.up * Mathf.Sin(Time.time * this.bobRate) * this.bobHeight;
			base.transform.position = Vector3.Lerp(base.transform.position, this.target.TransformPoint(this.offset), 1f - Mathf.Exp(-this.moveSpeed * Time.deltaTime));
			this.bobTf.localPosition = localPosition;
			base.transform.rotation = Quaternion.Lerp(base.transform.rotation, this.target.rotation, this.rotateSpeed * Time.deltaTime);
		}
	}

	// Token: 0x060006E4 RID: 1764 RVA: 0x0001D78A File Offset: 0x0001B98A
	public override void Spin(CrashController crash)
	{
	}

	// Token: 0x04000537 RID: 1335
	public Transform bobTf;

	// Token: 0x04000538 RID: 1336
	public float moveSpeed;

	// Token: 0x04000539 RID: 1337
	public float rotateSpeed;

	// Token: 0x0400053A RID: 1338
	[HideInInspector]
	public Transform target;

	// Token: 0x0400053B RID: 1339
	public Vector3 offset;

	// Token: 0x0400053C RID: 1340
	public float bobRate = 1f;

	// Token: 0x0400053D RID: 1341
	public float bobHeight = 1f;
}
