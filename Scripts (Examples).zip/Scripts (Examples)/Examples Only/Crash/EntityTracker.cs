﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000AE RID: 174
public class EntityTracker : MonoBehaviour
{
	// Token: 0x06000573 RID: 1395 RVA: 0x000184D4 File Offset: 0x000166D4
	private void Awake()
	{
		EntityTracker.instance = this;
	}

	// Token: 0x06000574 RID: 1396 RVA: 0x000184DC File Offset: 0x000166DC
	private void OnDestroy()
	{
		if (EntityTracker.instance == this)
		{
			EntityTracker.instance = null;
		}
	}

	// Token: 0x06000575 RID: 1397 RVA: 0x000184F1 File Offset: 0x000166F1
	public static bool IsOnStack(Entity entity)
	{
		return EntityTracker.instance && EntityTracker.instance.entityStack.Contains(entity);
	}

	// Token: 0x06000576 RID: 1398 RVA: 0x00018511 File Offset: 0x00016711
	public static void PushToStack(Entity entity)
	{
		if (!EntityTracker.instance)
		{
			return;
		}
		if (EntityTracker.instance.entityStack.Contains(entity))
		{
			return;
		}
		EntityTracker.instance.entityStack.Push(entity);
	}

	// Token: 0x06000577 RID: 1399 RVA: 0x00018543 File Offset: 0x00016743
	public static void SetCache()
	{
		if (!EntityTracker.instance)
		{
			return;
		}
		EntityTracker.instance.cachePoint = EntityTracker.instance.entityStack.Count;
	}

	// Token: 0x06000578 RID: 1400 RVA: 0x0001856B File Offset: 0x0001676B
	public static IEnumerator<Entity> PopCache()
	{
		if (!EntityTracker.instance)
		{
			yield break;
		}
		while (EntityTracker.instance.entityStack.Count > EntityTracker.instance.cachePoint)
		{
			yield return EntityTracker.instance.entityStack.Pop();
		}
		EntityTracker.instance.cachePoint = 0;
		yield break;
	}

	// Token: 0x06000579 RID: 1401 RVA: 0x00018574 File Offset: 0x00016774
	public static void ClearCache()
	{
		if (!EntityTracker.instance)
		{
			return;
		}
		IEnumerator<Entity> enumerator = EntityTracker.PopCache();
		while (enumerator.MoveNext())
		{
		}
	}

	// Token: 0x0600057A RID: 1402 RVA: 0x0001859C File Offset: 0x0001679C
	public static void Dump()
	{
		if (!EntityTracker.instance)
		{
			return;
		}
		EntityTracker.instance.entityStack.Clear();
		EntityTracker.instance.cachePoint = 0;
	}

	// Token: 0x040003D1 RID: 977
	public static EntityTracker instance;

	// Token: 0x040003D2 RID: 978
	public Stack<Entity> entityStack = new Stack<Entity>();

	// Token: 0x040003D3 RID: 979
	private int cachePoint;
}
