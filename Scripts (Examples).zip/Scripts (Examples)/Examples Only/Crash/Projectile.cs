﻿using System;
using UnityEngine;

// Token: 0x02000102 RID: 258
public class Projectile : Entity
{
	// Token: 0x060007DD RID: 2013 RVA: 0x00021616 File Offset: 0x0001F816
	private void Start()
	{
		this.TryPushToStack();
		this.timeSpawned = Clock.SynchronizedTime;
	}

	// Token: 0x060007DE RID: 2014 RVA: 0x0002162C File Offset: 0x0001F82C
	protected virtual void FixedUpdate()
	{
		base.transform.Translate(this.flightSpeed * Time.fixedDeltaTime * base.transform.forward, Space.World);
		if (this.lifetime > 0f && Clock.SynchronizedTime - this.timeSpawned >= this.lifetime)
		{
			this.Break();
			return;
		}
	}

	// Token: 0x060007DF RID: 2015 RVA: 0x0002168C File Offset: 0x0001F88C
	protected virtual void OnTriggerEnter(Collider other)
	{
		if (other.isTrigger)
		{
			return;
		}
		CrashController componentInParent = other.GetComponentInParent<CrashController>();
		if (componentInParent != null)
		{
			componentInParent.TakeDamage(this.crashDeathIndex);
		}
		else
		{
			SwitchCrate component = other.GetComponent<SwitchCrate>();
			if (component != null)
			{
				component.ToggleSwitchState();
			}
		}
		this.Break();
	}

	// Token: 0x060007E0 RID: 2016 RVA: 0x000216D4 File Offset: 0x0001F8D4
	protected virtual void Break()
	{
		if (this.spawnOnCollision)
		{
			Object.Instantiate<GameObject>(this.spawnOnCollision, base.transform.position, base.transform.rotation);
		}
		if (!string.IsNullOrEmpty(this.collisionSFX))
		{
			AudioManager.Play(this.collisionSFX, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		}
		Object.Destroy(base.gameObject);
	}

	// Token: 0x060007E1 RID: 2017 RVA: 0x0002174E File Offset: 0x0001F94E
	protected virtual void OnDisable()
	{
		Object.Destroy(base.gameObject);
	}

	// Token: 0x060007E2 RID: 2018 RVA: 0x0002175B File Offset: 0x0001F95B
	public override void ResetEntity()
	{
		Object.Destroy(base.gameObject);
	}

	// Token: 0x040005C4 RID: 1476
	public Vector3 spawnOffset = Vector3.zero;

	// Token: 0x040005C5 RID: 1477
	public float flightSpeed = 1f;

	// Token: 0x040005C6 RID: 1478
	public GameObject spawnOnCollision;

	// Token: 0x040005C7 RID: 1479
	public string collisionSFX;

	// Token: 0x040005C8 RID: 1480
	public int crashDeathIndex;

	// Token: 0x040005C9 RID: 1481
	public float lifetime = -1f;

	// Token: 0x040005CA RID: 1482
	[HideInInspector]
	public float timeSpawned;
}
