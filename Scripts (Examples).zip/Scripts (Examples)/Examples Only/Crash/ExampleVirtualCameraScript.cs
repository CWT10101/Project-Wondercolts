﻿using System;
using UnityEngine;

// Token: 0x020000B2 RID: 178
public class ExampleVirtualCameraScript : MonoBehaviour
{
	// Token: 0x0600058C RID: 1420 RVA: 0x0001898C File Offset: 0x00016B8C
	private void Start()
	{
		this._recomposer = base.GetComponent<CinemachineRecomposer>();
	}

	// Token: 0x0600058D RID: 1421 RVA: 0x0001899A File Offset: 0x00016B9A
	private void Update()
	{
		this.RotateCamera();
	}

	// Token: 0x0600058E RID: 1422 RVA: 0x000189A4 File Offset: 0x00016BA4
	private void RotateCamera()
	{
		this._eulerAngles = base.transform.rotation.eulerAngles;
		this._eulerAngles.y = this.CameraFollowTargetTransform.rotation.eulerAngles.y;
		base.transform.rotation = Quaternion.Euler(this._eulerAngles);
		this._recomposer.m_Tilt = this.CameraFollowTarget.GetTilt();
		this._recomposer.m_Pan = this.CameraFollowTarget.GetPan();
	}

	// Token: 0x040003ED RID: 1005
	[SerializeField]
	private Transform CameraFollowTargetTransform;

	// Token: 0x040003EE RID: 1006
	[SerializeField]
	private ExampleCameraFollowTarget CameraFollowTarget;

	// Token: 0x040003EF RID: 1007
	private CinemachineRecomposer _recomposer;

	// Token: 0x040003F0 RID: 1008
	private Vector3 _eulerAngles;
}
