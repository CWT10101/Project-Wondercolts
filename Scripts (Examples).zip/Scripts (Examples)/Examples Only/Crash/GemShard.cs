﻿using System;
using UnityEngine;

// Token: 0x0200011E RID: 286
public class GemShard : Pickup
{
	// Token: 0x060008B6 RID: 2230 RVA: 0x000245D4 File Offset: 0x000227D4
	public void Init(ShardsGem _gem, int _index)
	{
		this.gem = _gem;
		this.index = _index;
	}

	// Token: 0x060008B7 RID: 2231 RVA: 0x000245E4 File Offset: 0x000227E4
	public override void Despawn()
	{
		this.gem.CollectShard(this.index);
		base.Despawn();
	}

	// Token: 0x0400065F RID: 1631
	[HideInInspector]
	public ShardsGem gem;

	// Token: 0x04000660 RID: 1632
	public bool collected;

	// Token: 0x04000661 RID: 1633
	private int index;
}
