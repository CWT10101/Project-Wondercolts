﻿using System;
using UnityEngine;

// Token: 0x02000129 RID: 297
public class SpinDamager : MonoBehaviour
{
	// Token: 0x17000113 RID: 275
	// (get) Token: 0x060008E0 RID: 2272 RVA: 0x00024C8F File Offset: 0x00022E8F
	public CrashController Crash
	{
		get
		{
			if (this._crash == null)
			{
				this._crash = base.GetComponentInParent<CrashController>();
			}
			return this._crash;
		}
	}

	// Token: 0x060008E1 RID: 2273 RVA: 0x00024CB1 File Offset: 0x00022EB1
	private void OnEnable()
	{
		this.SetCollider();
	}

	// Token: 0x060008E2 RID: 2274 RVA: 0x00024CB9 File Offset: 0x00022EB9
	private void FixedUpdate()
	{
		this.SetCollider();
	}

	// Token: 0x060008E3 RID: 2275 RVA: 0x00024CC4 File Offset: 0x00022EC4
	private void SetCollider()
	{
		float y = this.Crash.IsGrounded ? ((this.Crash.input.sqrMagnitude > this.Crash.SqrDeadzone) ? this.highHeight : this.lowHeight) : this.highHeight;
		float z = this.extentDistance * this.Crash.input.magnitude;
		this.colliderTf.localPosition = new Vector3(0f, y, z);
		float y2 = this.Crash.IsGrounded ? ((this.Crash.input.sqrMagnitude > this.Crash.SqrDeadzone) ? this.maxThickness : this.minThickness) : this.minThickness;
		this.colliderTf.localScale = new Vector3(this.diameter, y2, Mathf.Lerp(this.diameter, this.squishDiameter, this.Crash.input.magnitude));
	}

	// Token: 0x060008E4 RID: 2276 RVA: 0x00024DBC File Offset: 0x00022FBC
	private void OnTriggerEnter(Collider other)
	{
		ISpin spin;
		if (other.TryGetComponent<ISpin>(out spin))
		{
			Vector3 center = this.collider.bounds.center;
			Vector3 vector = other.bounds.center - center;
			Debug.DrawRay(center, vector, Color.cyan, 2f, false);
			RaycastHit raycastHit;
			if (Physics.Raycast(center, vector, out raycastHit, vector.magnitude, LayerMask.GetMask(new string[]
			{
				"Entity"
			}), QueryTriggerInteraction.Collide))
			{
				Debug.DrawLine(center, raycastHit.point, Color.red, 2f, false);
				HitTrigger hitTrigger;
				if (raycastHit.collider.TryGetComponent<HitTrigger>(out hitTrigger))
				{
					hitTrigger.OnTriggerEnter(this.Crash.controller);
					return;
				}
			}
			spin.Spin(this.Crash);
		}
	}

	// Token: 0x060008E5 RID: 2277 RVA: 0x00024E80 File Offset: 0x00023080
	private void OnCollisionEnter(Collision collision)
	{
		ISpin spin;
		if (collision.gameObject.TryGetComponent<ISpin>(out spin))
		{
			spin.Spin(this.Crash);
		}
	}

	// Token: 0x04000679 RID: 1657
	public Collider collider;

	// Token: 0x0400067A RID: 1658
	public Transform colliderTf;

	// Token: 0x0400067B RID: 1659
	public float lowHeight;

	// Token: 0x0400067C RID: 1660
	public float highHeight;

	// Token: 0x0400067D RID: 1661
	public float extentDistance;

	// Token: 0x0400067E RID: 1662
	public float minThickness;

	// Token: 0x0400067F RID: 1663
	public float maxThickness;

	// Token: 0x04000680 RID: 1664
	public float diameter;

	// Token: 0x04000681 RID: 1665
	public float squishDiameter;

	// Token: 0x04000682 RID: 1666
	private CrashController _crash;
}
