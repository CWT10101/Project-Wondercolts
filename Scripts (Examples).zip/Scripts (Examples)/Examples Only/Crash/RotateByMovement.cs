﻿using System;
using UnityEngine;

// Token: 0x02000109 RID: 265
public class RotateByMovement : MonoBehaviour
{
	// Token: 0x06000817 RID: 2071 RVA: 0x0002225D File Offset: 0x0002045D
	private void Start()
	{
		this.lastPos = base.transform.position;
	}

	// Token: 0x06000818 RID: 2072 RVA: 0x00022270 File Offset: 0x00020470
	private void Update()
	{
		Vector3 forward = base.transform.position - this.lastPos;
		forward.y = 0f;
		forward.Normalize();
		if (forward.sqrMagnitude > 0.001f)
		{
			base.transform.rotation = Quaternion.RotateTowards(base.transform.rotation, Quaternion.LookRotation(forward), this.rotationSpeed * 360f * Time.deltaTime);
			this.lastPos = base.transform.position;
		}
	}

	// Token: 0x040005E6 RID: 1510
	public float rotationSpeed = 1f;

	// Token: 0x040005E7 RID: 1511
	private Vector3 lastPos;

	// Token: 0x040005E8 RID: 1512
	private const float deadzone = 0.001f;
}
