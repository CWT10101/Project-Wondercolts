﻿using System;
using UnityEngine;

// Token: 0x020000C8 RID: 200
public class IntroSequence : MonoBehaviour
{
	// Token: 0x0600060F RID: 1551 RVA: 0x0001A87C File Offset: 0x00018A7C
	private void LateUpdate()
	{
		Vector3 position = this.cam.position;
		float timeSinceLevelLoad = Time.timeSinceLevelLoad;
		position.y = this.curve.Evaluate(timeSinceLevelLoad);
		this.cam.position = position;
		if (timeSinceLevelLoad > this.curve.keys[this.curve.length - 1].time)
		{
			this.trigger.SetActive(true);
			base.enabled = false;
		}
	}

	// Token: 0x04000473 RID: 1139
	public GameObject trigger;

	// Token: 0x04000474 RID: 1140
	public Transform cam;

	// Token: 0x04000475 RID: 1141
	public AnimationCurve curve;
}
