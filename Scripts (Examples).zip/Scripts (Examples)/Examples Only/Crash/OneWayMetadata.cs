﻿using System;
using System.IO;
using LevelEditor;

// Token: 0x0200002D RID: 45
public class OneWayMetadata : ObjectMetadata
{
	// Token: 0x17000034 RID: 52
	// (get) Token: 0x06000110 RID: 272 RVA: 0x00006418 File Offset: 0x00004618
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000035 RID: 53
	// (get) Token: 0x06000111 RID: 273 RVA: 0x0000641B File Offset: 0x0000461B
	public override int Signature
	{
		get
		{
			return "OneWayMetadata".GetHashCode();
		}
	}

	// Token: 0x17000036 RID: 54
	// (get) Token: 0x06000112 RID: 274 RVA: 0x00006427 File Offset: 0x00004627
	public override int ValueHash
	{
		get
		{
			if (!this.value)
			{
				return -1;
			}
			return 1;
		}
	}

	// Token: 0x06000113 RID: 275 RVA: 0x00006434 File Offset: 0x00004634
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.value);
	}

	// Token: 0x06000114 RID: 276 RVA: 0x00006442 File Offset: 0x00004642
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.value = br.ReadBoolean();
	}

	// Token: 0x06000115 RID: 277 RVA: 0x00006450 File Offset: 0x00004650
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<OneWayMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<OneWayMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x04000091 RID: 145
	public bool value;
}
