﻿using System;
using UnityEngine;

// Token: 0x020000B9 RID: 185
public class FlapAway : MonoBehaviour
{
	// Token: 0x060005BD RID: 1469 RVA: 0x00019888 File Offset: 0x00017A88
	private void OnEnable()
	{
		this.tStart = Time.time;
	}

	// Token: 0x060005BE RID: 1470 RVA: 0x00019898 File Offset: 0x00017A98
	private void Update()
	{
		if (Time.time - this.tStart >= this.delay)
		{
			base.transform.Translate(Vector3.up * this.strength * Time.deltaTime, Space.World);
		}
		this.DestroyAfterTime();
	}

	// Token: 0x060005BF RID: 1471 RVA: 0x000198E8 File Offset: 0x00017AE8
	public void DestroyAfterTime()
	{
		this.t += Time.deltaTime;
		if (this.t >= this.timeUntilDestroy)
		{
			if (this.destroyParent)
			{
				Object.Destroy(base.transform.parent.gameObject);
				return;
			}
			Object.Destroy(base.gameObject);
		}
	}

	// Token: 0x060005C0 RID: 1472 RVA: 0x00019940 File Offset: 0x00017B40
	public void PlayFlapSFX()
	{
		AudioManager.Play("SFX_Angel", AudioManager.MixerTarget.SFX, null, null);
	}

	// Token: 0x04000428 RID: 1064
	public float delay;

	// Token: 0x04000429 RID: 1065
	public float strength = 1f;

	// Token: 0x0400042A RID: 1066
	public float timeUntilDestroy = 3f;

	// Token: 0x0400042B RID: 1067
	private float t;

	// Token: 0x0400042C RID: 1068
	public bool destroyParent;

	// Token: 0x0400042D RID: 1069
	private float tStart;
}
