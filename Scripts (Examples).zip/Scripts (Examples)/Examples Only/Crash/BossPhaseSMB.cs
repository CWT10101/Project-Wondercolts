﻿using System;
using UnityEngine;

// Token: 0x02000006 RID: 6
public class BossPhaseSMB : StateMachineBehaviour
{
	// Token: 0x06000012 RID: 18 RVA: 0x000028B0 File Offset: 0x00000AB0
	public override void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
	{
		if (this.phase == 0)
		{
			Debug.Log("Boss died");
		}
	}

	// Token: 0x06000013 RID: 19 RVA: 0x000028C4 File Offset: 0x00000AC4
	public override void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
	{
		if (animator.GetBool("TakeDamage"))
		{
			int num = animator.GetInteger("HP") - 1;
			animator.SetInteger("HP", num);
			if (num > 0)
			{
				animator.Play("Base Layer.Damaged.State", 0);
			}
			else
			{
				animator.Play("Base Layer.Defeated.State", 0);
			}
			animator.ResetTrigger("TakeDamage");
			animator.GetComponent<Boss>().LoseHP();
		}
	}

	// Token: 0x06000014 RID: 20 RVA: 0x0000292C File Offset: 0x00000B2C
	public override void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
	{
	}

	// Token: 0x04000013 RID: 19
	public byte phase;
}
