﻿using System;
using UnityEngine;

// Token: 0x02000077 RID: 119
public class BounceCrate : BasicCrate, IFallOn, ISpin, ISlide, ITouchBottom
{
	// Token: 0x0600035D RID: 861 RVA: 0x0000ECB3 File Offset: 0x0000CEB3
	protected override void OnEnable()
	{
		base.OnEnable();
		if (this._startBounceCounter != 0)
		{
			this.bounceCounter = this._startBounceCounter;
		}
	}

	// Token: 0x0600035E RID: 862 RVA: 0x0000ECCF File Offset: 0x0000CECF
	private void Awake()
	{
		this._startBounceCounter = this.bounceCounter;
	}

	// Token: 0x0600035F RID: 863 RVA: 0x0000ECDD File Offset: 0x0000CEDD
	public override void Slide(CrashController crash)
	{
		if (!base.IsAbove(crash))
		{
			this.Break();
			return;
		}
		if (base.CheckGap(crash))
		{
			this.FallOn(crash);
		}
	}

	// Token: 0x06000360 RID: 864 RVA: 0x0000ECFF File Offset: 0x0000CEFF
	public override void FallOn(CrashController crash)
	{
		crash.Bounce();
		this.Jerry(true);
	}

	// Token: 0x06000361 RID: 865 RVA: 0x0000ED0F File Offset: 0x0000CF0F
	public override void TouchBottom(CrashController crash)
	{
		if (this.Jerry(false))
		{
			crash.BounceDown();
		}
	}

	// Token: 0x06000362 RID: 866 RVA: 0x0000ED20 File Offset: 0x0000CF20
	public override void ResetEntity()
	{
		this.bounceCounter = this._startBounceCounter;
		base.ResetEntity();
	}

	// Token: 0x06000363 RID: 867 RVA: 0x0000ED34 File Offset: 0x0000CF34
	public bool Jerry(bool isTop)
	{
		BounceCrate.<>c__DisplayClass10_0 CS$<>8__locals1 = new BounceCrate.<>c__DisplayClass10_0();
		CS$<>8__locals1.<>4__this = this;
		CS$<>8__locals1.isTop = isTop;
		this.jerryCounter += 1;
		if (this.jerryCounter == 1)
		{
			this.TryPushToStack();
			base.StartCoroutine(CS$<>8__locals1.<Jerry>g__DoTheJerry|0());
			return true;
		}
		return false;
	}

	// Token: 0x04000232 RID: 562
	public Animator animator;

	// Token: 0x04000233 RID: 563
	public int bounceCounter = 5;

	// Token: 0x04000234 RID: 564
	private int _startBounceCounter;

	// Token: 0x04000235 RID: 565
	private byte jerryCounter;
}
