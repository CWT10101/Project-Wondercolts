﻿using System;
using UnityEngine;

// Token: 0x02000108 RID: 264
public class RollingMonkeyEnemy : BasicEnemy
{
	// Token: 0x06000810 RID: 2064 RVA: 0x0002215D File Offset: 0x0002035D
	protected override void OnEnable()
	{
		base.OnEnable();
		if (this._cachedSpeed == -1f)
		{
			this._cachedSpeed = this.speed;
		}
		this.StartRolling();
	}

	// Token: 0x06000811 RID: 2065 RVA: 0x00022184 File Offset: 0x00020384
	protected override void FixedUpdate()
	{
		Vector2 rhs = this._dir.XZ();
		base.FixedUpdate();
		if (this._dir.XZ() != rhs)
		{
			this._cachedDir = this._dir;
			this.StopRolling();
		}
	}

	// Token: 0x06000812 RID: 2066 RVA: 0x000221C8 File Offset: 0x000203C8
	private void StartRolling()
	{
		this.speed = this._cachedSpeed;
		this.animator.SetBool("IsRolling", true);
	}

	// Token: 0x06000813 RID: 2067 RVA: 0x000221E7 File Offset: 0x000203E7
	private void StopRolling()
	{
		this.speed = 0f;
		this.animator.SetBool("IsRolling", false);
		this.doRotation = false;
	}

	// Token: 0x06000814 RID: 2068 RVA: 0x0002220C File Offset: 0x0002040C
	public void SignalRollFinished()
	{
		this.doRotation = true;
		this._dir = Vector3.back;
	}

	// Token: 0x06000815 RID: 2069 RVA: 0x00022220 File Offset: 0x00020420
	public void SignalChestbeatFinished()
	{
		this._dir = this._cachedDir;
		this._cachedDir = Vector3.zero;
		this.StartRolling();
	}

	// Token: 0x040005E4 RID: 1508
	private float _cachedSpeed = -1f;

	// Token: 0x040005E5 RID: 1509
	private Vector3 _cachedDir = Vector3.zero;
}
