﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020000A2 RID: 162
public class DynamicConfirmScreen : MonoBehaviour
{
	// Token: 0x060004E8 RID: 1256 RVA: 0x00015A38 File Offset: 0x00013C38
	public void DisplayMessage(string header, string body, bool showCancelButton = false, Action confirmAction = null, Action cancelAction = null)
	{
		UIScreen.Focus(this.screen);
		this.headerText.text = header;
		this.bodyText.text = body;
		this.cancelButton.gameObject.SetActive(showCancelButton);
		this.onConfirm = confirmAction;
		this.onCancel = cancelAction;
	}

	// Token: 0x060004E9 RID: 1257 RVA: 0x00015A8C File Offset: 0x00013C8C
	public void PressConfirmButton()
	{
		UIScreen.activeScreen.BackOrClose();
		Action action = this.onConfirm;
		if (action != null)
		{
			action();
		}
		this.onConfirm = (this.onCancel = null);
	}

	// Token: 0x060004EA RID: 1258 RVA: 0x00015AC4 File Offset: 0x00013CC4
	public void PressCancelButton()
	{
		UIScreen.activeScreen.BackOrClose();
		Action action = this.onCancel;
		if (action != null)
		{
			action();
		}
		this.onConfirm = (this.onCancel = null);
	}

	// Token: 0x04000364 RID: 868
	public UIScreen screen;

	// Token: 0x04000365 RID: 869
	public TMP_Text headerText;

	// Token: 0x04000366 RID: 870
	public TMP_Text bodyText;

	// Token: 0x04000367 RID: 871
	public Button confirmButton;

	// Token: 0x04000368 RID: 872
	public Button cancelButton;

	// Token: 0x04000369 RID: 873
	private Action onConfirm;

	// Token: 0x0400036A RID: 874
	private Action onCancel;
}
