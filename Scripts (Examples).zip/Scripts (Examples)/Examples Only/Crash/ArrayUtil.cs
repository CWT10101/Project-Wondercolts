﻿using System;
using System.Collections.Generic;

// Token: 0x02000147 RID: 327
public static class ArrayUtil
{
	// Token: 0x060009B0 RID: 2480 RVA: 0x00027300 File Offset: 0x00025500
	public static void Default<T>(this T[] array)
	{
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = default(T);
		}
	}

	// Token: 0x060009B1 RID: 2481 RVA: 0x0002732C File Offset: 0x0002552C
	public static int CountNotDefault<T>(this T[] array)
	{
		int num = 0;
		for (int i = 0; i < array.Length; i++)
		{
			if (!array[i].Equals(default(T)))
			{
				num++;
			}
		}
		return num;
	}

	// Token: 0x060009B2 RID: 2482 RVA: 0x00027374 File Offset: 0x00025574
	public static int CountNotDefault<T>(this IReadOnlyList<T> array)
	{
		int num = 0;
		for (int i = 0; i < array.Count; i++)
		{
			T t = array[i];
			if (!t.Equals(default(T)))
			{
				num++;
			}
		}
		return num;
	}

	// Token: 0x060009B3 RID: 2483 RVA: 0x000273C0 File Offset: 0x000255C0
	public static void ForEach<T>(this IEnumerable<T> collection, Action<T> action)
	{
		foreach (T obj in collection)
		{
			action(obj);
		}
	}
}
