﻿using System;
using UnityEngine;

// Token: 0x020000BE RID: 190
public class GameOverScreen : MonoBehaviour
{
	// Token: 0x060005CD RID: 1485 RVA: 0x00019B6C File Offset: 0x00017D6C
	public void PlaySound()
	{
		AudioManager.Play("SFX_GameOver", AudioManager.Instance.musicMixer, null, null);
	}

	// Token: 0x060005CE RID: 1486 RVA: 0x00019BA0 File Offset: 0x00017DA0
	public void LoadWarpRoom()
	{
		InterfaceManager.instance.LoadWarpRoom();
	}

	// Token: 0x060005CF RID: 1487 RVA: 0x00019BAC File Offset: 0x00017DAC
	public void DisableObject()
	{
		base.gameObject.SetActive(false);
	}

	// Token: 0x060005D0 RID: 1488 RVA: 0x00019BBA File Offset: 0x00017DBA
	public void DisableMusic()
	{
		AudioManager.StopMusic();
	}
}
