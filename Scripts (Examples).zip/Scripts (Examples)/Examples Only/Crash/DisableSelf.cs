﻿using System;
using UnityEngine;

// Token: 0x0200009F RID: 159
public class DisableSelf : MonoBehaviour
{
	// Token: 0x060004DF RID: 1247 RVA: 0x00015956 File Offset: 0x00013B56
	public void DisableObject()
	{
		base.gameObject.SetActive(false);
	}
}
