﻿using System;
using UnityEngine;

// Token: 0x0200012C RID: 300
public class SpitterSeedProjectile : Projectile
{
	// Token: 0x060008F4 RID: 2292 RVA: 0x00025124 File Offset: 0x00023324
	protected override void FixedUpdate()
	{
		if (!this.inFlight)
		{
			this.fuse -= Time.fixedDeltaTime;
			if (this.fuse <= 0f)
			{
				this.Break();
			}
			return;
		}
		this._t += Time.deltaTime;
		if (this._t >= this.maxFlightDuration)
		{
			Object.Destroy(base.gameObject);
			return;
		}
		base.transform.Translate(Time.fixedDeltaTime * (this.flightSpeed * base.transform.forward + this.gravity * this._t * Vector3.down), Space.World);
	}

	// Token: 0x060008F5 RID: 2293 RVA: 0x000251D4 File Offset: 0x000233D4
	protected override void OnTriggerEnter(Collider other)
	{
		if (other.isTrigger)
		{
			return;
		}
		if (this.inFlight)
		{
			DeathTrigger deathTrigger;
			if (other.TryGetComponent<DeathTrigger>(out deathTrigger))
			{
				Object.Destroy(base.gameObject);
				return;
			}
			Projectile projectile;
			if (!other.TryGetComponent<Projectile>(out projectile))
			{
				Entity entity;
				if (other.GetComponentInParent<CrashController>() != null || other.TryGetComponent<Entity>(out entity))
				{
					this.Break();
					SwitchCrate component = other.GetComponent<SwitchCrate>();
					if (component != null)
					{
						component.ToggleSwitchState();
						return;
					}
				}
				else
				{
					this.inFlight = false;
					this.flightVisual.SetActive(false);
					this.landedVisual.SetActive(true);
				}
			}
		}
	}

	// Token: 0x0400068F RID: 1679
	public GameObject flightVisual;

	// Token: 0x04000690 RID: 1680
	public GameObject landedVisual;

	// Token: 0x04000691 RID: 1681
	public float gravity = 2f;

	// Token: 0x04000692 RID: 1682
	public float fuse = 3f;

	// Token: 0x04000693 RID: 1683
	public float maxFlightDuration = 5f;

	// Token: 0x04000694 RID: 1684
	private bool inFlight = true;

	// Token: 0x04000695 RID: 1685
	private float _t;
}
