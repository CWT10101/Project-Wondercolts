﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using LevelEditor;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020000BA RID: 186
public class FlashbackResultsScreen : MonoBehaviour
{
	// Token: 0x060005C2 RID: 1474 RVA: 0x0001998C File Offset: 0x00017B8C
	private void OnEnable()
	{
		this.interactionGroup.interactable = false;
		this.bronze.SetActive(false);
		this.silver.SetActive(false);
		this.gold.SetActive(false);
		this.barFill.fillAmount = 0f;
		this.boxesText.text = string.Format("0/{0}", LevelInterfaceManager.instance.maxBoxCount);
		base.StartCoroutine(this.<OnEnable>g__Routine|7_0());
	}

	// Token: 0x060005C3 RID: 1475 RVA: 0x00019A0A File Offset: 0x00017C0A
	public void RetryLevel()
	{
		UIScreen.Focus(InterfaceManager.instance.HUD);
		CrashController.instance.enabled = true;
		LevelManager.instance.LoadToPlay(LevelSerializer.activeFolder, LevelSerializer.instance.loadOnPlayString);
	}

	// Token: 0x060005C4 RID: 1476 RVA: 0x00019A3F File Offset: 0x00017C3F
	public void Continue()
	{
		LevelManager.instance.LoadWarpRoom();
	}

	// Token: 0x060005C6 RID: 1478 RVA: 0x00019A5E File Offset: 0x00017C5E
	[CompilerGenerated]
	private IEnumerator <OnEnable>g__Routine|7_0()
	{
		yield return new WaitForSeconds(0.5f);
		float completion = (float)LevelInterfaceManager.instance.boxesCollected / (float)LevelInterfaceManager.instance.maxBoxCount;
		byte b = (completion == 1f) ? 3 : ((completion >= 0.9f) ? 2 : ((completion >= 0.75f) ? 1 : 0));
		Debug.Log(string.Format("Completion: {0:N}% | Medal {1}", completion * 100f, b));
		if (LevelSerializer.instance.tapeIndex != -1 && SaveData.Info.tapeMedals[LevelSerializer.instance.tapeIndex] < b)
		{
			SaveData.Info.tapeMedals[LevelSerializer.instance.tapeIndex] = b;
			SaveData.Autosave();
			Debug.Log("Got a new medal!");
		}
		this.interactionGroup.interactable = true;
		float d = completion * this.maxAnimationTime;
		float t = 0f;
		while (t < completion)
		{
			float num = Time.deltaTime / d;
			this.barFill.fillAmount = t;
			this.boxesText.text = string.Format("{0}/{1}", (int)(t * (float)LevelInterfaceManager.instance.maxBoxCount), LevelInterfaceManager.instance.maxBoxCount);
			if (t < 0.75f)
			{
				if (t + num >= 0.75f && completion >= 0.75f)
				{
					this.bronze.SetActive(true);
				}
			}
			else if (t < 0.9f)
			{
				if (t + num >= 0.9f && completion >= 0.9f)
				{
					this.silver.SetActive(true);
				}
			}
			else if (t + num >= 1f && completion >= 1f)
			{
				this.gold.SetActive(true);
			}
			t += num;
			yield return new WaitForEndOfFrame();
		}
		this.barFill.fillAmount = completion;
		this.boxesText.text = string.Format("{0}/{1}", LevelInterfaceManager.instance.boxesCollected, LevelInterfaceManager.instance.maxBoxCount);
		yield break;
	}

	// Token: 0x0400042E RID: 1070
	public CanvasGroup interactionGroup;

	// Token: 0x0400042F RID: 1071
	public TMP_Text boxesText;

	// Token: 0x04000430 RID: 1072
	public GameObject bronze;

	// Token: 0x04000431 RID: 1073
	public GameObject silver;

	// Token: 0x04000432 RID: 1074
	public GameObject gold;

	// Token: 0x04000433 RID: 1075
	public Image barFill;

	// Token: 0x04000434 RID: 1076
	public float maxAnimationTime = 3f;
}
