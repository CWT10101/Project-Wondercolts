﻿using System;
using UnityEngine;

// Token: 0x02000133 RID: 307
public class SwordGuy : BasicEnemy
{
	// Token: 0x06000926 RID: 2342 RVA: 0x000258AC File Offset: 0x00023AAC
	protected override void FixedUpdate()
	{
		base.FixedUpdate();
		if (!this.isDead)
		{
			if (this.timer < this.stateLength)
			{
				this.timer += Time.deltaTime;
				return;
			}
			this.SwitchState();
			this.timer = 0f;
		}
	}

	// Token: 0x06000927 RID: 2343 RVA: 0x000258F9 File Offset: 0x00023AF9
	public override void Slam(CrashController crash)
	{
		if (this.animator.GetBool("isAttacking"))
		{
			this.HurtCrash(crash);
			return;
		}
		this.Die(true);
	}

	// Token: 0x06000928 RID: 2344 RVA: 0x0002591C File Offset: 0x00023B1C
	public void PlaySwordSFX()
	{
		AudioManager.Play(this.swordSwingSFX, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
	}

	// Token: 0x06000929 RID: 2345 RVA: 0x0002594F File Offset: 0x00023B4F
	public void SwitchState()
	{
		this.animator.SetBool("isAttacking", !this.animator.GetBool("isAttacking"));
	}

	// Token: 0x0600092A RID: 2346 RVA: 0x00025974 File Offset: 0x00023B74
	public override void ResetEntity()
	{
		this.timer = 0f;
		this.animator.SetBool("isAttacking", false);
		base.ResetEntity();
	}

	// Token: 0x0600092B RID: 2347 RVA: 0x00025998 File Offset: 0x00023B98
	public override void Die(bool playSFX = true)
	{
		this.timer = 0f;
		this.animator.SetBool("isAttacking", false);
		base.Die(playSFX);
	}

	// Token: 0x040006B2 RID: 1714
	public string swordSwingSFX = "SFX_SwordSwing";

	// Token: 0x040006B3 RID: 1715
	private float timer;

	// Token: 0x040006B4 RID: 1716
	public float stateLength = 3f;
}
