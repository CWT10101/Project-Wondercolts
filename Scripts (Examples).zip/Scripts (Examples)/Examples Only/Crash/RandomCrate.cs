﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x02000104 RID: 260
public class RandomCrate : Crate, ISpin, ITouchTop, ITouchBottom, ISlam, ISlide
{
	// Token: 0x17000100 RID: 256
	// (get) Token: 0x060007F0 RID: 2032 RVA: 0x00021BA1 File Offset: 0x0001FDA1
	public override bool AddsToBoxCount
	{
		get
		{
			return false;
		}
	}

	// Token: 0x060007F1 RID: 2033 RVA: 0x00021BA4 File Offset: 0x0001FDA4
	public void Change()
	{
		if (!this.changed)
		{
			base.StartCoroutine(this.<Change>g__WaitAndBreak|6_0());
			this.changed = true;
		}
	}

	// Token: 0x060007F2 RID: 2034 RVA: 0x00021BC4 File Offset: 0x0001FDC4
	public override void Break()
	{
		this.TryPushToStack();
		this.coll.enabled = false;
		BrokenCrate brokenCrate = Object.Instantiate<BrokenCrate>(ResourceManager.instance.brokenCrate, base.transform.position, base.transform.rotation);
		brokenCrate.crateCol = this.brokenBoxCol;
		brokenCrate.SetColour(this.brokenBoxCol);
		this.visual.SetActive(false);
		this.spawnedCrate = Object.Instantiate<Crate>(this.outcomeCrates[Random.Range(0, this.outcomeCrates.Length - 1)], base.transform.position, base.transform.rotation);
		this.spawnedCrate.canPushToStack = false;
		base.Break();
	}

	// Token: 0x060007F3 RID: 2035 RVA: 0x00021C75 File Offset: 0x0001FE75
	public override void ResetEntity()
	{
		this.changed = false;
		if (this.spawnedCrate)
		{
			Object.Destroy(this.spawnedCrate.gameObject);
		}
		base.ResetEntity();
	}

	// Token: 0x060007F4 RID: 2036 RVA: 0x00021CA1 File Offset: 0x0001FEA1
	public void TouchTop(CrashController crash)
	{
		CrashController.instance.Bounce();
		this.Change();
	}

	// Token: 0x060007F5 RID: 2037 RVA: 0x00021CB3 File Offset: 0x0001FEB3
	public void TouchBottom(CrashController crash)
	{
		this.Change();
	}

	// Token: 0x060007F6 RID: 2038 RVA: 0x00021CBB File Offset: 0x0001FEBB
	public void Spin(CrashController crash)
	{
		this.Change();
	}

	// Token: 0x060007F7 RID: 2039 RVA: 0x00021CC3 File Offset: 0x0001FEC3
	public void Slam(CrashController crash)
	{
		this.Change();
	}

	// Token: 0x060007F8 RID: 2040 RVA: 0x00021CCB File Offset: 0x0001FECB
	public void Slide(CrashController crash)
	{
		this.Change();
	}

	// Token: 0x060007FA RID: 2042 RVA: 0x00021CDB File Offset: 0x0001FEDB
	[CompilerGenerated]
	private IEnumerator <Change>g__WaitAndBreak|6_0()
	{
		AudioManager.Play("SFX_ActivatorCrate", new Vector3?(base.transform.position), null);
		this.animator.SetTrigger("Activate");
		yield return new WaitForSeconds(0.35f);
		this.Break();
		yield break;
	}

	// Token: 0x040005D6 RID: 1494
	public Animator animator;

	// Token: 0x040005D7 RID: 1495
	public Crate[] outcomeCrates;

	// Token: 0x040005D8 RID: 1496
	public Crate spawnedCrate;

	// Token: 0x040005D9 RID: 1497
	private bool changed;
}
