﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200009A RID: 154
public class DeathRoutePlatform : EditorBonusPlatform
{
	// Token: 0x170000C6 RID: 198
	// (get) Token: 0x0600049A RID: 1178 RVA: 0x00014CC0 File Offset: 0x00012EC0
	public static HashSet<DeathRoutePlatform> Platforms { get; } = new HashSet<DeathRoutePlatform>();

	// Token: 0x170000C7 RID: 199
	// (get) Token: 0x0600049B RID: 1179 RVA: 0x00014CC7 File Offset: 0x00012EC7
	// (set) Token: 0x0600049C RID: 1180 RVA: 0x00014CCE File Offset: 0x00012ECE
	public static bool IsTouched { get; private set; }

	// Token: 0x0600049D RID: 1181 RVA: 0x00014CD8 File Offset: 0x00012ED8
	public static void CrashDied()
	{
		if (!DeathRoutePlatform.IsTouched && DeathRoutePlatform.Platforms.Count > 0)
		{
			foreach (DeathRoutePlatform deathRoutePlatform in DeathRoutePlatform.Platforms)
			{
				deathRoutePlatform.SetTangible(false);
			}
		}
	}

	// Token: 0x0600049E RID: 1182 RVA: 0x00014D3C File Offset: 0x00012F3C
	public static void RestoreDefault()
	{
		DeathRoutePlatform.IsTouched = false;
		foreach (DeathRoutePlatform deathRoutePlatform in DeathRoutePlatform.Platforms)
		{
			deathRoutePlatform.SetTangible(true);
		}
	}

	// Token: 0x0600049F RID: 1183 RVA: 0x00014D94 File Offset: 0x00012F94
	protected override void OnEnable()
	{
		base.OnEnable();
		DeathRoutePlatform.Platforms.Add(this);
	}

	// Token: 0x060004A0 RID: 1184 RVA: 0x00014DA8 File Offset: 0x00012FA8
	private void OnDestroy()
	{
		DeathRoutePlatform.Platforms.Remove(this);
	}

	// Token: 0x060004A1 RID: 1185 RVA: 0x00014DB6 File Offset: 0x00012FB6
	public override void OnEnter(Transform tf)
	{
		base.OnEnter(tf);
		DeathRoutePlatform.IsTouched = true;
	}

	// Token: 0x060004A2 RID: 1186 RVA: 0x00014DC5 File Offset: 0x00012FC5
	private void SetTangible(bool tangible)
	{
		if (tangible)
		{
			this.rend.sharedMaterial = this.defaultMat;
		}
		else
		{
			this.rend.sharedMaterial = this.intangibleMat;
		}
		this.collider.enabled = tangible;
	}

	// Token: 0x0400033C RID: 828
	public MeshRenderer rend;

	// Token: 0x0400033D RID: 829
	public Material defaultMat;

	// Token: 0x0400033E RID: 830
	public Material intangibleMat;
}
