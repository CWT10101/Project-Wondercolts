﻿using System;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000061 RID: 97
public abstract class BlockTrigger : MonoBehaviour
{
	// Token: 0x06000262 RID: 610 RVA: 0x0000AC14 File Offset: 0x00008E14
	public virtual void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			this.Triggered();
			this.onTriggered.Invoke();
		}
	}

	// Token: 0x06000263 RID: 611 RVA: 0x0000AC3C File Offset: 0x00008E3C
	public virtual void OnTriggerExit(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			this.onTriggerExited.Invoke();
		}
	}

	// Token: 0x06000264 RID: 612 RVA: 0x0000AC5E File Offset: 0x00008E5E
	public virtual void Triggered()
	{
	}

	// Token: 0x0400015D RID: 349
	public UnityEvent onTriggered;

	// Token: 0x0400015E RID: 350
	public UnityEvent onTriggerExited;
}
