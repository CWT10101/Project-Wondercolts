﻿using System;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x020000AF RID: 175
public class EventOnCycle : MonoBehaviour
{
	// Token: 0x0600057C RID: 1404 RVA: 0x000185D8 File Offset: 0x000167D8
	private void FixedUpdate()
	{
		float num = Clock.SynchronizedTime + this.offset;
		float num2 = num % this.period;
		float num3 = (num + Time.fixedUnscaledDeltaTime) % this.period;
		if (num2 < num3)
		{
			if (num2 <= this.phase && num3 > this.phase)
			{
				UnityEvent unityEvent = this.evt;
				if (unityEvent == null)
				{
					return;
				}
				unityEvent.Invoke();
				return;
			}
		}
		else if (num2 <= this.phase)
		{
			UnityEvent unityEvent2 = this.evt;
			if (unityEvent2 == null)
			{
				return;
			}
			unityEvent2.Invoke();
		}
	}

	// Token: 0x040003D4 RID: 980
	public UnityEvent evt;

	// Token: 0x040003D5 RID: 981
	public float period = 1f;

	// Token: 0x040003D6 RID: 982
	public float phase;

	// Token: 0x040003D7 RID: 983
	public float offset;
}
