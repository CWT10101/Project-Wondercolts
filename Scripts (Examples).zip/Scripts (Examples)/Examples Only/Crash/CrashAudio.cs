﻿using System;
using UnityEngine;

// Token: 0x0200008B RID: 139
public class CrashAudio : MonoBehaviour
{
	// Token: 0x170000A1 RID: 161
	// (get) Token: 0x060003DD RID: 989 RVA: 0x00010018 File Offset: 0x0000E218
	// (set) Token: 0x060003DE RID: 990 RVA: 0x0001001F File Offset: 0x0000E21F
	public static string Spin { get; private set; } = "UNSET";

	// Token: 0x170000A2 RID: 162
	// (get) Token: 0x060003DF RID: 991 RVA: 0x00010027 File Offset: 0x0000E227
	// (set) Token: 0x060003E0 RID: 992 RVA: 0x0001002E File Offset: 0x0000E22E
	public static string Hurt { get; private set; } = "UNSET";

	// Token: 0x170000A3 RID: 163
	// (get) Token: 0x060003E1 RID: 993 RVA: 0x00010036 File Offset: 0x0000E236
	// (set) Token: 0x060003E2 RID: 994 RVA: 0x0001003D File Offset: 0x0000E23D
	public static string Death { get; private set; } = "UNSET";

	// Token: 0x060003E3 RID: 995 RVA: 0x00010045 File Offset: 0x0000E245
	private void Awake()
	{
		this.SetSkin(CrashAnimator.Skin);
	}

	// Token: 0x060003E4 RID: 996 RVA: 0x00010052 File Offset: 0x0000E252
	public void SetSkin(int index)
	{
		CrashAudio.Spin = this.spinSounds[index];
		CrashAudio.Hurt = this.hurtSounds[index];
		CrashAudio.Death = this.deathSounds[index];
	}

	// Token: 0x040002A3 RID: 675
	[SerializeField]
	private string[] spinSounds;

	// Token: 0x040002A4 RID: 676
	[SerializeField]
	private string[] hurtSounds;

	// Token: 0x040002A5 RID: 677
	[SerializeField]
	private string[] deathSounds;
}
