﻿using System;
using UnityEngine;

// Token: 0x020000BC RID: 188
public class FlipMetadataReceiver : MonoBehaviour, IMetadataReceiver<FlipMetadata>
{
	// Token: 0x060005CA RID: 1482 RVA: 0x00019AF4 File Offset: 0x00017CF4
	public void ProcessMetadata(FlipMetadata meta)
	{
		((this.objectToFlip == null) ? base.gameObject : this.objectToFlip).transform.localEulerAngles = (meta.isFlipped ? new Vector3(0f, 90f, 0f) : new Vector3(0f, -90f, 0f));
	}

	// Token: 0x0400043A RID: 1082
	public GameObject objectToFlip;
}
