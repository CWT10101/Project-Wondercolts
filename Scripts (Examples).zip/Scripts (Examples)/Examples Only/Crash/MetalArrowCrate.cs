﻿using System;

// Token: 0x020000E3 RID: 227
public class MetalArrowCrate : ArrowCrate
{
	// Token: 0x060006F3 RID: 1779 RVA: 0x0001DD77 File Offset: 0x0001BF77
	public override void Slam(CrashController crash)
	{
		if (base.IsBelow(crash))
		{
			return;
		}
		this.animator.SetTrigger("Bounce");
		crash.ArrowBounce(true);
	}

	// Token: 0x060006F4 RID: 1780 RVA: 0x0001DD9A File Offset: 0x0001BF9A
	public override void Slide(CrashController crash)
	{
		if (base.IsAbove(crash) && base.CheckGap(crash))
		{
			this.FallOn(crash);
		}
	}

	// Token: 0x060006F5 RID: 1781 RVA: 0x0001DDB5 File Offset: 0x0001BFB5
	public override void TouchBottom(CrashController crash)
	{
	}

	// Token: 0x060006F6 RID: 1782 RVA: 0x0001DDB7 File Offset: 0x0001BFB7
	public override void Spin(CrashController crash)
	{
		if (base.IsAbove(crash) && !crash.WasGrounded)
		{
			this.animator.SetTrigger("Bounce");
		}
	}

	// Token: 0x060006F7 RID: 1783 RVA: 0x0001DDDA File Offset: 0x0001BFDA
	public override void Fall(float withVelocity = 0f)
	{
	}

	// Token: 0x060006F8 RID: 1784 RVA: 0x0001DDDC File Offset: 0x0001BFDC
	public override void Break()
	{
	}

	// Token: 0x060006F9 RID: 1785 RVA: 0x0001DDDE File Offset: 0x0001BFDE
	public override void ForceBreak()
	{
	}
}
