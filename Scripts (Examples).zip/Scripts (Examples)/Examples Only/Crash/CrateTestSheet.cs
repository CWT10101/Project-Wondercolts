﻿using System;
using UnityEngine;

// Token: 0x02000167 RID: 359
public class CrateTestSheet : MonoBehaviour
{
	// Token: 0x06000A43 RID: 2627 RVA: 0x00028F5C File Offset: 0x0002715C
	private void Start()
	{
		float num = (float)this.gridSize.x * this.spacing;
		this.cam.orthographicSize = num / 2f;
		base.transform.position = new Vector3((float)(-(float)(this.gridSize.x - 1)) * this.spacing / 2f, (float)(this.gridSize.y - 1) * this.spacing / 2f, 0f);
		for (int i = 0; i < this.gridSize.y; i++)
		{
			for (int j = 0; j < this.gridSize.x; j++)
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this.target, base.transform);
				gameObject.SetActive(true);
				gameObject.transform.localPosition = new Vector3((float)j * this.spacing, (float)(-(float)i) * this.spacing, 0f);
				gameObject.transform.rotation = Quaternion.AngleAxis(this.tiltAngle, Vector3.left) * Quaternion.AngleAxis((float)(j + i * this.gridSize.y) / (float)(this.gridSize.x * this.gridSize.y) * this.turnaroundDegrees, Vector3.up);
			}
		}
	}

	// Token: 0x04000761 RID: 1889
	public Camera cam;

	// Token: 0x04000762 RID: 1890
	public GameObject target;

	// Token: 0x04000763 RID: 1891
	public Vector2Int gridSize;

	// Token: 0x04000764 RID: 1892
	public float spacing = 1f;

	// Token: 0x04000765 RID: 1893
	public float turnaroundDegrees = 360f;

	// Token: 0x04000766 RID: 1894
	public float tiltAngle = 30f;
}
