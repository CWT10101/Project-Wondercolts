﻿using System;
using System.IO;
using LevelEditor;
using LevelEditor3D;
using UnityEngine;

// Token: 0x02000031 RID: 49
public class RotationMetadata : ObjectMetadata
{
	// Token: 0x17000045 RID: 69
	// (get) Token: 0x06000138 RID: 312 RVA: 0x0000672C File Offset: 0x0000492C
	// (set) Token: 0x06000139 RID: 313 RVA: 0x00006734 File Offset: 0x00004934
	public bool HasData { get; private set; }

	// Token: 0x17000046 RID: 70
	// (get) Token: 0x0600013A RID: 314 RVA: 0x0000673D File Offset: 0x0000493D
	public override bool SupportsMultiEditing
	{
		get
		{
			return false;
		}
	}

	// Token: 0x17000047 RID: 71
	// (get) Token: 0x0600013B RID: 315 RVA: 0x00006740 File Offset: 0x00004940
	public override int Signature
	{
		get
		{
			return "RotationMetadata".GetHashCode();
		}
	}

	// Token: 0x17000048 RID: 72
	// (get) Token: 0x0600013C RID: 316 RVA: 0x0000674C File Offset: 0x0000494C
	public override int ValueHash
	{
		get
		{
			return this.valueHash;
		}
	}

	// Token: 0x0600013D RID: 317 RVA: 0x00006754 File Offset: 0x00004954
	public void Start()
	{
		if (LevelInterfaceManager3D.Instance)
		{
			IMetadataReceiver<RotationMetadata>[] componentsInChildren = base.GetComponentsInChildren<IMetadataReceiver<RotationMetadata>>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].ProcessMetadata(this);
			}
		}
	}

	// Token: 0x0600013E RID: 318 RVA: 0x0000678C File Offset: 0x0000498C
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.HasData);
		if (this.HasData)
		{
			bw.Write((short)this.Rotation.x);
			bw.Write((short)this.Rotation.y);
			bw.Write((short)this.Rotation.z);
		}
	}

	// Token: 0x0600013F RID: 319 RVA: 0x000067E3 File Offset: 0x000049E3
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.HasData = br.ReadBoolean();
		if (this.HasData)
		{
			this.Rotation = new Vector3Int((int)br.ReadInt16(), (int)br.ReadInt16(), (int)br.ReadInt16());
			return;
		}
		this.Rotation = default(Vector3Int);
	}

	// Token: 0x06000140 RID: 320 RVA: 0x00006824 File Offset: 0x00004A24
	public override void Apply(LevelObj obj)
	{
		if (LevelInterfaceManager3D.Instance)
		{
			IMetadataReceiver<RotationMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<RotationMetadata>>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].ProcessMetadata(this);
			}
		}
	}

	// Token: 0x0400009B RID: 155
	public Vector3Int Rotation;

	// Token: 0x0400009C RID: 156
	private int valueHash;
}
