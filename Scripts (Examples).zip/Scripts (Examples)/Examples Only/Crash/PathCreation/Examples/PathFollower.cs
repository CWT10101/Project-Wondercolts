﻿using System;
using UnityEngine;

namespace PathCreation.Examples
{
	// Token: 0x020001A3 RID: 419
	public class PathFollower : MonoBehaviour
	{
		// Token: 0x06001063 RID: 4195 RVA: 0x000394C4 File Offset: 0x000376C4
		private void Start()
		{
			this.startPosition = base.transform.position;
			if (this.pathCreator != null)
			{
				this.pathCreator.pathUpdated += this.OnPathChanged;
			}
		}

		// Token: 0x06001064 RID: 4196 RVA: 0x000394FC File Offset: 0x000376FC
		private void FixedUpdate()
		{
			if (this.pathCreator != null && this.isMoving)
			{
				this.distanceTravelled += this.speed * Time.deltaTime;
				base.transform.position = this.pathCreator.path.GetPointAtDistance(this.distanceTravelled, this.endOfPathInstruction);
			}
		}

		// Token: 0x06001065 RID: 4197 RVA: 0x0003955F File Offset: 0x0003775F
		private void OnPathChanged()
		{
			this.distanceTravelled = this.pathCreator.path.GetClosestDistanceAlongPath(base.transform.position);
		}

		// Token: 0x06001066 RID: 4198 RVA: 0x00039582 File Offset: 0x00037782
		public void ResetPath()
		{
			this.isMoving = false;
			this.distanceTravelled = 0f;
			base.transform.position = this.startPosition;
		}

		// Token: 0x04000A9A RID: 2714
		public PathCreator pathCreator;

		// Token: 0x04000A9B RID: 2715
		public EndOfPathInstruction endOfPathInstruction;

		// Token: 0x04000A9C RID: 2716
		public float speed = 5f;

		// Token: 0x04000A9D RID: 2717
		public float distanceTravelled;

		// Token: 0x04000A9E RID: 2718
		public bool isMoving;

		// Token: 0x04000A9F RID: 2719
		private Vector3 startPosition;
	}
}
