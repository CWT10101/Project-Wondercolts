﻿using System;
using UnityEngine;

namespace PathCreation.Examples
{
	// Token: 0x020001A5 RID: 421
	[ExecuteInEditMode]
	public abstract class PathSceneTool : MonoBehaviour
	{
		// Token: 0x1400001B RID: 27
		// (add) Token: 0x0600106C RID: 4204 RVA: 0x000396D4 File Offset: 0x000378D4
		// (remove) Token: 0x0600106D RID: 4205 RVA: 0x0003970C File Offset: 0x0003790C
		public event Action onDestroyed;

		// Token: 0x17000426 RID: 1062
		// (get) Token: 0x0600106E RID: 4206 RVA: 0x00039741 File Offset: 0x00037941
		protected VertexPath path
		{
			get
			{
				return this.pathCreator.path;
			}
		}

		// Token: 0x0600106F RID: 4207 RVA: 0x0003974E File Offset: 0x0003794E
		public void TriggerUpdate()
		{
			this.PathUpdated();
		}

		// Token: 0x06001070 RID: 4208 RVA: 0x00039756 File Offset: 0x00037956
		protected virtual void OnDestroy()
		{
			if (this.onDestroyed != null)
			{
				this.onDestroyed();
			}
		}

		// Token: 0x06001071 RID: 4209
		protected abstract void PathUpdated();

		// Token: 0x04000AA5 RID: 2725
		public PathCreator pathCreator;

		// Token: 0x04000AA6 RID: 2726
		public bool autoUpdate = true;
	}
}
