﻿using System;
using UnityEngine;

namespace PathCreation.Examples
{
	// Token: 0x020001A6 RID: 422
	public class PathSpawner : MonoBehaviour
	{
		// Token: 0x06001073 RID: 4211 RVA: 0x0003977C File Offset: 0x0003797C
		private void Start()
		{
			foreach (Transform transform in this.spawnPoints)
			{
				PathCreator pathCreator = Object.Instantiate<PathCreator>(this.pathPrefab, transform.position, transform.rotation);
				Object.Instantiate<PathFollower>(this.followerPrefab).pathCreator = pathCreator;
				pathCreator.transform.parent = transform;
			}
		}

		// Token: 0x04000AA7 RID: 2727
		public PathCreator pathPrefab;

		// Token: 0x04000AA8 RID: 2728
		public PathFollower followerPrefab;

		// Token: 0x04000AA9 RID: 2729
		public Transform[] spawnPoints;
	}
}
