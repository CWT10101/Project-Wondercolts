﻿using System;
using UnityEngine;

namespace PathCreation.Examples
{
	// Token: 0x020001A4 RID: 420
	[ExecuteInEditMode]
	public class PathPlacer : PathSceneTool
	{
		// Token: 0x06001068 RID: 4200 RVA: 0x000395BC File Offset: 0x000377BC
		private void Generate()
		{
			if (this.pathCreator != null && this.prefab != null && this.holder != null)
			{
				this.DestroyObjects();
				VertexPath path = this.pathCreator.path;
				this.spacing = Mathf.Max(0.1f, this.spacing);
				for (float num = 0f; num < path.length; num += this.spacing)
				{
					Vector3 pointAtDistance = path.GetPointAtDistance(num, EndOfPathInstruction.Loop);
					Quaternion rotationAtDistance = path.GetRotationAtDistance(num, EndOfPathInstruction.Loop);
					Object.Instantiate<GameObject>(this.prefab, pointAtDistance, rotationAtDistance, this.holder.transform);
				}
			}
		}

		// Token: 0x06001069 RID: 4201 RVA: 0x00039664 File Offset: 0x00037864
		private void DestroyObjects()
		{
			for (int i = this.holder.transform.childCount - 1; i >= 0; i--)
			{
				Object.DestroyImmediate(this.holder.transform.GetChild(i).gameObject, false);
			}
		}

		// Token: 0x0600106A RID: 4202 RVA: 0x000396AA File Offset: 0x000378AA
		protected override void PathUpdated()
		{
			if (this.pathCreator != null)
			{
				this.Generate();
			}
		}

		// Token: 0x04000AA0 RID: 2720
		public GameObject prefab;

		// Token: 0x04000AA1 RID: 2721
		public GameObject holder;

		// Token: 0x04000AA2 RID: 2722
		public float spacing = 3f;

		// Token: 0x04000AA3 RID: 2723
		private const float minSpacing = 0.1f;
	}
}
