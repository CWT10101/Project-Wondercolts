﻿using System;
using UnityEngine;

namespace PathCreation.Examples
{
	// Token: 0x020001A2 RID: 418
	[RequireComponent(typeof(PathCreator))]
	public class GeneratePathExample : MonoBehaviour
	{
		// Token: 0x06001061 RID: 4193 RVA: 0x00039480 File Offset: 0x00037680
		private void Start()
		{
			if (this.waypoints.Length != 0)
			{
				BezierPath bezierPath = new BezierPath(this.waypoints, this.closedLoop, PathSpace.xyz);
				base.GetComponent<PathCreator>().bezierPath = bezierPath;
			}
		}

		// Token: 0x04000A98 RID: 2712
		public bool closedLoop = true;

		// Token: 0x04000A99 RID: 2713
		public Transform[] waypoints;
	}
}
