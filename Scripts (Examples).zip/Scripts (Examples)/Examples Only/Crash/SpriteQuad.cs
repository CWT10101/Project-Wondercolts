﻿using System;
using UnityEngine;

// Token: 0x0200012D RID: 301
public class SpriteQuad : MonoBehaviour
{
	// Token: 0x17000114 RID: 276
	// (get) Token: 0x060008F7 RID: 2295 RVA: 0x0002528A File Offset: 0x0002348A
	// (set) Token: 0x060008F8 RID: 2296 RVA: 0x00025292 File Offset: 0x00023492
	public Sprite Sprite
	{
		get
		{
			return this.sprite;
		}
		set
		{
			this.sprite = value;
			this.Refresh();
		}
	}

	// Token: 0x060008F9 RID: 2297 RVA: 0x000252A1 File Offset: 0x000234A1
	private void Awake()
	{
		this.Refresh();
	}

	// Token: 0x060008FA RID: 2298 RVA: 0x000252A9 File Offset: 0x000234A9
	private void OnDidApplyAnimationProperties()
	{
		this.Refresh();
	}

	// Token: 0x060008FB RID: 2299 RVA: 0x000252B4 File Offset: 0x000234B4
	private void Refresh()
	{
		if (this.sprite == null)
		{
			this.sprite = this._prevSprite;
			return;
		}
		if (this._prevSprite != this.sprite)
		{
			this._prevSprite = this.sprite;
			if (this.mp == null)
			{
				this.mp = new MeshProvider(this.sprite);
				this.mp.AssignMesh(this.meshFilter);
			}
			this.mp.UseSpriteRect(this.sprite);
			this.meshRenderer.material.mainTexture = (this.sprite ? this.sprite.texture : null);
			this.meshRenderer.transform.localScale = new Vector3(this.sprite.rect.width * this.scale.x / this.sprite.pixelsPerUnit, this.sprite.rect.height * this.scale.y / this.sprite.pixelsPerUnit);
		}
	}

	// Token: 0x04000696 RID: 1686
	[SerializeField]
	private MeshFilter meshFilter;

	// Token: 0x04000697 RID: 1687
	[SerializeField]
	private MeshRenderer meshRenderer;

	// Token: 0x04000698 RID: 1688
	[SerializeField]
	private Vector2 scale = Vector2.one;

	// Token: 0x04000699 RID: 1689
	[SerializeField]
	private Sprite sprite;

	// Token: 0x0400069A RID: 1690
	private MeshProvider mp;

	// Token: 0x0400069B RID: 1691
	private Sprite _prevSprite;
}
