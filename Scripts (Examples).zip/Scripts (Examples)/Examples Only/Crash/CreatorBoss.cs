﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200006B RID: 107
public abstract class CreatorBoss : Enemy, IPlayModeCallback, IMetadataReceiver<FlipMetadata>, IMetadataReceiver<WarpSpawnMetadata>, IMetadataReceiver<MaxHPMetadata>
{
	// Token: 0x17000079 RID: 121
	// (get) Token: 0x060002BE RID: 702
	public abstract BossPhase[] Phases { get; }

	// Token: 0x1700007A RID: 122
	// (get) Token: 0x060002BF RID: 703
	public abstract BossPhase FallbackPhase { get; }

	// Token: 0x1700007B RID: 123
	// (get) Token: 0x060002C0 RID: 704
	public abstract IMover Mover { get; }

	// Token: 0x1700007C RID: 124
	// (get) Token: 0x060002C1 RID: 705 RVA: 0x0000BFD9 File Offset: 0x0000A1D9
	// (set) Token: 0x060002C2 RID: 706 RVA: 0x0000BFE1 File Offset: 0x0000A1E1
	public Sprite Icon { get; private set; }

	// Token: 0x1700007D RID: 125
	// (get) Token: 0x060002C3 RID: 707 RVA: 0x0000BFEA File Offset: 0x0000A1EA
	public BossPhase CurrentPhase
	{
		get
		{
			if (this.phaseIndex < 0)
			{
				return null;
			}
			if (this.phaseIndex >= this.Phases.Length)
			{
				return this.FallbackPhase;
			}
			return this.Phases[this.phaseIndex];
		}
	}

	// Token: 0x1700007E RID: 126
	// (get) Token: 0x060002C4 RID: 708 RVA: 0x0000C01B File Offset: 0x0000A21B
	public int MaxHP
	{
		get
		{
			return this.Phases.Length;
		}
	}

	// Token: 0x1700007F RID: 127
	// (get) Token: 0x060002C5 RID: 709 RVA: 0x0000C025 File Offset: 0x0000A225
	public int HP
	{
		get
		{
			return this.MaxHP - ((this.phaseIndex >= 0) ? this.phaseIndex : 0);
		}
	}

	// Token: 0x17000080 RID: 128
	// (get) Token: 0x060002C6 RID: 710 RVA: 0x0000C040 File Offset: 0x0000A240
	// (set) Token: 0x060002C7 RID: 711 RVA: 0x0000C048 File Offset: 0x0000A248
	public Vector2 Velocity { get; protected set; } = Vector2.zero;

	// Token: 0x17000081 RID: 129
	// (get) Token: 0x060002C8 RID: 712 RVA: 0x0000C051 File Offset: 0x0000A251
	// (set) Token: 0x060002C9 RID: 713 RVA: 0x0000C059 File Offset: 0x0000A259
	public IMover.MoveResult MoveResult { get; protected set; }

	// Token: 0x060002CA RID: 714 RVA: 0x0000C062 File Offset: 0x0000A262
	protected virtual void Initialize()
	{
	}

	// Token: 0x060002CB RID: 715 RVA: 0x0000C064 File Offset: 0x0000A264
	protected override void OnEnable()
	{
		base.OnEnable();
		if (this.renderers == null)
		{
			this.renderers = this.visual.GetComponentsInChildren<Renderer>(true);
		}
		if (this.mpb == null)
		{
			this.mpb = new MaterialPropertyBlock();
		}
		base.transform.rotation = Quaternion.LookRotation(this.startsFlipped ? Vector3.left : Vector3.right);
		this.SetVulnerableOff();
		this.Initialize();
		this.phaseIndex = -1;
	}

	// Token: 0x060002CC RID: 716 RVA: 0x0000C0DC File Offset: 0x0000A2DC
	protected override void FixedUpdate()
	{
		if (!this.Mover.CanUpdate)
		{
			return;
		}
		if (this.isAwake)
		{
			if (!this.isDead && MathUtil.InRange(base.transform.position, CrashController.instance.transform.position, (float)this.healthbarRange))
			{
				this.ShowHealthbar(true);
			}
			else
			{
				this.ShowHealthbar(false);
			}
		}
		if (!this.isDead && !this.isAwake && MathUtil.InRange(base.transform.position, CrashController.instance.transform.position, (float)this.sightRange))
		{
			Debug.Log("Awaken");
			this.isAwake = true;
			this.animator.speed = this.animatorSpeed;
		}
		else if (this.isAwake && this.MoveResult.Grounded && !MathUtil.InRange(base.transform.position, CrashController.instance.transform.position, (float)this.sightRange))
		{
			Debug.Log("Sleep");
			this.isAwake = false;
			this.animator.speed = 0f;
			return;
		}
		if (!this.isAwake)
		{
			return;
		}
		this.MoveResult = this.Mover.Move(this.Velocity, Time.fixedDeltaTime);
		Debug.DrawRay(base.transform.position, this.Velocity * Time.fixedDeltaTime, Color.yellow, Time.fixedDeltaTime, false);
		foreach (IMover.MoveHit moveHit in this.MoveResult.Hits)
		{
			Debug.DrawRay(moveHit.Position, moveHit.Normal, Color.red, Time.fixedDeltaTime, false);
			CrashController crashController;
			if (moveHit.Collider.TryGetComponent<CrashController>(out crashController))
			{
				Debug.Log("generate collision");
				base.GenerateCollision(crashController.controller, this.collider, moveHit.Normal, moveHit.Position, this.Velocity.normalized, this.Velocity.magnitude);
			}
		}
		if (this.phaseIndex >= 0)
		{
			this.CurrentPhase.Evaluate(this, this.CurrentPhase);
			return;
		}
		this.phaseIndex++;
		BossPhase.EvalFunc phaseEnter = this.CurrentPhase.PhaseEnter;
		if (phaseEnter == null)
		{
			return;
		}
		phaseEnter(this, this.CurrentPhase);
	}

	// Token: 0x060002CD RID: 717 RVA: 0x0000C34C File Offset: 0x0000A54C
	public void SetupHealthbar()
	{
		InterfaceManager.instance.bossIcon.sprite = this.Icon;
		for (int i = 0; i < InterfaceManager.instance.bossHP.Length; i++)
		{
			InterfaceManager.instance.bossHP[i].gameObject.SetActive(false);
		}
		for (int j = 0; j < this.MaxHP; j++)
		{
			InterfaceManager.instance.bossHP[j].m_bottomLeftColor = this.hpBarGradient.Evaluate((float)j / (float)this.MaxHP);
			InterfaceManager.instance.bossHP[j].m_topLeftColor = this.hpBarGradient.Evaluate((float)j / (float)this.MaxHP);
			InterfaceManager.instance.bossHP[j].m_bottomRightColor = this.hpBarGradient.Evaluate(((float)j + 1f) / (float)this.MaxHP);
			InterfaceManager.instance.bossHP[j].m_topRightColor = this.hpBarGradient.Evaluate(((float)j + 1f) / (float)this.MaxHP);
		}
		for (int k = 0; k < this.HP; k++)
		{
			InterfaceManager.instance.bossHP[k].gameObject.SetActive(true);
		}
	}

	// Token: 0x060002CE RID: 718 RVA: 0x0000C47F File Offset: 0x0000A67F
	public void ShowHealthbar(bool show)
	{
		if (show)
		{
			this.SetupHealthbar();
		}
		InterfaceManager.instance.bossUIHolder.SetActive(show);
	}

	// Token: 0x060002CF RID: 719 RVA: 0x0000C49A File Offset: 0x0000A69A
	public void SetVulnerableOn()
	{
		this.SetVulnerable(true);
	}

	// Token: 0x060002D0 RID: 720 RVA: 0x0000C4A3 File Offset: 0x0000A6A3
	public void SetVulnerableOff()
	{
		this.SetVulnerable(false);
	}

	// Token: 0x060002D1 RID: 721 RVA: 0x0000C4AC File Offset: 0x0000A6AC
	public void SetVulnerable(bool value)
	{
		Debug.Log("Set Vulnerable " + value.ToString());
		this.isVulnerable = value;
		this.mpb.SetFloat("_Flashing", (float)(value ? 1 : 0));
		Renderer[] array = this.renderers;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetPropertyBlock(this.mpb);
		}
	}

	// Token: 0x060002D2 RID: 722 RVA: 0x0000C514 File Offset: 0x0000A714
	public void TakeDamage()
	{
		if (this.wasHit)
		{
			return;
		}
		this.wasHit = true;
		this.SetVulnerableOff();
		this.ShowHealthbar(true);
		BossPhase.EvalFunc phaseExit = this.CurrentPhase.PhaseExit;
		if (phaseExit != null)
		{
			phaseExit(this, this.CurrentPhase);
		}
		this.phaseIndex++;
		if (this.CurrentPhase != null)
		{
			BossPhase.EvalFunc phaseEnter = this.CurrentPhase.PhaseEnter;
			if (phaseEnter != null)
			{
				phaseEnter(this, this.CurrentPhase);
			}
			if (this.CurrentPhase == this.FallbackPhase)
			{
				this.Die(true);
			}
		}
		else
		{
			this.Die(true);
		}
		for (int i = 0; i < InterfaceManager.instance.bossHP.Length; i++)
		{
			InterfaceManager.instance.bossHP[i].gameObject.SetActive(i < this.HP);
		}
	}

	// Token: 0x060002D3 RID: 723 RVA: 0x0000C5E2 File Offset: 0x0000A7E2
	public virtual void Teleport()
	{
		this.Mover.Teleport(base.transform.parent.position);
	}

	// Token: 0x060002D4 RID: 724 RVA: 0x0000C600 File Offset: 0x0000A800
	public override void Die(bool playSFX = true)
	{
		if (this.isDead)
		{
			this.SetVelocity(0f, 0f);
			AudioManager.Play("SFX_HitEnemy", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
			this.TrySpawnParticle();
			Collider[] colliders = base.Colliders;
			for (int i = 0; i < colliders.Length; i++)
			{
				colliders[i].enabled = false;
			}
			base.DisableEntity();
			return;
		}
		if (playSFX)
		{
			AudioManager.Play("SFX_HitEnemy", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		}
		if (this.audioSource != null)
		{
			this.audioSource.enabled = false;
		}
		this.isDead = true;
		base.RegisterKill();
		Debug.Log("Registered Kill probably meaning pushing to stack here");
		this.ShowHealthbar(false);
		if (this.spawnsWarpPortal)
		{
			base.StartCoroutine(this.SpawnPortalDelayed(2f));
		}
	}

	// Token: 0x060002D5 RID: 725 RVA: 0x0000C6EF File Offset: 0x0000A8EF
	private IEnumerator SpawnPortalDelayed(float delayTime)
	{
		float t = Clock.SynchronizedTime;
		while (this.collider.enabled)
		{
			if (Clock.SynchronizedTime - t >= delayTime)
			{
				break;
			}
			yield return new WaitForFixedUpdate();
		}
		while (this.collider.enabled && !this.MoveResult.Grounded)
		{
			yield return new WaitForFixedUpdate();
		}
		if (this.collider.enabled)
		{
			this.spawnedWarp = Object.Instantiate<GameObject>(ResourceManager.instance.spawnableEditorOrb, base.transform.position + this.spawnOffset, Quaternion.identity, LevelManager.instance.projectileHolder);
		}
		else
		{
			this.spawnedWarp = Object.Instantiate<GameObject>(ResourceManager.instance.spawnableEditorOrb, base.transform.parent.position + this.spawnOffset, Quaternion.identity, LevelManager.instance.projectileHolder);
		}
		yield break;
	}

	// Token: 0x060002D6 RID: 726 RVA: 0x0000C708 File Offset: 0x0000A908
	public bool CheckOtherBossesInRange()
	{
		Debug.Log("I am happening");
		if (Object.FindObjectsOfType<CreatorBoss>().Length > 1)
		{
			CreatorBoss[] array = Object.FindObjectsOfType<CreatorBoss>();
			int i = 0;
			while (i < array.Length)
			{
				if (array[i] != this)
				{
					Debug.Log("Found other boss: " + array[i].name);
					if (MathUtil.InRange(array[i].transform.position, CrashController.instance.transform.position, 20f))
					{
						array[i].ShowHealthbar(true);
						Debug.Log(array[i].name + " is in range");
						return true;
					}
					return false;
				}
				else
				{
					i++;
				}
			}
		}
		return false;
	}

	// Token: 0x060002D7 RID: 727 RVA: 0x0000C7AF File Offset: 0x0000A9AF
	public void SetVelocity_X(float x)
	{
		this.Velocity = new Vector2(x, this.Velocity.y);
	}

	// Token: 0x060002D8 RID: 728 RVA: 0x0000C7C8 File Offset: 0x0000A9C8
	public void SetVelocity_Y(float y)
	{
		this.Velocity = new Vector2(this.Velocity.x, y);
	}

	// Token: 0x060002D9 RID: 729 RVA: 0x0000C7E1 File Offset: 0x0000A9E1
	public void SetVelocity(float x, float y)
	{
		this.Velocity = new Vector2(x, y);
	}

	// Token: 0x060002DA RID: 730 RVA: 0x0000C7F0 File Offset: 0x0000A9F0
	public void AddVelocity_X(float x)
	{
		this.Velocity = new Vector2(this.Velocity.x + x, this.Velocity.y);
	}

	// Token: 0x060002DB RID: 731 RVA: 0x0000C815 File Offset: 0x0000AA15
	public void AddVelocity_Y(float y)
	{
		this.Velocity = new Vector2(this.Velocity.x, this.Velocity.y + y);
	}

	// Token: 0x060002DC RID: 732 RVA: 0x0000C83C File Offset: 0x0000AA3C
	protected bool IsAnimationState(string stateName)
	{
		return this.animator.GetCurrentAnimatorStateInfo(0).shortNameHash == Animator.StringToHash(stateName);
	}

	// Token: 0x060002DD RID: 733 RVA: 0x0000C868 File Offset: 0x0000AA68
	protected bool AnimationJustStarted()
	{
		return this.animator.GetCurrentAnimatorStateInfo(0).normalizedTime <= 0.1f;
	}

	// Token: 0x060002DE RID: 734 RVA: 0x0000C894 File Offset: 0x0000AA94
	protected bool IsAnimationFinished()
	{
		return this.animator.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.99f;
	}

	// Token: 0x060002DF RID: 735 RVA: 0x0000C8BF File Offset: 0x0000AABF
	public override void Slam(CrashController crash)
	{
		if (this.isDead)
		{
			crash.Bounce();
			return;
		}
		if (this.isVulnerable)
		{
			this.TakeDamage();
			return;
		}
		if (this.isDangerous)
		{
			this.HurtCrash(crash);
		}
	}

	// Token: 0x060002E0 RID: 736 RVA: 0x0000C8EE File Offset: 0x0000AAEE
	public override void Slide(CrashController crash)
	{
		if (this.isVulnerable)
		{
			this.TakeDamage();
			return;
		}
		if (this.isDangerous)
		{
			this.HurtCrash(crash);
		}
	}

	// Token: 0x060002E1 RID: 737 RVA: 0x0000C90E File Offset: 0x0000AB0E
	public override void Spin(CrashController crash)
	{
		if (this.isVulnerable)
		{
			this.TakeDamage();
			return;
		}
		if (this.isDangerous)
		{
			this.HurtCrash(crash);
		}
	}

	// Token: 0x060002E2 RID: 738 RVA: 0x0000C92E File Offset: 0x0000AB2E
	public override void SpinDeath(Transform source)
	{
		if (this.isVulnerable)
		{
			this.TakeDamage();
		}
	}

	// Token: 0x060002E3 RID: 739 RVA: 0x0000C93E File Offset: 0x0000AB3E
	public override void TouchBottom(CrashController crash)
	{
		if (this.isDangerous && !this.isVulnerable)
		{
			this.HurtCrash(crash);
		}
	}

	// Token: 0x060002E4 RID: 740 RVA: 0x0000C957 File Offset: 0x0000AB57
	public override void TouchSide(CrashController crash)
	{
		if (this.isDangerous && !this.isVulnerable)
		{
			this.HurtCrash(crash);
		}
	}

	// Token: 0x060002E5 RID: 741 RVA: 0x0000C970 File Offset: 0x0000AB70
	public override void TouchTop(CrashController crash)
	{
		if (this.isDangerous && !this.isVulnerable)
		{
			this.HurtCrash(crash);
			return;
		}
		crash.Bounce();
	}

	// Token: 0x060002E6 RID: 742 RVA: 0x0000C990 File Offset: 0x0000AB90
	public override void ResetEntity()
	{
		base.ResetEntity();
		this.SetVelocity(0f, 0f);
		this.isAwake = false;
		this.isVulnerable = false;
		this.wasHit = false;
		this.isDangerous = true;
		this.animator.speed = 0f;
		this.phaseIndex = -1;
		if (this.spawnedWarp)
		{
			Object.Destroy(this.spawnedWarp);
			this.spawnedWarp = null;
		}
		Debug.Log("Reset Creator Boss");
	}

	// Token: 0x060002E7 RID: 743 RVA: 0x0000CA0F File Offset: 0x0000AC0F
	public virtual void ProcessMetadata(FlipMetadata meta)
	{
		this.startsFlipped = meta.isFlipped;
	}

	// Token: 0x060002E8 RID: 744 RVA: 0x0000CA1D File Offset: 0x0000AC1D
	public virtual void ProcessMetadata(WarpSpawnMetadata meta)
	{
		this.spawnsWarpPortal = meta.spawnsWarpPortal;
	}

	// Token: 0x060002E9 RID: 745 RVA: 0x0000CA2B File Offset: 0x0000AC2B
	public virtual void ProcessMetadata(MaxHPMetadata meta)
	{
		this.maxHPSetting = (int)meta.maxHP;
	}

	// Token: 0x060002EA RID: 746 RVA: 0x0000CA39 File Offset: 0x0000AC39
	public void PlayModeChanged(bool isPlaying)
	{
		if (!isPlaying)
		{
			this.ShowHealthbar(false);
		}
	}

	// Token: 0x060002EB RID: 747 RVA: 0x0000CA45 File Offset: 0x0000AC45
	private void OnDrawGizmosSelected()
	{
		Gizmos.color = Color.yellow;
		Gizmos.DrawWireSphere(base.transform.position, (float)this.sightRange);
	}

	// Token: 0x040001A0 RID: 416
	public Gradient hpBarGradient;

	// Token: 0x040001A1 RID: 417
	public bool startsFlipped;

	// Token: 0x040001A2 RID: 418
	public bool spawnsWarpPortal;

	// Token: 0x040001A3 RID: 419
	public Vector3 spawnOffset;

	// Token: 0x040001A4 RID: 420
	protected GameObject spawnedWarp;

	// Token: 0x040001A5 RID: 421
	protected int phaseIndex = -1;

	// Token: 0x040001A6 RID: 422
	public int maxHPSetting = 3;

	// Token: 0x040001A7 RID: 423
	public int sightRange = 20;

	// Token: 0x040001A8 RID: 424
	public int healthbarRange = 20;

	// Token: 0x040001AB RID: 427
	protected bool isAwake;

	// Token: 0x040001AC RID: 428
	[SerializeField]
	protected bool wasHit;

	// Token: 0x040001AD RID: 429
	[SerializeField]
	protected bool isVulnerable;

	// Token: 0x040001AE RID: 430
	[SerializeField]
	protected bool isDangerous = true;

	// Token: 0x040001AF RID: 431
	protected float animatorSpeed = 1f;

	// Token: 0x040001B0 RID: 432
	protected Renderer[] renderers;

	// Token: 0x040001B1 RID: 433
	protected MaterialPropertyBlock mpb;
}
