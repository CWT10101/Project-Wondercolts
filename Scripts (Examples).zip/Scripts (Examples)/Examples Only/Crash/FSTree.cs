﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x02000015 RID: 21
public class FSTree : FSFolder
{
	// Token: 0x17000009 RID: 9
	// (get) Token: 0x06000055 RID: 85 RVA: 0x000037F2 File Offset: 0x000019F2
	private Dictionary<string, FSObject> Objects { get; } = new Dictionary<string, FSObject>();

	// Token: 0x06000056 RID: 86 RVA: 0x000037FC File Offset: 0x000019FC
	public FSTree(DirectoryInfo root) : base(root.Name, null)
	{
		this.<.ctor>g__PopulateBranch|3_0(root, this);
		foreach (KeyValuePair<string, FSObject> keyValuePair in this.Objects)
		{
			Debug.Log(keyValuePair.Key);
		}
	}

	// Token: 0x06000057 RID: 87 RVA: 0x00003874 File Offset: 0x00001A74
	[CompilerGenerated]
	private void <.ctor>g__PopulateBranch|3_0(DirectoryInfo dir, FSFolder dirFolder)
	{
		IEnumerable<DirectoryInfo> enumerable = dir.EnumerateDirectories();
		foreach (FileInfo fileInfo in dir.EnumerateFiles())
		{
			FSFile fsfile = new FSFile(fileInfo.Name, dirFolder);
			dirFolder.Files.Add(fsfile.Name, fsfile);
			string path = fsfile.GetPath();
			this.Objects.Add(path, fsfile);
		}
		foreach (DirectoryInfo directoryInfo in enumerable)
		{
			FSFolder fsfolder = new FSFolder(directoryInfo.Name, dirFolder);
			dirFolder.Folders.Add(fsfolder.Name, fsfolder);
			string path2 = fsfolder.GetPath();
			this.Objects.Add(path2, fsfolder);
			this.<.ctor>g__PopulateBranch|3_0(directoryInfo, fsfolder);
		}
	}
}
