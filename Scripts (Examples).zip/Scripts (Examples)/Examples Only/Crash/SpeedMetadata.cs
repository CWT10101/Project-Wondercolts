﻿using System;
using System.IO;
using LevelEditor;

// Token: 0x02000034 RID: 52
public class SpeedMetadata : ObjectMetadata
{
	// Token: 0x17000051 RID: 81
	// (get) Token: 0x06000154 RID: 340 RVA: 0x00006A54 File Offset: 0x00004C54
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000052 RID: 82
	// (get) Token: 0x06000155 RID: 341 RVA: 0x00006A57 File Offset: 0x00004C57
	public override int Signature
	{
		get
		{
			return "SpeedMetadata".GetHashCode();
		}
	}

	// Token: 0x17000053 RID: 83
	// (get) Token: 0x06000156 RID: 342 RVA: 0x00006A63 File Offset: 0x00004C63
	public override int ValueHash
	{
		get
		{
			return (int)this.speed;
		}
	}

	// Token: 0x06000157 RID: 343 RVA: 0x00006A6B File Offset: 0x00004C6B
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.speed);
	}

	// Token: 0x06000158 RID: 344 RVA: 0x00006A79 File Offset: 0x00004C79
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.speed = br.ReadByte();
	}

	// Token: 0x06000159 RID: 345 RVA: 0x00006A88 File Offset: 0x00004C88
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<SpeedMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<SpeedMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x040000A1 RID: 161
	public byte speed;
}
