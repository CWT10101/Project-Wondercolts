﻿using System;
using UnityEngine;

// Token: 0x0200006C RID: 108
public class FireBreathingTiki : Entity, IMetadataReceiver<FlipMetadata>, IMetadataReceiver<PhaseMetadata>
{
	// Token: 0x17000082 RID: 130
	// (get) Token: 0x060002ED RID: 749 RVA: 0x0000CAB6 File Offset: 0x0000ACB6
	private float CycleLength
	{
		get
		{
			return this.durationOff + this.durationOn;
		}
	}

	// Token: 0x060002EE RID: 750 RVA: 0x0000CAC8 File Offset: 0x0000ACC8
	private void Start()
	{
		this._m = new Mesh
		{
			vertices = new Vector3[]
			{
				new Vector3(-0.5f, -0.5f, 0f),
				new Vector3(0.5f, -0.5f, 0f),
				new Vector3(-0.5f, 0.5f, 0f),
				new Vector3(0.5f, 0.5f, 0f)
			},
			triangles = new int[]
			{
				0,
				2,
				1,
				2,
				3,
				1
			},
			normals = new Vector3[]
			{
				Vector3.back,
				Vector3.back,
				Vector3.back,
				Vector3.back
			}
		};
		this.uvOperation = (this.texStartsFromTop ? new Action(this.SetMeshUVsTop) : new Action(this.SetMeshUVsBottom));
		this.uvOperation();
		this.flame.sharedMesh = this._m;
	}

	// Token: 0x060002EF RID: 751 RVA: 0x0000CBF4 File Offset: 0x0000ADF4
	private void FixedUpdate()
	{
		float num = this.offset * this.CycleLength;
		float num2 = Clock.SynchronizedTime + num - Time.fixedDeltaTime;
		float num3 = Clock.SynchronizedTime + num;
		num2 %= this.CycleLength;
		num3 %= this.CycleLength;
		this.hazard.SetActive(num3 > this.durationOff);
		this.flame.transform.parent.localScale = Vector3.one * this.particleScaleCurve.Evaluate(num3);
		this.lightSource.radius = this.lightRadiusCurve.Evaluate(num3);
		this.uvOperation();
		if (num2 < this.igniteAudioTime && num3 >= this.igniteAudioTime)
		{
			this.igniteAudioSrc.Play();
			return;
		}
		if (num2 < this.flameAudioTime && num3 >= this.flameAudioTime)
		{
			this.flameAudioSrc.Play();
		}
	}

	// Token: 0x060002F0 RID: 752 RVA: 0x0000CCD4 File Offset: 0x0000AED4
	private void SetMeshUVsBottom()
	{
		int num = (int)(Clock.SynchronizedTime * (float)this.texFramesPerSec);
		float num2 = (float)num % (float)this.texTilesW / (float)this.texTilesW;
		float num3 = Mathf.Floor((float)num / (float)this.texTilesW) / (float)this.texTilesH;
		float num4 = 1f / (float)this.texTilesW;
		float num5 = 1f / (float)this.texTilesH;
		this.uvs[0] = new Vector2(num2, num3);
		this.uvs[1] = new Vector2(num2 + num4, num3);
		this.uvs[2] = new Vector2(num2, num3 + num5);
		this.uvs[3] = new Vector2(num2 + num4, num3 + num5);
		this._m.uv = this.uvs;
	}

	// Token: 0x060002F1 RID: 753 RVA: 0x0000CD9C File Offset: 0x0000AF9C
	private void SetMeshUVsTop()
	{
		int num = (int)(Clock.SynchronizedTime * (float)this.texFramesPerSec);
		float num2 = (float)num % (float)this.texTilesW / (float)this.texTilesW;
		float num3 = ((float)(this.texTilesH - 1) - Mathf.Floor((float)num / (float)this.texTilesW)) / (float)this.texTilesH;
		float num4 = 1f / (float)this.texTilesW;
		float num5 = 1f / (float)this.texTilesH;
		this.uvs[0] = new Vector2(num2, num3);
		this.uvs[1] = new Vector2(num2 + num4, num3);
		this.uvs[2] = new Vector2(num2, num3 + num5);
		this.uvs[3] = new Vector2(num2 + num4, num3 + num5);
		this._m.uv = this.uvs;
	}

	// Token: 0x060002F2 RID: 754 RVA: 0x0000CE71 File Offset: 0x0000B071
	public void ProcessMetadata(PhaseMetadata meta)
	{
		this.offset = meta.NormalizedValue;
	}

	// Token: 0x060002F3 RID: 755 RVA: 0x0000CE7F File Offset: 0x0000B07F
	public void ProcessMetadata(FlipMetadata meta)
	{
		this.flame.transform.parent.rotation = (meta.isFlipped ? this.rightFacingFlame.rotation : this.leftFacingFlame.rotation);
	}

	// Token: 0x040001B2 RID: 434
	public GameObject hazard;

	// Token: 0x040001B3 RID: 435
	public MeshFilter flame;

	// Token: 0x040001B4 RID: 436
	public LightSource lightSource;

	// Token: 0x040001B5 RID: 437
	public AudioSource igniteAudioSrc;

	// Token: 0x040001B6 RID: 438
	public AudioSource flameAudioSrc;

	// Token: 0x040001B7 RID: 439
	public AnimationCurve particleScaleCurve;

	// Token: 0x040001B8 RID: 440
	public AnimationCurve lightRadiusCurve;

	// Token: 0x040001B9 RID: 441
	public float durationOn = 2f;

	// Token: 0x040001BA RID: 442
	public float durationOff = 4f;

	// Token: 0x040001BB RID: 443
	public float igniteAudioTime = 3f;

	// Token: 0x040001BC RID: 444
	public float flameAudioTime = 4f;

	// Token: 0x040001BD RID: 445
	public float offset;

	// Token: 0x040001BE RID: 446
	public byte texTilesW = 8;

	// Token: 0x040001BF RID: 447
	public byte texTilesH = 4;

	// Token: 0x040001C0 RID: 448
	public byte texFramesPerSec = 20;

	// Token: 0x040001C1 RID: 449
	public bool texStartsFromTop = true;

	// Token: 0x040001C2 RID: 450
	private Mesh _m;

	// Token: 0x040001C3 RID: 451
	private readonly Vector2[] uvs = new Vector2[4];

	// Token: 0x040001C4 RID: 452
	private Action uvOperation;

	// Token: 0x040001C5 RID: 453
	public Transform rightFacingFlame;

	// Token: 0x040001C6 RID: 454
	public Transform leftFacingFlame;
}
