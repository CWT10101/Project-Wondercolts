﻿using System;
using UnityEngine;

// Token: 0x020000B3 RID: 179
public class Explosion : MonoBehaviour
{
	// Token: 0x06000590 RID: 1424 RVA: 0x00018A37 File Offset: 0x00016C37
	public virtual void Start()
	{
		this.tStart = Time.time;
	}

	// Token: 0x06000591 RID: 1425 RVA: 0x00018A44 File Offset: 0x00016C44
	private void OnDisable()
	{
		Object.Destroy(base.gameObject);
	}

	// Token: 0x06000592 RID: 1426 RVA: 0x00018A54 File Offset: 0x00016C54
	public virtual void FixedUpdate()
	{
		float num = (Time.time - this.tStart) / this.duration;
		if (num > 1f)
		{
			num = 1f;
		}
		foreach (Collider collider in Physics.OverlapSphere(base.transform.position, Mathf.Lerp(0.5f, this.size, num)))
		{
			Crate crate;
			if (collider.TryGetComponent<Crate>(out crate))
			{
				crate.Break();
			}
			Pickup pickup;
			if (collider.TryGetComponent<Pickup>(out pickup) && (pickup is WumpaPickup || pickup is LifePickup || pickup is Mask))
			{
				pickup.SpinAway(base.transform, false, true);
			}
			RooTNT rooTNT;
			if (collider.TryGetComponent<RooTNT>(out rooTNT))
			{
				rooTNT.Explode();
			}
		}
		if (num == 1f)
		{
			Object.Destroy(base.gameObject);
		}
	}

	// Token: 0x040003F1 RID: 1009
	[HideInInspector]
	public float size;

	// Token: 0x040003F2 RID: 1010
	public float duration;

	// Token: 0x040003F3 RID: 1011
	[HideInInspector]
	public float tStart;
}
