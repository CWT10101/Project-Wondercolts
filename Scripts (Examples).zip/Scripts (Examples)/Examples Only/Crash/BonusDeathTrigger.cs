﻿using System;

// Token: 0x02000062 RID: 98
public class BonusDeathTrigger : DeathTrigger
{
}
