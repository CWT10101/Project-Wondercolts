﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200009C RID: 156
public class DestroyAfterTime : DestroyHook
{
	// Token: 0x060004A9 RID: 1193 RVA: 0x00014FAA File Offset: 0x000131AA
	private void Start()
	{
		this.Destroy();
	}

	// Token: 0x060004AA RID: 1194 RVA: 0x00014FB2 File Offset: 0x000131B2
	private void OnDisable()
	{
		base.Destroy();
	}

	// Token: 0x060004AB RID: 1195 RVA: 0x00014FBA File Offset: 0x000131BA
	public override void Destroy()
	{
		if (!this.isDestroying)
		{
			base.StartCoroutine(this.WaitAndDestroy());
		}
	}

	// Token: 0x060004AC RID: 1196 RVA: 0x00014FD1 File Offset: 0x000131D1
	private IEnumerator WaitAndDestroy()
	{
		this.isDestroying = true;
		yield return new WaitForSeconds(this.timeUntilDestroy);
		base.Destroy();
		yield break;
	}

	// Token: 0x04000346 RID: 838
	public float timeUntilDestroy = 3f;

	// Token: 0x04000347 RID: 839
	private bool isDestroying;
}
