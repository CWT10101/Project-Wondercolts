﻿using System;
using UnityEngine;

// Token: 0x020000AD RID: 173
public class Entity : MonoBehaviour
{
	// Token: 0x14000002 RID: 2
	// (add) Token: 0x06000569 RID: 1385 RVA: 0x000183B4 File Offset: 0x000165B4
	// (remove) Token: 0x0600056A RID: 1386 RVA: 0x000183EC File Offset: 0x000165EC
	public event Action onPushedToStack;

	// Token: 0x0600056B RID: 1387 RVA: 0x00018421 File Offset: 0x00016621
	public virtual void TryPushToStack()
	{
		if (EntityTracker.instance && this.canPushToStack)
		{
			this.PushToEntityStack();
		}
	}

	// Token: 0x0600056C RID: 1388 RVA: 0x0001843D File Offset: 0x0001663D
	public void PushToEntityStack()
	{
		EntityTracker.PushToStack(this);
		Action action = this.onPushedToStack;
		if (action == null)
		{
			return;
		}
		action();
	}

	// Token: 0x0600056D RID: 1389 RVA: 0x00018455 File Offset: 0x00016655
	public virtual void ResetEntity()
	{
		this.EnableEntity();
	}

	// Token: 0x0600056E RID: 1390 RVA: 0x0001845D File Offset: 0x0001665D
	public virtual void RememberState()
	{
	}

	// Token: 0x0600056F RID: 1391 RVA: 0x0001845F File Offset: 0x0001665F
	public void DisableEntity()
	{
		this.SetEntityEnabled(false);
	}

	// Token: 0x06000570 RID: 1392 RVA: 0x00018468 File Offset: 0x00016668
	public void EnableEntity()
	{
		this.SetEntityEnabled(true);
	}

	// Token: 0x06000571 RID: 1393 RVA: 0x00018474 File Offset: 0x00016674
	private void SetEntityEnabled(bool enabled)
	{
		if (this.collider)
		{
			this.collider.enabled = enabled;
		}
		if (!this.visual)
		{
			Debug.LogWarning(string.Format("{0} has no visual", this), this);
			return;
		}
		this.visual.SetActive(enabled);
	}

	// Token: 0x040003CD RID: 973
	public Collider collider;

	// Token: 0x040003CE RID: 974
	public GameObject visual;

	// Token: 0x040003D0 RID: 976
	[HideInInspector]
	public bool canPushToStack = true;
}
