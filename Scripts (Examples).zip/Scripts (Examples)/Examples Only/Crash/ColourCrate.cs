﻿using System;
using UnityEngine;

// Token: 0x02000086 RID: 134
public abstract class ColourCrate : Crate
{
	// Token: 0x060003B2 RID: 946 RVA: 0x0000F987 File Offset: 0x0000DB87
	public override void Break()
	{
	}

	// Token: 0x060003B3 RID: 947 RVA: 0x0000F989 File Offset: 0x0000DB89
	public override void ForceBreak()
	{
	}

	// Token: 0x060003B4 RID: 948 RVA: 0x0000F98B File Offset: 0x0000DB8B
	public override void ResetEntity()
	{
	}

	// Token: 0x060003B5 RID: 949 RVA: 0x0000F990 File Offset: 0x0000DB90
	public virtual void SetSolid(bool isSolid, bool onEnable = false)
	{
		if (this.visual.activeInHierarchy)
		{
			this.clearVis.SetActive(!isSolid);
			this.solidVis.SetActive(isSolid);
			this.collider.enabled = isSolid;
			Crate crate;
			if (!onEnable && !isSolid && base.CrateCheck(out crate))
			{
				crate.Fall(0f);
				return;
			}
		}
		else
		{
			Debug.Log("Setting status of a Colour crate that is not currently visible in the scene, outline mode?");
		}
	}

	// Token: 0x04000271 RID: 625
	public GameObject clearVis;

	// Token: 0x04000272 RID: 626
	public GameObject solidVis;
}
