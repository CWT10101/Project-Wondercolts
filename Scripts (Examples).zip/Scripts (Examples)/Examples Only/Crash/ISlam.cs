﻿using System;

// Token: 0x020000CC RID: 204
public interface ISlam
{
	// Token: 0x06000618 RID: 1560
	void Slam(CrashController crash);
}
