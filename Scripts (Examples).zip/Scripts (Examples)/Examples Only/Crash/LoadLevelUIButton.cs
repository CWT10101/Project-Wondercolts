﻿using System;
using LevelEditor;
using TMPro;
using UnityEngine;

// Token: 0x02000022 RID: 34
public class LoadLevelUIButton : MonoBehaviour
{
	// Token: 0x060000B0 RID: 176 RVA: 0x00005947 File Offset: 0x00003B47
	public void LoadLevel()
	{
		UIScreen.activeScreen.FocusScreen(LevelInterfaceManager.instance.editorHUD);
		LevelSerializer.instance.LoadLevelButton(this.levelName);
	}

	// Token: 0x0400007F RID: 127
	public TMP_Text text;

	// Token: 0x04000080 RID: 128
	public string levelName;
}
