﻿using System;
using UnityEngine;

// Token: 0x0200004C RID: 76
[DefaultExecutionOrder(10)]
public class AnimationSegment : MonoBehaviour
{
	// Token: 0x06000207 RID: 519 RVA: 0x000092C4 File Offset: 0x000074C4
	private void OnEnable()
	{
		this.PerformLockBehavior(this.lockOnEnter);
		if (this.animator == null || !this.animator.gameObject.activeInHierarchy)
		{
			this.animator = base.GetComponentInChildren<Animator>();
		}
		if (this.effectOnEnable)
		{
			Object.Instantiate<GameObject>(this.effectOnEnable, base.transform.position, base.transform.rotation);
		}
		if (!string.IsNullOrEmpty(this.sfxClip))
		{
			AudioManager.Play(this.sfxClip, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		}
	}

	// Token: 0x06000208 RID: 520 RVA: 0x0000936C File Offset: 0x0000756C
	private void Update()
	{
		if (this.animator && !this.animator.gameObject.activeSelf)
		{
			this.animator = base.GetComponentInChildren<Animator>();
		}
		if (this.nextState && this.animator && this.animator.GetCurrentAnimatorStateInfo(0).normalizedTime >= 1f)
		{
			this.PerformLockBehavior(this.lockOnExit);
			this.crashAnimator.SetState(this.nextState, false);
		}
	}

	// Token: 0x06000209 RID: 521 RVA: 0x000093F7 File Offset: 0x000075F7
	private void PerformLockBehavior(AnimationSegment.LockBehavior lb)
	{
		if (lb == AnimationSegment.LockBehavior.None)
		{
			return;
		}
		if (lb == AnimationSegment.LockBehavior.Lock)
		{
			this.crashAnimator.Controller.isInputLocked = true;
			return;
		}
		if (lb == AnimationSegment.LockBehavior.Unlock)
		{
			this.crashAnimator.Controller.isInputLocked = false;
		}
	}

	// Token: 0x04000114 RID: 276
	public CrashAnimator crashAnimator;

	// Token: 0x04000115 RID: 277
	public Animator animator;

	// Token: 0x04000116 RID: 278
	public GameObject nextState;

	// Token: 0x04000117 RID: 279
	public AnimationSegment.LockBehavior lockOnEnter;

	// Token: 0x04000118 RID: 280
	public AnimationSegment.LockBehavior lockOnExit;

	// Token: 0x04000119 RID: 281
	public GameObject effectOnEnable;

	// Token: 0x0400011A RID: 282
	public string sfxClip;

	// Token: 0x020001E3 RID: 483
	public enum LockBehavior
	{
		// Token: 0x04000C63 RID: 3171
		None,
		// Token: 0x04000C64 RID: 3172
		Lock,
		// Token: 0x04000C65 RID: 3173
		Unlock
	}
}
