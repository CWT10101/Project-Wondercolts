﻿using System;
using LevelEditor3D;
using UnityEngine;

// Token: 0x02000009 RID: 9
public class DarknessWeather : MonoBehaviour, IPlayModeCallback
{
	// Token: 0x06000024 RID: 36 RVA: 0x00002F48 File Offset: 0x00001148
	private void OnEnable()
	{
		if (LevelManager.instance)
		{
			this.SetProperties(LevelManager.instance.inEditorMode, true);
			return;
		}
		if (LevelBuilder.Instance)
		{
			this.SetProperties(LevelBuilder.Instance.EditMode, true);
		}
	}

	// Token: 0x06000025 RID: 37 RVA: 0x00002F88 File Offset: 0x00001188
	private void OnDisable()
	{
		if (!base.gameObject)
		{
			return;
		}
		if (LevelManager.instance)
		{
			this.SetProperties(LevelManager.instance.inEditorMode, false);
			return;
		}
		if (LevelBuilder.Instance)
		{
			this.SetProperties(LevelBuilder.Instance.EditMode, false);
		}
	}

	// Token: 0x06000026 RID: 38 RVA: 0x00002FE0 File Offset: 0x000011E0
	private void SetProperties(bool inEditor, bool enable)
	{
		if (inEditor)
		{
			if (InterfaceManager.instance)
			{
				InterfaceManager.instance.darknessEditorOverlay.SetActive(enable);
			}
			this.pp.SetMix((float)(enable ? 1 : 0), true);
			return;
		}
		if (enable)
		{
			this.pp.FadeOn();
			return;
		}
		this.pp.FadeOff();
	}

	// Token: 0x06000027 RID: 39 RVA: 0x0000303B File Offset: 0x0000123B
	public void PlayModeChanged(bool isPlaying)
	{
		InterfaceManager.instance.darknessEditorOverlay.SetActive(!isPlaying);
		this.pp.enabled = isPlaying;
	}

	// Token: 0x04000027 RID: 39
	public DarknessPP pp;
}
