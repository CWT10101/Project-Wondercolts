﻿using System;
using UnityEngine;

// Token: 0x020000DF RID: 223
public class ResourceManager : MonoBehaviour
{
	// Token: 0x170000F0 RID: 240
	// (get) Token: 0x060006DA RID: 1754 RVA: 0x0001D577 File Offset: 0x0001B777
	// (set) Token: 0x060006DB RID: 1755 RVA: 0x0001D57E File Offset: 0x0001B77E
	public static ResourceManager instance { get; private set; }

	// Token: 0x060006DC RID: 1756 RVA: 0x0001D586 File Offset: 0x0001B786
	private void Awake()
	{
		ResourceManager.instance = this;
		Object.DontDestroyOnLoad(base.gameObject);
	}

	// Token: 0x060006DD RID: 1757 RVA: 0x0001D59C File Offset: 0x0001B79C
	private void Start()
	{
		if (PlayerPrefs.HasKey("Quality"))
		{
			int @int = PlayerPrefs.GetInt("Quality");
			Debug.Log("Initializing Quality Level " + @int.ToString());
			QualitySettings.SetQualityLevel(@int, true);
		}
	}

	// Token: 0x060006DE RID: 1758 RVA: 0x0001D5DD File Offset: 0x0001B7DD
	public static void InstantiateDeathEffect(Transform t, int index = 0)
	{
		Object.Instantiate<GameObject>(ResourceManager.instance.crashDeathEffects[index], t.position, t.rotation);
	}

	// Token: 0x0400052A RID: 1322
	public BrokenCrate brokenCrate;

	// Token: 0x0400052B RID: 1323
	public GameObject slamWaveEffect;

	// Token: 0x0400052C RID: 1324
	public Aku aku;

	// Token: 0x0400052D RID: 1325
	public CrashController crash;

	// Token: 0x0400052E RID: 1326
	public Pickup crateGemPickup;

	// Token: 0x0400052F RID: 1327
	public GameObject[] crashDeathEffects;

	// Token: 0x04000530 RID: 1328
	public ActivatorTimerVisual timerCircle;

	// Token: 0x04000531 RID: 1329
	public GameObject timerFXPrefab;

	// Token: 0x04000532 RID: 1330
	public Material[] conveyorBeltMatsGreen;

	// Token: 0x04000533 RID: 1331
	public Material[] conveyorBeltMatsBlue;

	// Token: 0x04000534 RID: 1332
	public GameObject spawnableEditorOrb;

	// Token: 0x04000535 RID: 1333
	public static string[] LevelTypeNames = new string[]
	{
		"Practice",
		"Flashback",
		"Trial",
		"Adventure"
	};

	// Token: 0x04000536 RID: 1334
	public LayerMask visionMask;
}
