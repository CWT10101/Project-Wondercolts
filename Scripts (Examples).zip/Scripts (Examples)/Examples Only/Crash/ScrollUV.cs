﻿using System;
using UnityEngine;

// Token: 0x02000111 RID: 273
public class ScrollUV : MonoBehaviour
{
	// Token: 0x0600086F RID: 2159 RVA: 0x0002361F File Offset: 0x0002181F
	private void Reset()
	{
		this.renderer = base.GetComponent<Renderer>();
		this.textureTarget = "_MainTex";
	}

	// Token: 0x06000870 RID: 2160 RVA: 0x00023638 File Offset: 0x00021838
	private void Update()
	{
		this.renderer.material.SetTextureOffset(this.textureTarget, this.scroll * ((this.quantization == 0f) ? Time.time : (this.quantization * (float)((int)(Time.time / this.quantization)))));
	}

	// Token: 0x04000629 RID: 1577
	public string textureTarget;

	// Token: 0x0400062A RID: 1578
	public Renderer renderer;

	// Token: 0x0400062B RID: 1579
	public Vector2 scroll = Vector2.up;

	// Token: 0x0400062C RID: 1580
	public float quantization;
}
