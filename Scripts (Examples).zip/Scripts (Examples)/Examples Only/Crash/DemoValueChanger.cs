﻿using System;
using UnityEngine;

// Token: 0x02000040 RID: 64
public class DemoValueChanger : MonoBehaviour
{
	// Token: 0x0600019A RID: 410 RVA: 0x00007479 File Offset: 0x00005679
	private void Start()
	{
		this.psx = Object.FindObjectOfType<PSXEffects>();
	}

	// Token: 0x0600019B RID: 411 RVA: 0x00007488 File Offset: 0x00005688
	public void _ResolutionFactor(string input)
	{
		int resolutionFactor = int.Parse(input);
		this.psx.resolutionFactor = resolutionFactor;
		this.psx.UpdateProperties();
	}

	// Token: 0x0600019C RID: 412 RVA: 0x000074B4 File Offset: 0x000056B4
	public void _FrameSkip(string input)
	{
		int skipFrames = int.Parse(input);
		this.psx.skipFrames = skipFrames;
		this.psx.UpdateProperties();
	}

	// Token: 0x0600019D RID: 413 RVA: 0x000074DF File Offset: 0x000056DF
	public void _AffineMapping(bool input)
	{
		this.psx.affineMapping = input;
		this.psx.UpdateProperties();
	}

	// Token: 0x0600019E RID: 414 RVA: 0x000074F8 File Offset: 0x000056F8
	public void _DrawDistance(string input)
	{
		float polygonalDrawDistance = float.Parse(input);
		this.psx.polygonalDrawDistance = polygonalDrawDistance;
		this.psx.UpdateProperties();
	}

	// Token: 0x0600019F RID: 415 RVA: 0x00007524 File Offset: 0x00005724
	public void _PolygonInaccuracy(string input)
	{
		int polygonInaccuracy = int.Parse(input);
		this.psx.polygonInaccuracy = polygonInaccuracy;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001A0 RID: 416 RVA: 0x00007550 File Offset: 0x00005750
	public void _VertexInaccuracy(string input)
	{
		int vertexInaccuracy = int.Parse(input);
		this.psx.vertexInaccuracy = vertexInaccuracy;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001A1 RID: 417 RVA: 0x0000757B File Offset: 0x0000577B
	public void _WorldSpaceSnapping(bool input)
	{
		this.psx.worldSpaceSnapping = input;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001A2 RID: 418 RVA: 0x00007594 File Offset: 0x00005794
	public void _CameraBasedSnapping(bool input)
	{
		this.psx.camSnapping = input;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001A3 RID: 419 RVA: 0x000075B0 File Offset: 0x000057B0
	public void _SaturatedDiffuse(string input)
	{
		int maxDarkness = int.Parse(input);
		this.psx.maxDarkness = maxDarkness;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001A4 RID: 420 RVA: 0x000075DB File Offset: 0x000057DB
	public void _PostProcessing(bool input)
	{
		this.psx.postProcessing = input;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001A5 RID: 421 RVA: 0x000075F4 File Offset: 0x000057F4
	public void _ColorDepth(string input)
	{
		int colorDepth = int.Parse(input);
		this.psx.colorDepth = colorDepth;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001A6 RID: 422 RVA: 0x0000761F File Offset: 0x0000581F
	public void _SubtractionFade(float input)
	{
		this.psx.subtractFade = (int)input;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001A7 RID: 423 RVA: 0x0000763C File Offset: 0x0000583C
	public void _FavorRed(string input)
	{
		float favorRed = float.Parse(input);
		this.psx.favorRed = favorRed;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001A8 RID: 424 RVA: 0x00007667 File Offset: 0x00005867
	public void _Scanlines(bool input)
	{
		this.psx.scanlines = input;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001A9 RID: 425 RVA: 0x00007680 File Offset: 0x00005880
	public void _Vertical(bool input)
	{
		this.psx.verticalScanlines = input;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001AA RID: 426 RVA: 0x0000769C File Offset: 0x0000589C
	public void _ScanlineIntensity(string input)
	{
		int scanlineIntensity = int.Parse(input);
		this.psx.scanlineIntensity = scanlineIntensity;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001AB RID: 427 RVA: 0x000076C7 File Offset: 0x000058C7
	public void _Dithering(bool input)
	{
		this.psx.dithering = input;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001AC RID: 428 RVA: 0x000076E0 File Offset: 0x000058E0
	public void _DitherThreshold(string input)
	{
		float ditherThreshold = float.Parse(input);
		this.psx.ditherThreshold = ditherThreshold;
		this.psx.UpdateProperties();
	}

	// Token: 0x060001AD RID: 429 RVA: 0x0000770C File Offset: 0x0000590C
	public void _DitherIntensity(string input)
	{
		int ditherIntensity = int.Parse(input);
		this.psx.ditherIntensity = ditherIntensity;
		this.psx.UpdateProperties();
	}

	// Token: 0x040000C6 RID: 198
	private PSXEffects psx;
}
