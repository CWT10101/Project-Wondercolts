﻿using System;
using UnityEngine;

// Token: 0x0200014B RID: 331
public class FloatAndFollow : MonoBehaviour
{
	// Token: 0x060009BB RID: 2491 RVA: 0x000274E2 File Offset: 0x000256E2
	public virtual void SetTarget(Transform targ)
	{
		this.target = targ;
	}

	// Token: 0x060009BC RID: 2492 RVA: 0x000274EC File Offset: 0x000256EC
	private void LateUpdate()
	{
		if (this.target)
		{
			Vector3 localPosition = Vector3.up * Mathf.Sin(Time.time * this.bobRate) * this.bobHeight;
			base.transform.position = Vector3.Lerp(base.transform.position, this.target.TransformPoint(this.offset), 1f - Mathf.Exp(-this.moveSpeed * Time.deltaTime));
			this.visual.localPosition = localPosition;
			base.transform.rotation = Quaternion.Lerp(base.transform.rotation, this.target.rotation, this.rotateSpeed * Time.deltaTime);
		}
	}

	// Token: 0x0400070A RID: 1802
	public Transform visual;

	// Token: 0x0400070B RID: 1803
	public Transform target;

	// Token: 0x0400070C RID: 1804
	public float moveSpeed = 3f;

	// Token: 0x0400070D RID: 1805
	public float rotateSpeed = 2.5f;

	// Token: 0x0400070E RID: 1806
	public Vector3 offset = new Vector3(-1f, 2f, 0f);

	// Token: 0x0400070F RID: 1807
	public float bobRate = 1.75f;

	// Token: 0x04000710 RID: 1808
	public float bobHeight = 0.2f;
}
