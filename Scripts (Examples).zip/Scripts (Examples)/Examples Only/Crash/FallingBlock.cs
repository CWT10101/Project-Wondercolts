﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x020000B5 RID: 181
public class FallingBlock : Entity, ITouchTop, IFallOn, ISlide
{
	// Token: 0x0600059B RID: 1435 RVA: 0x00018BC9 File Offset: 0x00016DC9
	private void OnDisable()
	{
		this.isFalling = false;
		base.EnableEntity();
	}

	// Token: 0x0600059C RID: 1436 RVA: 0x00018BD8 File Offset: 0x00016DD8
	public IEnumerator Fall()
	{
		this.isFalling = true;
		for (float t = 0f; t < this.timeUntilFall; t += Time.fixedDeltaTime)
		{
			float f = -Mathf.Sin(t * 3.1415927f * 4f);
			float y = Mathf.Max(0f, Mathf.Abs(f) - t) * Mathf.Sign(f) * 0.15f;
			this.visual.transform.localPosition = new Vector3(0f, y, 0f);
			yield return new WaitForFixedUpdate();
		}
		if (this.rubbleEffect)
		{
			Object.Instantiate<GameObject>(this.rubbleEffect, this.rubbleSpawnPoint.position, Quaternion.identity);
		}
		if (!string.IsNullOrEmpty(this.fallSFX))
		{
			AudioManager.Play(this.fallSFX, AudioManager.MixerTarget.SFX, null, null);
		}
		if (this.animator != null)
		{
			this.animator.SetTrigger("Fall");
		}
		else
		{
			base.DisableEntity();
		}
		yield return new WaitForSeconds(this.timeUntilReset);
		this.TryEnable();
		yield break;
	}

	// Token: 0x0600059D RID: 1437 RVA: 0x00018BE8 File Offset: 0x00016DE8
	private void TryEnable()
	{
		if (CrashController.instance.controller.bounds.Intersects(this.collider.bounds))
		{
			base.StartCoroutine(this.TryEnableLater());
			return;
		}
		base.EnableEntity();
		this.isFalling = false;
		if (this.animator != null)
		{
			this.animator.SetTrigger("Reset");
		}
	}

	// Token: 0x0600059E RID: 1438 RVA: 0x00018C52 File Offset: 0x00016E52
	private IEnumerator TryEnableLater()
	{
		yield return new WaitForSeconds(1f);
		this.TryEnable();
		yield break;
	}

	// Token: 0x0600059F RID: 1439 RVA: 0x00018C61 File Offset: 0x00016E61
	public void TouchTop(CrashController crash)
	{
		this.TryFall();
	}

	// Token: 0x060005A0 RID: 1440 RVA: 0x00018C69 File Offset: 0x00016E69
	public void FallOn(CrashController crash)
	{
		this.TryFall();
	}

	// Token: 0x060005A1 RID: 1441 RVA: 0x00018C71 File Offset: 0x00016E71
	public void Slide(CrashController crash)
	{
		if (this.IsAbove(crash))
		{
			this.TryFall();
		}
	}

	// Token: 0x060005A2 RID: 1442 RVA: 0x00018C82 File Offset: 0x00016E82
	private void TryFall()
	{
		if (!this.isFalling)
		{
			base.StartCoroutine(this.Fall());
		}
	}

	// Token: 0x060005A3 RID: 1443 RVA: 0x00018C9C File Offset: 0x00016E9C
	protected bool IsAbove(CrashController crash)
	{
		return this.collider.ClosestPoint(crash.controller.ClosestPoint(this.collider.bounds.center)).y - this.collider.bounds.max.y >= 0f;
	}

	// Token: 0x040003F6 RID: 1014
	[HideInInspector]
	public Vector3 startingPos;

	// Token: 0x040003F7 RID: 1015
	public float timeUntilFall = 3f;

	// Token: 0x040003F8 RID: 1016
	public float timeUntilReset = 5f;

	// Token: 0x040003F9 RID: 1017
	private bool isFalling;

	// Token: 0x040003FA RID: 1018
	public GameObject rubbleEffect;

	// Token: 0x040003FB RID: 1019
	public Transform rubbleSpawnPoint;

	// Token: 0x040003FC RID: 1020
	public string fallSFX = "";

	// Token: 0x040003FD RID: 1021
	public Animator animator;
}
