﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

// Token: 0x020000DC RID: 220
[DefaultExecutionOrder(-300)]
public class AudioManager : MonoBehaviour
{
	// Token: 0x170000ED RID: 237
	// (get) Token: 0x06000666 RID: 1638 RVA: 0x0001BE05 File Offset: 0x0001A005
	public AudioSource MusicSource
	{
		get
		{
			return this.musicSources[(int)this.activeMusicSource];
		}
	}

	// Token: 0x170000EE RID: 238
	// (get) Token: 0x06000667 RID: 1639 RVA: 0x0001BE14 File Offset: 0x0001A014
	private static HashSet<AudioClip> SoundQueue { get; } = new HashSet<AudioClip>();

	// Token: 0x170000EF RID: 239
	// (get) Token: 0x06000668 RID: 1640 RVA: 0x0001BE1B File Offset: 0x0001A01B
	// (set) Token: 0x06000669 RID: 1641 RVA: 0x0001BE22 File Offset: 0x0001A022
	public static AudioManager Instance { get; private set; }

	// Token: 0x0600066A RID: 1642 RVA: 0x0001BE2A File Offset: 0x0001A02A
	private void Awake()
	{
		if (AudioManager.Instance == null)
		{
			AudioManager.Instance = this;
			Object.DontDestroyOnLoad(base.gameObject);
			this.InitBanks();
			return;
		}
		Object.Destroy(base.gameObject);
	}

	// Token: 0x0600066B RID: 1643 RVA: 0x0001BE5C File Offset: 0x0001A05C
	private void Start()
	{
		this.InitMixer();
		this.masterMixer.updateMode = AudioMixerUpdateMode.UnscaledTime;
	}

	// Token: 0x0600066C RID: 1644 RVA: 0x0001BE70 File Offset: 0x0001A070
	private void Update()
	{
		AudioManager.SetPitchByTimeScale();
	}

	// Token: 0x0600066D RID: 1645 RVA: 0x0001BE77 File Offset: 0x0001A077
	private void LateUpdate()
	{
		AudioManager.SoundQueue.Clear();
	}

	// Token: 0x0600066E RID: 1646 RVA: 0x0001BE83 File Offset: 0x0001A083
	private void InitBanks()
	{
		this.soundBank.Build();
		this.musicBank.Build();
	}

	// Token: 0x0600066F RID: 1647 RVA: 0x0001BE9B File Offset: 0x0001A09B
	private void InitMixer()
	{
		this.SetMixerFromPref(AudioManager.mainVolumeParam);
		this.SetMixerFromPref(AudioManager.musicVolumeParam);
		this.SetMixerFromPref(AudioManager.sfxVolumeParam);
		this.SetMixerFromPref(AudioManager.uiVolumeParam);
	}

	// Token: 0x06000670 RID: 1648 RVA: 0x0001BEC9 File Offset: 0x0001A0C9
	public static float ToDecibels(float value)
	{
		if (value == 0f)
		{
			return -80f;
		}
		return Mathf.Log10(value) * 20f;
	}

	// Token: 0x06000671 RID: 1649 RVA: 0x0001BEE5 File Offset: 0x0001A0E5
	public static float FromDecibels(float db)
	{
		if (db == -80f)
		{
			return 0f;
		}
		return Mathf.Pow(10f, db / 20f);
	}

	// Token: 0x06000672 RID: 1650 RVA: 0x0001BF08 File Offset: 0x0001A108
	public static float GetFloatNormalized(string param)
	{
		float db;
		if (AudioManager.Instance.masterMixer.GetFloat(param, out db))
		{
			return AudioManager.FromDecibels(db);
		}
		return -1f;
	}

	// Token: 0x06000673 RID: 1651 RVA: 0x0001BF38 File Offset: 0x0001A138
	public static void Snapshot(string name, float duration = 0f)
	{
		if (string.IsNullOrWhiteSpace(name))
		{
			AudioManager.Instance.defaultSnapshot.TransitionTo(duration);
			return;
		}
		try
		{
			AudioManager.Instance.masterMixer.FindSnapshot(name).TransitionTo(duration);
		}
		catch
		{
			Debug.LogWarning("Failed to transition to snapshot \"" + name + "\"");
		}
	}

	// Token: 0x06000674 RID: 1652 RVA: 0x0001BFA0 File Offset: 0x0001A1A0
	public static bool GetSoundClip(string clipName, out AudioClip audioClip)
	{
		if (!AudioManager.Instance || string.IsNullOrWhiteSpace(clipName))
		{
			audioClip = null;
			return false;
		}
		return AudioManager.Instance.soundBank.TryGetAudio(clipName, out audioClip);
	}

	// Token: 0x06000675 RID: 1653 RVA: 0x0001BFCC File Offset: 0x0001A1CC
	public static bool GetMusicClip(string clipName, out AudioClip audioClip)
	{
		if (!AudioManager.Instance || string.IsNullOrWhiteSpace(clipName))
		{
			audioClip = null;
			return false;
		}
		return AudioManager.Instance.musicBank.TryGetAudio(clipName, out audioClip);
	}

	// Token: 0x06000676 RID: 1654 RVA: 0x0001BFF8 File Offset: 0x0001A1F8
	public static bool HasMusic(string name)
	{
		AudioClip audioClip;
		return AudioManager.GetMusicClip(name, out audioClip);
	}

	// Token: 0x06000677 RID: 1655 RVA: 0x0001C010 File Offset: 0x0001A210
	public static AudioSource Play(string clip, AudioMixerGroup mixerTarget, Vector3? position = null, Vector2? disparity = null)
	{
		AudioClip audioClip;
		if (AudioManager.Instance.soundBank.TryGetAudio(clip, out audioClip))
		{
			if (position != null || !AudioManager.SoundQueue.Contains(audioClip))
			{
				AudioManager.SoundQueue.Add(audioClip);
				GameObject gameObject = new GameObject(clip, new Type[]
				{
					typeof(AudioDestroyer)
				});
				AudioSource audioSource = gameObject.AddComponent<AudioSource>();
				audioSource.bypassReverbZones = (mixerTarget == AudioManager.Instance.uiMixer);
				if (position != null)
				{
					gameObject.transform.position = position.Value;
					audioSource.spatialBlend = 1f;
					audioSource.rolloffMode = AudioRolloffMode.Linear;
					audioSource.maxDistance = 50f;
					audioSource.dopplerLevel = 0f;
				}
				if (disparity != null)
				{
					audioSource.pitch = Random.Range(disparity.Value.x, disparity.Value.y);
				}
				audioSource.clip = audioClip;
				audioSource.outputAudioMixerGroup = mixerTarget;
				audioSource.Play();
				return audioSource;
			}
		}
		else
		{
			Debug.LogWarning("AudioClip '" + clip + "' not present in audio bank");
		}
		return null;
	}

	// Token: 0x06000678 RID: 1656 RVA: 0x0001C12B File Offset: 0x0001A32B
	public static AudioSource Play(string clip, AudioManager.MixerTarget mixerTarget, Vector3? position = null, Vector2? disparity = null)
	{
		return AudioManager.Play(clip, AudioManager.Instance.GetMixerGroup(mixerTarget), position, disparity);
	}

	// Token: 0x06000679 RID: 1657 RVA: 0x0001C140 File Offset: 0x0001A340
	public static AudioSource Play(string clip, string mixerTarget, Vector3? position = null, Vector2? disparity = null)
	{
		return AudioManager.Play(clip, AudioManager.Instance.GetMixerGroup(mixerTarget), position, disparity);
	}

	// Token: 0x0600067A RID: 1658 RVA: 0x0001C155 File Offset: 0x0001A355
	public static AudioSource Play(string clip, Vector3? position = null, Vector2? disparity = null)
	{
		return AudioManager.Play(clip, AudioManager.MixerTarget.Default, position, disparity);
	}

	// Token: 0x0600067B RID: 1659 RVA: 0x0001C160 File Offset: 0x0001A360
	public static AudioSource PlayAndFollow(string clip, Transform target, AudioManager.MixerTarget mixerTarget)
	{
		AudioClip clip2;
		if (AudioManager.Instance.soundBank.TryGetAudio(clip, out clip2))
		{
			GameObject gameObject = new GameObject(clip, new Type[]
			{
				typeof(AudioDestroyer)
			});
			AudioSource audioSource = gameObject.AddComponent<AudioSource>();
			FollowTarget followTarget = gameObject.AddComponent<FollowTarget>();
			audioSource.bypassReverbZones = true;
			audioSource.spatialBlend = 1f;
			audioSource.rolloffMode = AudioRolloffMode.Linear;
			audioSource.maxDistance = 50f;
			audioSource.dopplerLevel = 0f;
			audioSource.clip = clip2;
			audioSource.outputAudioMixerGroup = AudioManager.Instance.GetMixerGroup(mixerTarget);
			followTarget.target = target;
			audioSource.Play();
			return audioSource;
		}
		Debug.LogWarning("AudioClip '" + clip + "' not present in audio bank");
		return null;
	}

	// Token: 0x0600067C RID: 1660 RVA: 0x0001C211 File Offset: 0x0001A411
	public static AudioSource PlayAndFollow(string clip, Transform target)
	{
		return AudioManager.PlayAndFollow(clip, target, AudioManager.MixerTarget.Default);
	}

	// Token: 0x0600067D RID: 1661 RVA: 0x0001C21C File Offset: 0x0001A41C
	public static void PlayMusic(string music, float fadeTime = 1f)
	{
		if (!string.IsNullOrEmpty(music))
		{
			AudioClip audioClip;
			if (AudioManager.Instance.musicBank.TryGetAudio(music, out audioClip))
			{
				if (AudioManager.Instance.MusicSource.isPlaying)
				{
					if (AudioManager.Instance.MusicSource.clip == audioClip)
					{
						return;
					}
					AudioManager.Instance.activeMusicSource = 1 - AudioManager.Instance.activeMusicSource;
				}
				AudioManager.Instance.MusicSource.clip = audioClip;
				AudioManager.Instance.MusicSource.Play();
				AudioManager.Instance.masterMixer.FindSnapshot(string.Format("Music Channel {0}", (int)(AudioManager.Instance.activeMusicSource + 1))).TransitionTo(fadeTime);
				return;
			}
			Debug.LogWarning("AudioClip '" + music + "' not present in music bank");
		}
	}

	// Token: 0x0600067E RID: 1662 RVA: 0x0001C2F0 File Offset: 0x0001A4F0
	public static void FadeOutMusic(float fadeTime = 1f)
	{
		AudioManager.Instance.activeMusicSource = 1 - AudioManager.Instance.activeMusicSource;
		AudioManager.Instance.MusicSource.Stop();
		AudioManager.Instance.masterMixer.FindSnapshot(string.Format("Music Channel {0}", (int)(AudioManager.Instance.activeMusicSource + 1))).TransitionTo(fadeTime);
	}

	// Token: 0x0600067F RID: 1663 RVA: 0x0001C354 File Offset: 0x0001A554
	public static void SwapMusic(float fadeTime = 1f)
	{
		AudioManager.Instance.activeMusicSource = 1 - AudioManager.Instance.activeMusicSource;
		AudioManager.Instance.masterMixer.FindSnapshot(string.Format("Music Channel {0}", (int)(AudioManager.Instance.activeMusicSource + 1))).TransitionTo(fadeTime);
	}

	// Token: 0x06000680 RID: 1664 RVA: 0x0001C3A8 File Offset: 0x0001A5A8
	public static void PlayMusic(params string[] musicOptions)
	{
		AudioManager.PlayMusic(musicOptions[Random.Range(0, musicOptions.Length)], 1f);
	}

	// Token: 0x06000681 RID: 1665 RVA: 0x0001C3C0 File Offset: 0x0001A5C0
	public static void PauseMusic()
	{
		AudioSource[] array = AudioManager.Instance.musicSources;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].Pause();
		}
	}

	// Token: 0x06000682 RID: 1666 RVA: 0x0001C3F0 File Offset: 0x0001A5F0
	public static void UnpauseMusic()
	{
		AudioSource[] array = AudioManager.Instance.musicSources;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].UnPause();
		}
	}

	// Token: 0x06000683 RID: 1667 RVA: 0x0001C420 File Offset: 0x0001A620
	public static void PitchPauseMusic()
	{
		AudioSource[] array = AudioManager.Instance.musicSources;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].pitch = 0f;
		}
	}

	// Token: 0x06000684 RID: 1668 RVA: 0x0001C454 File Offset: 0x0001A654
	public static void PitchUnpauseMusic()
	{
		foreach (AudioSource audioSource in AudioManager.Instance.musicSources)
		{
			if (audioSource)
			{
				audioSource.pitch = 1f;
			}
		}
	}

	// Token: 0x06000685 RID: 1669 RVA: 0x0001C494 File Offset: 0x0001A694
	public static void StopMusic()
	{
		foreach (AudioSource audioSource in AudioManager.Instance.musicSources)
		{
			audioSource.Stop();
			audioSource.clip = null;
		}
		AudioManager.Instance.activeMusicSource = 0;
	}

	// Token: 0x06000686 RID: 1670 RVA: 0x0001C4D4 File Offset: 0x0001A6D4
	public static void SetVolumeMaster(float value)
	{
		AudioManager.Instance.masterMixer.SetFloat(AudioManager.mainVolumeParam, AudioManager.ToDecibels(value));
		AudioManager.SetPref(AudioManager.mainVolumeParam, value);
	}

	// Token: 0x06000687 RID: 1671 RVA: 0x0001C4FC File Offset: 0x0001A6FC
	public static void SetVolumeSFX(float value)
	{
		AudioManager.Instance.masterMixer.SetFloat(AudioManager.sfxVolumeParam, AudioManager.ToDecibels(value));
		AudioManager.SetPref(AudioManager.sfxVolumeParam, value);
		AudioManager.SetVolumeUI(value);
	}

	// Token: 0x06000688 RID: 1672 RVA: 0x0001C52A File Offset: 0x0001A72A
	public static void SetVolumeUI(float value)
	{
		AudioManager.Instance.masterMixer.SetFloat(AudioManager.uiVolumeParam, AudioManager.ToDecibels(value));
		AudioManager.SetPref(AudioManager.uiVolumeParam, value);
	}

	// Token: 0x06000689 RID: 1673 RVA: 0x0001C552 File Offset: 0x0001A752
	public static void SetVolumeMusic(float value)
	{
		AudioManager.Instance.masterMixer.SetFloat(AudioManager.musicVolumeParam, AudioManager.ToDecibels(value));
		AudioManager.SetPref(AudioManager.musicVolumeParam, value);
	}

	// Token: 0x0600068A RID: 1674 RVA: 0x0001C57A File Offset: 0x0001A77A
	private static float GetPref(string pref)
	{
		return PlayerPrefs.GetFloat(pref, 0.5f);
	}

	// Token: 0x0600068B RID: 1675 RVA: 0x0001C587 File Offset: 0x0001A787
	private static void SetPref(string pref, float val)
	{
		PlayerPrefs.SetFloat(pref, val);
	}

	// Token: 0x0600068C RID: 1676 RVA: 0x0001C590 File Offset: 0x0001A790
	private void SetMixerFromPref(string pref)
	{
		this.masterMixer.SetFloat(pref, AudioManager.ToDecibels(AudioManager.GetPref(pref)));
	}

	// Token: 0x0600068D RID: 1677 RVA: 0x0001C5AA File Offset: 0x0001A7AA
	private static void SetPitchByTimeScale()
	{
		AudioManager.Instance.masterMixer.SetFloat("SFXPitch", Time.timeScale);
	}

	// Token: 0x0600068E RID: 1678 RVA: 0x0001C5C6 File Offset: 0x0001A7C6
	private AudioMixerGroup DefaultMixerGroup()
	{
		return this.GetMixerGroup((AudioManager.MixerTarget)AudioManager.Instance.defaultMixer);
	}

	// Token: 0x0600068F RID: 1679 RVA: 0x0001C5D8 File Offset: 0x0001A7D8
	private AudioMixerGroup GetMixerGroup(AudioManager.MixerTarget target)
	{
		if (target == AudioManager.MixerTarget.None)
		{
			return null;
		}
		if (target == AudioManager.MixerTarget.Default)
		{
			return this.GetMixerGroup((AudioManager.MixerTarget)this.defaultMixer);
		}
		if (target == AudioManager.MixerTarget.SFX)
		{
			return this.sfxMixer;
		}
		if (target == AudioManager.MixerTarget.UI)
		{
			return this.uiMixer;
		}
		if (target == AudioManager.MixerTarget.Music)
		{
			return this.musicMixer;
		}
		throw new Exception("Invalid MixerTarget");
	}

	// Token: 0x06000690 RID: 1680 RVA: 0x0001C628 File Offset: 0x0001A828
	private AudioMixerGroup GetMixerGroup(string target)
	{
		AudioMixerGroup[] array = this.masterMixer.FindMatchingGroups(target);
		if (array.Length != 0)
		{
			return array[0];
		}
		throw new Exception("No mixer group by the name " + target + " could be found");
	}

	// Token: 0x040004BE RID: 1214
	public AudioSource[] musicSources;

	// Token: 0x040004BF RID: 1215
	public byte activeMusicSource;

	// Token: 0x040004C0 RID: 1216
	public AudioMixer masterMixer;

	// Token: 0x040004C1 RID: 1217
	public AudioMixerGroup sfxMixer;

	// Token: 0x040004C2 RID: 1218
	public AudioMixerGroup uiMixer;

	// Token: 0x040004C3 RID: 1219
	public AudioMixerGroup musicMixer;

	// Token: 0x040004C4 RID: 1220
	public AudioManager.DefaultMixerTarget defaultMixer;

	// Token: 0x040004C5 RID: 1221
	public AudioMixerSnapshot defaultSnapshot;

	// Token: 0x040004C6 RID: 1222
	public AudioHighPassFilter musicHighpass;

	// Token: 0x040004C7 RID: 1223
	public static readonly string mainVolumeParam = "Volume";

	// Token: 0x040004C8 RID: 1224
	public static readonly string sfxVolumeParam = "SFXVol";

	// Token: 0x040004C9 RID: 1225
	public static readonly string uiVolumeParam = "UIVol";

	// Token: 0x040004CA RID: 1226
	public static readonly string musicVolumeParam = "MusicVol";

	// Token: 0x040004CB RID: 1227
	[SerializeField]
	private AudioManager.AudioBank soundBank;

	// Token: 0x040004CC RID: 1228
	[SerializeField]
	private AudioManager.AudioBank musicBank;

	// Token: 0x02000218 RID: 536
	public enum MixerTarget
	{
		// Token: 0x04000D06 RID: 3334
		None,
		// Token: 0x04000D07 RID: 3335
		Default,
		// Token: 0x04000D08 RID: 3336
		SFX,
		// Token: 0x04000D09 RID: 3337
		UI,
		// Token: 0x04000D0A RID: 3338
		Music
	}

	// Token: 0x02000219 RID: 537
	public enum DefaultMixerTarget
	{
		// Token: 0x04000D0C RID: 3340
		None,
		// Token: 0x04000D0D RID: 3341
		SFX = 2,
		// Token: 0x04000D0E RID: 3342
		UI
	}

	// Token: 0x0200021A RID: 538
	[Serializable]
	public class BankKVP
	{
		// Token: 0x04000D0F RID: 3343
		public string Key;

		// Token: 0x04000D10 RID: 3344
		public AudioClip Value;
	}

	// Token: 0x0200021B RID: 539
	[Serializable]
	public class AudioBank
	{
		// Token: 0x0600135E RID: 4958 RVA: 0x00044D48 File Offset: 0x00042F48
		public bool Validate()
		{
			if (this.kvps.Length == 0)
			{
				return false;
			}
			List<string> list = new List<string>();
			foreach (AudioManager.BankKVP bankKVP in this.kvps)
			{
				if (list.Contains(bankKVP.Key))
				{
					return false;
				}
				list.Add(bankKVP.Key);
			}
			return true;
		}

		// Token: 0x0600135F RID: 4959 RVA: 0x00044D9C File Offset: 0x00042F9C
		public void Build()
		{
			if (this.Validate())
			{
				for (int i = 0; i < this.kvps.Length; i++)
				{
					this.dictionary.Add(this.kvps[i].Key, this.kvps[i].Value);
				}
			}
		}

		// Token: 0x06001360 RID: 4960 RVA: 0x00044DE9 File Offset: 0x00042FE9
		public bool TryGetAudio(string key, out AudioClip audio)
		{
			return this.dictionary.TryGetValue(key, out audio);
		}

		// Token: 0x04000D11 RID: 3345
		[SerializeField]
		private AudioManager.BankKVP[] kvps;

		// Token: 0x04000D12 RID: 3346
		private readonly Dictionary<string, AudioClip> dictionary = new Dictionary<string, AudioClip>();
	}
}
