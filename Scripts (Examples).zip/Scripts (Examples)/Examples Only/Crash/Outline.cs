﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

// Token: 0x02000046 RID: 70
[DisallowMultipleComponent]
public class Outline : MonoBehaviour
{
	// Token: 0x17000063 RID: 99
	// (get) Token: 0x060001D2 RID: 466 RVA: 0x00008570 File Offset: 0x00006770
	// (set) Token: 0x060001D3 RID: 467 RVA: 0x00008578 File Offset: 0x00006778
	public Outline.Mode OutlineMode
	{
		get
		{
			return this.outlineMode;
		}
		set
		{
			this.outlineMode = value;
			this.needsUpdate = true;
		}
	}

	// Token: 0x17000064 RID: 100
	// (get) Token: 0x060001D4 RID: 468 RVA: 0x00008588 File Offset: 0x00006788
	// (set) Token: 0x060001D5 RID: 469 RVA: 0x00008590 File Offset: 0x00006790
	public Color OutlineColor
	{
		get
		{
			return this.outlineColor;
		}
		set
		{
			this.outlineColor = value;
			this.needsUpdate = true;
		}
	}

	// Token: 0x17000065 RID: 101
	// (get) Token: 0x060001D6 RID: 470 RVA: 0x000085A0 File Offset: 0x000067A0
	// (set) Token: 0x060001D7 RID: 471 RVA: 0x000085A8 File Offset: 0x000067A8
	public float OutlineWidth
	{
		get
		{
			return this.outlineWidth;
		}
		set
		{
			this.outlineWidth = value;
			this.needsUpdate = true;
		}
	}

	// Token: 0x060001D8 RID: 472 RVA: 0x000085B8 File Offset: 0x000067B8
	private void Awake()
	{
		this.renderers = base.GetComponentsInChildren<Renderer>();
		this.outlineMaskMaterial = Object.Instantiate<Material>(Resources.Load<Material>("Materials/OutlineMask"));
		this.outlineFillMaterial = Object.Instantiate<Material>(Resources.Load<Material>("Materials/OutlineFill"));
		this.outlineMaskMaterial.name = "OutlineMask (Instance)";
		this.outlineFillMaterial.name = "OutlineFill (Instance)";
		this.LoadSmoothNormals();
		this.needsUpdate = true;
	}

	// Token: 0x060001D9 RID: 473 RVA: 0x00008628 File Offset: 0x00006828
	private void OnEnable()
	{
		foreach (Renderer renderer in this.renderers)
		{
			List<Material> list = renderer.sharedMaterials.ToList<Material>();
			list.Add(this.outlineMaskMaterial);
			list.Add(this.outlineFillMaterial);
			renderer.materials = list.ToArray();
		}
	}

	// Token: 0x060001DA RID: 474 RVA: 0x0000867C File Offset: 0x0000687C
	private void OnValidate()
	{
		this.needsUpdate = true;
		if ((!this.precomputeOutline && this.bakeKeys.Count != 0) || this.bakeKeys.Count != this.bakeValues.Count)
		{
			this.bakeKeys.Clear();
			this.bakeValues.Clear();
		}
		if (this.precomputeOutline && this.bakeKeys.Count == 0)
		{
			this.Bake();
		}
	}

	// Token: 0x060001DB RID: 475 RVA: 0x000086EE File Offset: 0x000068EE
	private void Update()
	{
		if (this.needsUpdate)
		{
			this.needsUpdate = false;
			this.UpdateMaterialProperties();
		}
	}

	// Token: 0x060001DC RID: 476 RVA: 0x00008708 File Offset: 0x00006908
	private void OnDisable()
	{
		foreach (Renderer renderer in this.renderers)
		{
			List<Material> list = renderer.sharedMaterials.ToList<Material>();
			list.Remove(this.outlineMaskMaterial);
			list.Remove(this.outlineFillMaterial);
			renderer.materials = list.ToArray();
		}
	}

	// Token: 0x060001DD RID: 477 RVA: 0x0000875E File Offset: 0x0000695E
	private void OnDestroy()
	{
		Object.Destroy(this.outlineMaskMaterial);
		Object.Destroy(this.outlineFillMaterial);
	}

	// Token: 0x060001DE RID: 478 RVA: 0x00008778 File Offset: 0x00006978
	private void Bake()
	{
		HashSet<Mesh> hashSet = new HashSet<Mesh>();
		foreach (MeshFilter meshFilter in base.GetComponentsInChildren<MeshFilter>())
		{
			if (hashSet.Add(meshFilter.sharedMesh))
			{
				List<Vector3> data = this.SmoothNormals(meshFilter.sharedMesh);
				this.bakeKeys.Add(meshFilter.sharedMesh);
				this.bakeValues.Add(new Outline.ListVector3
				{
					data = data
				});
			}
		}
	}

	// Token: 0x060001DF RID: 479 RVA: 0x000087EC File Offset: 0x000069EC
	private void LoadSmoothNormals()
	{
		foreach (MeshFilter meshFilter in base.GetComponentsInChildren<MeshFilter>())
		{
			if (Outline.registeredMeshes.Add(meshFilter.sharedMesh))
			{
				int num = this.bakeKeys.IndexOf(meshFilter.sharedMesh);
				List<Vector3> uvs = (num >= 0) ? this.bakeValues[num].data : this.SmoothNormals(meshFilter.sharedMesh);
				meshFilter.sharedMesh.SetUVs(3, uvs);
				Renderer component = meshFilter.GetComponent<Renderer>();
				if (component != null)
				{
					this.CombineSubmeshes(meshFilter.sharedMesh, component.sharedMaterials);
				}
			}
		}
		foreach (SkinnedMeshRenderer skinnedMeshRenderer in base.GetComponentsInChildren<SkinnedMeshRenderer>())
		{
			if (Outline.registeredMeshes.Add(skinnedMeshRenderer.sharedMesh))
			{
				skinnedMeshRenderer.sharedMesh.uv4 = new Vector2[skinnedMeshRenderer.sharedMesh.vertexCount];
				this.CombineSubmeshes(skinnedMeshRenderer.sharedMesh, skinnedMeshRenderer.sharedMaterials);
			}
		}
	}

	// Token: 0x060001E0 RID: 480 RVA: 0x000088F8 File Offset: 0x00006AF8
	private List<Vector3> SmoothNormals(Mesh mesh)
	{
		IEnumerable<IGrouping<Vector3, KeyValuePair<Vector3, int>>> enumerable = from pair in mesh.vertices.Select((Vector3 vertex, int index) => new KeyValuePair<Vector3, int>(vertex, index))
		group pair by pair.Key;
		List<Vector3> list = new List<Vector3>(mesh.normals);
		foreach (IGrouping<Vector3, KeyValuePair<Vector3, int>> grouping in enumerable)
		{
			if (grouping.Count<KeyValuePair<Vector3, int>>() != 1)
			{
				Vector3 vector = Vector3.zero;
				foreach (KeyValuePair<Vector3, int> keyValuePair in grouping)
				{
					if (keyValuePair.Value < 0 || keyValuePair.Value >= list.Count)
					{
						Debug.LogWarning(string.Format("SmoothNormals anomaly for {0} ({1})\nsmoothNormals.Count is {2}, requested index {3}", new object[]
						{
							base.gameObject.name,
							mesh.name,
							list.Count,
							keyValuePair.Value
						}));
					}
					else
					{
						vector += list[keyValuePair.Value];
					}
				}
				vector.Normalize();
				foreach (KeyValuePair<Vector3, int> keyValuePair2 in grouping)
				{
					list[keyValuePair2.Value] = vector;
				}
			}
		}
		return list;
	}

	// Token: 0x060001E1 RID: 481 RVA: 0x00008AD0 File Offset: 0x00006CD0
	private void CombineSubmeshes(Mesh mesh, Material[] materials)
	{
		if (mesh.subMeshCount == 1)
		{
			return;
		}
		if (mesh.subMeshCount > materials.Length)
		{
			return;
		}
		int subMeshCount = mesh.subMeshCount;
		mesh.subMeshCount = subMeshCount + 1;
		mesh.SetTriangles(mesh.triangles, mesh.subMeshCount - 1);
	}

	// Token: 0x060001E2 RID: 482 RVA: 0x00008B18 File Offset: 0x00006D18
	private void UpdateMaterialProperties()
	{
		this.outlineFillMaterial.renderQueue = this.renderQueue + 10;
		this.outlineMaskMaterial.renderQueue = this.renderQueue;
		this.outlineFillMaterial.SetColor("_OutlineColor", this.outlineColor);
		switch (this.outlineMode)
		{
		case Outline.Mode.OutlineAll:
			this.outlineMaskMaterial.SetFloat("_ZTest", 8f);
			this.outlineFillMaterial.SetFloat("_ZTest", 8f);
			this.outlineFillMaterial.SetFloat("_OutlineWidth", this.outlineWidth);
			return;
		case Outline.Mode.OutlineVisible:
			this.outlineMaskMaterial.SetFloat("_ZTest", 8f);
			this.outlineFillMaterial.SetFloat("_ZTest", 4f);
			this.outlineFillMaterial.SetFloat("_OutlineWidth", this.outlineWidth);
			return;
		case Outline.Mode.OutlineHidden:
			this.outlineMaskMaterial.SetFloat("_ZTest", 8f);
			this.outlineFillMaterial.SetFloat("_ZTest", 5f);
			this.outlineFillMaterial.SetFloat("_OutlineWidth", this.outlineWidth);
			return;
		case Outline.Mode.OutlineAndSilhouette:
			this.outlineMaskMaterial.SetFloat("_ZTest", 4f);
			this.outlineFillMaterial.SetFloat("_ZTest", 8f);
			this.outlineFillMaterial.SetFloat("_OutlineWidth", this.outlineWidth);
			return;
		case Outline.Mode.SilhouetteOnly:
			this.outlineMaskMaterial.SetFloat("_ZTest", 4f);
			this.outlineFillMaterial.SetFloat("_ZTest", 5f);
			this.outlineFillMaterial.SetFloat("_OutlineWidth", 0f);
			return;
		default:
			return;
		}
	}

	// Token: 0x040000F8 RID: 248
	private static HashSet<Mesh> registeredMeshes = new HashSet<Mesh>();

	// Token: 0x040000F9 RID: 249
	[SerializeField]
	private Outline.Mode outlineMode;

	// Token: 0x040000FA RID: 250
	[SerializeField]
	private Color outlineColor = Color.white;

	// Token: 0x040000FB RID: 251
	[SerializeField]
	[Range(0f, 10f)]
	private float outlineWidth = 2f;

	// Token: 0x040000FC RID: 252
	[SerializeField]
	private int renderQueue = 3100;

	// Token: 0x040000FD RID: 253
	[Header("Optional")]
	[SerializeField]
	[Tooltip("Precompute enabled: Per-vertex calculations are performed in the editor and serialized with the object. Precompute disabled: Per-vertex calculations are performed at runtime in Awake(). This may cause a pause for large meshes.")]
	private bool precomputeOutline;

	// Token: 0x040000FE RID: 254
	[SerializeField]
	[HideInInspector]
	private List<Mesh> bakeKeys = new List<Mesh>();

	// Token: 0x040000FF RID: 255
	[SerializeField]
	[HideInInspector]
	private List<Outline.ListVector3> bakeValues = new List<Outline.ListVector3>();

	// Token: 0x04000100 RID: 256
	private Renderer[] renderers;

	// Token: 0x04000101 RID: 257
	private Material outlineMaskMaterial;

	// Token: 0x04000102 RID: 258
	private Material outlineFillMaterial;

	// Token: 0x04000103 RID: 259
	private bool needsUpdate;

	// Token: 0x020001DD RID: 477
	public enum Mode
	{
		// Token: 0x04000C4E RID: 3150
		OutlineAll,
		// Token: 0x04000C4F RID: 3151
		OutlineVisible,
		// Token: 0x04000C50 RID: 3152
		OutlineHidden,
		// Token: 0x04000C51 RID: 3153
		OutlineAndSilhouette,
		// Token: 0x04000C52 RID: 3154
		SilhouetteOnly
	}

	// Token: 0x020001DE RID: 478
	[Serializable]
	private class ListVector3
	{
		// Token: 0x04000C53 RID: 3155
		public List<Vector3> data;
	}
}
