﻿using System;

// Token: 0x0200001C RID: 28
public interface IMetadataReceiver<T> where T : ObjectMetadata
{
	// Token: 0x06000075 RID: 117
	void ProcessMetadata(T meta);
}
