﻿using System;
using UnityEngine;

// Token: 0x02000131 RID: 305
public class SwingingHazard : MonoBehaviour
{
	// Token: 0x06000909 RID: 2313 RVA: 0x0002564B File Offset: 0x0002384B
	private void Start()
	{
		this.yaw = base.transform.localEulerAngles.y;
	}

	// Token: 0x0600090A RID: 2314 RVA: 0x00025664 File Offset: 0x00023864
	private void FixedUpdate()
	{
		float timeSinceLevelLoad = Time.timeSinceLevelLoad;
		base.transform.localRotation = Quaternion.Euler(0f, this.yaw, this.curve.Evaluate(timeSinceLevelLoad * this.frequency + this.offset) * this.amplitude);
	}

	// Token: 0x0600090B RID: 2315 RVA: 0x000256B4 File Offset: 0x000238B4
	private void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (other.gameObject.TryGetComponent<CrashController>(out crashController))
		{
			crashController.TakeDamage(0);
		}
	}

	// Token: 0x040006A5 RID: 1701
	public AnimationCurve curve;

	// Token: 0x040006A6 RID: 1702
	public float frequency = 1f;

	// Token: 0x040006A7 RID: 1703
	public float amplitude = 1f;

	// Token: 0x040006A8 RID: 1704
	public float offset;

	// Token: 0x040006A9 RID: 1705
	private float yaw;
}
