﻿using System;
using UnityEngine;

// Token: 0x02000130 RID: 304
public class SurveilanceRobotVisual : MonoBehaviour
{
	// Token: 0x06000907 RID: 2311 RVA: 0x00025588 File Offset: 0x00023788
	private void Update()
	{
		if (!this.ren.isVisible)
		{
			return;
		}
		float num = Mathf.PerlinNoise(Time.timeSinceLevelLoad, (float)base.GetInstanceID());
		this.ren.SetBlendShapeWeight(0, num * 100f);
		Quaternion b = Quaternion.LookRotation(CrashController.instance.controller.bounds.center - base.transform.position - Vector3.forward, Vector3.back);
		base.transform.rotation = Quaternion.Slerp(base.transform.rotation, b, 1f - Mathf.Exp(-this.lookSpeed * Time.deltaTime));
	}

	// Token: 0x040006A3 RID: 1699
	[SerializeField]
	private SkinnedMeshRenderer ren;

	// Token: 0x040006A4 RID: 1700
	[SerializeField]
	private float lookSpeed = 1f;
}
