﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200008A RID: 138
public class CrashAnimator : MonoBehaviour
{
	// Token: 0x1700009B RID: 155
	// (get) Token: 0x060003CD RID: 973 RVA: 0x0000FDB8 File Offset: 0x0000DFB8
	// (set) Token: 0x060003CE RID: 974 RVA: 0x0000FDC5 File Offset: 0x0000DFC5
	public static int Skin
	{
		get
		{
			return PlayerPrefs.GetInt("PlayerSkin", 0);
		}
		set
		{
			PlayerPrefs.SetInt("PlayerSkin", value);
			if (CrashController.instance)
			{
				CrashController.instance.animator.SetSkin(value);
				CrashController.instance.audio.SetSkin(value);
			}
		}
	}

	// Token: 0x1700009C RID: 156
	// (get) Token: 0x060003CF RID: 975 RVA: 0x0000FDFE File Offset: 0x0000DFFE
	public CrashController Controller
	{
		get
		{
			if (this._controller == null)
			{
				this._controller = base.GetComponentInParent<CrashController>();
			}
			return this._controller;
		}
	}

	// Token: 0x1700009D RID: 157
	// (get) Token: 0x060003D0 RID: 976 RVA: 0x0000FE20 File Offset: 0x0000E020
	// (set) Token: 0x060003D1 RID: 977 RVA: 0x0000FE28 File Offset: 0x0000E028
	public GameObject RunObj { get; private set; }

	// Token: 0x060003D2 RID: 978 RVA: 0x0000FE31 File Offset: 0x0000E031
	public IEnumerable<GameObject> AnimationObjects()
	{
		yield return this.idleObj;
		yield return this.walkObj;
		yield return this.runObj;
		yield return this.runBoulderObj;
		yield return this.spinObj;
		yield return this.jumpObj;
		yield return this.jumpPeakObj;
		yield return this.jumpFlipObj;
		yield return this.jumpHighObj;
		yield return this.landObj;
		yield return this.ukaJumpObj;
		yield return this.slamStartObj;
		yield return this.slamImpactObj;
		yield return this.slamToStandObj;
		yield return this.crouchObj;
		yield return this.crawlObj;
		yield return this.slideObj;
		yield return this.slipObj;
		yield return this.slipWalkObj;
		yield return this.elevatorObj;
		yield return this.deadState;
		yield return this.warpInObj;
		yield return this.warpOutObj;
		yield return this.wearAkuObj;
		yield return this.levelWarpObj;
		yield return this.levelWarpOrbObj;
		yield return this.asleepObj;
		yield return this.wakeUpObj;
		yield break;
	}

	// Token: 0x1700009E RID: 158
	// (get) Token: 0x060003D3 RID: 979 RVA: 0x0000FE41 File Offset: 0x0000E041
	// (set) Token: 0x060003D4 RID: 980 RVA: 0x0000FE49 File Offset: 0x0000E049
	public GameObject previousState { get; private set; }

	// Token: 0x1700009F RID: 159
	// (get) Token: 0x060003D5 RID: 981 RVA: 0x0000FE52 File Offset: 0x0000E052
	// (set) Token: 0x060003D6 RID: 982 RVA: 0x0000FE5A File Offset: 0x0000E05A
	public GameObject currentState { get; private set; }

	// Token: 0x170000A0 RID: 160
	// (get) Token: 0x060003D7 RID: 983 RVA: 0x0000FE63 File Offset: 0x0000E063
	public float TimeSinceStateChanged
	{
		get
		{
			return Time.time - this.tCurrentState;
		}
	}

	// Token: 0x060003D8 RID: 984 RVA: 0x0000FE71 File Offset: 0x0000E071
	private void Awake()
	{
		this.currentState = base.GetComponentInChildren<AnimationSegment>(false).gameObject;
		this.RunObj = this.runObj;
		this.SetSkin(CrashAnimator.Skin);
	}

	// Token: 0x060003D9 RID: 985 RVA: 0x0000FE9C File Offset: 0x0000E09C
	public void SetRunMode(bool boulder)
	{
		bool activeSelf = this.RunObj.activeSelf;
		if (activeSelf)
		{
			this.RunObj.SetActive(false);
		}
		this.RunObj = (boulder ? this.runBoulderObj : this.runObj);
		if (activeSelf)
		{
			this.RunObj.SetActive(true);
		}
	}

	// Token: 0x060003DA RID: 986 RVA: 0x0000FEE8 File Offset: 0x0000E0E8
	public void SetSkin(int index)
	{
		foreach (GameObject gameObject in this.AnimationObjects())
		{
			if (gameObject.transform.childCount != 0)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					gameObject.transform.GetChild(i).gameObject.SetActive(i == index);
				}
			}
		}
	}

	// Token: 0x060003DB RID: 987 RVA: 0x0000FF6C File Offset: 0x0000E16C
	public void SetState(GameObject state, bool allowSelf = false)
	{
		if (state == this.idleObj && this.Controller.IsStandingObstructed())
		{
			state = this.crawlObj;
		}
		if (state != this.currentState || allowSelf)
		{
			this.tCurrentState = Time.time;
			foreach (GameObject gameObject in this.AnimationObjects())
			{
				gameObject.SetActive(false);
			}
			state.SetActive(true);
			this.previousState = this.currentState;
			this.currentState = state;
		}
	}

	// Token: 0x04000281 RID: 641
	private CrashController _controller;

	// Token: 0x04000282 RID: 642
	public GameObject idleObj;

	// Token: 0x04000283 RID: 643
	public GameObject walkObj;

	// Token: 0x04000284 RID: 644
	public GameObject runObj;

	// Token: 0x04000285 RID: 645
	public GameObject runBoulderObj;

	// Token: 0x04000287 RID: 647
	public GameObject spinObj;

	// Token: 0x04000288 RID: 648
	public GameObject jumpObj;

	// Token: 0x04000289 RID: 649
	public GameObject jumpPeakObj;

	// Token: 0x0400028A RID: 650
	public GameObject jumpFlipObj;

	// Token: 0x0400028B RID: 651
	public GameObject jumpHighObj;

	// Token: 0x0400028C RID: 652
	public GameObject landObj;

	// Token: 0x0400028D RID: 653
	public GameObject ukaJumpObj;

	// Token: 0x0400028E RID: 654
	public GameObject slamStartObj;

	// Token: 0x0400028F RID: 655
	public GameObject slamImpactObj;

	// Token: 0x04000290 RID: 656
	public GameObject slamToStandObj;

	// Token: 0x04000291 RID: 657
	public GameObject crouchObj;

	// Token: 0x04000292 RID: 658
	public GameObject crawlObj;

	// Token: 0x04000293 RID: 659
	public GameObject slideObj;

	// Token: 0x04000294 RID: 660
	public GameObject slipObj;

	// Token: 0x04000295 RID: 661
	public GameObject slipWalkObj;

	// Token: 0x04000296 RID: 662
	public GameObject elevatorObj;

	// Token: 0x04000297 RID: 663
	public AnimationSegment elevatorAnim;

	// Token: 0x04000298 RID: 664
	public GameObject deadState;

	// Token: 0x04000299 RID: 665
	public GameObject warpInObj;

	// Token: 0x0400029A RID: 666
	public GameObject warpOutObj;

	// Token: 0x0400029B RID: 667
	public GameObject wearAkuObj;

	// Token: 0x0400029C RID: 668
	public GameObject levelWarpObj;

	// Token: 0x0400029D RID: 669
	public GameObject levelWarpOrbObj;

	// Token: 0x0400029E RID: 670
	public GameObject asleepObj;

	// Token: 0x0400029F RID: 671
	public GameObject wakeUpObj;

	// Token: 0x040002A2 RID: 674
	private float tCurrentState;
}
