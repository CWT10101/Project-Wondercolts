﻿using System;
using UnityEngine;

// Token: 0x0200011A RID: 282
public class SlipCollider : MonoBehaviour
{
	// Token: 0x06000898 RID: 2200 RVA: 0x00023E94 File Offset: 0x00022094
	private void Start()
	{
	}
}
