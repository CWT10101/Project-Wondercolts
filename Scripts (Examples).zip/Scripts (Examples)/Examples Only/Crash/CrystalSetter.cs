﻿using System;
using UnityEngine;

// Token: 0x02000090 RID: 144
public class CrystalSetter : PickupSetter
{
	// Token: 0x170000B7 RID: 183
	// (get) Token: 0x06000458 RID: 1112 RVA: 0x00013FB7 File Offset: 0x000121B7
	public override Pickup Pickup
	{
		get
		{
			return this.crystal;
		}
	}

	// Token: 0x170000B8 RID: 184
	// (get) Token: 0x06000459 RID: 1113 RVA: 0x00013FBF File Offset: 0x000121BF
	// (set) Token: 0x0600045A RID: 1114 RVA: 0x00013FC7 File Offset: 0x000121C7
	public override bool Collected
	{
		get
		{
			return this.collected;
		}
		set
		{
			this.collected = value;
		}
	}

	// Token: 0x04000302 RID: 770
	[SerializeField]
	private CrystalPickup crystal;

	// Token: 0x04000303 RID: 771
	[SerializeField]
	private bool collected;
}
