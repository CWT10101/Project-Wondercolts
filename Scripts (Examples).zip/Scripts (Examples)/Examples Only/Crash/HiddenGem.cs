﻿using System;

// Token: 0x0200011F RID: 287
public class HiddenGem : SpecialGem
{
	// Token: 0x060008B9 RID: 2233 RVA: 0x00024605 File Offset: 0x00022805
	public override void Despawn()
	{
		base.Despawn();
		RedGemPlatform.OnGemCollected();
		GemLockBlock.OnGemCollected();
	}
}
