﻿using System;
using UnityEngine;

// Token: 0x02000041 RID: 65
public class ObjectRotate : MonoBehaviour
{
	// Token: 0x060001AF RID: 431 RVA: 0x0000773F File Offset: 0x0000593F
	private void Start()
	{
	}

	// Token: 0x060001B0 RID: 432 RVA: 0x00007741 File Offset: 0x00005941
	private void Update()
	{
		base.transform.Rotate(Vector3.one * Time.deltaTime * this.speed);
	}

	// Token: 0x040000C7 RID: 199
	public float speed = 20f;
}
