﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using TMPro;
using UnityEngine;

// Token: 0x02000107 RID: 263
public class ResolutionUI : MonoBehaviour
{
	// Token: 0x0600080C RID: 2060 RVA: 0x00021E7C File Offset: 0x0002007C
	private void Awake()
	{
		if (Application.platform == RuntimePlatform.WindowsPlayer || Application.platform == RuntimePlatform.WindowsEditor)
		{
			FullScreenMode[] array = new FullScreenMode[3];
			array[0] = FullScreenMode.Windowed;
			array[1] = FullScreenMode.FullScreenWindow;
			this.fullscreenModes = array;
		}
		else if (Application.platform == RuntimePlatform.OSXPlayer)
		{
			FullScreenMode[] array2 = new FullScreenMode[3];
			RuntimeHelpers.InitializeArray(array2, fieldof(<PrivateImplementationDetails>.DEC2809E6E374A6F8998DEF7721D410CA4D634F5B842BD3989C5CC94ED785DDB).FieldHandle);
			this.fullscreenModes = array2;
		}
		else
		{
			this.fullscreenModes = new FullScreenMode[]
			{
				FullScreenMode.Windowed,
				FullScreenMode.FullScreenWindow
			};
		}
		this.fullscreenModeDropdown.ClearOptions();
		this.fullscreenModeDropdown.AddOptions((from m in this.fullscreenModes
		select Regex.Replace(Enum.GetName(typeof(FullScreenMode), m).Replace("FullScreen", "Fullscreen"), "\\B[A-Z][a-z]+", " $&")).ToList<string>());
		int k;
		this.fullscreenModeDropdown.onValueChanged.AddListener(delegate(int i)
		{
			CameraManager.SetScreenMode(this.fullscreenModes[k]);
		});
		this.resolutions = Screen.resolutions.GroupBy((Resolution r) => string.Format("{0}/{1}", r.width, r.height), (Resolution r) => r, (string k, IEnumerable<Resolution> e) => e.First<Resolution>()).GroupBy((Resolution r) => MathUtil.Ratio(r), (Resolution r) => r, (string k, IEnumerable<Resolution> e) => e).SelectMany((IEnumerable<Resolution> r) => r).ToArray<Resolution>();
		this.resolutionDropdown.ClearOptions();
		this.resolutionDropdown.AddOptions((from r in this.resolutions
		select string.Format("{0}x{1} ({2})", r.width, r.height, MathUtil.Ratio(r))).ToList<string>());
		this.resolutionDropdown.onValueChanged.AddListener(delegate(int i)
		{
			Resolution resolution2 = this.resolutions[i];
			CameraManager.SetScreenResolution(resolution2.width, resolution2.height);
		});
		for (k = 0; k < this.fullscreenModes.Length; k++)
		{
			if (this.fullscreenModes[k] == Screen.fullScreenMode)
			{
				this.fullscreenModeDropdown.SetValueWithoutNotify(k);
				break;
			}
		}
		for (int j = 0; j < this.resolutions.Length; j++)
		{
			Resolution resolution = this.resolutions[j];
			if (resolution.width == Screen.width && resolution.height == Screen.height)
			{
				this.resolutionDropdown.SetValueWithoutNotify(j);
				return;
			}
		}
	}

	// Token: 0x040005E0 RID: 1504
	public TMP_Dropdown fullscreenModeDropdown;

	// Token: 0x040005E1 RID: 1505
	public TMP_Dropdown resolutionDropdown;

	// Token: 0x040005E2 RID: 1506
	private FullScreenMode[] fullscreenModes;

	// Token: 0x040005E3 RID: 1507
	private Resolution[] resolutions;
}
