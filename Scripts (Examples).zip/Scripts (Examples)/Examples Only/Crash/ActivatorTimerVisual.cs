﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000049 RID: 73
public class ActivatorTimerVisual : MonoBehaviour
{
	// Token: 0x060001F6 RID: 502 RVA: 0x0000900A File Offset: 0x0000720A
	public void SetFillAmount(float amount)
	{
		this.fill.fillAmount = amount;
	}

	// Token: 0x04000109 RID: 265
	public Image fill;
}
