﻿using System;
using UnityEngine;

// Token: 0x02000005 RID: 5
public class Aligner : MonoBehaviour
{
	// Token: 0x0600000D RID: 13 RVA: 0x0000247C File Offset: 0x0000067C
	private void OnValidate()
	{
		if (this.bakeMesh)
		{
			this.bakeMesh = false;
			if (this._mesh == null)
			{
				this._mesh = new Mesh();
			}
			this.skinnedTarget.BakeMesh(this._mesh);
			this.targetingMesh.sharedMesh = this._mesh;
			this.targetingMesh.sharedMesh.RecalculateBounds();
		}
		if (this.apply)
		{
			this.apply = false;
			Vector3 o = (this.rightReference.position + this.leftReference.position) / 2f;
			float size = Vector3.Distance(this.rightReference.position, this.leftReference.position) / 2f;
			Plane p = new Plane(this.rightReference.position, this.upReference.position, this.leftReference.position);
			this.DrawPlane(p, o, size, Color.green, 5f);
			Quaternion rotation = Quaternion.LookRotation(p.normal, this.flipped ? Vector3.down : Vector3.up);
			o = this.Average(new Vector3[]
			{
				this.rightReference.position,
				this.rightReference.position + rotation * Vector3.forward,
				this.rightReference.position + rotation * Vector3.right
			});
			this.DrawPoly(Color.red, 5f, new Vector3[]
			{
				this.rightReference.position,
				this.rightReference.position + rotation * Vector3.forward,
				this.rightReference.position + rotation * Vector3.right
			});
			Plane p2 = new Plane(this.rightReference.position, this.rightReference.position + rotation * Vector3.forward, this.rightReference.position + rotation * Vector3.right);
			this.DrawPlane(p2, o, size, Color.red, 5f);
			Ray ray = new Ray(this.upReference.position, rotation * Vector3.down);
			float distance;
			p2.Raycast(ray, out distance);
			Vector3 point = ray.GetPoint(distance);
			Debug.DrawLine(ray.origin, point, Color.white, 5f);
			base.transform.SetPositionAndRotation(point, rotation);
		}
	}

	// Token: 0x0600000E RID: 14 RVA: 0x00002720 File Offset: 0x00000920
	private void DrawPlane(Plane p, Vector3 o, float size, Color c, float duration)
	{
		Quaternion rotation = Quaternion.LookRotation(p.normal);
		Vector3 b = rotation * Vector3.right * size;
		Vector3 b2 = rotation * Vector3.up * size;
		Debug.DrawLine(o + b + b2, o + b - b2, c, duration);
		Debug.DrawLine(o + b - b2, o - b - b2, c, duration);
		Debug.DrawLine(o - b - b2, o - b + b2, c, duration);
		Debug.DrawLine(o - b + b2, o + b + b2, c, duration);
	}

	// Token: 0x0600000F RID: 15 RVA: 0x000027E8 File Offset: 0x000009E8
	private void DrawPoly(Color c, float duration, params Vector3[] p)
	{
		for (int i = 0; i < p.Length; i++)
		{
			Vector3 start = p[i];
			Vector3 end = (i == p.Length - 1) ? p[0] : p[i + 1];
			Debug.DrawLine(start, end, c, duration);
		}
	}

	// Token: 0x06000010 RID: 16 RVA: 0x00002830 File Offset: 0x00000A30
	private Vector3 Average(params Vector3[] p)
	{
		float num = 0f;
		float num2 = 0f;
		float num3 = 0f;
		foreach (Vector3 vector in p)
		{
			num += vector.x;
			num2 += vector.y;
			num3 += vector.z;
		}
		num /= (float)p.Length;
		num2 /= (float)p.Length;
		num3 /= (float)p.Length;
		return new Vector3(num, num2, num3);
	}

	// Token: 0x0400000A RID: 10
	public Transform upReference;

	// Token: 0x0400000B RID: 11
	public Transform rightReference;

	// Token: 0x0400000C RID: 12
	public Transform leftReference;

	// Token: 0x0400000D RID: 13
	public bool apply;

	// Token: 0x0400000E RID: 14
	public bool flipped;

	// Token: 0x0400000F RID: 15
	public SkinnedMeshRenderer skinnedTarget;

	// Token: 0x04000010 RID: 16
	public MeshFilter targetingMesh;

	// Token: 0x04000011 RID: 17
	public bool bakeMesh;

	// Token: 0x04000012 RID: 18
	private Mesh _mesh;
}
