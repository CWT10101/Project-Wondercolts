﻿using System;
using Rewired;
using UnityEngine;

// Token: 0x020000DB RID: 219
public class MainMenuAnimatorBridge : MonoBehaviour
{
	// Token: 0x0600065F RID: 1631 RVA: 0x0001BCE7 File Offset: 0x00019EE7
	private void Awake()
	{
		this.rwInput = ReInput.players.GetPlayer(0);
	}

	// Token: 0x06000660 RID: 1632 RVA: 0x0001BCFC File Offset: 0x00019EFC
	private void Start()
	{
		this.screenMat = Object.Instantiate<Material>(this.screenRen.sharedMaterial);
		this.screenRen.sharedMaterial = this.screenMat;
		this.screenGlowMat = Object.Instantiate<Material>(this.screenGlowRen.sharedMaterial);
		this.screenGlowRen.sharedMaterial = this.screenGlowMat;
	}

	// Token: 0x06000661 RID: 1633 RVA: 0x0001BD57 File Offset: 0x00019F57
	private void Update()
	{
		if (this.rwInput.GetButtonDown("Pause"))
		{
			Debug.Log("Skipped the intro by using Pause");
			this.animator.SetTrigger("SkipIntro");
			base.enabled = false;
		}
	}

	// Token: 0x06000662 RID: 1634 RVA: 0x0001BD8C File Offset: 0x00019F8C
	public void ToggleHighPass(int enabled)
	{
		AudioManager.Instance.musicHighpass.enabled = (enabled != 0);
	}

	// Token: 0x06000663 RID: 1635 RVA: 0x0001BDA4 File Offset: 0x00019FA4
	public void PlaySFX(string sfx)
	{
		AudioManager.Play(sfx, AudioManager.MixerTarget.Music, null, null);
	}

	// Token: 0x06000664 RID: 1636 RVA: 0x0001BDCB File Offset: 0x00019FCB
	public void SetScreenImageIndex(int index)
	{
		this.screenMat.SetTexture("_EmissiveTex", this.screenSequence[index]);
		this.screenGlowMat.SetTexture("_MainTex", this.screenSequence[index]);
	}

	// Token: 0x040004B7 RID: 1207
	[SerializeField]
	private Animator animator;

	// Token: 0x040004B8 RID: 1208
	[SerializeField]
	private Texture2D[] screenSequence;

	// Token: 0x040004B9 RID: 1209
	[SerializeField]
	private Renderer screenRen;

	// Token: 0x040004BA RID: 1210
	[SerializeField]
	private Renderer screenGlowRen;

	// Token: 0x040004BB RID: 1211
	private Material screenMat;

	// Token: 0x040004BC RID: 1212
	private Material screenGlowMat;

	// Token: 0x040004BD RID: 1213
	private Player rwInput;
}
