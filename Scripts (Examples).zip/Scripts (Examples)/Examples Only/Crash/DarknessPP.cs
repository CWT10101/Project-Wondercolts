﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Experimental.Rendering;

// Token: 0x02000008 RID: 8
public class DarknessPP : MonoBehaviour
{
	// Token: 0x06000019 RID: 25 RVA: 0x00002990 File Offset: 0x00000B90
	private void Awake()
	{
		this.cam = base.GetComponent<Camera>();
		this.rt = new RenderTexture(Screen.width, Screen.height, 16, GraphicsFormat.R8G8B8A8_UNorm);
		this.subcam = new GameObject("Shadow Camera", new Type[]
		{
			typeof(Camera)
		}).GetComponent<Camera>();
		this.subcam.transform.SetParent(this.cam.transform);
		this.subcam.CopyFrom(this.cam);
		this.subcam.SetReplacementShader(this.replacementShader, "RenderType");
		this.subcam.enabled = false;
		this.lightAdd = new Material(this.passAddShader)
		{
			hideFlags = HideFlags.HideAndDontSave
		};
		this.shadowMat = new Material(this.shadowCompositeShader)
		{
			hideFlags = HideFlags.HideAndDontSave
		};
		this.shadowMat.SetTexture("_Mask", this.rt);
	}

	// Token: 0x0600001A RID: 26 RVA: 0x00002A7F File Offset: 0x00000C7F
	private void OnEnable()
	{
		this.SetQuality(QualitySettings.GetQualityLevel());
		QualityDropdown.OnQualityChanged += this.SetQuality;
	}

	// Token: 0x0600001B RID: 27 RVA: 0x00002A9D File Offset: 0x00000C9D
	private void OnDisable()
	{
		QualityDropdown.OnQualityChanged -= this.SetQuality;
	}

	// Token: 0x0600001C RID: 28 RVA: 0x00002AB0 File Offset: 0x00000CB0
	private void SetQuality(int q)
	{
		if (q == 0)
		{
			this.maxLights = 8;
			this.maxLightDistance = 16f;
			return;
		}
		if (q == 1)
		{
			this.maxLights = 16;
			this.maxLightDistance = 24f;
			return;
		}
		if (q == 2)
		{
			this.maxLights = 32;
			this.maxLightDistance = 32f;
			return;
		}
		if (q == 3)
		{
			this.maxLights = 64;
			this.maxLightDistance = 32f;
		}
	}

	// Token: 0x0600001D RID: 29 RVA: 0x00002B1C File Offset: 0x00000D1C
	private void LateUpdate()
	{
		if (this.mixTarget != this.mixValue)
		{
			this.SetMix(Mathf.MoveTowards(this.mixValue, this.mixTarget, this.fadeRate * Time.deltaTime), false);
			if (this.mixValue == 0f)
			{
				base.enabled = false;
			}
		}
	}

	// Token: 0x0600001E RID: 30 RVA: 0x00002B70 File Offset: 0x00000D70
	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		DarknessPP.<>c__DisplayClass21_0 CS$<>8__locals1 = new DarknessPP.<>c__DisplayClass21_0();
		CS$<>8__locals1.<>4__this = this;
		if (Screen.width != this.rt.width || Screen.height != this.rt.height)
		{
			Debug.Log("Getting new render texture");
			this.rt.Release();
			this.rt = new RenderTexture(Screen.width, Screen.height, 16, GraphicsFormat.R8G8B8A8_UNorm);
			this.shadowMat.SetTexture("_Mask", this.rt);
		}
		this.subcam.CopyFrom(this.cam);
		this.subcam.SetReplacementShader(this.replacementShader, "RenderType");
		this.subcam.clearFlags = CameraClearFlags.Color;
		this.subcam.backgroundColor = Color.white;
		RenderTexture active = RenderTexture.active;
		RenderTexture.active = this.rt;
		GL.Clear(true, true, Color.clear);
		RenderTexture.active = active;
		RenderTexture temporary = RenderTexture.GetTemporary(this.rt.width, this.rt.height, this.rt.depth, this.rt.format);
		this.subcam.targetTexture = temporary;
		CS$<>8__locals1.camX = this.cam.transform.position.x;
		CS$<>8__locals1.camY = this.cam.transform.position.y;
		foreach (IEnumerable<LightSource> enumerable in from p in LightSource.lights.Where(new Func<LightSource, bool>(DarknessPP.<OnRenderImage>g__ContributesLight|21_1)).Where(new Func<LightSource, bool>(CS$<>8__locals1.<OnRenderImage>g__InRange|0)).OrderBy(new Func<LightSource, float>(CS$<>8__locals1.<OnRenderImage>g__Dist|2)).Take(this.maxLights).Select((LightSource l, int i) => new ValueTuple<LightSource, int>(l, i / 8))
		group p.Item1 by p.Item2)
		{
			byte b = 0;
			foreach (LightSource lightSource in enumerable)
			{
				this.posArray[(int)b] = lightSource.transform.position;
				this.colArray[(int)b] = lightSource.color;
				this.radiusArray[(int)b] = lightSource.radius;
				b += 1;
			}
			Shader.SetGlobalVectorArray("_PointLightPos", this.posArray);
			Shader.SetGlobalVectorArray("_PointLightColor", this.colArray);
			Shader.SetGlobalFloatArray("_PointLightRadius", this.radiusArray);
			Shader.SetGlobalInteger("_PointLightsUsed", (int)b);
			this.subcam.Render();
			Graphics.Blit(temporary, this.rt, this.lightAdd);
		}
		RenderTexture.ReleaseTemporary(temporary);
		Graphics.Blit(source, destination, this.shadowMat);
	}

	// Token: 0x0600001F RID: 31 RVA: 0x00002E98 File Offset: 0x00001098
	public void SetMix(float m, bool setTarget = false)
	{
		this.mixValue = m;
		if (setTarget)
		{
			this.mixTarget = m;
		}
		this.shadowMat.SetFloat("_Mix", this.mixValue);
	}

	// Token: 0x06000020 RID: 32 RVA: 0x00002EC1 File Offset: 0x000010C1
	public void FadeOff()
	{
		this.mixTarget = 0f;
	}

	// Token: 0x06000021 RID: 33 RVA: 0x00002ECE File Offset: 0x000010CE
	public void FadeOn()
	{
		base.enabled = true;
		this.mixTarget = 1f;
	}

	// Token: 0x06000023 RID: 35 RVA: 0x00002F39 File Offset: 0x00001139
	[CompilerGenerated]
	internal static bool <OnRenderImage>g__ContributesLight|21_1(LightSource l)
	{
		return l.radius > 0f;
	}

	// Token: 0x04000017 RID: 23
	public Shader replacementShader;

	// Token: 0x04000018 RID: 24
	public Shader passAddShader;

	// Token: 0x04000019 RID: 25
	public Shader shadowCompositeShader;

	// Token: 0x0400001A RID: 26
	private Material lightAdd;

	// Token: 0x0400001B RID: 27
	private Material shadowMat;

	// Token: 0x0400001C RID: 28
	public float fadeRate = 2f;

	// Token: 0x0400001D RID: 29
	public int maxLights = 32;

	// Token: 0x0400001E RID: 30
	public float maxLightDistance = 32f;

	// Token: 0x0400001F RID: 31
	private Camera cam;

	// Token: 0x04000020 RID: 32
	private Camera subcam;

	// Token: 0x04000021 RID: 33
	[SerializeField]
	[ReadOnly]
	private RenderTexture rt;

	// Token: 0x04000022 RID: 34
	private float mixValue;

	// Token: 0x04000023 RID: 35
	private float mixTarget;

	// Token: 0x04000024 RID: 36
	private readonly Vector4[] posArray = new Vector4[8];

	// Token: 0x04000025 RID: 37
	private readonly Vector4[] colArray = new Vector4[8];

	// Token: 0x04000026 RID: 38
	private readonly float[] radiusArray = new float[8];
}
