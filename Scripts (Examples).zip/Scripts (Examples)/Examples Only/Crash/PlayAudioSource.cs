﻿using System;
using UnityEngine;

// Token: 0x02000053 RID: 83
public class PlayAudioSource : MonoBehaviour
{
	// Token: 0x17000069 RID: 105
	// (get) Token: 0x0600021A RID: 538 RVA: 0x000096FD File Offset: 0x000078FD
	public AudioSource Source
	{
		get
		{
			return this.src;
		}
	}

	// Token: 0x0600021B RID: 539 RVA: 0x00009708 File Offset: 0x00007908
	public void PlayAudio()
	{
		if (!this.src.enabled || !this.src.gameObject.activeInHierarchy)
		{
			return;
		}
		this.src.pitch = Random.Range(this.minPitch, this.maxPitch);
		this.src.Play();
	}

	// Token: 0x0600021C RID: 540 RVA: 0x0000975C File Offset: 0x0000795C
	public void PlayMinPitch()
	{
		if (!this.src.enabled)
		{
			return;
		}
		this.src.pitch = this.minPitch;
		this.src.Play();
	}

	// Token: 0x0600021D RID: 541 RVA: 0x00009788 File Offset: 0x00007988
	public void PlayMaxPitch()
	{
		if (!this.src.enabled)
		{
			return;
		}
		this.src.pitch = this.maxPitch;
		this.src.Play();
	}

	// Token: 0x0400012B RID: 299
	[SerializeField]
	private AudioSource src;

	// Token: 0x0400012C RID: 300
	public float minPitch = 1f;

	// Token: 0x0400012D RID: 301
	public float maxPitch = 1f;
}
