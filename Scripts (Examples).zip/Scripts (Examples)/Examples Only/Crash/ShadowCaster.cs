﻿using System;
using UnityEngine;

// Token: 0x02000114 RID: 276
[DefaultExecutionOrder(100)]
public class ShadowCaster : MonoBehaviour
{
	// Token: 0x0600087E RID: 2174 RVA: 0x00023B08 File Offset: 0x00021D08
	private void FixedUpdate()
	{
		RaycastHit raycastHit;
		if (Physics.SphereCast(base.transform.position, this.castRadius, Vector3.down, out raycastHit, this.maxCast, this.layerMask, QueryTriggerInteraction.Ignore))
		{
			this.shadow.transform.position = new Vector3(base.transform.position.x, raycastHit.point.y + this.offset, base.transform.position.z);
			this.shadow.transform.localScale = Vector3.one * this.size * Mathf.Lerp(1f, 1f - this.scaleFactor, raycastHit.distance / this.maxCast);
			this.shadow.SetActive(true);
			return;
		}
		this.shadow.SetActive(false);
	}

	// Token: 0x0400063F RID: 1599
	public LayerMask layerMask = -1;

	// Token: 0x04000640 RID: 1600
	public GameObject shadow;

	// Token: 0x04000641 RID: 1601
	public float castRadius = 1f;

	// Token: 0x04000642 RID: 1602
	public float maxCast = 10f;

	// Token: 0x04000643 RID: 1603
	public float size = 1f;

	// Token: 0x04000644 RID: 1604
	[Range(0f, 1f)]
	public float scaleFactor = 0.5f;

	// Token: 0x04000645 RID: 1605
	public float offset = 0.05f;
}
