﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000043 RID: 67
public class PropertyModifier : MonoBehaviour
{
	// Token: 0x060001B8 RID: 440 RVA: 0x000079C2 File Offset: 0x00005BC2
	private void Start()
	{
		this.propsShown = false;
		this.panel.gameObject.SetActive(false);
		this.pForProps.gameObject.SetActive(true);
	}

	// Token: 0x060001B9 RID: 441 RVA: 0x000079F0 File Offset: 0x00005BF0
	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.Q))
		{
			this.propsShown = !this.propsShown;
			this.panel.gameObject.SetActive(this.propsShown);
			this.pForProps.gameObject.SetActive(!this.propsShown);
			this.flythrough.LockCursor(!this.propsShown);
		}
	}

	// Token: 0x060001BA RID: 442 RVA: 0x00007A58 File Offset: 0x00005C58
	public void SetResFactor(InputField input)
	{
		this.effects.resolutionFactor = int.Parse(input.text);
	}

	// Token: 0x060001BB RID: 443 RVA: 0x00007A70 File Offset: 0x00005C70
	public void SetLimFrame(InputField input)
	{
		this.effects.limitFramerate = int.Parse(input.text);
	}

	// Token: 0x060001BC RID: 444 RVA: 0x00007A88 File Offset: 0x00005C88
	public void SetDD(InputField input)
	{
		Debug.Log("Set DD");
		this.effects.polygonalDrawDistance = (float)int.Parse(input.text);
	}

	// Token: 0x060001BD RID: 445 RVA: 0x00007AAB File Offset: 0x00005CAB
	public void SetVI(InputField input)
	{
		this.effects.vertexInaccuracy = int.Parse(input.text);
	}

	// Token: 0x060001BE RID: 446 RVA: 0x00007AC3 File Offset: 0x00005CC3
	public void SetPI(InputField input)
	{
		this.effects.polygonInaccuracy = int.Parse(input.text);
	}

	// Token: 0x060001BF RID: 447 RVA: 0x00007ADB File Offset: 0x00005CDB
	public void SetCD(InputField input)
	{
		this.effects.colorDepth = int.Parse(input.text);
	}

	// Token: 0x060001C0 RID: 448 RVA: 0x00007AF3 File Offset: 0x00005CF3
	public void SetScanlines(Toggle input)
	{
		this.effects.scanlines = input.isOn;
	}

	// Token: 0x060001C1 RID: 449 RVA: 0x00007B06 File Offset: 0x00005D06
	public void SetDithering(Toggle input)
	{
		this.effects.dithering = input.isOn;
	}

	// Token: 0x060001C2 RID: 450 RVA: 0x00007B19 File Offset: 0x00005D19
	public void SetSF(Slider input)
	{
		this.effects.subtractFade = (int)(input.value * 100f);
	}

	// Token: 0x060001C3 RID: 451 RVA: 0x00007B33 File Offset: 0x00005D33
	public void SetDR(InputField input)
	{
		this.effects.favorRed = float.Parse(input.text);
	}

	// Token: 0x040000CD RID: 205
	public PSXEffects effects;

	// Token: 0x040000CE RID: 206
	public Text pForProps;

	// Token: 0x040000CF RID: 207
	public Image panel;

	// Token: 0x040000D0 RID: 208
	public CameraFlythrough flythrough;

	// Token: 0x040000D1 RID: 209
	private bool propsShown;
}
