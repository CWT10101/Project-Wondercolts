﻿using System;

// Token: 0x020000CE RID: 206
public interface ISpin
{
	// Token: 0x0600061A RID: 1562
	void Spin(CrashController crash);
}
