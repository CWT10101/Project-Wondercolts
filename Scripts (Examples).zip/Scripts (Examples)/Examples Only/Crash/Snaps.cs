﻿using System;
using UnityEngine;

// Token: 0x02000166 RID: 358
public class Snaps : MonoBehaviour
{
	// Token: 0x1700012A RID: 298
	// (get) Token: 0x06000A3E RID: 2622 RVA: 0x00028E6B File Offset: 0x0002706B
	// (set) Token: 0x06000A3F RID: 2623 RVA: 0x00028E73 File Offset: 0x00027073
	public Transform[] Points { get; private set; }

	// Token: 0x06000A40 RID: 2624 RVA: 0x00028E7C File Offset: 0x0002707C
	public void SnapTo(Transform point)
	{
		Transform bestFit = this.GetBestFit(point);
		base.transform.rotation = point.rotation;
		base.transform.position = point.position - (bestFit.position - base.transform.position);
	}

	// Token: 0x06000A41 RID: 2625 RVA: 0x00028ED0 File Offset: 0x000270D0
	public Transform GetBestFit(Transform otherSnap)
	{
		if (this.Points == null || this.Points.Length == 0)
		{
			return null;
		}
		Transform transform = null;
		float num = 1f;
		foreach (Transform transform2 in this.Points)
		{
			if (transform == null)
			{
				transform = transform2;
				num = Quaternion.Dot(otherSnap.rotation, transform2.rotation);
			}
			else
			{
				float num2 = Quaternion.Dot(otherSnap.rotation, transform2.rotation);
				if (num2 < num)
				{
					transform = transform2;
					num = num2;
				}
			}
		}
		return transform;
	}
}
