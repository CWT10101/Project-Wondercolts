﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using LevelEditor;

// Token: 0x02000027 RID: 39
public class DetonatorLinkMetadata : ObjectMetadata
{
	// Token: 0x1700001F RID: 31
	// (get) Token: 0x060000D7 RID: 215 RVA: 0x00005E01 File Offset: 0x00004001
	public List<LevelObj> Connections { get; } = new List<LevelObj>();

	// Token: 0x17000020 RID: 32
	// (get) Token: 0x060000D8 RID: 216 RVA: 0x00005E09 File Offset: 0x00004009
	public override bool SupportsMultiEditing
	{
		get
		{
			return false;
		}
	}

	// Token: 0x17000021 RID: 33
	// (get) Token: 0x060000D9 RID: 217 RVA: 0x00005E0C File Offset: 0x0000400C
	public override int Signature
	{
		get
		{
			return "DetonatorLinkMetadata".GetHashCode();
		}
	}

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x060000DA RID: 218 RVA: 0x00005E18 File Offset: 0x00004018
	public override int ValueHash
	{
		get
		{
			return this.valueHash;
		}
	}

	// Token: 0x060000DB RID: 219 RVA: 0x00005E20 File Offset: 0x00004020
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write((short)this.Connections.Count);
		for (int i = 0; i < this.Connections.Count; i++)
		{
			bw.Write((short)this.Connections[i].gridPosX);
			bw.Write((short)this.Connections[i].gridPosY);
		}
	}

	// Token: 0x060000DC RID: 220 RVA: 0x00005E88 File Offset: 0x00004088
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.valueHash = 0;
		this.Connections.ToList<LevelObj>().ForEach(delegate(LevelObj obj)
		{
			this.RemoveConnection(obj);
		});
		int num = (int)br.ReadInt16();
		for (int i = 0; i < num; i++)
		{
			short num2 = br.ReadInt16();
			short num3 = br.ReadInt16();
			this.AddConnection(grid[(int)num2, (int)num3].placedObj);
		}
	}

	// Token: 0x060000DD RID: 221 RVA: 0x00005EEC File Offset: 0x000040EC
	public override void Apply(LevelObj obj)
	{
		this.removed.Clear();
		IMetadataReceiver<DetonatorLinkMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<DetonatorLinkMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x060000DE RID: 222 RVA: 0x00005F23 File Offset: 0x00004123
	public override void OnDeleted(LevelObj obj)
	{
		this.Connections.ToList<LevelObj>().ForEach(delegate(LevelObj c)
		{
			this.RemoveConnection(c);
		});
		this.Apply(obj);
	}

	// Token: 0x060000DF RID: 223 RVA: 0x00005F48 File Offset: 0x00004148
	public void AddConnection(LevelObj obj)
	{
		if (this.Connections.Contains(obj))
		{
			return;
		}
		this.Connections.Add(obj);
		this.valueHash ^= obj.GetHashCode();
		obj.OnObjDeleted += this.ObjDeletedCallback;
	}

	// Token: 0x060000E0 RID: 224 RVA: 0x00005F98 File Offset: 0x00004198
	public void RemoveConnection(LevelObj obj)
	{
		if (this.Connections.Remove(obj))
		{
			this.removed.Add(obj);
			this.valueHash ^= obj.GetHashCode();
			obj.OnObjDeleted -= this.ObjDeletedCallback;
		}
	}

	// Token: 0x060000E1 RID: 225 RVA: 0x00005FE4 File Offset: 0x000041E4
	public void ReplaceConnection(LevelObj oldObj, LevelObj newObj)
	{
		int num = this.Connections.IndexOf(oldObj);
		if (num != -1)
		{
			this.Connections[num] = newObj;
			this.removed.Add(oldObj);
			this.valueHash ^= oldObj.GetHashCode();
			this.valueHash ^= newObj.GetHashCode();
			oldObj.OnObjDeleted -= this.ObjDeletedCallback;
			newObj.OnObjDeleted += this.ObjDeletedCallback;
		}
	}

	// Token: 0x060000E2 RID: 226 RVA: 0x00006065 File Offset: 0x00004265
	private void ObjDeletedCallback(LevelObj obj)
	{
		this.RemoveConnection(obj);
		this.Apply(base.GetComponent<LevelObj>());
	}

	// Token: 0x060000E3 RID: 227 RVA: 0x0000607A File Offset: 0x0000427A
	public override string ToString()
	{
		return string.Join<LevelObj>(", ", this.Connections);
	}

	// Token: 0x04000088 RID: 136
	private readonly List<LevelObj> removed = new List<LevelObj>();

	// Token: 0x04000089 RID: 137
	private int valueHash;
}
