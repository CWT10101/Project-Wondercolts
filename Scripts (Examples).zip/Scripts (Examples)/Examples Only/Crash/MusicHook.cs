﻿using System;
using UnityEngine;

// Token: 0x020000E9 RID: 233
public class MusicHook : MonoBehaviour
{
	// Token: 0x06000726 RID: 1830 RVA: 0x0001E930 File Offset: 0x0001CB30
	public void FadeOut(float time)
	{
		AudioManager.FadeOutMusic(time);
	}

	// Token: 0x06000727 RID: 1831 RVA: 0x0001E938 File Offset: 0x0001CB38
	public void Play(string track)
	{
		AudioManager.PlayMusic(track, 1f);
	}

	// Token: 0x06000728 RID: 1832 RVA: 0x0001E945 File Offset: 0x0001CB45
	public void PlayImmediate(string track)
	{
		AudioManager.PlayMusic(track, 0f);
	}
}
