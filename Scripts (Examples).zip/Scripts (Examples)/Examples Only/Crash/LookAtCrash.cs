﻿using System;
using UnityEngine;

// Token: 0x020000DA RID: 218
public class LookAtCrash : MonoBehaviour
{
	// Token: 0x0600065D RID: 1629 RVA: 0x0001BC90 File Offset: 0x00019E90
	private void FixedUpdate()
	{
		Vector3 position = CrashController.instance.transform.position;
		if (this.isClamped)
		{
			position.y = base.transform.position.y;
		}
		base.transform.LookAt(position);
	}

	// Token: 0x040004B6 RID: 1206
	public bool isClamped = true;
}
