﻿using System;
using UnityEngine;

// Token: 0x0200004B RID: 75
public class AllCratesGemSetter : PickupSetter
{
	// Token: 0x17000067 RID: 103
	// (get) Token: 0x06000203 RID: 515 RVA: 0x000092A1 File Offset: 0x000074A1
	public override Pickup Pickup
	{
		get
		{
			return this.allCratesGem;
		}
	}

	// Token: 0x17000068 RID: 104
	// (get) Token: 0x06000204 RID: 516 RVA: 0x000092A9 File Offset: 0x000074A9
	// (set) Token: 0x06000205 RID: 517 RVA: 0x000092B1 File Offset: 0x000074B1
	public override bool Collected
	{
		get
		{
			return this.collected;
		}
		set
		{
			this.collected = value;
		}
	}

	// Token: 0x04000112 RID: 274
	[SerializeField]
	private CrystalPickup allCratesGem;

	// Token: 0x04000113 RID: 275
	[SerializeField]
	private bool collected;
}
