﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020000BB RID: 187
public class FlashbackTapeButton : MonoBehaviour
{
	// Token: 0x060005C7 RID: 1479 RVA: 0x00019A6D File Offset: 0x00017C6D
	public void LaunchFlashbackLevel()
	{
		ScreenCanvas.instance.LaunchFlashbackLevel(this.tapeIndex);
	}

	// Token: 0x060005C8 RID: 1480 RVA: 0x00019A80 File Offset: 0x00017C80
	public void SetData(int index)
	{
		this.flashbackString = string.Format("Flashback0{0}", index);
		this.tapeText.text = this.flashbackString;
		this.tapeIndex = index;
		this.awardIcon.color = this.medalColors[(int)SaveData.Info.tapeMedals[index]];
	}

	// Token: 0x04000435 RID: 1077
	public int tapeIndex;

	// Token: 0x04000436 RID: 1078
	public string flashbackString;

	// Token: 0x04000437 RID: 1079
	public TMP_Text tapeText;

	// Token: 0x04000438 RID: 1080
	public Image awardIcon;

	// Token: 0x04000439 RID: 1081
	public Color[] medalColors = new Color[4];
}
