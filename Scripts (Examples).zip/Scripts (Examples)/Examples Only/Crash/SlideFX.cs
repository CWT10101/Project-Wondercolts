﻿using System;
using UnityEngine;

// Token: 0x02000057 RID: 87
public class SlideFX : MonoBehaviour
{
	// Token: 0x06000226 RID: 550 RVA: 0x000098C0 File Offset: 0x00007AC0
	private void Update()
	{
		CrashController instance = CrashController.instance;
		if (instance != null)
		{
			base.transform.position = instance.transform.position;
			if (instance.animator.currentState != instance.animator.slideObj)
			{
				base.GetComponent<ParticleSystem>().Stop(false, ParticleSystemStopBehavior.StopEmitting);
			}
		}
	}
}
