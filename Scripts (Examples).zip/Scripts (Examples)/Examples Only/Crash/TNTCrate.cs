﻿using System;
using UnityEngine;

// Token: 0x02000139 RID: 313
public class TNTCrate : Crate, IFallOn, ISpin, ISlide, ISlam, ITouchBottom
{
	// Token: 0x1700011D RID: 285
	// (get) Token: 0x06000949 RID: 2377 RVA: 0x00025F61 File Offset: 0x00024161
	public override bool AddsToBoxCount
	{
		get
		{
			return true;
		}
	}

	// Token: 0x0600094A RID: 2378 RVA: 0x00025F64 File Offset: 0x00024164
	protected override void OnEnable()
	{
		base.OnEnable();
		if (!this.isBroken && this.lit)
		{
			this.ResetEntity();
		}
	}

	// Token: 0x0600094B RID: 2379 RVA: 0x00025F82 File Offset: 0x00024182
	public override void Break()
	{
		if (this.isBroken)
		{
			return;
		}
		this.Explode();
	}

	// Token: 0x0600094C RID: 2380 RVA: 0x00025F93 File Offset: 0x00024193
	protected override void Settle()
	{
		this.Light();
	}

	// Token: 0x0600094D RID: 2381 RVA: 0x00025F9B File Offset: 0x0002419B
	public override void ResetEntity()
	{
		this.lit = false;
		if (this.spawnedExplosion)
		{
			Object.Destroy(this.spawnedExplosion);
		}
		this.spawnedExplosion = null;
		this.countdownAnimator.SetTrigger("reset");
		base.ResetEntity();
	}

	// Token: 0x0600094E RID: 2382 RVA: 0x00025FDC File Offset: 0x000241DC
	public virtual void Explode()
	{
		this.countdownAnimator.SetTrigger("reset");
		base.Break();
		this.coll.enabled = false;
		foreach (Collider collider in Physics.OverlapSphere(base.transform.position + new Vector3(0f, 0.5f, 0f), this.explosionRadius))
		{
			CrashController crashController;
			if (collider.TryGetComponent<CrashController>(out crashController))
			{
				crashController.TakeDamage(this.crashDeathIndex);
			}
			Enemy enemy;
			if (collider.TryGetComponent<Enemy>(out enemy))
			{
				enemy.Explode(base.transform);
			}
		}
		Transform parent = Level.instance ? Level.instance.transform : (LevelManager.instance ? LevelManager.instance.projectileHolder : null);
		this.spawnedExplosion = Object.Instantiate<Explosion>(this.explosion, base.ColliderCenter, Quaternion.identity, parent);
		this.spawnedExplosion.size = this.explosionRadius;
		if (this.explosionEffect)
		{
			Object.Instantiate<GameObject>(this.explosionEffect, base.transform.position, Quaternion.identity, parent);
		}
		this.lit = false;
	}

	// Token: 0x0600094F RID: 2383 RVA: 0x0002610A File Offset: 0x0002430A
	public virtual void FallOn(CrashController crash)
	{
		if (!this.lit && crash)
		{
			crash.Bounce();
		}
		this.Light();
	}

	// Token: 0x06000950 RID: 2384 RVA: 0x00026128 File Offset: 0x00024328
	public virtual void Light()
	{
		if (!this.lit)
		{
			this.lit = true;
			this.countdownAnimator.SetTrigger("countdown");
		}
	}

	// Token: 0x06000951 RID: 2385 RVA: 0x0002614C File Offset: 0x0002434C
	public void PlayCountdownSFX()
	{
		AudioManager.Play("SFX_TNTBeep", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
	}

	// Token: 0x06000952 RID: 2386 RVA: 0x0002617E File Offset: 0x0002437E
	public virtual void Slam(CrashController crash)
	{
		this.Explode();
	}

	// Token: 0x06000953 RID: 2387 RVA: 0x00026186 File Offset: 0x00024386
	public virtual void Slide(CrashController crash)
	{
		if (!base.IsAbove(crash) && !base.IsBelow(crash))
		{
			this.Explode();
		}
	}

	// Token: 0x06000954 RID: 2388 RVA: 0x000261A0 File Offset: 0x000243A0
	public virtual void Spin(CrashController crash)
	{
		this.Explode();
	}

	// Token: 0x06000955 RID: 2389 RVA: 0x000261A8 File Offset: 0x000243A8
	public virtual void TouchBottom(CrashController crash)
	{
		crash.StopAscent();
		this.Light();
	}

	// Token: 0x06000956 RID: 2390 RVA: 0x000261B6 File Offset: 0x000243B6
	private void OnDrawGizmosSelected()
	{
		Gizmos.color = Color.yellow;
		Gizmos.DrawWireSphere(base.ColliderCenter, this.explosionRadius);
	}

	// Token: 0x040006C8 RID: 1736
	public Explosion explosion;

	// Token: 0x040006C9 RID: 1737
	public GameObject explosionEffect;

	// Token: 0x040006CA RID: 1738
	public float explosionRadius = 2f;

	// Token: 0x040006CB RID: 1739
	public Animator countdownAnimator;

	// Token: 0x040006CC RID: 1740
	[HideInInspector]
	public bool lit;

	// Token: 0x040006CD RID: 1741
	[HideInInspector]
	public Explosion spawnedExplosion;

	// Token: 0x040006CE RID: 1742
	public int crashDeathIndex = 4;
}
