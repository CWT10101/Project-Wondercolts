﻿using System;
using System.Collections.Generic;
using LevelEditor;
using UnityEngine;

// Token: 0x02000080 RID: 128
public class CheckpointCrate : Crate, ISpin, IFallOn, ISlide, ISlam, ITouchBottom
{
	// Token: 0x17000095 RID: 149
	// (get) Token: 0x0600038C RID: 908 RVA: 0x0000F48E File Offset: 0x0000D68E
	public override bool AddsToBoxCount
	{
		get
		{
			return this.theBoolINeed;
		}
	}

	// Token: 0x0600038D RID: 909 RVA: 0x0000F496 File Offset: 0x0000D696
	protected override void OnEnable()
	{
		base.OnEnable();
		if (this.isBroken)
		{
			this.anim.SetTrigger("Break");
		}
	}

	// Token: 0x0600038E RID: 910 RVA: 0x0000F4B6 File Offset: 0x0000D6B6
	public void FallOn(CrashController crash)
	{
		if (!this.isBroken)
		{
			crash.Bounce();
		}
		this.Break();
	}

	// Token: 0x0600038F RID: 911 RVA: 0x0000F4CC File Offset: 0x0000D6CC
	public void Slam(CrashController crash)
	{
		this.Break();
	}

	// Token: 0x06000390 RID: 912 RVA: 0x0000F4D4 File Offset: 0x0000D6D4
	public void Slide(CrashController crash)
	{
		if (!base.IsAbove(crash))
		{
			this.Break();
		}
	}

	// Token: 0x06000391 RID: 913 RVA: 0x0000F4E5 File Offset: 0x0000D6E5
	public void Spin(CrashController crash)
	{
		this.Break();
	}

	// Token: 0x06000392 RID: 914 RVA: 0x0000F4ED File Offset: 0x0000D6ED
	public void TouchBottom(CrashController crash)
	{
		this.Break();
	}

	// Token: 0x06000393 RID: 915 RVA: 0x0000F4F5 File Offset: 0x0000D6F5
	public override void Fall(float withVelocity = 0f)
	{
	}

	// Token: 0x06000394 RID: 916 RVA: 0x0000F4F8 File Offset: 0x0000D6F8
	public override void ForceBreak()
	{
		if (!this.isBroken)
		{
			this.isBroken = true;
			AudioManager.Play("SFX_Checkpoint", new Vector3?(base.transform.position), null);
			AudioManager.Play("SFX_CheckpointBreak", new Vector3?(base.transform.position), null);
			CrashSpawner.instance.crashSpawnPoint.position = this.crashSpawnPoint.position;
			SwitchCrate.StoreSwitchState();
			if (LevelInterfaceManager.instance)
			{
				LevelInterfaceManager.instance.SetWeatherRollback();
				LevelInterfaceManager.instance.SetMusicRollback();
			}
			this.anim.SetTrigger("Break");
			this.coll.enabled = !this.theBoolINeed;
			if (this.AddsToBoxCount && LevelInterfaceManager.instance != null)
			{
				LevelInterfaceManager.instance.AddCrateCollected(this);
			}
			if (this.AddsToBoxCount && Level.instance != null)
			{
				Level.instance.AddCrateCollected(this);
			}
			this.TryPushToStack();
			base.OnBreak();
		}
	}

	// Token: 0x06000395 RID: 917 RVA: 0x0000F610 File Offset: 0x0000D810
	public override void TryPushToStack()
	{
		IEnumerator<Entity> enumerator = EntityTracker.PopCache();
		while (enumerator.MoveNext())
		{
			if (enumerator.Current)
			{
				enumerator.Current.RememberState();
			}
		}
	}

	// Token: 0x06000396 RID: 918 RVA: 0x0000F645 File Offset: 0x0000D845
	public override void ResetEntity()
	{
		base.ResetEntity();
		CrashSpawner.instance.crashSpawnPoint.position = CrashSpawner.instance.startingPosition;
		this.anim.SetTrigger("reset");
	}

	// Token: 0x0400025F RID: 607
	public bool theBoolINeed = true;

	// Token: 0x04000260 RID: 608
	public Transform crashSpawnPoint;

	// Token: 0x04000261 RID: 609
	public Animator anim;
}
