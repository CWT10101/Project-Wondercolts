﻿using System;
using UnityEngine;

// Token: 0x0200004F RID: 79
public class DinoSetStateSMB : StateMachineBehaviour
{
	// Token: 0x0600020F RID: 527 RVA: 0x000094B3 File Offset: 0x000076B3
	public override void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
	{
		if (this.dino == null)
		{
			this.dino = animator.GetComponent<Dino>();
		}
		if (this.setOnEnter)
		{
			this.dino.state = this.stateOnEnter;
		}
	}

	// Token: 0x06000210 RID: 528 RVA: 0x000094E8 File Offset: 0x000076E8
	public override void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
	{
		if (this.setOnExit)
		{
			this.dino.state = this.stateOnExit;
		}
	}

	// Token: 0x0400011D RID: 285
	public bool setOnEnter;

	// Token: 0x0400011E RID: 286
	public bool setOnExit;

	// Token: 0x0400011F RID: 287
	public Dino.State stateOnEnter;

	// Token: 0x04000120 RID: 288
	public Dino.State stateOnExit;

	// Token: 0x04000121 RID: 289
	private Dino dino;
}
