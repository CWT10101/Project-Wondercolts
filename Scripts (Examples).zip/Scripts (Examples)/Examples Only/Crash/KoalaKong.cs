﻿using System;
using UnityEngine;

// Token: 0x0200006E RID: 110
public class KoalaKong : CreatorBoss, IMetadataReceiver<ProjectileMetadata>, IMetadataReceiver<SpeedMetadata>, IMetadataReceiver<KongQuickThrowMetadata>
{
	// Token: 0x17000085 RID: 133
	// (get) Token: 0x060002F9 RID: 761 RVA: 0x0000CF20 File Offset: 0x0000B120
	public override IMover Mover
	{
		get
		{
			IMover result;
			if ((result = this._mover) == null)
			{
				result = (this._mover = base.gameObject.AddComponent<CCMover>().Init(this.cc, true));
			}
			return result;
		}
	}

	// Token: 0x17000086 RID: 134
	// (get) Token: 0x060002FA RID: 762 RVA: 0x0000CF58 File Offset: 0x0000B158
	public override BossPhase[] Phases
	{
		get
		{
			BossPhase[] result;
			if ((result = this._phases) == null)
			{
				result = (this._phases = this.CreatePhases(this.maxHPSetting));
			}
			return result;
		}
	}

	// Token: 0x17000087 RID: 135
	// (get) Token: 0x060002FB RID: 763 RVA: 0x0000CF84 File Offset: 0x0000B184
	public override BossPhase FallbackPhase
	{
		get
		{
			BossPhase result;
			if ((result = this._fallbackPhase) == null)
			{
				result = (this._fallbackPhase = this.CreateFallbackPhase());
			}
			return result;
		}
	}

	// Token: 0x060002FC RID: 764 RVA: 0x0000CFAC File Offset: 0x0000B1AC
	private BossPhase[] CreatePhases(int count)
	{
		BossPhase[] array = new BossPhase[count];
		for (int i = 0; i < count; i++)
		{
			array[i] = this.CreatePhase(i);
		}
		return array;
	}

	// Token: 0x060002FD RID: 765 RVA: 0x0000CFD8 File Offset: 0x0000B1D8
	private BossPhase CreatePhase(int phaseIndex)
	{
		return new BossPhase("Phase " + phaseIndex.ToString())
		{
			PhaseEnter = delegate(CreatorBoss self, BossPhase ctx)
			{
				this.animator.SetFloat("Speed", this.throwSpeed);
				this.projectilesThrown = 0;
				if (phaseIndex == 0)
				{
					this.UpdateFacing();
				}
			},
			PhaseExit = delegate(CreatorBoss self, BossPhase ctx)
			{
				this.isDangerous = false;
				this.animator.Play(this.animHit);
				AudioManager.Play(this.hitSound, AudioManager.MixerTarget.SFX, new Vector3?(this.collider.bounds.center), null);
				this.SetVelocity((CrashController.instance.transform.position.x < this.transform.position.x) ? this.hitKnockback : (-this.hitKnockback), this.hitKnockback);
				this.isDangerous = false;
				this.wasHit = true;
			},
			Evaluate = delegate(CreatorBoss self, BossPhase ctx)
			{
				if (this.facing != 0)
				{
					Quaternion quaternion = Quaternion.LookRotation(Vector3.right * Mathf.Sign((float)this.facing));
					this.transform.rotation = Quaternion.RotateTowards(this.transform.rotation, quaternion, 720f * Time.fixedDeltaTime);
					if (this.transform.rotation == quaternion)
					{
						this.facing = 0;
					}
				}
				if (self.MoveResult.Grounded)
				{
					if (this.IsAnimationState(this.animJump))
					{
						this.SetVelocity_X(0f);
						if (this.IsAnimationFinished())
						{
							this.animator.Play(this.animLift);
							this.UpdateFacing();
						}
					}
					else if (this.IsAnimationState(this.animLift))
					{
						if (this.IsAnimationFinished())
						{
							this.animator.Play(this.animThrow);
						}
					}
					else if (this.IsAnimationState(this.animThrow))
					{
						if (this.IsAnimationFinished() && this.projectilesThrown != this.projectileCount + phaseIndex)
						{
							if (this.quickThrow)
							{
								this.animator.Play(this.animThrow);
							}
							else
							{
								this.animator.Play(this.animLift);
							}
						}
					}
					else if (this.IsAnimationState(this.animHit))
					{
						if (this.IsAnimationFinished())
						{
							this.SetVelocity(0f, 0f);
							this.animator.Play(this.animRecover);
						}
					}
					else if (this.IsAnimationState(this.animRecover))
					{
						if (this.IsAnimationFinished())
						{
							this.SetVulnerableOff();
							this.animator.Play(this.animLift);
							this.wasHit = false;
							this.isDangerous = true;
							this.UpdateFacing();
						}
					}
					else if (this.IsAnimationState(this.animFlex))
					{
						if (this.AnimationJustStarted())
						{
							this.isDangerous = false;
						}
						if (this.IsAnimationFinished())
						{
							this.projectilesThrown = 0;
							this.SetVulnerableOff();
							this.animator.Play(this.animLift);
							this.wasHit = false;
							this.isDangerous = true;
							this.UpdateFacing();
						}
					}
					if (!this.IsAnimationState(this.animJump) && !this.IsAnimationState(this.animFlex) && !this.IsAnimationState(this.animRecover) && !this.IsAnimationState(this.animHit) && !this.IsAnimationState(this.animThrow) && (this.tLastJumped == 0f || (Clock.SynchronizedTime - this.tLastJumped > this.jumpInterval && !CrashController.instance.isDead)) && MathUtil.InRange(this.transform.position, CrashController.instance.transform.position, this.fleeRadius))
					{
						this.RunFromCrash();
						if (this.FacingCrash())
						{
							this.JumpThrowRock();
							return;
						}
					}
				}
				else
				{
					self.AddVelocity_Y(-this.gravityForce * Time.fixedDeltaTime);
					if (this.IsAnimationState(this.animHit) && this.IsAnimationFinished())
					{
						this.SetVelocity_X(0f);
					}
				}
			}
		};
	}

	// Token: 0x060002FE RID: 766 RVA: 0x0000D049 File Offset: 0x0000B249
	private BossPhase CreateFallbackPhase()
	{
		return new BossPhase("Fallback")
		{
			PhaseEnter = delegate(CreatorBoss self, BossPhase ctx)
			{
				this.animator.Play(this.animDefeated);
			},
			Evaluate = delegate(CreatorBoss self, BossPhase ctx)
			{
				if (self.MoveResult.Grounded)
				{
					self.SetVelocity(0f, 0f);
					return;
				}
				self.AddVelocity_Y(-this.gravityForce * Time.fixedDeltaTime);
			}
		};
	}

	// Token: 0x060002FF RID: 767 RVA: 0x0000D07C File Offset: 0x0000B27C
	private bool FacingCrash()
	{
		return Vector3.Dot(base.transform.forward, (CrashController.instance.transform.position - base.transform.position).normalized) < 0f;
	}

	// Token: 0x06000300 RID: 768 RVA: 0x0000D0C7 File Offset: 0x0000B2C7
	public void SpawnProjectile()
	{
		if (this.isDead)
		{
			return;
		}
		if (this.projectilesThrown <= this.projectileCount + this.phaseIndex)
		{
			this.projectilesThrown++;
			this.ForceSpawnProjectile();
		}
	}

	// Token: 0x06000301 RID: 769 RVA: 0x0000D0FC File Offset: 0x0000B2FC
	private void JumpThrowRock()
	{
		Projectile p = Object.Instantiate<Projectile>(this.potentialProjectiles[0], this.spawnNode.position - base.transform.TransformVector(this.projectilePrefab.spawnOffset), this.spawnNode.rotation, LevelManager.instance.projectileHolder);
		this.PostProcessProjectile(p);
		if (!string.IsNullOrEmpty(this.fireSFX))
		{
			AudioManager.Play(this.fireSFX, AudioManager.MixerTarget.SFX, new Vector3?(this.spawnNode.position), null);
		}
	}

	// Token: 0x06000302 RID: 770 RVA: 0x0000D18C File Offset: 0x0000B38C
	private void ForceSpawnProjectile()
	{
		Projectile p;
		if (Level.instance)
		{
			p = Object.Instantiate<Projectile>(this.projectilePrefab, this.spawnNode.position - base.transform.TransformVector(this.projectilePrefab.spawnOffset), this.spawnNode.rotation, Level.instance.transform);
		}
		else if (LevelManager.instance)
		{
			p = Object.Instantiate<Projectile>(this.projectilePrefab, this.spawnNode.position - base.transform.TransformVector(this.projectilePrefab.spawnOffset), this.spawnNode.rotation, LevelManager.instance.projectileHolder);
		}
		else
		{
			p = Object.Instantiate<Projectile>(this.projectilePrefab, this.spawnNode.position - base.transform.TransformVector(this.projectilePrefab.spawnOffset), this.spawnNode.rotation);
		}
		this.PostProcessProjectile(p);
		if (!string.IsNullOrEmpty(this.fireSFX))
		{
			AudioManager.Play(this.fireSFX, AudioManager.MixerTarget.SFX, new Vector3?(this.spawnNode.position), null);
		}
	}

	// Token: 0x06000303 RID: 771 RVA: 0x0000D2C0 File Offset: 0x0000B4C0
	private void RunFromCrash()
	{
		float x = CrashController.instance.transform.position.x;
		float x2 = base.transform.position.x;
		base.SetVelocity((x > x2) ? (-this.movementSpeed) : this.movementSpeed, this.bounceImpulse);
		this.animator.Play(this.animJump, 0, 0f);
		this.tLastJumped = Clock.SynchronizedTime;
	}

	// Token: 0x06000304 RID: 772 RVA: 0x0000D334 File Offset: 0x0000B534
	private void UpdateFacing()
	{
		float x = CrashController.instance.transform.position.x;
		float x2 = base.transform.position.x;
		if (x > x2)
		{
			this.facing = -1;
			return;
		}
		if (x < x2)
		{
			this.facing = 1;
		}
	}

	// Token: 0x06000305 RID: 773 RVA: 0x0000D37E File Offset: 0x0000B57E
	public void TryFlex()
	{
		if (this.projectilesThrown == this.projectileCount + this.phaseIndex)
		{
			this.animator.Play(this.animFlex);
		}
	}

	// Token: 0x06000306 RID: 774 RVA: 0x0000D3A6 File Offset: 0x0000B5A6
	public override void ResetEntity()
	{
		this._phases = null;
		this.projectilesThrown = 0;
		this.tLastJumped = 0f;
		base.ResetEntity();
	}

	// Token: 0x06000307 RID: 775 RVA: 0x0000D3C7 File Offset: 0x0000B5C7
	protected override void OnEnable()
	{
		base.OnEnable();
		if (this.isDead)
		{
			this.animator.Play(this.animDefeated, 0, 1f);
		}
	}

	// Token: 0x06000308 RID: 776 RVA: 0x0000D3EE File Offset: 0x0000B5EE
	protected virtual void PostProcessProjectile(Projectile p)
	{
		p.flightSpeed += 1f;
		if (base.IsAnimationState(this.animJump))
		{
			p.transform.LookAt(CrashController.instance.transform.position);
		}
	}

	// Token: 0x06000309 RID: 777 RVA: 0x0000D42A File Offset: 0x0000B62A
	public void ProcessMetadata(ProjectileMetadata meta)
	{
		this.projectilePrefab = this.potentialProjectiles[(int)meta.projectileIndex];
		if (this.projectilePreVisuals.Length != 0)
		{
			this.SetProjectilePrevisuals((int)meta.projectileIndex);
		}
	}

	// Token: 0x0600030A RID: 778 RVA: 0x0000D454 File Offset: 0x0000B654
	private void SetProjectilePrevisuals(int index)
	{
		GameObject[] array = this.projectilePreVisuals;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(false);
		}
		this.projectilePreVisuals[index].SetActive(true);
	}

	// Token: 0x0600030B RID: 779 RVA: 0x0000D490 File Offset: 0x0000B690
	public void ProcessMetadata(SpeedMetadata meta)
	{
		float num = 0.5f;
		float num2 = 2f;
		this.throwSpeed = (float)meta.speed / 5f * (num2 - num) + num;
	}

	// Token: 0x0600030C RID: 780 RVA: 0x0000D4C2 File Offset: 0x0000B6C2
	public void ProcessMetadata(KongQuickThrowMetadata meta)
	{
		this.quickThrow = meta.value;
	}

	// Token: 0x040001C7 RID: 455
	[SerializeField]
	private CharacterController cc;

	// Token: 0x040001C8 RID: 456
	public Transform spawnNode;

	// Token: 0x040001C9 RID: 457
	public Projectile projectilePrefab;

	// Token: 0x040001CA RID: 458
	public string fireSFX;

	// Token: 0x040001CB RID: 459
	public Projectile[] potentialProjectiles;

	// Token: 0x040001CC RID: 460
	public GameObject[] projectilePreVisuals;

	// Token: 0x040001CD RID: 461
	[SerializeField]
	private int projectileCount = 3;

	// Token: 0x040001CE RID: 462
	private int projectilesThrown;

	// Token: 0x040001CF RID: 463
	[SerializeField]
	private float fleeRadius = 6f;

	// Token: 0x040001D0 RID: 464
	[SerializeField]
	private float movementSpeed = 1.5f;

	// Token: 0x040001D1 RID: 465
	[SerializeField]
	private float bounceImpulse = 6.5f;

	// Token: 0x040001D2 RID: 466
	[SerializeField]
	private float hitKnockback = 2f;

	// Token: 0x040001D3 RID: 467
	[SerializeField]
	private float gravityForce = 10f;

	// Token: 0x040001D4 RID: 468
	[SerializeField]
	private float jumpInterval = 4f;

	// Token: 0x040001D5 RID: 469
	[Header("Animations")]
	[SerializeField]
	private string animLift = "Koala Kong Lift";

	// Token: 0x040001D6 RID: 470
	[SerializeField]
	private string animThrow = "Koala Kong Throw";

	// Token: 0x040001D7 RID: 471
	[SerializeField]
	private string animFlex = "Koala Kong Flex";

	// Token: 0x040001D8 RID: 472
	[SerializeField]
	private string animHit = "Koala Kong Hit";

	// Token: 0x040001D9 RID: 473
	[SerializeField]
	private string animRecover = "Koala Kong Recover";

	// Token: 0x040001DA RID: 474
	[SerializeField]
	private string animJump = "Koala Kong Jump";

	// Token: 0x040001DB RID: 475
	[SerializeField]
	private string animSidestep = "Koala Kong Sidestep";

	// Token: 0x040001DC RID: 476
	[SerializeField]
	private string animSidestepBoulder = "Koala Kong SidestepBoulder";

	// Token: 0x040001DD RID: 477
	[SerializeField]
	private string animDefeated = "Koala Kong Defeated";

	// Token: 0x040001DE RID: 478
	[Header("Sounds")]
	[SerializeField]
	private string hitSound = "SFX_BossImpact";

	// Token: 0x040001DF RID: 479
	private IMover _mover;

	// Token: 0x040001E0 RID: 480
	private BossPhase[] _phases;

	// Token: 0x040001E1 RID: 481
	private BossPhase _fallbackPhase;

	// Token: 0x040001E2 RID: 482
	private int facing;

	// Token: 0x040001E3 RID: 483
	private float tLastJumped;

	// Token: 0x040001E4 RID: 484
	private float throwSpeed = 1f;

	// Token: 0x040001E5 RID: 485
	public bool quickThrow;
}
