﻿using System;
using UnityEngine;

// Token: 0x0200012B RID: 299
public class SpitterPlant : EnemyWithProjectile, IMetadataReceiver<RangeMetadata>
{
	// Token: 0x060008EC RID: 2284 RVA: 0x00024F68 File Offset: 0x00023168
	protected override void FixedUpdate()
	{
		base.FixedUpdate();
		this.CrashSearch();
		if (!this._cower)
		{
			this._t += Time.fixedDeltaTime;
			if (this._t >= this.spitPeriod)
			{
				this._t -= this.spitPeriod;
				this.animator.SetTrigger("Spit");
			}
		}
	}

	// Token: 0x060008ED RID: 2285 RVA: 0x00024FCC File Offset: 0x000231CC
	protected override void PostProcessProjectile(Projectile p)
	{
		p.flightSpeed = (float)this.projectileStrength / 5f * (this.projectileStrengthRange.y - this.projectileStrengthRange.x) + this.projectileStrengthRange.x;
	}

	// Token: 0x060008EE RID: 2286 RVA: 0x00025005 File Offset: 0x00023205
	public override void TouchTop(CrashController crash)
	{
		crash.ArrowBounce(true);
	}

	// Token: 0x060008EF RID: 2287 RVA: 0x0002500E File Offset: 0x0002320E
	public override void Spin(CrashController crash)
	{
		if (base.IsAbove(crash))
		{
			this.TouchTop(crash);
			return;
		}
		crash.Deflect(base.transform);
	}

	// Token: 0x060008F0 RID: 2288 RVA: 0x00025030 File Offset: 0x00023230
	private void CrashSearch()
	{
		bool flag = false;
		Collider[] array = Physics.OverlapSphere(this.collider.bounds.center, this.cowerDistance, LayerMask.GetMask(new string[]
		{
			"Player"
		}));
		for (int i = 0; i < array.Length; i++)
		{
			CrashController crashController;
			if (array[i].TryGetComponent<CrashController>(out crashController))
			{
				flag = true;
				break;
			}
		}
		if (this._cower != flag)
		{
			this._cower = flag;
			if (this._cower)
			{
				this._t = 0f;
			}
			this.headCollider.SetActive(!this._cower);
			this.animator.SetBool("Cower", this._cower);
		}
	}

	// Token: 0x060008F1 RID: 2289 RVA: 0x000250DC File Offset: 0x000232DC
	public override void ResetEntity()
	{
		base.ResetEntity();
		this._t = 0f;
	}

	// Token: 0x060008F2 RID: 2290 RVA: 0x000250EF File Offset: 0x000232EF
	public void ProcessMetadata(RangeMetadata meta)
	{
		this.projectileStrength = (int)meta.range;
	}

	// Token: 0x04000688 RID: 1672
	public GameObject headCollider;

	// Token: 0x04000689 RID: 1673
	public float spitPeriod = 3f;

	// Token: 0x0400068A RID: 1674
	public float cowerDistance = 5f;

	// Token: 0x0400068B RID: 1675
	[Range(0f, 4f)]
	public int projectileStrength = 2;

	// Token: 0x0400068C RID: 1676
	public Vector2 projectileStrengthRange;

	// Token: 0x0400068D RID: 1677
	private float _t;

	// Token: 0x0400068E RID: 1678
	private bool _cower;
}
