﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using LevelEditor;

// Token: 0x02000026 RID: 38
public class ConnectionsMetadata : ObjectMetadata
{
	// Token: 0x1700001B RID: 27
	// (get) Token: 0x060000C7 RID: 199 RVA: 0x00005AB4 File Offset: 0x00003CB4
	public IReadOnlyList<LevelObj> Connections
	{
		get
		{
			return this.connections;
		}
	}

	// Token: 0x1700001C RID: 28
	// (get) Token: 0x060000C8 RID: 200 RVA: 0x00005ABC File Offset: 0x00003CBC
	public override bool SupportsMultiEditing
	{
		get
		{
			return false;
		}
	}

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x060000C9 RID: 201 RVA: 0x00005ABF File Offset: 0x00003CBF
	public override int Signature
	{
		get
		{
			return "ConnectionsMetadata".GetHashCode();
		}
	}

	// Token: 0x1700001E RID: 30
	// (get) Token: 0x060000CA RID: 202 RVA: 0x00005ACB File Offset: 0x00003CCB
	public override int ValueHash
	{
		get
		{
			return this.valueHash;
		}
	}

	// Token: 0x060000CB RID: 203 RVA: 0x00005AD4 File Offset: 0x00003CD4
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write((short)this.connections.Count);
		for (int i = 0; i < this.connections.Count; i++)
		{
			bw.Write((short)this.connections[i].gridPosX);
			bw.Write((short)this.connections[i].gridPosY);
		}
	}

	// Token: 0x060000CC RID: 204 RVA: 0x00005B3C File Offset: 0x00003D3C
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.valueHash = 0;
		this.connections.ToList<LevelObj>().ForEach(delegate(LevelObj obj)
		{
			this.RemoveConnection(obj);
		});
		int num = (int)br.ReadInt16();
		for (int i = 0; i < num; i++)
		{
			short num2 = br.ReadInt16();
			short num3 = br.ReadInt16();
			this.AddConnection(grid[(int)num2, (int)num3].placedObj);
		}
	}

	// Token: 0x060000CD RID: 205 RVA: 0x00005BA0 File Offset: 0x00003DA0
	public override void Apply(LevelObj obj)
	{
		this.connections.ForEach(delegate(LevelObj c)
		{
			c.SetOutline();
		});
		this.removed.ForEach(delegate(LevelObj c)
		{
			if (c)
			{
				c.SetOutline();
			}
		});
		this.removed.Clear();
		IMetadataReceiver<ConnectionsMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<ConnectionsMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x060000CE RID: 206 RVA: 0x00005C2B File Offset: 0x00003E2B
	public override void OnDeleted(LevelObj obj)
	{
		this.connections.ToList<LevelObj>().ForEach(delegate(LevelObj c)
		{
			this.RemoveConnection(c);
		});
		this.Apply(obj);
	}

	// Token: 0x060000CF RID: 207 RVA: 0x00005C50 File Offset: 0x00003E50
	public void AddConnection(LevelObj obj)
	{
		if (this.connections.Contains(obj))
		{
			return;
		}
		this.connections.Add(obj);
		this.valueHash ^= obj.GetHashCode();
		obj.OnObjDeleted += this.ObjDeletedCallback;
		obj.activatorConnections += 1;
	}

	// Token: 0x060000D0 RID: 208 RVA: 0x00005CAC File Offset: 0x00003EAC
	public void RemoveConnection(LevelObj obj)
	{
		if (this.connections.Remove(obj))
		{
			this.removed.Add(obj);
			this.valueHash ^= obj.GetHashCode();
			obj.OnObjDeleted -= this.ObjDeletedCallback;
			obj.activatorConnections -= 1;
		}
	}

	// Token: 0x060000D1 RID: 209 RVA: 0x00005D08 File Offset: 0x00003F08
	public void ReplaceConnection(LevelObj oldObj, LevelObj newObj)
	{
		int num = this.connections.IndexOf(oldObj);
		if (num != -1)
		{
			this.connections[num] = newObj;
			this.removed.Add(oldObj);
			this.valueHash ^= oldObj.GetHashCode();
			this.valueHash ^= newObj.GetHashCode();
			oldObj.OnObjDeleted -= this.ObjDeletedCallback;
			oldObj.activatorConnections -= 1;
			newObj.OnObjDeleted += this.ObjDeletedCallback;
			newObj.activatorConnections += 1;
		}
	}

	// Token: 0x060000D2 RID: 210 RVA: 0x00005DAA File Offset: 0x00003FAA
	private void ObjDeletedCallback(LevelObj obj)
	{
		this.RemoveConnection(obj);
		this.Apply(base.GetComponent<LevelObj>());
	}

	// Token: 0x060000D3 RID: 211 RVA: 0x00005DBF File Offset: 0x00003FBF
	public override string ToString()
	{
		return string.Join<LevelObj>(", ", this.connections);
	}

	// Token: 0x04000084 RID: 132
	private readonly List<LevelObj> connections = new List<LevelObj>();

	// Token: 0x04000085 RID: 133
	private readonly List<LevelObj> removed = new List<LevelObj>();

	// Token: 0x04000086 RID: 134
	private int valueHash;
}
