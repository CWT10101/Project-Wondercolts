﻿using System;
using UnityEngine;

// Token: 0x0200004D RID: 77
public class CheckForIdle : MonoBehaviour
{
	// Token: 0x0600020B RID: 523 RVA: 0x00009430 File Offset: 0x00007630
	public void CheckForTransitionToIdle()
	{
		if (this.crash.input.sqrMagnitude <= 0f)
		{
			this.crash.animator.SetState(this.crash.animator.idleObj, false);
		}
	}

	// Token: 0x0400011B RID: 283
	public CrashController crash;
}
