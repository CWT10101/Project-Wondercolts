﻿using System;
using UnityEngine;

// Token: 0x02000112 RID: 274
public class SewerLightBlock : Entity
{
	// Token: 0x06000872 RID: 2162 RVA: 0x000236A2 File Offset: 0x000218A2
	public override void ResetEntity()
	{
		this.SetOn(false);
		base.ResetEntity();
	}

	// Token: 0x06000873 RID: 2163 RVA: 0x000236B1 File Offset: 0x000218B1
	private void SetOn(bool isOn)
	{
		this.onVisual.SetActive(isOn);
		this.offVisual.SetActive(!isOn);
	}

	// Token: 0x0400062D RID: 1581
	public GameObject onVisual;

	// Token: 0x0400062E RID: 1582
	public GameObject offVisual;
}
