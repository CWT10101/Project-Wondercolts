﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000EF RID: 239
public class NitroCrate : TNTCrate, ITouchSide, ITouchTop
{
	// Token: 0x170000F5 RID: 245
	// (get) Token: 0x06000755 RID: 1877 RVA: 0x0001EE4C File Offset: 0x0001D04C
	public static HashSet<NitroCrate> Crates { get; } = new HashSet<NitroCrate>();

	// Token: 0x06000756 RID: 1878 RVA: 0x0001EE53 File Offset: 0x0001D053
	protected override void OnEnable()
	{
		base.OnEnable();
		NitroCrate.Crates.Add(this);
		this.PlayIdleAudio();
	}

	// Token: 0x06000757 RID: 1879 RVA: 0x0001EE70 File Offset: 0x0001D070
	private void PlayIdleAudio()
	{
		this.idleAudioSrc.PlayDelayed(Random.Range(0f, this.idleAudioSrc.clip.length));
		this.idleAudioSrc.pitch = Random.Range(0.95f, 1f);
		this.idleAudioSrc.volume = Random.Range(0.5f, 1f);
	}

	// Token: 0x06000758 RID: 1880 RVA: 0x0001EED6 File Offset: 0x0001D0D6
	private void OnDisable()
	{
		NitroCrate.Crates.Remove(this);
	}

	// Token: 0x06000759 RID: 1881 RVA: 0x0001EEE4 File Offset: 0x0001D0E4
	public override void FallOn(CrashController crash)
	{
		this.Explode();
	}

	// Token: 0x0600075A RID: 1882 RVA: 0x0001EEEC File Offset: 0x0001D0EC
	public override void TouchBottom(CrashController crash)
	{
		this.Explode();
	}

	// Token: 0x0600075B RID: 1883 RVA: 0x0001EEF4 File Offset: 0x0001D0F4
	public virtual void TouchTop(CrashController crash)
	{
		this.Explode();
	}

	// Token: 0x0600075C RID: 1884 RVA: 0x0001EEFC File Offset: 0x0001D0FC
	public virtual void TouchSide(CrashController crash)
	{
		this.Explode();
	}

	// Token: 0x0600075D RID: 1885 RVA: 0x0001EF04 File Offset: 0x0001D104
	public override void Slide(CrashController crash)
	{
		if (!base.IsAbove(crash) && !base.IsBelow(crash))
		{
			this.Explode();
		}
	}

	// Token: 0x0600075E RID: 1886 RVA: 0x0001EF1E File Offset: 0x0001D11E
	public override void Light()
	{
		this.Explode();
	}

	// Token: 0x0600075F RID: 1887 RVA: 0x0001EF26 File Offset: 0x0001D126
	public override void Explode()
	{
		base.Explode();
		this.idleAudioSrc.enabled = false;
	}

	// Token: 0x06000760 RID: 1888 RVA: 0x0001EF3A File Offset: 0x0001D13A
	public override void ResetEntity()
	{
		base.ResetEntity();
		this.idleAudioSrc.enabled = true;
	}

	// Token: 0x04000569 RID: 1385
	public AudioSource idleAudioSrc;
}
