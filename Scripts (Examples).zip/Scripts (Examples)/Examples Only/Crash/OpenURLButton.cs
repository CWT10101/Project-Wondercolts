﻿using System;
using UnityEngine;

// Token: 0x02000151 RID: 337
public class OpenURLButton : MonoBehaviour
{
	// Token: 0x060009E2 RID: 2530 RVA: 0x00027C43 File Offset: 0x00025E43
	private void Start()
	{
		if (Application.internetReachability == NetworkReachability.NotReachable)
		{
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x060009E3 RID: 2531 RVA: 0x00027C58 File Offset: 0x00025E58
	public void OpenURLHook()
	{
		if (Application.internetReachability != NetworkReachability.NotReachable)
		{
			Application.OpenURL(this.url);
		}
	}

	// Token: 0x0400071B RID: 1819
	public string url;
}
