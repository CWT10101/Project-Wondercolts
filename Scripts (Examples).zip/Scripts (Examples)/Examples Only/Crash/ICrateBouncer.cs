﻿using System;

// Token: 0x020000C5 RID: 197
public interface ICrateBouncer
{
	// Token: 0x06000605 RID: 1541
	void BounceCrate(Crate crate);
}
