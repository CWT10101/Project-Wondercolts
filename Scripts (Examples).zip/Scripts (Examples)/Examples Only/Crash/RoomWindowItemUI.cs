﻿using System;
using LevelEditor3D;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200000F RID: 15
public class RoomWindowItemUI : MonoBehaviour
{
	// Token: 0x17000004 RID: 4
	// (get) Token: 0x06000041 RID: 65 RVA: 0x000034AD File Offset: 0x000016AD
	// (set) Token: 0x06000042 RID: 66 RVA: 0x000034B5 File Offset: 0x000016B5
	public Room Room { get; private set; }

	// Token: 0x06000043 RID: 67 RVA: 0x000034BE File Offset: 0x000016BE
	public RoomWindowItemUI Init(Room room, ToggleGroup toggleGroup)
	{
		this.Room = room;
		this.label.text = room.DisplayName;
		this.graphic.sprite = room.DisplayIcon;
		this.toggle.group = toggleGroup;
		return this;
	}

	// Token: 0x04000038 RID: 56
	public TMP_Text label;

	// Token: 0x04000039 RID: 57
	public Image graphic;

	// Token: 0x0400003A RID: 58
	public Toggle toggle;
}
