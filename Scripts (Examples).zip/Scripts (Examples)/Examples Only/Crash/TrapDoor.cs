﻿using System;
using UnityEngine;

// Token: 0x0200013A RID: 314
public class TrapDoor : MonoBehaviour
{
	// Token: 0x06000958 RID: 2392 RVA: 0x000261F0 File Offset: 0x000243F0
	public virtual void FixedUpdate()
	{
		this.leftDoor.transform.position = Vector3.Lerp(this.pointALeft.position, this.pointBLeft.position, this.speedCurve.Evaluate(Time.time + this.offset));
		this.rightDoor.transform.position = Vector3.Lerp(this.pointARight.position, this.pointBRight.position, this.speedCurve.Evaluate(Time.time + this.offset));
	}

	// Token: 0x040006CF RID: 1743
	public GameObject leftDoor;

	// Token: 0x040006D0 RID: 1744
	public GameObject rightDoor;

	// Token: 0x040006D1 RID: 1745
	public Transform pointALeft;

	// Token: 0x040006D2 RID: 1746
	public Transform pointBLeft;

	// Token: 0x040006D3 RID: 1747
	public Transform pointARight;

	// Token: 0x040006D4 RID: 1748
	public Transform pointBRight;

	// Token: 0x040006D5 RID: 1749
	public AnimationCurve speedCurve;

	// Token: 0x040006D6 RID: 1750
	public float offset;
}
