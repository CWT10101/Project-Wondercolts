﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x0200013E RID: 318
public class Tribesman : BasicEnemy
{
	// Token: 0x1700011E RID: 286
	// (get) Token: 0x06000966 RID: 2406 RVA: 0x000263E0 File Offset: 0x000245E0
	private float DefaultHeight
	{
		get
		{
			if (this._defaultHeight != -1f)
			{
				return this._defaultHeight;
			}
			return this._defaultHeight = this.controller.height;
		}
	}

	// Token: 0x06000967 RID: 2407 RVA: 0x00026415 File Offset: 0x00024615
	protected override void Awake()
	{
		base.Awake();
		this.shieldCollider.enabled = false;
	}

	// Token: 0x06000968 RID: 2408 RVA: 0x00026429 File Offset: 0x00024629
	protected override void OnEnable()
	{
		base.OnEnable();
		this._dir = base.Direction;
		base.transform.rotation = Quaternion.LookRotation(this._dir);
	}

	// Token: 0x06000969 RID: 2409 RVA: 0x00026454 File Offset: 0x00024654
	protected override void FixedUpdate()
	{
		if (this.isDead)
		{
			return;
		}
		if (this.externalForce.sqrMagnitude > 0f)
		{
			this.externalForce = Vector3.MoveTowards(this.externalForce, Vector3.zero, Time.fixedDeltaTime * 2f);
		}
		base.FixedUpdate();
		if (this.state == Tribesman.State.Walking)
		{
			this.timer -= Time.deltaTime;
			if (this.timer <= 0f)
			{
				this.timer = 0f;
				this.CalmDown();
			}
		}
		else if (this.state == Tribesman.State.Idle)
		{
			this.SightCheck();
		}
		else if (this.state == Tribesman.State.Shielding)
		{
			this.shieldIdleTime -= Time.deltaTime;
			if (this.shieldIdleTime <= 0f)
			{
				this.shieldIdleTime = 0f;
				this.CalmDown();
			}
		}
		base.FixedUpdate();
	}

	// Token: 0x0600096A RID: 2410 RVA: 0x0002652D File Offset: 0x0002472D
	public override void TouchTop(CrashController crash)
	{
		crash.Bounce();
		this.ShieldUp();
	}

	// Token: 0x0600096B RID: 2411 RVA: 0x0002653B File Offset: 0x0002473B
	public override void TouchSide(CrashController crash)
	{
		if (this.IsInFront(crash.transform))
		{
			crash.Deflect(base.transform);
			return;
		}
		base.TouchSide(crash);
	}

	// Token: 0x0600096C RID: 2412 RVA: 0x0002655F File Offset: 0x0002475F
	public override void Slide(CrashController crash)
	{
		if (this.state == Tribesman.State.Shielding)
		{
			base.Slide(crash);
			return;
		}
		if (this.IsInFront(crash.transform))
		{
			crash.Deflect(base.transform);
			return;
		}
		base.Slide(crash);
	}

	// Token: 0x0600096D RID: 2413 RVA: 0x00026594 File Offset: 0x00024794
	public override void Spin(CrashController crash)
	{
		if (this.state == Tribesman.State.Shielding)
		{
			base.Spin(crash);
			return;
		}
		if (this.IsInFront(crash.transform))
		{
			this.Deflect(crash.transform);
			return;
		}
		base.Slide(crash);
	}

	// Token: 0x0600096E RID: 2414 RVA: 0x000265CC File Offset: 0x000247CC
	private void Deflect(Transform other)
	{
		this.externalForce = Vector3.Scale(base.transform.position - other.position, new Vector3(1f, 0f, 1f)).normalized;
	}

	// Token: 0x0600096F RID: 2415 RVA: 0x00026618 File Offset: 0x00024818
	public virtual void SightCheck()
	{
		Vector3 vector = new Vector3(this.collider.bounds.center.x, this.collider.bounds.min.y + this.eyeHeight, this.collider.bounds.center.z);
		foreach (Collider collider in Physics.OverlapSphere(vector, this.sightDistance))
		{
			Debug.DrawLine(vector, collider.bounds.center, new Color(0f, 1f, 0f, 0.1f), Time.fixedDeltaTime);
			CrashController crashController;
			if (collider.TryGetComponent<CrashController>(out crashController))
			{
				Debug.DrawLine(vector, collider.bounds.center, new Color(0f, 1f, 0f), Time.fixedDeltaTime);
				Vector3 normalized = (collider.bounds.center - vector).normalized;
				if (Vector3.Dot(normalized, this._dir.normalized) > 0.5f)
				{
					Debug.DrawLine(vector, collider.bounds.center, new Color(1f, 1f, 0f), Time.fixedDeltaTime);
					RaycastHit raycastHit;
					if (Physics.Raycast(vector, normalized, out raycastHit, this.sightDistance))
					{
						Debug.DrawLine(vector, raycastHit.point, new Color(1f, 0f, 0f), Time.fixedDeltaTime);
						if (raycastHit.collider == collider)
						{
							this.Panic();
							return;
						}
					}
				}
			}
		}
	}

	// Token: 0x06000970 RID: 2416 RVA: 0x000267C8 File Offset: 0x000249C8
	public virtual void Panic()
	{
		if (!this.isDead && this.state != Tribesman.State.Walking)
		{
			this.state = Tribesman.State.Walking;
			this.timer = 10f;
			this.animator.SetTrigger("Triggered");
			base.StartCoroutine(this.<Panic>g__PanicRoutine|21_0());
		}
	}

	// Token: 0x06000971 RID: 2417 RVA: 0x00026818 File Offset: 0x00024A18
	public virtual void CalmDown()
	{
		if (this.state != Tribesman.State.Idle)
		{
			this.state = Tribesman.State.Idle;
			this.speed = 0f;
			this.animator.SetTrigger("Calm");
			base.transform.rotation = Quaternion.LookRotation(this._dir);
		}
	}

	// Token: 0x06000972 RID: 2418 RVA: 0x00026868 File Offset: 0x00024A68
	public void ShieldUp()
	{
		if (this.state != Tribesman.State.Shielding)
		{
			this.state = Tribesman.State.Shielding;
			this.speed = 0f;
			this.animator.SetTrigger("Shield");
			this.shieldCollider.enabled = true;
			this.SetColliderHeight(this.shieldedHeight);
		}
		this.shieldIdleTime = 3f;
	}

	// Token: 0x06000973 RID: 2419 RVA: 0x000268C4 File Offset: 0x00024AC4
	private void SetColliderHeight(float h)
	{
		this.controller.height = h;
		Vector3 center = this.controller.center;
		center.y = h / 2f;
		this.controller.center = center;
	}

	// Token: 0x06000974 RID: 2420 RVA: 0x00026903 File Offset: 0x00024B03
	public override void ResetEntity()
	{
		base.ResetEntity();
		this.state = Tribesman.State.Idle;
		this.timer = 0f;
		this.shieldCollider.enabled = false;
		this.SetColliderHeight(this.DefaultHeight);
		this.speed = 0f;
	}

	// Token: 0x06000975 RID: 2421 RVA: 0x00026940 File Offset: 0x00024B40
	private bool IsInFront(Transform other)
	{
		Vector3 position = other.position;
		position.y = base.transform.position.y;
		return Vector3.Dot(base.transform.forward, (position - base.transform.position).normalized) > 0f;
	}

	// Token: 0x06000977 RID: 2423 RVA: 0x000269F1 File Offset: 0x00024BF1
	[CompilerGenerated]
	private IEnumerator <Panic>g__PanicRoutine|21_0()
	{
		yield return new WaitForSeconds(0.1f);
		this.speed = this.panicSpeed;
		yield break;
	}

	// Token: 0x040006DC RID: 1756
	public Collider shieldCollider;

	// Token: 0x040006DD RID: 1757
	public float panicSpeed = 2f;

	// Token: 0x040006DE RID: 1758
	public float sightDistance = 5f;

	// Token: 0x040006DF RID: 1759
	public float eyeHeight = 1.5f;

	// Token: 0x040006E0 RID: 1760
	public float shieldedHeight = 1f;

	// Token: 0x040006E1 RID: 1761
	public Tribesman.State state;

	// Token: 0x040006E2 RID: 1762
	[HideInInspector]
	public float timer;

	// Token: 0x040006E3 RID: 1763
	private float shieldIdleTime = 3f;

	// Token: 0x040006E4 RID: 1764
	private float _defaultHeight = -1f;

	// Token: 0x0200023C RID: 572
	public enum State
	{
		// Token: 0x04000D93 RID: 3475
		Idle,
		// Token: 0x04000D94 RID: 3476
		Walking,
		// Token: 0x04000D95 RID: 3477
		Shielding
	}
}
