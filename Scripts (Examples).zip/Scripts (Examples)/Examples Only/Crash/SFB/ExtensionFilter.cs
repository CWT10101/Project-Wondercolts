﻿using System;

namespace SFB
{
	// Token: 0x02000169 RID: 361
	public struct ExtensionFilter
	{
		// Token: 0x06000A4B RID: 2635 RVA: 0x000290D5 File Offset: 0x000272D5
		public ExtensionFilter(string filterName, params string[] filterExtensions)
		{
			this.Name = filterName;
			this.Extensions = filterExtensions;
		}

		// Token: 0x04000767 RID: 1895
		public string Name;

		// Token: 0x04000768 RID: 1896
		public string[] Extensions;
	}
}
