﻿using System;

namespace SFB
{
	// Token: 0x02000168 RID: 360
	public interface IStandaloneFileBrowser
	{
		// Token: 0x06000A45 RID: 2629
		string[] OpenFilePanel(string title, string directory, ExtensionFilter[] extensions, bool multiselect);

		// Token: 0x06000A46 RID: 2630
		string[] OpenFolderPanel(string title, string directory, bool multiselect);

		// Token: 0x06000A47 RID: 2631
		string SaveFilePanel(string title, string directory, string defaultName, ExtensionFilter[] extensions);

		// Token: 0x06000A48 RID: 2632
		void OpenFilePanelAsync(string title, string directory, ExtensionFilter[] extensions, bool multiselect, Action<string[]> cb);

		// Token: 0x06000A49 RID: 2633
		void OpenFolderPanelAsync(string title, string directory, bool multiselect, Action<string[]> cb);

		// Token: 0x06000A4A RID: 2634
		void SaveFilePanelAsync(string title, string directory, string defaultName, ExtensionFilter[] extensions, Action<string> cb);
	}
}
