﻿using System;
using System.Windows.Forms;

namespace SFB
{
	// Token: 0x0200016B RID: 363
	public class WindowWrapper : IWin32Window
	{
		// Token: 0x06000A58 RID: 2648 RVA: 0x00029273 File Offset: 0x00027473
		public WindowWrapper(IntPtr handle)
		{
			this._hwnd = handle;
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x06000A59 RID: 2649 RVA: 0x00029282 File Offset: 0x00027482
		public IntPtr Handle
		{
			get
			{
				return this._hwnd;
			}
		}

		// Token: 0x0400076A RID: 1898
		private IntPtr _hwnd;
	}
}
