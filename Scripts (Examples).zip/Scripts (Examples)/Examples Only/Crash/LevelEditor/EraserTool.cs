﻿using System;
using LevelEditor3D;

namespace LevelEditor
{
	// Token: 0x020001BD RID: 445
	public class EraserTool : EditorTool
	{
		// Token: 0x17000442 RID: 1090
		// (get) Token: 0x0600115A RID: 4442 RVA: 0x0003DE82 File Offset: 0x0003C082
		public override bool PrimaryIsContinuous
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000443 RID: 1091
		// (get) Token: 0x0600115B RID: 4443 RVA: 0x0003DE85 File Offset: 0x0003C085
		public override bool SecondaryIsContinuous
		{
			get
			{
				return false;
			}
		}

		// Token: 0x0600115C RID: 4444 RVA: 0x0003DE88 File Offset: 0x0003C088
		public override void PrimaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
			if (LevelCreator.instance)
			{
				LevelCreator.DeleteObjectAtMouse();
				return;
			}
			if (LevelBuilder.Instance)
			{
				LevelBuilder.Instance.DeleteObject();
			}
		}

		// Token: 0x0600115D RID: 4445 RVA: 0x0003DEB2 File Offset: 0x0003C0B2
		public override void SecondaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
		}
	}
}
