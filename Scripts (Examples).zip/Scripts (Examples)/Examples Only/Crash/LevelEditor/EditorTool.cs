﻿using System;
using UnityEngine;

namespace LevelEditor
{
	// Token: 0x020001AB RID: 427
	public abstract class EditorTool : MonoBehaviour
	{
		// Token: 0x1700042A RID: 1066
		// (get) Token: 0x0600108C RID: 4236
		public abstract bool PrimaryIsContinuous { get; }

		// Token: 0x1700042B RID: 1067
		// (get) Token: 0x0600108D RID: 4237
		public abstract bool SecondaryIsContinuous { get; }

		// Token: 0x0600108E RID: 4238
		public abstract void PrimaryAction(EditorTool.ToolPhase phase, float timeActive);

		// Token: 0x0600108F RID: 4239
		public abstract void SecondaryAction(EditorTool.ToolPhase phase, float timeActive);

		// Token: 0x06001090 RID: 4240 RVA: 0x0003A034 File Offset: 0x00038234
		public virtual void OnToolEnabled()
		{
		}

		// Token: 0x06001091 RID: 4241 RVA: 0x0003A036 File Offset: 0x00038236
		public virtual void OnToolDisabled()
		{
		}

		// Token: 0x02000283 RID: 643
		public enum ToolState
		{
			// Token: 0x04000EBA RID: 3770
			Idle,
			// Token: 0x04000EBB RID: 3771
			Primary,
			// Token: 0x04000EBC RID: 3772
			Secondary
		}

		// Token: 0x02000284 RID: 644
		public enum ToolPhase
		{
			// Token: 0x04000EBE RID: 3774
			Idle,
			// Token: 0x04000EBF RID: 3775
			Begin,
			// Token: 0x04000EC0 RID: 3776
			Hold,
			// Token: 0x04000EC1 RID: 3777
			End
		}
	}
}
