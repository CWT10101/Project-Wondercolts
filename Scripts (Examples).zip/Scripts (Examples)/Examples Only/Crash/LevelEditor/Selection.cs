﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace LevelEditor
{
	// Token: 0x020001B6 RID: 438
	public class Selection : MonoBehaviour
	{
		// Token: 0x17000437 RID: 1079
		// (get) Token: 0x06001120 RID: 4384 RVA: 0x0003CCE4 File Offset: 0x0003AEE4
		// (set) Token: 0x06001121 RID: 4385 RVA: 0x0003CCEB File Offset: 0x0003AEEB
		public static Selection instance { get; private set; }

		// Token: 0x06001122 RID: 4386 RVA: 0x0003CCF3 File Offset: 0x0003AEF3
		private void Awake()
		{
			Selection.instance = this;
		}

		// Token: 0x06001123 RID: 4387 RVA: 0x0003CCFB File Offset: 0x0003AEFB
		private void OnDestroy()
		{
			Selection.instance = null;
		}

		// Token: 0x17000438 RID: 1080
		// (get) Token: 0x06001124 RID: 4388 RVA: 0x0003CD03 File Offset: 0x0003AF03
		// (set) Token: 0x06001125 RID: 4389 RVA: 0x0003CD0B File Offset: 0x0003AF0B
		public Transform Transit { get; private set; }

		// Token: 0x17000439 RID: 1081
		// (get) Token: 0x06001126 RID: 4390 RVA: 0x0003CD14 File Offset: 0x0003AF14
		// (set) Token: 0x06001127 RID: 4391 RVA: 0x0003CD1C File Offset: 0x0003AF1C
		public bool InTransit { get; private set; }

		// Token: 0x1700043A RID: 1082
		// (get) Token: 0x06001128 RID: 4392 RVA: 0x0003CD25 File Offset: 0x0003AF25
		public static int Count
		{
			get
			{
				if (!Selection.instance)
				{
					return 0;
				}
				return Selection.instance.selection.Count;
			}
		}

		// Token: 0x06001129 RID: 4393 RVA: 0x0003CD44 File Offset: 0x0003AF44
		public static void Include(LevelObj obj)
		{
			if (!Selection.instance)
			{
				return;
			}
			if (Selection.instance.selection.Add(obj))
			{
				obj.OnObjDeleted += Selection.Exclude;
				obj.Select(false);
			}
		}

		// Token: 0x0600112A RID: 4394 RVA: 0x0003CD80 File Offset: 0x0003AF80
		public static void Include(IEnumerable<LevelObj> objs)
		{
			if (!Selection.instance)
			{
				return;
			}
			if (objs == null)
			{
				return;
			}
			foreach (LevelObj obj in objs)
			{
				Selection.Include(obj);
			}
		}

		// Token: 0x0600112B RID: 4395 RVA: 0x0003CDD8 File Offset: 0x0003AFD8
		public static void Exclude(LevelObj obj)
		{
			if (!Selection.instance)
			{
				return;
			}
			if (Selection.instance.selection.Remove(obj))
			{
				obj.OnObjDeleted -= Selection.Exclude;
				obj.Deselect();
			}
		}

		// Token: 0x0600112C RID: 4396 RVA: 0x0003CE14 File Offset: 0x0003B014
		public static void DeselectAll()
		{
			if (!Selection.instance)
			{
				return;
			}
			foreach (LevelObj levelObj in Selection.instance.selection)
			{
				levelObj.OnObjDeleted -= Selection.Exclude;
				levelObj.Deselect();
			}
			Selection.instance.selection.Clear();
		}

		// Token: 0x0600112D RID: 4397 RVA: 0x0003CE98 File Offset: 0x0003B098
		public static bool Contains(LevelObj obj)
		{
			return Selection.instance && Selection.instance.selection.Contains(obj);
		}

		// Token: 0x0600112E RID: 4398 RVA: 0x0003CEB8 File Offset: 0x0003B0B8
		public static IEnumerable<LevelObj> Enumerate()
		{
			if (!Selection.instance)
			{
				return null;
			}
			return Selection.instance.selection;
		}

		// Token: 0x0600112F RID: 4399 RVA: 0x0003CED4 File Offset: 0x0003B0D4
		public static void MoveToTransit()
		{
			if (!Selection.instance)
			{
				return;
			}
			IEnumerable<LevelObj> enumerable = Selection.Enumerate();
			LevelObj levelObj = enumerable.FirstOrDefault<LevelObj>();
			if (levelObj == null)
			{
				return;
			}
			Selection.instance.InTransit = true;
			float num = (float)levelObj.gridPosX;
			float num2 = (float)levelObj.gridPosY;
			float num3 = (float)levelObj.gridPosX;
			float num4 = (float)levelObj.gridPosY;
			foreach (LevelObj levelObj2 in enumerable)
			{
				if ((float)levelObj2.gridPosX < num)
				{
					num = (float)levelObj2.gridPosX;
				}
				else if ((float)levelObj2.gridPosX > num3)
				{
					num3 = (float)levelObj2.gridPosX;
				}
				if ((float)levelObj2.gridPosY < num2)
				{
					num2 = (float)levelObj2.gridPosY;
				}
				else if ((float)levelObj2.gridPosY > num4)
				{
					num4 = (float)levelObj2.gridPosY;
				}
			}
			Selection.instance.Transit.position = new Vector3(num + (num3 - num) / 2f, num2 + (num4 - num2) / 2f, -1f);
			foreach (LevelObj levelObj3 in enumerable)
			{
				levelObj3.transform.SetParent(Selection.instance.Transit, true);
				GridManager.instance.grid[levelObj3.gridPosX, levelObj3.gridPosY].placedObj = null;
				levelObj3.Select(true);
			}
			Selection.instance.Transit.Translate(Vector3.forward);
		}

		// Token: 0x06001130 RID: 4400 RVA: 0x0003D084 File Offset: 0x0003B284
		public static void CancelTransit()
		{
			if (!Selection.instance)
			{
				return;
			}
			Selection.instance.InTransit = false;
			foreach (LevelObj levelObj in Selection.Enumerate())
			{
				Tile tile = GridManager.instance.grid[levelObj.gridPosX, levelObj.gridPosY];
				levelObj.transform.SetParent(LevelManager.instance.levelObjectsHolder);
				levelObj.transform.position = tile.Position;
				tile.placedObj = levelObj;
				levelObj.Select(false);
			}
		}

		// Token: 0x06001131 RID: 4401 RVA: 0x0003D134 File Offset: 0x0003B334
		public static void CommitTransit()
		{
			if (!Selection.instance)
			{
				return;
			}
			Selection.instance.InTransit = false;
			foreach (LevelObj levelObj in Selection.Enumerate())
			{
				bool flag;
				Tile tile = GridManager.instance.TileFromWorldPosition(levelObj.transform.position, out flag);
				if (flag)
				{
					if (tile.placedObj)
					{
						LevelCreator.DeleteObject(tile);
					}
					levelObj.transform.SetParent(LevelManager.instance.levelObjectsHolder);
					levelObj.transform.position = tile.Position;
					levelObj.gridPosX = tile.posX;
					levelObj.gridPosY = tile.posY;
					tile.placedObj = levelObj;
					levelObj.Select(false);
					ObjectMetadata[] metadata = levelObj.GetMetadata();
					for (int i = 0; i < metadata.Length; i++)
					{
						metadata[i].Apply(levelObj);
					}
				}
				else
				{
					LevelCreator.DeleteObject(levelObj);
				}
			}
		}

		// Token: 0x04000B6D RID: 2925
		private readonly HashSet<LevelObj> selection = new HashSet<LevelObj>();
	}
}
