﻿using System;
using System.IO;

namespace LevelEditor
{
	// Token: 0x020001B0 RID: 432
	public class SaveableLevelObject
	{
		// Token: 0x04000B54 RID: 2900
		public string obj_ID;

		// Token: 0x04000B55 RID: 2901
		public int posX;

		// Token: 0x04000B56 RID: 2902
		public int posY;

		// Token: 0x04000B57 RID: 2903
		public MemoryStream metaStream;
	}
}
