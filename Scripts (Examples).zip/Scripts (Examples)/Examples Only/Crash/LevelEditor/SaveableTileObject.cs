﻿using System;

namespace LevelEditor
{
	// Token: 0x020001B9 RID: 441
	[Serializable]
	public class SaveableTileObject
	{
		// Token: 0x04000B72 RID: 2930
		public int posX;

		// Token: 0x04000B73 RID: 2931
		public int posY;
	}
}
