﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace LevelEditor
{
	// Token: 0x020001B3 RID: 435
	public class LevelResourcesManager : MonoBehaviour
	{
		// Token: 0x06001119 RID: 4377 RVA: 0x0003CBCE File Offset: 0x0003ADCE
		private void Awake()
		{
			LevelResourcesManager.instance = this;
		}

		// Token: 0x0600111A RID: 4378 RVA: 0x0003CBD8 File Offset: 0x0003ADD8
		public LevelGameObjectBase GetObjBase(string ObjID)
		{
			LevelGameObjectBase result = null;
			for (int i = 0; i < this.levelGameObjects.Count; i++)
			{
				if (ObjID.Equals(this.levelGameObjects[i].obj_ID))
				{
					result = this.levelGameObjects[i];
					break;
				}
			}
			return result;
		}

		// Token: 0x04000B5D RID: 2909
		public static LevelResourcesManager instance;

		// Token: 0x04000B5E RID: 2910
		public LevelObjDatabase database;

		// Token: 0x04000B5F RID: 2911
		public List<LevelGameObjectBase> levelGameObjects = new List<LevelGameObjectBase>();

		// Token: 0x04000B60 RID: 2912
		public List<Material> skyboxMaterials = new List<Material>();

		// Token: 0x04000B61 RID: 2913
		public List<string> backgroundSongs = new List<string>();

		// Token: 0x04000B62 RID: 2914
		public DynamicLevelObjButton dynamicLevelObjButton;

		// Token: 0x04000B63 RID: 2915
		public LevelObjButton levelObjButton;

		// Token: 0x04000B64 RID: 2916
		public LevelObjSelectionToggle levelObjSelectionToggle;

		// Token: 0x04000B65 RID: 2917
		public Color selectionColorNormal;

		// Token: 0x04000B66 RID: 2918
		public Color selectionColorTransit;
	}
}
