﻿using System;

namespace LevelEditor
{
	// Token: 0x020001BE RID: 446
	public class PanTool : EditorTool
	{
		// Token: 0x17000444 RID: 1092
		// (get) Token: 0x0600115F RID: 4447 RVA: 0x0003DEBC File Offset: 0x0003C0BC
		public override bool PrimaryIsContinuous
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000445 RID: 1093
		// (get) Token: 0x06001160 RID: 4448 RVA: 0x0003DEBF File Offset: 0x0003C0BF
		public override bool SecondaryIsContinuous
		{
			get
			{
				return false;
			}
		}

		// Token: 0x06001161 RID: 4449 RVA: 0x0003DEC2 File Offset: 0x0003C0C2
		public override void PrimaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
		}

		// Token: 0x06001162 RID: 4450 RVA: 0x0003DEC4 File Offset: 0x0003C0C4
		public override void SecondaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
		}
	}
}
