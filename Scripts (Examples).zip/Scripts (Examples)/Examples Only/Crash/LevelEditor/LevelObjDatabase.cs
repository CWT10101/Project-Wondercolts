﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace LevelEditor
{
	// Token: 0x020001B1 RID: 433
	public class LevelObjDatabase : MonoBehaviour
	{
		// Token: 0x06001110 RID: 4368 RVA: 0x0003CA04 File Offset: 0x0003AC04
		private void Start()
		{
			this.db = new Database<LevelObj>();
			this.db.Initialize(from lgo in LevelResourcesManager.instance.levelGameObjects
			select lgo.objPrefab.GetComponent<DBDescriptor>() into x
			where x && (x.IsSecret || !x.ExcludeFromDatabase)
			select x);
		}

		// Token: 0x06001111 RID: 4369 RVA: 0x0003CA7C File Offset: 0x0003AC7C
		public void Search(string query)
		{
			query = query.ToLowerInvariant();
			HashSet<LevelObj> hashSet = new HashSet<LevelObj>();
			HashSet<LevelObj> hashSet2 = new HashSet<LevelObj>();
			this.db.Search(query, hashSet, hashSet2);
			Action<IEnumerable<LevelObj>> action = this.onSearchFinished;
			if (action == null)
			{
				return;
			}
			action(hashSet.Concat(hashSet2));
		}

		// Token: 0x04000B58 RID: 2904
		private Database<LevelObj> db;

		// Token: 0x04000B59 RID: 2905
		public Action<IEnumerable<LevelObj>> onSearchFinished;
	}
}
