﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace LevelEditor
{
	// Token: 0x020001AA RID: 426
	public class EditorGizmos : MonoBehaviour
	{
		// Token: 0x17000429 RID: 1065
		// (get) Token: 0x06001083 RID: 4227 RVA: 0x00039F06 File Offset: 0x00038106
		// (set) Token: 0x06001084 RID: 4228 RVA: 0x00039F0D File Offset: 0x0003810D
		public static EditorGizmos instance { get; private set; }

		// Token: 0x06001085 RID: 4229 RVA: 0x00039F15 File Offset: 0x00038115
		private void Awake()
		{
			EditorGizmos.instance = this;
		}

		// Token: 0x06001086 RID: 4230 RVA: 0x00039F1D File Offset: 0x0003811D
		private void OnDestroy()
		{
			EditorGizmos.instance = null;
		}

		// Token: 0x06001087 RID: 4231 RVA: 0x00039F25 File Offset: 0x00038125
		private void Start()
		{
			this.canvas.worldCamera = Camera.main;
		}

		// Token: 0x06001088 RID: 4232 RVA: 0x00039F38 File Offset: 0x00038138
		public static Guid CreateGizmo(Vector3 worldPos, Action<EditorGizmo, PointerEventData> onDrag = null, Action<EditorGizmo> onBeginDrag = null, Action<EditorGizmo> onEndDrag = null, Action<EditorGizmo> onLeftClick = null, Action<EditorGizmo> onRightClick = null, GizmoStyle style = null, object meta = null)
		{
			EditorGizmo editorGizmo = Object.Instantiate<EditorGizmo>(EditorGizmos.instance.gizmoPrefab, worldPos, Quaternion.identity, EditorGizmos.instance.canvas.transform);
			editorGizmo.onDrag = onDrag;
			editorGizmo.onBeginDrag = onBeginDrag;
			editorGizmo.onEndDrag = onEndDrag;
			editorGizmo.onLeftClick = onLeftClick;
			editorGizmo.onRightClick = onRightClick;
			editorGizmo.meta = meta;
			if (style != null)
			{
				editorGizmo.ApplyStyle(style);
			}
			if (onDrag == null && onBeginDrag == null && onEndDrag == null)
			{
				editorGizmo.graphic.raycastTarget = false;
			}
			Guid guid = Guid.NewGuid();
			EditorGizmos.instance.Gizmos.Add(guid, editorGizmo);
			return guid;
		}

		// Token: 0x06001089 RID: 4233 RVA: 0x00039FD0 File Offset: 0x000381D0
		public static bool TryGetGizmo(Guid id, out EditorGizmo gizmo)
		{
			return EditorGizmos.instance.Gizmos.TryGetValue(id, out gizmo);
		}

		// Token: 0x0600108A RID: 4234 RVA: 0x00039FE4 File Offset: 0x000381E4
		public static void DestroyGizmo(Guid id)
		{
			EditorGizmo editorGizmo;
			if (EditorGizmos.instance.Gizmos.TryGetValue(id, out editorGizmo))
			{
				Object.Destroy(editorGizmo.gameObject);
				EditorGizmos.instance.Gizmos.Remove(id);
			}
		}

		// Token: 0x04000AC0 RID: 2752
		public Canvas canvas;

		// Token: 0x04000AC1 RID: 2753
		public EditorGizmo gizmoPrefab;

		// Token: 0x04000AC2 RID: 2754
		private readonly Dictionary<Guid, EditorGizmo> Gizmos = new Dictionary<Guid, EditorGizmo>();
	}
}
