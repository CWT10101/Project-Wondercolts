﻿using System;

namespace LevelEditor
{
	// Token: 0x020001B7 RID: 439
	public abstract class SubTool<TSuper> : EditorTool where TSuper : EditorTool
	{
		// Token: 0x04000B6E RID: 2926
		public TSuper superTool;
	}
}
