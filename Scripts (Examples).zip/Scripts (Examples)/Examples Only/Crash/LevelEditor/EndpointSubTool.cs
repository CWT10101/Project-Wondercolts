﻿using System;
using UnityEngine;

namespace LevelEditor
{
	// Token: 0x020001BC RID: 444
	public class EndpointSubTool : SubTool<SelectTool>
	{
		// Token: 0x17000440 RID: 1088
		// (get) Token: 0x06001152 RID: 4434 RVA: 0x0003DBD7 File Offset: 0x0003BDD7
		public override bool PrimaryIsContinuous
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000441 RID: 1089
		// (get) Token: 0x06001153 RID: 4435 RVA: 0x0003DBDA File Offset: 0x0003BDDA
		public override bool SecondaryIsContinuous
		{
			get
			{
				return false;
			}
		}

		// Token: 0x06001154 RID: 4436 RVA: 0x0003DBE0 File Offset: 0x0003BDE0
		public override void PrimaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
			if (phase == EditorTool.ToolPhase.End)
			{
				return;
			}
			Tile tile;
			if (LevelCreator.GetTileAtMouse(out tile))
			{
				foreach (EndpointMetadata endpointMetadata in this.endpoints)
				{
					if (!tile.placedObj || tile.placedObj != ObjectInfoPanel.Context[endpointMetadata])
					{
						endpointMetadata.SetPosition(tile.posX, tile.posY);
						endpointMetadata.Apply(ObjectInfoPanel.Context[endpointMetadata]);
						EditorGizmo editorGizmo;
						if (EditorGizmos.TryGetGizmo(this.gizmoId, out editorGizmo))
						{
							editorGizmo.transform.position = endpointMetadata.Position - Vector3.forward;
						}
						else
						{
							this.gizmoId = EditorGizmos.CreateGizmo(endpointMetadata.Position - Vector3.forward, null, null, null, null, null, null, null);
						}
						this.RefreshLine(endpointMetadata);
					}
				}
			}
		}

		// Token: 0x06001155 RID: 4437 RVA: 0x0003DCD4 File Offset: 0x0003BED4
		public override void SecondaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
			if (phase == EditorTool.ToolPhase.End)
			{
				return;
			}
			Tile tile;
			if (LevelCreator.GetTileAtMouse(out tile))
			{
				foreach (EndpointMetadata endpointMetadata in this.endpoints)
				{
					if (endpointMetadata.Position.x == tile.posX && endpointMetadata.Position.y == tile.posY)
					{
						endpointMetadata.ClearPosition();
						endpointMetadata.Apply(ObjectInfoPanel.Context[endpointMetadata]);
						EditorGizmos.DestroyGizmo(this.gizmoId);
						this.RefreshLine(endpointMetadata);
					}
				}
			}
		}

		// Token: 0x06001156 RID: 4438 RVA: 0x0003DD60 File Offset: 0x0003BF60
		public override void OnToolEnabled()
		{
			ObjectInfoPanel.GetMeta<EndpointMetadata>(out this.endpoints);
			foreach (EndpointMetadata endpointMetadata in this.endpoints)
			{
				if (endpointMetadata.HasData)
				{
					this.gizmoId = EditorGizmos.CreateGizmo(endpointMetadata.Position - Vector3.forward, null, null, null, null, null, null, null);
				}
				this.RefreshLine(endpointMetadata);
			}
		}

		// Token: 0x06001157 RID: 4439 RVA: 0x0003DDCD File Offset: 0x0003BFCD
		public override void OnToolDisabled()
		{
			this.endpoints = null;
			EditorGizmos.DestroyGizmo(this.gizmoId);
			this.lineRen.enabled = false;
		}

		// Token: 0x06001158 RID: 4440 RVA: 0x0003DDF0 File Offset: 0x0003BFF0
		private void RefreshLine(EndpointMetadata e)
		{
			if (e.HasData)
			{
				this.lineRen.enabled = true;
				this.lineRen.SetPosition(0, ObjectInfoPanel.Context[e].transform.position - Vector3.forward);
				this.lineRen.SetPosition(1, e.Position - Vector3.forward);
				return;
			}
			this.lineRen.enabled = false;
		}

		// Token: 0x04000B7B RID: 2939
		public LineRenderer lineRen;

		// Token: 0x04000B7C RID: 2940
		private EndpointMetadata[] endpoints;

		// Token: 0x04000B7D RID: 2941
		private Guid gizmoId = Guid.Empty;
	}
}
