﻿using System;
using LevelEditor3D;

namespace LevelEditor
{
	// Token: 0x020001BF RID: 447
	public class PencilTool : EditorTool
	{
		// Token: 0x17000446 RID: 1094
		// (get) Token: 0x06001164 RID: 4452 RVA: 0x0003DECE File Offset: 0x0003C0CE
		public override bool PrimaryIsContinuous
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000447 RID: 1095
		// (get) Token: 0x06001165 RID: 4453 RVA: 0x0003DED1 File Offset: 0x0003C0D1
		public override bool SecondaryIsContinuous
		{
			get
			{
				return true;
			}
		}

		// Token: 0x06001166 RID: 4454 RVA: 0x0003DED4 File Offset: 0x0003C0D4
		public override void PrimaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
			if (phase == EditorTool.ToolPhase.End)
			{
				return;
			}
			if (LevelCreator.instance)
			{
				LevelCreator.PlaceObjectAtMouse();
				return;
			}
			if (LevelBuilder.Instance)
			{
				LevelBuilder.Instance.PlaceObject();
			}
		}

		// Token: 0x06001167 RID: 4455 RVA: 0x0003DF04 File Offset: 0x0003C104
		public override void SecondaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
			if (phase == EditorTool.ToolPhase.End)
			{
				if (LevelCreator.instance)
				{
					LevelCreator.instance.showClone = true;
				}
				return;
			}
			if (phase == EditorTool.ToolPhase.Begin && LevelCreator.instance)
			{
				LevelCreator.instance.showClone = false;
			}
			if (LevelCreator.instance)
			{
				LevelCreator.DeleteObjectAtMouse();
				return;
			}
			if (LevelBuilder.Instance)
			{
				LevelBuilder.Instance.DeleteObject();
			}
		}

		// Token: 0x06001168 RID: 4456 RVA: 0x0003DF70 File Offset: 0x0003C170
		public override void OnToolEnabled()
		{
			if (LevelCreator.instance)
			{
				LevelCreator.instance.showClone = true;
			}
		}

		// Token: 0x06001169 RID: 4457 RVA: 0x0003DF89 File Offset: 0x0003C189
		public override void OnToolDisabled()
		{
			if (LevelCreator.instance)
			{
				LevelCreator.instance.showClone = false;
			}
		}
	}
}
