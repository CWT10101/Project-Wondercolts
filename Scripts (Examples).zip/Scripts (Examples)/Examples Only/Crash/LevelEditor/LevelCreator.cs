﻿using System;
using Rewired;
using UnityEngine;
using UnityEngine.Events;

namespace LevelEditor
{
	// Token: 0x020001AC RID: 428
	public class LevelCreator : MonoBehaviour
	{
		// Token: 0x1700042C RID: 1068
		// (get) Token: 0x06001093 RID: 4243 RVA: 0x0003A040 File Offset: 0x00038240
		// (set) Token: 0x06001094 RID: 4244 RVA: 0x0003A048 File Offset: 0x00038248
		public EditorTool ActiveTool { get; private set; }

		// Token: 0x1700042D RID: 1069
		// (get) Token: 0x06001095 RID: 4245 RVA: 0x0003A051 File Offset: 0x00038251
		// (set) Token: 0x06001096 RID: 4246 RVA: 0x0003A058 File Offset: 0x00038258
		public static Vector3 MousePos { get; private set; }

		// Token: 0x06001097 RID: 4247 RVA: 0x0003A060 File Offset: 0x00038260
		private void Awake()
		{
			LevelCreator.instance = this;
			this.rwInput = ReInput.players.GetPlayer(0);
		}

		// Token: 0x06001098 RID: 4248 RVA: 0x0003A079 File Offset: 0x00038279
		private void Start()
		{
			this.gridManager = GridManager.instance;
			this.levelManager = LevelManager.instance;
			this.ui = LevelInterfaceManager.instance;
			if (this.ActiveTool)
			{
				this.ActiveTool.OnToolEnabled();
			}
		}

		// Token: 0x06001099 RID: 4249 RVA: 0x0003A0B4 File Offset: 0x000382B4
		private void Update()
		{
			if (this.levelManager.inEditorMode)
			{
				this.UpdateMousePosition();
				this.HandleClone();
				this.RunTool();
			}
		}

		// Token: 0x0600109A RID: 4250 RVA: 0x0003A0D8 File Offset: 0x000382D8
		public void UpdateMousePosition()
		{
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			float distance;
			if (new Plane(Vector3.back, Vector3.zero).Raycast(ray, out distance))
			{
				LevelCreator.MousePos = ray.GetPoint(distance);
			}
		}

		// Token: 0x0600109B RID: 4251 RVA: 0x0003A120 File Offset: 0x00038320
		private void HandleClone()
		{
			if (!this.showClone || !this.objToPlace || LevelInterfaceManager.instance.mouseOverUI)
			{
				if (this.cloneObj != null)
				{
					Object.Destroy(this.cloneObj);
				}
				return;
			}
			bool flag;
			Tile tile = GridManager.instance.TileFromWorldPosition(LevelCreator.MousePos, out flag);
			if (!flag)
			{
				this.ClearCloneObj();
				return;
			}
			this.worldPos = tile.Position;
			if (this.cloneObj == null)
			{
				this.cloneObj = Object.Instantiate<GameObject>(this.objToPlace, this.worldPos + new Vector3(0f, 0f, -0.1f), Quaternion.identity);
				this.objProperties = this.cloneObj.GetComponent<LevelObj>();
				return;
			}
			this.cloneObj.transform.position = this.worldPos + new Vector3(0f, 0f, -0.1f);
		}

		// Token: 0x0600109C RID: 4252 RVA: 0x0003A21D File Offset: 0x0003841D
		public void SetTool(EditorTool tool)
		{
			if (this.ActiveTool == tool)
			{
				return;
			}
			this.ActiveTool.OnToolDisabled();
			this.ActiveTool = tool;
			this.ActiveTool.OnToolEnabled();
			this.ActiveToolState = EditorTool.ToolState.Idle;
		}

		// Token: 0x0600109D RID: 4253 RVA: 0x0003A254 File Offset: 0x00038454
		private void RunTool()
		{
			if (!this.ActiveTool)
			{
				return;
			}
			if (this.ActiveToolState != EditorTool.ToolState.Primary && this.rwInput.GetButtonDown("ToolPrimary") && !LevelInterfaceManager.instance.mouseOverUI)
			{
				this.ActiveToolState = EditorTool.ToolState.Primary;
				this.ActiveToolPhase = EditorTool.ToolPhase.Begin;
				this.tUsedTool = Time.timeSinceLevelLoad;
			}
			else if (this.ActiveToolState != EditorTool.ToolState.Secondary && this.rwInput.GetButtonDown("ToolSecondary") && !LevelInterfaceManager.instance.mouseOverUI)
			{
				this.ActiveToolState = EditorTool.ToolState.Secondary;
				this.ActiveToolPhase = EditorTool.ToolPhase.Begin;
				this.tUsedTool = Time.timeSinceLevelLoad;
			}
			else if (this.ActiveToolState == EditorTool.ToolState.Primary && (!this.ActiveTool.PrimaryIsContinuous || this.rwInput.GetButtonUp("ToolPrimary") || LevelInterfaceManager.instance.mouseOverUI))
			{
				this.ActiveToolPhase = EditorTool.ToolPhase.End;
			}
			else if (this.ActiveToolState == EditorTool.ToolState.Secondary && (!this.ActiveTool.SecondaryIsContinuous || this.rwInput.GetButtonUp("ToolSecondary") || LevelInterfaceManager.instance.mouseOverUI))
			{
				this.ActiveToolPhase = EditorTool.ToolPhase.End;
			}
			if (this.ActiveToolState == EditorTool.ToolState.Primary)
			{
				this.ActiveTool.PrimaryAction(this.ActiveToolPhase, Time.timeSinceLevelLoad - this.tUsedTool);
			}
			else if (this.ActiveToolState == EditorTool.ToolState.Secondary)
			{
				this.ActiveTool.SecondaryAction(this.ActiveToolPhase, Time.timeSinceLevelLoad - this.tUsedTool);
			}
			if (this.ActiveToolPhase == EditorTool.ToolPhase.Begin)
			{
				this.ActiveToolPhase = EditorTool.ToolPhase.Hold;
				return;
			}
			if (this.ActiveToolPhase == EditorTool.ToolPhase.End)
			{
				this.ActiveToolState = EditorTool.ToolState.Idle;
				this.ActiveToolPhase = EditorTool.ToolPhase.Idle;
				this.tUsedTool = 0f;
			}
		}

		// Token: 0x0600109E RID: 4254 RVA: 0x0003A3F0 File Offset: 0x000385F0
		public static bool GetTileAtMouse(out Tile tile)
		{
			bool result;
			tile = GridManager.instance.TileFromWorldPosition(LevelCreator.MousePos, out result);
			return result;
		}

		// Token: 0x0600109F RID: 4255 RVA: 0x0003A414 File Offset: 0x00038614
		public static void PlaceObjectAtMouse()
		{
			bool flag;
			Tile tile = GridManager.instance.TileFromWorldPosition(LevelCreator.MousePos, out flag);
			if (flag)
			{
				LevelCreator.PlaceObject(tile);
			}
		}

		// Token: 0x060010A0 RID: 4256 RVA: 0x0003A43C File Offset: 0x0003863C
		public static void PlaceObject(Tile tile)
		{
			if (LevelCreator.instance.objToPlace == null)
			{
				return;
			}
			if (tile.placedObj != null)
			{
				LevelCreator.instance.levelManager.inSceneLevelObjects.Remove(tile.placedObj.gameObject);
				Object.Destroy(tile.placedObj.gameObject);
				tile.placedObj = null;
			}
			GameObject gameObject = Object.Instantiate<GameObject>(LevelCreator.instance.objToPlace, tile.Position, LevelCreator.instance.objToPlace.transform.rotation);
			gameObject.transform.parent = LevelCreator.instance.levelManager.levelObjectsHolder;
			LevelObj component = gameObject.GetComponent<LevelObj>();
			component.gridPosX = tile.posX;
			component.gridPosY = tile.posY;
			tile.placedObj = component;
			LevelCreator.instance.levelManager.inSceneLevelObjects.Add(gameObject);
			if (component.IsSingularInstance)
			{
				foreach (LevelObj levelObj in Object.FindObjectsOfType<LevelObj>())
				{
					if (levelObj.gameObject != gameObject && levelObj.gameObject != LevelCreator.instance.cloneObj && ((!string.IsNullOrWhiteSpace(component.obj_instanceGroup) && component.obj_instanceGroup == levelObj.obj_instanceGroup) || levelObj.obj_ID == component.obj_ID))
					{
						if (component.obj_ID == "Obj_CrashSpawnPoint")
						{
							CrashSpawner.instance.crashSpawnPoint.transform.position = gameObject.transform.position;
						}
						LevelManager.instance.inSceneLevelObjects.Remove(levelObj.gameObject);
						Object.Destroy(levelObj.gameObject);
					}
				}
			}
		}

		// Token: 0x060010A1 RID: 4257 RVA: 0x0003A600 File Offset: 0x00038800
		public void PassGameObjectToPlace(string objID)
		{
			if (this.cloneObj != null)
			{
				Object.Destroy(this.cloneObj);
				this.cloneObj = null;
			}
			this.objToPlace = LevelResourcesManager.instance.GetObjBase(objID).objPrefab;
			LevelInterfaceManager.instance.drawToggle.isOn = true;
		}

		// Token: 0x060010A2 RID: 4258 RVA: 0x0003A653 File Offset: 0x00038853
		public void ClearCloneObj()
		{
			if (this.cloneObj != null)
			{
				Object.Destroy(this.cloneObj);
			}
			this.cloneObj = null;
		}

		// Token: 0x060010A3 RID: 4259 RVA: 0x0003A678 File Offset: 0x00038878
		public static void DeleteObjectAtMouse()
		{
			bool flag;
			Tile tile = GridManager.instance.TileFromWorldPosition(LevelCreator.MousePos, out flag);
			if (flag)
			{
				LevelCreator.DeleteObject(tile);
			}
		}

		// Token: 0x060010A4 RID: 4260 RVA: 0x0003A6A0 File Offset: 0x000388A0
		public static void DeleteObject(Tile tile)
		{
			if (tile.placedObj != null && LevelCreator.instance.levelManager.inSceneLevelObjects.Contains(tile.placedObj.gameObject))
			{
				LevelCreator.DeleteObject(tile.placedObj);
			}
		}

		// Token: 0x060010A5 RID: 4261 RVA: 0x0003A6DC File Offset: 0x000388DC
		public static void DeleteObject(LevelObj obj)
		{
			Object.Instantiate<BrokenCrate>(ResourceManager.instance.brokenCrate, obj.transform.position, Quaternion.identity);
			AudioManager.Play("SFX_Scrap", AudioManager.MixerTarget.SFX, null, null);
			LevelCreator.instance.levelManager.inSceneLevelObjects.Remove(obj.gameObject);
			Object.Destroy(obj.gameObject);
		}

		// Token: 0x060010A6 RID: 4262 RVA: 0x0003A750 File Offset: 0x00038950
		public void EraseAll()
		{
			LevelInterfaceManager.instance.warningScreen.SetWarningText("ERASE ALL", "Warning, are you sure you want to erase all objects in the level?");
			UIScreen.Focus(LevelInterfaceManager.instance.warningScreen.screen);
			LevelInterfaceManager.instance.warningScreen.confirmActionButton.onClick.RemoveAllListeners();
			LevelInterfaceManager.instance.warningScreen.confirmActionButton.onClick.AddListener(new UnityAction(this.levelManager.ClearSceneObjects));
			LevelInterfaceManager.instance.warningScreen.confirmActionButton.onClick.AddListener(new UnityAction(LevelInterfaceManager.instance.warningScreen.ConfirmAction));
			LevelInterfaceManager.instance.warningScreen.confirmActionButton.onClick.AddListener(new UnityAction(this.PlayClickSound));
		}

		// Token: 0x060010A7 RID: 4263 RVA: 0x0003A820 File Offset: 0x00038A20
		public void PlayClickSound()
		{
			AudioManager.Play("clickUI", AudioManager.MixerTarget.UI, null, null);
		}

		// Token: 0x060010A8 RID: 4264 RVA: 0x0003A84C File Offset: 0x00038A4C
		public void TryNewLevel()
		{
			LevelInterfaceManager.instance.warningScreen.SetWarningText("NEW LEVEL", "Warning, are you sure you want to clear everything and start a fresh new level?");
			UIScreen.Focus(LevelInterfaceManager.instance.warningScreen.screen);
			LevelInterfaceManager.instance.warningScreen.confirmActionButton.onClick.RemoveAllListeners();
			LevelInterfaceManager.instance.warningScreen.confirmActionButton.onClick.AddListener(new UnityAction(this.NewLevel));
			LevelInterfaceManager.instance.warningScreen.confirmActionButton.onClick.AddListener(new UnityAction(LevelInterfaceManager.instance.warningScreen.ConfirmAction));
			LevelInterfaceManager.instance.warningScreen.confirmActionButton.onClick.AddListener(new UnityAction(this.PlayClickSound));
		}

		// Token: 0x060010A9 RID: 4265 RVA: 0x0003A918 File Offset: 0x00038B18
		public void NewLevel()
		{
			LevelManager.instance.ClearSceneObjects();
			LevelInterfaceManager.instance.saveInputField.text = "";
			LevelInterfaceManager.instance.levelAuthorInputField.text = "";
			LevelInterfaceManager.instance.musicDropdown.SetValueWithoutNotify(0);
			LevelInterfaceManager.instance.levelStats.ClearStats();
			LevelInterfaceManager.instance.SetSceneryContent(0);
			LevelInterfaceManager.instance.SetSkyboxContent(0);
			InterfaceManager.instance.SetTitleAndAuthor("", "");
		}

		// Token: 0x04000AC4 RID: 2756
		public static LevelCreator instance;

		// Token: 0x04000AC5 RID: 2757
		private GridManager gridManager;

		// Token: 0x04000AC6 RID: 2758
		private LevelManager levelManager;

		// Token: 0x04000AC7 RID: 2759
		private LevelInterfaceManager ui;

		// Token: 0x04000AC9 RID: 2761
		public EditorTool.ToolState ActiveToolState;

		// Token: 0x04000ACA RID: 2762
		public EditorTool.ToolPhase ActiveToolPhase;

		// Token: 0x04000ACB RID: 2763
		private float tUsedTool;

		// Token: 0x04000ACC RID: 2764
		private GameObject objToPlace;

		// Token: 0x04000ACD RID: 2765
		[HideInInspector]
		public GameObject cloneObj;

		// Token: 0x04000ACE RID: 2766
		private LevelObj objProperties;

		// Token: 0x04000AD0 RID: 2768
		private Vector3 worldPos;

		// Token: 0x04000AD1 RID: 2769
		public bool showClone;

		// Token: 0x04000AD2 RID: 2770
		private Player rwInput;
	}
}
