﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;

namespace LevelEditor
{
	// Token: 0x020001BA RID: 442
	public class ActivatorSubTool : SubTool<SelectTool>
	{
		// Token: 0x1700043B RID: 1083
		// (get) Token: 0x06001138 RID: 4408 RVA: 0x0003D2A8 File Offset: 0x0003B4A8
		public override bool PrimaryIsContinuous
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700043C RID: 1084
		// (get) Token: 0x06001139 RID: 4409 RVA: 0x0003D2AB File Offset: 0x0003B4AB
		public override bool SecondaryIsContinuous
		{
			get
			{
				return false;
			}
		}

		// Token: 0x0600113A RID: 4410 RVA: 0x0003D2B0 File Offset: 0x0003B4B0
		public override void PrimaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
			if (phase == EditorTool.ToolPhase.End)
			{
				return;
			}
			Tile tile;
			if (LevelCreator.GetTileAtMouse(out tile))
			{
				foreach (ConnectionsMetadata connectionsMetadata in this.connections)
				{
					if (!connectionsMetadata.Connections.Contains(tile.placedObj))
					{
						bool flag = ObjectInfoPanel.Context[connectionsMetadata].GetComponentInChildren<TimedActivatorCrate>(true);
						if (tile.placedObj && tile.placedObj != ObjectInfoPanel.Context[connectionsMetadata])
						{
							Crate componentInChildren = tile.placedObj.GetComponentInChildren<Crate>(true);
							if (componentInChildren != null && !(componentInChildren is ColourCrate) && (!flag || !(componentInChildren is CheckpointCrate)))
							{
								connectionsMetadata.AddConnection(tile.placedObj);
								if (flag)
								{
									componentInChildren.SetOutlineColor(Color.red);
								}
								this.gizmoIds.Add(EditorGizmos.CreateGizmo(tile.placedObj.transform.position - Vector3.forward, new Action<EditorGizmo, PointerEventData>(this.OnDragGizmoCallback), new Action<EditorGizmo>(this.OnBeginDragGizmoCallback), new Action<EditorGizmo>(this.OnEndDragGizmoCallback), null, new Action<EditorGizmo>(this.OnRightClickGizmoCallback), null, new ValueTuple<ConnectionsMetadata, LevelObj>(connectionsMetadata, tile.placedObj)));
								this.RefreshLine(connectionsMetadata);
								connectionsMetadata.Apply(ObjectInfoPanel.Context[connectionsMetadata]);
								AudioManager.Play("SFX_ExclamationCrate", AudioManager.MixerTarget.UI, null, null);
							}
						}
					}
				}
			}
		}

		// Token: 0x0600113B RID: 4411 RVA: 0x0003D438 File Offset: 0x0003B638
		public override void SecondaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
			if (phase == EditorTool.ToolPhase.End)
			{
				return;
			}
			Tile tile;
			if (LevelCreator.GetTileAtMouse(out tile))
			{
				foreach (ConnectionsMetadata connectionsMetadata in this.connections)
				{
					if (connectionsMetadata.Connections.Contains(tile.placedObj))
					{
						connectionsMetadata.RemoveConnection(tile.placedObj);
						this.RefreshGizmos();
						this.RefreshLine(connectionsMetadata);
						connectionsMetadata.Apply(ObjectInfoPanel.Context[connectionsMetadata]);
						AudioManager.Play("SFX_ExclamationCrate", AudioManager.MixerTarget.UI, null, null);
					}
				}
			}
		}

		// Token: 0x0600113C RID: 4412 RVA: 0x0003D4CC File Offset: 0x0003B6CC
		public override void OnToolEnabled()
		{
			ObjectInfoPanel.GetMeta<ConnectionsMetadata>(out this.connections);
			this.RefreshGizmos();
			foreach (ConnectionsMetadata c in this.connections)
			{
				this.RefreshLine(c);
			}
			this.lineRen.enabled = true;
		}

		// Token: 0x0600113D RID: 4413 RVA: 0x0003D517 File Offset: 0x0003B717
		public override void OnToolDisabled()
		{
			this.lineRen.enabled = false;
			this.lineRen.positionCount = 0;
			this.ClearGizmos();
			this.connections = null;
		}

		// Token: 0x0600113E RID: 4414 RVA: 0x0003D540 File Offset: 0x0003B740
		private void RefreshLine(ConnectionsMetadata c)
		{
			this.lineRen.positionCount = this.gizmoIds.Count + 1;
			this.lineRen.SetPosition(0, ObjectInfoPanel.Context[c].transform.position + Vector3.back);
			int i = 1;
			this.gizmoIds.ForEach(delegate(Guid id)
			{
				EditorGizmo editorGizmo;
				int i;
				if (EditorGizmos.TryGetGizmo(id, out editorGizmo))
				{
					this.lineRen.SetPosition(i, editorGizmo.transform.position + Vector3.back);
				}
				i = i;
				i++;
			});
		}

		// Token: 0x0600113F RID: 4415 RVA: 0x0003D5BC File Offset: 0x0003B7BC
		private void RefreshGizmos()
		{
			this.ClearGizmos();
			ConnectionsMetadata[] array = this.connections;
			for (int i = 0; i < array.Length; i++)
			{
				ConnectionsMetadata c = array[i];
				c.Connections.ForEach(delegate(LevelObj obj)
				{
					Guid item = EditorGizmos.CreateGizmo(obj.transform.position - Vector3.forward, new Action<EditorGizmo, PointerEventData>(this.OnDragGizmoCallback), new Action<EditorGizmo>(this.OnBeginDragGizmoCallback), new Action<EditorGizmo>(this.OnEndDragGizmoCallback), null, new Action<EditorGizmo>(this.OnRightClickGizmoCallback), null, new ValueTuple<ConnectionsMetadata, LevelObj>(c, obj));
					this.gizmoIds.Add(item);
				});
			}
		}

		// Token: 0x06001140 RID: 4416 RVA: 0x0003D616 File Offset: 0x0003B816
		private void ClearGizmos()
		{
			this.gizmoIds.ForEach(delegate(Guid id)
			{
				EditorGizmos.DestroyGizmo(id);
			});
			this.gizmoIds.Clear();
		}

		// Token: 0x06001141 RID: 4417 RVA: 0x0003D64D File Offset: 0x0003B84D
		private void OnDragGizmoCallback(EditorGizmo gizmo, PointerEventData evt)
		{
			gizmo.transform.Translate(evt.delta / EditorGizmo.WorldToPixelAmount);
			this.RefreshLine(((ValueTuple<ConnectionsMetadata, LevelObj>)gizmo.meta).Item1);
		}

		// Token: 0x06001142 RID: 4418 RVA: 0x0003D688 File Offset: 0x0003B888
		private void OnBeginDragGizmoCallback(EditorGizmo gizmo)
		{
			try
			{
				this._gizmoLevelObjTemp = ((ValueTuple<ConnectionsMetadata, LevelObj>)gizmo.meta).Item2;
			}
			catch (InvalidCastException)
			{
				if (gizmo.meta == null)
				{
					Debug.LogWarning("Gizmo meta is null");
				}
				else
				{
					Debug.LogWarning(string.Format("Gizmo meta is {0}", gizmo.meta.GetType()));
				}
			}
		}

		// Token: 0x06001143 RID: 4419 RVA: 0x0003D6F0 File Offset: 0x0003B8F0
		private void OnEndDragGizmoCallback(EditorGizmo gizmo)
		{
			ConnectionsMetadata item = ((ValueTuple<ConnectionsMetadata, LevelObj>)gizmo.meta).Item1;
			bool flag;
			Tile tile = GridManager.instance.TileFromWorldPosition(gizmo.transform.position, out flag);
			if (flag)
			{
				LevelObj placedObj = tile.placedObj;
				Crate crate = (placedObj != null) ? placedObj.GetComponentInChildren<Crate>(true) : null;
				if (crate != null && !(crate is ColourCrate) && !item.Connections.Contains(tile.placedObj) && tile.placedObj != ObjectInfoPanel.Context[item])
				{
					item.ReplaceConnection(this._gizmoLevelObjTemp, tile.placedObj);
					gizmo.transform.position = tile.placedObj.transform.position;
					gizmo.meta = new ValueTuple<ConnectionsMetadata, LevelObj>(item, tile.placedObj);
					this.RefreshLine(item);
					item.Apply(ObjectInfoPanel.Context[item]);
					goto IL_FF;
				}
			}
			gizmo.transform.position = this._gizmoLevelObjTemp.transform.position;
			this.RefreshLine(item);
			IL_FF:
			this._gizmoLevelObjTemp = null;
		}

		// Token: 0x06001144 RID: 4420 RVA: 0x0003D804 File Offset: 0x0003BA04
		private void OnRightClickGizmoCallback(EditorGizmo gizmo)
		{
			ConnectionsMetadata item = ((ValueTuple<ConnectionsMetadata, LevelObj>)gizmo.meta).Item1;
			item.RemoveConnection(((ValueTuple<ConnectionsMetadata, LevelObj>)gizmo.meta).Item2);
			this.RefreshGizmos();
			this.RefreshLine(item);
			item.Apply(ObjectInfoPanel.Context[item]);
			AudioManager.Play("SFX_ExclamationCrate", AudioManager.MixerTarget.UI, null, null);
		}

		// Token: 0x04000B74 RID: 2932
		public LineRenderer lineRen;

		// Token: 0x04000B75 RID: 2933
		private ConnectionsMetadata[] connections;

		// Token: 0x04000B76 RID: 2934
		private readonly List<Guid> gizmoIds = new List<Guid>();

		// Token: 0x04000B77 RID: 2935
		private LevelObj _gizmoLevelObjTemp;
	}
}
