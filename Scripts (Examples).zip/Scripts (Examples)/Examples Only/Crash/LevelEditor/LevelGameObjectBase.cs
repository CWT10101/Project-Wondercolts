﻿using System;
using UnityEngine;

namespace LevelEditor
{
	// Token: 0x020001B4 RID: 436
	[Serializable]
	public class LevelGameObjectBase
	{
		// Token: 0x04000B67 RID: 2919
		public string obj_ID;

		// Token: 0x04000B68 RID: 2920
		public GameObject objPrefab;
	}
}
