﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace LevelEditor
{
	// Token: 0x020001BB RID: 443
	public class DetonatorSubTool : SubTool<SelectTool>
	{
		// Token: 0x1700043D RID: 1085
		// (get) Token: 0x06001146 RID: 4422 RVA: 0x0003D887 File Offset: 0x0003BA87
		public override bool PrimaryIsContinuous
		{
			get
			{
				return true;
			}
		}

		// Token: 0x1700043E RID: 1086
		// (get) Token: 0x06001147 RID: 4423 RVA: 0x0003D88A File Offset: 0x0003BA8A
		public override bool SecondaryIsContinuous
		{
			get
			{
				return true;
			}
		}

		// Token: 0x1700043F RID: 1087
		// (get) Token: 0x06001148 RID: 4424 RVA: 0x0003D890 File Offset: 0x0003BA90
		public GizmoStyle GizmoStyle
		{
			get
			{
				GizmoStyle result;
				if ((result = this._gizmoStyle) == null)
				{
					GizmoStyle gizmoStyle = new GizmoStyle();
					gizmoStyle.color = new Color32?(Color.red);
					GizmoStyle gizmoStyle2 = gizmoStyle;
					this._gizmoStyle = gizmoStyle;
					result = gizmoStyle2;
				}
				return result;
			}
		}

		// Token: 0x06001149 RID: 4425 RVA: 0x0003D8CC File Offset: 0x0003BACC
		public override void PrimaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
			if (phase == EditorTool.ToolPhase.End)
			{
				return;
			}
			Tile tile;
			if (LevelCreator.GetTileAtMouse(out tile))
			{
				foreach (DetonatorLinkMetadata detonatorLinkMetadata in this.connections)
				{
					if (!detonatorLinkMetadata.Connections.Contains(tile.placedObj) && tile.placedObj && tile.placedObj.GetComponentInChildren<Crate>(true) is TNTCrate && tile.placedObj != ObjectInfoPanel.Context[detonatorLinkMetadata])
					{
						detonatorLinkMetadata.AddConnection(tile.placedObj);
						this.gizmoIds.Add(EditorGizmos.CreateGizmo(tile.placedObj.transform.position - Vector3.forward, null, null, null, null, new Action<EditorGizmo>(this.OnRightClickGizmoCallback), this.GizmoStyle, tile.placedObj));
						detonatorLinkMetadata.Apply(ObjectInfoPanel.Context[detonatorLinkMetadata]);
						AudioManager.Play("SFX_ExclamationCrate", AudioManager.MixerTarget.UI, null, null);
					}
				}
			}
		}

		// Token: 0x0600114A RID: 4426 RVA: 0x0003D9E4 File Offset: 0x0003BBE4
		public override void SecondaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
			if (phase == EditorTool.ToolPhase.End)
			{
				return;
			}
			Tile tile;
			if (LevelCreator.GetTileAtMouse(out tile))
			{
				foreach (DetonatorLinkMetadata detonatorLinkMetadata in this.connections)
				{
					if (detonatorLinkMetadata.Connections.Contains(tile.placedObj))
					{
						detonatorLinkMetadata.RemoveConnection(tile.placedObj);
						this.RefreshGizmos();
						detonatorLinkMetadata.Apply(ObjectInfoPanel.Context[detonatorLinkMetadata]);
						AudioManager.Play("SFX_ExclamationCrate", AudioManager.MixerTarget.UI, null, null);
					}
				}
			}
		}

		// Token: 0x0600114B RID: 4427 RVA: 0x0003DA6E File Offset: 0x0003BC6E
		public override void OnToolEnabled()
		{
			ObjectInfoPanel.GetMeta<DetonatorLinkMetadata>(out this.connections);
			this.RefreshGizmos();
		}

		// Token: 0x0600114C RID: 4428 RVA: 0x0003DA82 File Offset: 0x0003BC82
		public override void OnToolDisabled()
		{
			this.ClearGizmos();
			this.connections = null;
		}

		// Token: 0x0600114D RID: 4429 RVA: 0x0003DA94 File Offset: 0x0003BC94
		private void RefreshGizmos()
		{
			this.ClearGizmos();
			DetonatorLinkMetadata[] array = this.connections;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].Connections.ForEach(delegate(LevelObj obj)
				{
					Guid item = EditorGizmos.CreateGizmo(obj.transform.position - Vector3.forward, null, null, null, null, new Action<EditorGizmo>(this.OnRightClickGizmoCallback), this.GizmoStyle, obj);
					this.gizmoIds.Add(item);
				});
			}
		}

		// Token: 0x0600114E RID: 4430 RVA: 0x0003DAD5 File Offset: 0x0003BCD5
		private void ClearGizmos()
		{
			this.gizmoIds.ForEach(delegate(Guid id)
			{
				EditorGizmos.DestroyGizmo(id);
			});
			this.gizmoIds.Clear();
		}

		// Token: 0x0600114F RID: 4431 RVA: 0x0003DB0C File Offset: 0x0003BD0C
		private void OnRightClickGizmoCallback(EditorGizmo gizmo)
		{
			foreach (DetonatorLinkMetadata detonatorLinkMetadata in this.connections)
			{
				detonatorLinkMetadata.RemoveConnection((LevelObj)gizmo.meta);
				this.RefreshGizmos();
				detonatorLinkMetadata.Apply(ObjectInfoPanel.Context[detonatorLinkMetadata]);
			}
			AudioManager.Play("SFX_ExclamationCrate", AudioManager.MixerTarget.UI, null, null);
		}

		// Token: 0x04000B78 RID: 2936
		private DetonatorLinkMetadata[] connections;

		// Token: 0x04000B79 RID: 2937
		private readonly List<Guid> gizmoIds = new List<Guid>();

		// Token: 0x04000B7A RID: 2938
		private GizmoStyle _gizmoStyle;
	}
}
