﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace LevelEditor
{
	// Token: 0x020001A8 RID: 424
	public class EditorGizmo : MonoBehaviour, IBeginDragHandler, IEventSystemHandler, IDragHandler, IEndDragHandler, IPointerClickHandler
	{
		// Token: 0x17000427 RID: 1063
		// (get) Token: 0x0600107A RID: 4218 RVA: 0x00039D8C File Offset: 0x00037F8C
		public static Vector2 WorldUnitsInCamera
		{
			get
			{
				if (!EditorGizmo._worldUnitsInCameraIsSet)
				{
					EditorGizmo._worldUnitsInCamera.y = Camera.main.orthographicSize * 2f;
					EditorGizmo._worldUnitsInCamera.x = EditorGizmo._worldUnitsInCamera.y * (float)Screen.width / (float)Screen.height;
					EditorGizmo._worldUnitsInCameraIsSet = true;
				}
				return EditorGizmo._worldUnitsInCamera;
			}
		}

		// Token: 0x17000428 RID: 1064
		// (get) Token: 0x0600107B RID: 4219 RVA: 0x00039DE8 File Offset: 0x00037FE8
		public static Vector2 WorldToPixelAmount
		{
			get
			{
				if (!EditorGizmo._worldUnitsInCameraIsSet || !EditorGizmo._worldToPixelAmountIsSet)
				{
					EditorGizmo._worldToPixelAmount.x = (float)Screen.width / EditorGizmo.WorldUnitsInCamera.x;
					EditorGizmo._worldToPixelAmount.y = (float)Screen.height / EditorGizmo.WorldUnitsInCamera.y;
					EditorGizmo._worldToPixelAmountIsSet = true;
				}
				return EditorGizmo._worldToPixelAmount;
			}
		}

		// Token: 0x0600107C RID: 4220 RVA: 0x00039E44 File Offset: 0x00038044
		public void OnDrag(PointerEventData eventData)
		{
			if (eventData.button == PointerEventData.InputButton.Left)
			{
				Action<EditorGizmo, PointerEventData> action = this.onDrag;
				if (action == null)
				{
					return;
				}
				action(this, eventData);
			}
		}

		// Token: 0x0600107D RID: 4221 RVA: 0x00039E60 File Offset: 0x00038060
		public void OnBeginDrag(PointerEventData eventData)
		{
			if (eventData.button == PointerEventData.InputButton.Left)
			{
				Action<EditorGizmo> action = this.onBeginDrag;
				if (action == null)
				{
					return;
				}
				action(this);
			}
		}

		// Token: 0x0600107E RID: 4222 RVA: 0x00039E7B File Offset: 0x0003807B
		public void OnEndDrag(PointerEventData eventData)
		{
			if (eventData.button == PointerEventData.InputButton.Left)
			{
				Action<EditorGizmo> action = this.onEndDrag;
				if (action == null)
				{
					return;
				}
				action(this);
			}
		}

		// Token: 0x0600107F RID: 4223 RVA: 0x00039E96 File Offset: 0x00038096
		public void OnPointerClick(PointerEventData eventData)
		{
			if (eventData.button != PointerEventData.InputButton.Left)
			{
				if (eventData.button == PointerEventData.InputButton.Right)
				{
					Action<EditorGizmo> action = this.onRightClick;
					if (action == null)
					{
						return;
					}
					action(this);
				}
				return;
			}
			Action<EditorGizmo> action2 = this.onLeftClick;
			if (action2 == null)
			{
				return;
			}
			action2(this);
		}

		// Token: 0x06001080 RID: 4224 RVA: 0x00039ECC File Offset: 0x000380CC
		public void ApplyStyle(GizmoStyle style)
		{
			if (style.color != null)
			{
				this.graphic.color = style.color.Value;
			}
		}

		// Token: 0x04000AB4 RID: 2740
		private static bool _worldUnitsInCameraIsSet;

		// Token: 0x04000AB5 RID: 2741
		private static Vector2 _worldUnitsInCamera;

		// Token: 0x04000AB6 RID: 2742
		private static bool _worldToPixelAmountIsSet;

		// Token: 0x04000AB7 RID: 2743
		private static Vector2 _worldToPixelAmount;

		// Token: 0x04000AB8 RID: 2744
		public Graphic graphic;

		// Token: 0x04000AB9 RID: 2745
		public Action<EditorGizmo, PointerEventData> onDrag;

		// Token: 0x04000ABA RID: 2746
		public Action<EditorGizmo> onBeginDrag;

		// Token: 0x04000ABB RID: 2747
		public Action<EditorGizmo> onEndDrag;

		// Token: 0x04000ABC RID: 2748
		public Action<EditorGizmo> onLeftClick;

		// Token: 0x04000ABD RID: 2749
		public Action<EditorGizmo> onRightClick;

		// Token: 0x04000ABE RID: 2750
		public object meta;
	}
}
