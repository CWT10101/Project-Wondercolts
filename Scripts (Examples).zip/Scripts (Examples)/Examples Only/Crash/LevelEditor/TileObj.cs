﻿using System;
using UnityEngine;

namespace LevelEditor
{
	// Token: 0x020001B8 RID: 440
	public class TileObj : MonoBehaviour
	{
		// Token: 0x06001134 RID: 4404 RVA: 0x0003D25F File Offset: 0x0003B45F
		public void UpdateTileObj(Tile curTile, SaveableTileObject saveable)
		{
			this.posX = saveable.posX;
			this.posY = saveable.posY;
		}

		// Token: 0x06001135 RID: 4405 RVA: 0x0003D279 File Offset: 0x0003B479
		public SaveableTileObject GetSaveableObject()
		{
			return new SaveableTileObject
			{
				posX = this.posX,
				posY = this.posY
			};
		}

		// Token: 0x04000B6F RID: 2927
		public int posX;

		// Token: 0x04000B70 RID: 2928
		public int posY;

		// Token: 0x04000B71 RID: 2929
		public MeshRenderer tileVis;
	}
}
