﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace LevelEditor
{
	// Token: 0x020001AE RID: 430
	public class LevelInterfaceManager : MonoBehaviour
	{
		// Token: 0x1700042E RID: 1070
		// (get) Token: 0x060010B1 RID: 4273 RVA: 0x0003ABA0 File Offset: 0x00038DA0
		private Dictionary<LevelObj, LevelObjSelectionToggle> LevelObjToggleTable { get; } = new Dictionary<LevelObj, LevelObjSelectionToggle>();

		// Token: 0x1700042F RID: 1071
		// (get) Token: 0x060010B2 RID: 4274 RVA: 0x0003ABA8 File Offset: 0x00038DA8
		public int boxesCollected
		{
			get
			{
				return this.CrateSet.Count;
			}
		}

		// Token: 0x060010B3 RID: 4275 RVA: 0x0003ABB5 File Offset: 0x00038DB5
		private void Awake()
		{
			LevelInterfaceManager.instance = this;
		}

		// Token: 0x060010B4 RID: 4276 RVA: 0x0003ABC0 File Offset: 0x00038DC0
		private void Start()
		{
			this.CreateButtonsForList(LevelSerializer.instance.userCreatedList, this.userCreatedButtonHolder);
			this.CreateButtonsForList(LevelSerializer.instance.ukaTrialsList, this.ukaTrialsButtonHolder);
			this.CreateButtonsForList(LevelSerializer.instance.flashbackTapesList, this.flashbackTapesButtonHolder);
			this.ConfigureButtonAccessibility();
			UIScreen.Focus(this.editorHUD);
			this.InitializeMusicDropdown();
			this.InitializeLevelTypeDropdown();
			this.InitObjButtons();
			this.InitFavoritesPalette();
			LevelObjDatabase database = LevelResourcesManager.instance.database;
			database.onSearchFinished = (Action<IEnumerable<LevelObj>>)Delegate.Combine(database.onSearchFinished, new Action<IEnumerable<LevelObj>>(this.ProcessSearch));
		}

		// Token: 0x17000430 RID: 1072
		// (get) Token: 0x060010B5 RID: 4277 RVA: 0x0003AC63 File Offset: 0x00038E63
		private string FavPalettePath
		{
			get
			{
				if (SaveData.ActiveSlot < 0)
				{
					return null;
				}
				return Path.Combine(Application.persistentDataPath, string.Format("slot{0}.fav", SaveData.ActiveSlot));
			}
		}

		// Token: 0x060010B6 RID: 4278 RVA: 0x0003AC90 File Offset: 0x00038E90
		private void InitFavoritesPalette()
		{
			if (File.Exists(this.FavPalettePath))
			{
				try
				{
					using (FileStream fileStream = new FileStream(this.FavPalettePath, FileMode.Open))
					{
						using (BinaryReader binaryReader = new BinaryReader(fileStream))
						{
							this.favsPalette.Deserialize(binaryReader);
						}
					}
				}
				catch (IOException ex)
				{
					this.warningScreen.confirmActionButton.onClick.RemoveAllListeners();
					this.warningScreen.SetWarningText("Error Loading", string.Concat(new string[]
					{
						ex.GetType().Name,
						": ",
						ex.Message,
						"\n",
						ex.StackTrace
					}));
					UIScreen.Focus(this.warningScreen.screen);
					throw ex;
				}
			}
			int num = 0;
			foreach (LevelObj levelObj in this.favsPalette)
			{
				if (levelObj == null)
				{
					this.favsButtons[num].ClearObject();
				}
				else
				{
					this.favsButtons[num].Init(levelObj.obj_ID, levelObj.obj_Icon, levelObj.flipIcon);
				}
				num++;
			}
		}

		// Token: 0x060010B7 RID: 4279 RVA: 0x0003AE00 File Offset: 0x00039000
		private void SaveFavoritesPalette()
		{
			if (this.FavPalettePath == null)
			{
				return;
			}
			try
			{
				using (FileStream fileStream = new FileStream(this.FavPalettePath, FileMode.Create))
				{
					using (BinaryWriter binaryWriter = new BinaryWriter(fileStream))
					{
						this.favsPalette.Serialize(binaryWriter);
					}
				}
			}
			catch (IOException ex)
			{
				this.warningScreen.confirmActionButton.onClick.RemoveAllListeners();
				this.warningScreen.SetWarningText("Error Saving", string.Concat(new string[]
				{
					ex.GetType().Name,
					": ",
					ex.Message,
					"\n",
					ex.StackTrace
				}));
				UIScreen.Focus(this.warningScreen.screen);
				throw ex;
			}
		}

		// Token: 0x060010B8 RID: 4280 RVA: 0x0003AEEC File Offset: 0x000390EC
		private void ProcessSearch(IEnumerable<LevelObj> objs)
		{
			foreach (KeyValuePair<LevelObj, LevelObjSelectionToggle> keyValuePair in this.LevelObjToggleTable)
			{
				keyValuePair.Value.gameObject.SetActive(false);
			}
			foreach (LevelObj levelObj in objs)
			{
				LevelObjSelectionToggle levelObjSelectionToggle;
				if (this.LevelObjToggleTable.TryGetValue(levelObj, out levelObjSelectionToggle))
				{
					levelObjSelectionToggle.gameObject.SetActive(true);
				}
				else
				{
					Debug.LogWarning(string.Format("{0} not present in table", levelObj));
				}
			}
		}

		// Token: 0x060010B9 RID: 4281 RVA: 0x0003AFAC File Offset: 0x000391AC
		private void UnhideLevelObjButtons()
		{
			foreach (KeyValuePair<LevelObj, LevelObjSelectionToggle> keyValuePair in this.LevelObjToggleTable)
			{
				keyValuePair.Value.gameObject.SetActive(true);
			}
		}

		// Token: 0x060010BA RID: 4282 RVA: 0x0003B00C File Offset: 0x0003920C
		private void OnDestroy()
		{
			LevelInterfaceManager.instance = null;
			this.SaveFavoritesPalette();
			AudioManager.PitchUnpauseMusic();
		}

		// Token: 0x060010BB RID: 4283 RVA: 0x0003B01F File Offset: 0x0003921F
		private void Update()
		{
			this.mouseOverUI = EventSystem.current.IsPointerOverGameObject();
			if (this.mouseOverUI && LevelCreator.instance.cloneObj != null)
			{
				LevelCreator.instance.ClearCloneObj();
			}
		}

		// Token: 0x060010BC RID: 4284 RVA: 0x0003B058 File Offset: 0x00039258
		private void FixedUpdate()
		{
			if (this.timeTrialStarted)
			{
				if (this.pauseTicks > 0)
				{
					this.pauseTicks--;
					if (this.pauseTicks <= 0)
					{
						this.pauseTicks = 0;
						this.clockTickSource.Stop();
					}
				}
				else
				{
					this.ticksElapsed++;
				}
				this.UpdateTimeUI();
			}
		}

		// Token: 0x060010BD RID: 4285 RVA: 0x0003B0B8 File Offset: 0x000392B8
		private void InitObjButtons()
		{
			LevelObjButton levelObjButton = LevelResourcesManager.instance.levelObjButton;
			List<LevelGameObjectBase> levelGameObjects = LevelResourcesManager.instance.levelGameObjects;
			for (int i = 0; i < levelGameObjects.Count; i++)
			{
				LevelObj levelObj;
				if (levelGameObjects[i].objPrefab.TryGetComponent<LevelObj>(out levelObj) && !levelObj.excludeFromEditor2D)
				{
					Transform transform = null;
					if (levelObj.obj_category == "Crate")
					{
						transform = this.crateScrollHolder;
					}
					else if (levelObj.obj_category == "Block")
					{
						transform = this.blocksScrollHolder;
					}
					else if (levelObj.obj_category == "Hazards")
					{
						transform = this.hazardScrollHolder;
					}
					else if (levelObj.obj_category == "Enemies")
					{
						transform = this.enemiesScrollHolder;
					}
					else if (levelObj.obj_category == "Gameplay")
					{
						transform = this.gameplayScrollHolder;
					}
					if (transform != null)
					{
						LevelObjButton levelObjButton2 = Object.Instantiate<LevelObjButton>(levelObjButton, transform);
						Sprite icon;
						if (CrashAnimator.Skin != 0 && levelObj.Obj_IconCocoVariant != null)
						{
							icon = levelObj.Obj_IconCocoVariant;
						}
						else
						{
							icon = levelObj.obj_Icon;
						}
						levelObjButton2.Init(levelObj.obj_ID, icon, levelObj.flipIcon);
					}
				}
			}
			LevelObjSelectionToggle levelObjSelectionToggle = LevelResourcesManager.instance.levelObjSelectionToggle;
			List<LevelGameObjectBase> levelGameObjects2 = LevelResourcesManager.instance.levelGameObjects;
			Transform parent = this.objSelectionGridHolder;
			for (int j = 0; j < levelGameObjects2.Count; j++)
			{
				LevelObj levelObj2;
				if (levelGameObjects2[j].objPrefab.TryGetComponent<LevelObj>(out levelObj2) && !string.IsNullOrWhiteSpace(levelObj2.obj_category))
				{
					LevelObjSelectionToggle levelObjSelectionToggle2 = Object.Instantiate<LevelObjSelectionToggle>(levelObjSelectionToggle, parent);
					levelObjSelectionToggle2.Init(levelObj2, levelObj2.flipIcon);
					this.LevelObjToggleTable[levelObj2] = levelObjSelectionToggle2;
					if (levelObj2.obj_category == "Secret")
					{
						levelObjSelectionToggle2.gameObject.SetActive(false);
					}
				}
			}
		}

		// Token: 0x060010BE RID: 4286 RVA: 0x0003B294 File Offset: 0x00039494
		private void ConfigureButtonAccessibility()
		{
			for (int i = 0; i < this.flashbackTapesButtonHolder.childCount; i++)
			{
				this.flashbackTapesButtonHolder.GetChild(i).gameObject.SetActive(SaveData.Info.lvlTapes[i]);
			}
			for (int j = 0; j < this.ukaTrialsButtonHolder.childCount; j++)
			{
				this.ukaTrialsButtonHolder.GetChild(j).gameObject.SetActive(SaveData.Info.lvlTrials[j]);
			}
			SaveData.Info.lvlTapes.CountNotDefault<bool>();
			SaveData.Info.lvlTrials.CountNotDefault<bool>();
		}

		// Token: 0x060010BF RID: 4287 RVA: 0x0003B334 File Offset: 0x00039534
		public void TryLeave()
		{
			this.warningScreen.SetWarningText("LEAVE", "Are you sure you want to leave? Any unsaved changes will be lost");
			UIScreen.Focus(this.warningScreen.screen);
			this.warningScreen.confirmActionButton.onClick.RemoveAllListeners();
			this.warningScreen.confirmActionButton.onClick.AddListener(new UnityAction(LevelManager.instance.LoadWarpRoom));
			this.warningScreen.confirmActionButton.onClick.AddListener(new UnityAction(this.warningScreen.ConfirmAction));
			this.warningScreen.confirmActionButton.onClick.AddListener(new UnityAction(this.PlayClickSound));
		}

		// Token: 0x060010C0 RID: 4288 RVA: 0x0003B3E8 File Offset: 0x000395E8
		public void PlayClickSound()
		{
			AudioManager.Play("clickUI", AudioManager.MixerTarget.UI, null, null);
		}

		// Token: 0x060010C1 RID: 4289 RVA: 0x0003B413 File Offset: 0x00039613
		public void StopLevelMusic()
		{
			AudioManager.PlayMusic(LevelManager.instance.crashCreatorSongs[0], 1f);
			this.testMusicIcon.sprite = this.testMusicSprite;
		}

		// Token: 0x060010C2 RID: 4290 RVA: 0x0003B43C File Offset: 0x0003963C
		public void TestLevelMusic()
		{
			if (this.playingJukebox)
			{
				this.StopLevelMusic();
			}
			else
			{
				string text = LevelResourcesManager.instance.backgroundSongs[this.musicDropdown.value];
				if (AudioManager.HasMusic(text))
				{
					AudioManager.PlayMusic(text, 1f);
				}
				else
				{
					AudioManager.StopMusic();
				}
				this.testMusicIcon.sprite = this.stopMusicSprite;
			}
			this.playingJukebox = !this.playingJukebox;
		}

		// Token: 0x060010C3 RID: 4291 RVA: 0x0003B4B0 File Offset: 0x000396B0
		public void InitializeMusicDropdown()
		{
			this.musicDropdown.ClearOptions();
			List<string> list = new List<string>();
			for (int i = 0; i < LevelResourcesManager.instance.backgroundSongs.Count; i++)
			{
				list.Add(LevelResourcesManager.instance.backgroundSongs[i]);
			}
			this.musicDropdown.AddOptions(list);
			this.musicDropdown.value = 0;
		}

		// Token: 0x060010C4 RID: 4292 RVA: 0x0003B516 File Offset: 0x00039716
		public void InitializeLevelTypeDropdown()
		{
			this.levelTypeDropdown.ClearOptions();
			this.levelTypeDropdown.AddOptions(ResourceManager.LevelTypeNames.ToList<string>());
			this.levelTypeDropdown.value = 0;
		}

		// Token: 0x060010C5 RID: 4293 RVA: 0x0003B544 File Offset: 0x00039744
		public void SetMusicForLevel(int index)
		{
			if (LevelManager.instance.inEditorMode)
			{
				this.currentMusic = index;
				this.rollbackMusic = index;
				this.initialMusic = index;
				return;
			}
			this.currentMusic = index;
			string text = LevelResourcesManager.instance.backgroundSongs[this.currentMusic];
			if (AudioManager.HasMusic(text))
			{
				AudioManager.PlayMusic(text, 1f);
				return;
			}
			AudioManager.StopMusic();
		}

		// Token: 0x060010C6 RID: 4294 RVA: 0x0003B5AD File Offset: 0x000397AD
		public void SetMusicRollback()
		{
			this.rollbackMusic = this.currentMusic;
		}

		// Token: 0x060010C7 RID: 4295 RVA: 0x0003B5BB File Offset: 0x000397BB
		public void RecallMusicRollback()
		{
			this.SetMusicForLevel(this.rollbackMusic);
		}

		// Token: 0x060010C8 RID: 4296 RVA: 0x0003B5CC File Offset: 0x000397CC
		public void ResetMusic()
		{
			if (LevelManager.instance.inEditorMode)
			{
				AudioManager.PlayMusic(LevelManager.instance.crashCreatorSongs[0], 1f);
				return;
			}
			this.SetMusicForLevel(this.rollbackMusic = (this.currentMusic = this.initialMusic));
		}

		// Token: 0x060010C9 RID: 4297 RVA: 0x0003B61A File Offset: 0x0003981A
		public void SetLevelType()
		{
			this.currentLevelType = this.levelTypeDropdown.value;
		}

		// Token: 0x060010CA RID: 4298 RVA: 0x0003B630 File Offset: 0x00039830
		public void SetBoxCollectionObject(bool enabled)
		{
			this.maxBoxCount = 0;
			this.boxCollectionObject.SetActive(enabled);
			if (enabled)
			{
				for (int i = 0; i < LevelManager.instance.inSceneLevelObjects.Count; i++)
				{
					LevelObj component = LevelManager.instance.inSceneLevelObjects[i].GetComponent<LevelObj>();
					if (component.isBreakable)
					{
						this.maxBoxCount++;
					}
					else
					{
						Enemy componentInChildren = component.GetComponentInChildren<Enemy>(true);
						if (componentInChildren != null)
						{
							this.EnemiesInLevel.Add(componentInChildren);
						}
					}
				}
				if (this.maxBoxCount <= 0)
				{
					this.boxCollectionObject.SetActive(false);
				}
			}
			this.CrateSet.Clear();
			this.CheckCratesCollected();
			this.CheckEnemiesKilled();
		}

		// Token: 0x060010CB RID: 4299 RVA: 0x0003B6DF File Offset: 0x000398DF
		public void SetTimeTrialObject(bool enabled)
		{
			this.ticksElapsed = 0;
			this.timeTrialObject.SetActive(enabled);
			this.UpdateTimeUI();
		}

		// Token: 0x060010CC RID: 4300 RVA: 0x0003B6FA File Offset: 0x000398FA
		public void UpdateBoxesCollectedUI()
		{
			this.boxesText.text = string.Format("{0:00}/{1:00}", this.boxesCollected, this.maxBoxCount);
		}

		// Token: 0x17000431 RID: 1073
		// (get) Token: 0x060010CD RID: 4301 RVA: 0x0003B727 File Offset: 0x00039927
		private HashSet<Crate> CrateSet { get; } = new HashSet<Crate>();

		// Token: 0x17000432 RID: 1074
		// (get) Token: 0x060010CE RID: 4302 RVA: 0x0003B72F File Offset: 0x0003992F
		public HashSet<Enemy> EnemiesInLevel { get; } = new HashSet<Enemy>();

		// Token: 0x17000433 RID: 1075
		// (get) Token: 0x060010CF RID: 4303 RVA: 0x0003B737 File Offset: 0x00039937
		public HashSet<Enemy> EnemiesKilled { get; } = new HashSet<Enemy>();

		// Token: 0x060010D0 RID: 4304 RVA: 0x0003B73F File Offset: 0x0003993F
		public SpecialGem GetSpecialGem()
		{
			if (!this.checkedForSpecialGem)
			{
				this.checkedForSpecialGem = true;
				this.specialGem = Object.FindObjectOfType<SpecialGem>(true);
			}
			return this.specialGem;
		}

		// Token: 0x060010D1 RID: 4305 RVA: 0x0003B764 File Offset: 0x00039964
		public CrystalPickup GetAllCratesGem()
		{
			if (!this.checkedForAllCratesGem)
			{
				this.checkedForAllCratesGem = true;
				this.allCratesGem = null;
				AllCratesGemSetter allCratesGemSetter = Object.FindObjectOfType<AllCratesGemSetter>();
				if (allCratesGemSetter != null)
				{
					CrystalPickup crystalPickup = allCratesGemSetter.Pickup as CrystalPickup;
					if (crystalPickup != null)
					{
						this.allCratesGem = crystalPickup;
					}
				}
			}
			return this.allCratesGem;
		}

		// Token: 0x060010D2 RID: 4306 RVA: 0x0003B7AC File Offset: 0x000399AC
		public void ClearCache()
		{
			if (this.specialGem && this.specialGem is NoDeathGem)
			{
				this.specialGem.gameObject.SetActive(true);
			}
			this.specialGem = null;
			this.checkedForSpecialGem = false;
			this.allCratesGem = null;
			this.checkedForAllCratesGem = false;
			this.CrateSet.Clear();
			this.EnemiesInLevel.Clear();
			this.EnemiesKilled.Clear();
		}

		// Token: 0x060010D3 RID: 4307 RVA: 0x0003B821 File Offset: 0x00039A21
		public void AddCrateCollected(Crate crate)
		{
			if (!this.CrateSet.Add(crate))
			{
				Debug.LogError(string.Format("{0} is already collected", crate));
			}
			this.CheckCratesCollected();
			if (CrashController.instance.inBonus)
			{
				BonusManager.instance.AddBonusCrate();
			}
		}

		// Token: 0x060010D4 RID: 4308 RVA: 0x0003B85D File Offset: 0x00039A5D
		public void RemoveCrateCollected(Crate crate)
		{
			this.CrateSet.Remove(crate);
			this.CheckCratesCollected();
		}

		// Token: 0x060010D5 RID: 4309 RVA: 0x0003B872 File Offset: 0x00039A72
		public void EnemyKilled(Enemy enemy)
		{
			this.EnemiesKilled.Add(enemy);
			InterfaceManager.instance.hudTrack.SetKillsText();
			this.CheckEnemiesKilled();
		}

		// Token: 0x060010D6 RID: 4310 RVA: 0x0003B896 File Offset: 0x00039A96
		public void EnemyReset(Enemy enemy)
		{
			this.EnemiesKilled.Remove(enemy);
			this.CheckEnemiesKilled();
		}

		// Token: 0x060010D7 RID: 4311 RVA: 0x0003B8AC File Offset: 0x00039AAC
		private void CheckCratesCollected()
		{
			if (this.GetAllCratesGem() != null)
			{
				this.allCratesGem.gameObject.SetActive(this.maxBoxCount <= 0 || this.boxesCollected >= this.maxBoxCount);
			}
			if (this.GetSpecialGem() is NoCratesGem)
			{
				this.specialGem.gameObject.SetActive(this.maxBoxCount <= 0 || this.boxesCollected <= 0);
			}
			this.UpdateBoxesCollectedUI();
		}

		// Token: 0x060010D8 RID: 4312 RVA: 0x0003B92C File Offset: 0x00039B2C
		private void CheckEnemiesKilled()
		{
			if (this.GetSpecialGem() is NoKillsGem)
			{
				this.specialGem.gameObject.SetActive(this.EnemiesKilled.Count <= 0);
				return;
			}
			if (this.GetSpecialGem() is AllKillsGem)
			{
				this.specialGem.gameObject.SetActive(this.EnemiesKilled.Count >= this.EnemiesInLevel.Count);
			}
		}

		// Token: 0x060010D9 RID: 4313 RVA: 0x0003B9A0 File Offset: 0x00039BA0
		public void NoCratesGemCheck()
		{
			int num = 0;
			foreach (NoCratesGemSetter noCratesGemSetter in Object.FindObjectsOfType<NoCratesGemSetter>())
			{
				num++;
				if (this.maxBoxCount <= 0 || this.boxesCollected <= 0)
				{
					noCratesGemSetter.Set(true);
				}
				else
				{
					noCratesGemSetter.Set(false);
				}
			}
		}

		// Token: 0x060010DA RID: 4314 RVA: 0x0003B9F0 File Offset: 0x00039BF0
		public void AllCratesGemCheck()
		{
			int num = 0;
			foreach (AllCratesGemSetter allCratesGemSetter in Object.FindObjectsOfType<AllCratesGemSetter>())
			{
				num++;
				if (this.maxBoxCount <= 0)
				{
					allCratesGemSetter.Set(true);
				}
				else if (this.boxesCollected < this.maxBoxCount)
				{
					allCratesGemSetter.Set(false);
				}
				else
				{
					allCratesGemSetter.Set(true);
				}
			}
		}

		// Token: 0x060010DB RID: 4315 RVA: 0x0003BA4C File Offset: 0x00039C4C
		public void UpdateTimeUI()
		{
			this.trialTimeText.text = string.Format("{0:#00.00}", (float)this.ticksElapsed * Time.fixedDeltaTime).Replace('.', ':');
			if (this.pauseTicks > 0)
			{
				this.trialTimeText.font = this.timetrialFontPaused;
				return;
			}
			this.trialTimeText.font = this.timetrialFontDefault;
		}

		// Token: 0x060010DC RID: 4316 RVA: 0x0003BAB5 File Offset: 0x00039CB5
		public void BeginTimeTrial()
		{
			this.timeTrialStarted = true;
			this.startedTrial = true;
		}

		// Token: 0x060010DD RID: 4317 RVA: 0x0003BAC8 File Offset: 0x00039CC8
		public void PauseTimeTrial(int t)
		{
			if (!this.timeTrialStarted)
			{
				return;
			}
			if (this.pauseTicks == 0 && t > 0)
			{
				this.clockTickSource.Play();
			}
			int num = (int)((float)t / Time.fixedUnscaledDeltaTime);
			this.pauseTicks += num;
			Debug.LogWarning(string.Format("Pausing for {0} ticks", num));
		}

		// Token: 0x060010DE RID: 4318 RVA: 0x0003BB22 File Offset: 0x00039D22
		public void FinishTimeTrial()
		{
			this.timeTrialStarted = false;
			this.pauseTicks = 0;
			this.clockTickSource.Stop();
		}

		// Token: 0x060010DF RID: 4319 RVA: 0x0003BB3D File Offset: 0x00039D3D
		public void ResetTimeTrial()
		{
			this.startedTrial = false;
			this.timeTrialStarted = false;
			this.ticksElapsed = 0;
			this.pauseTicks = 0;
			this.clockTickSource.Stop();
			this.UpdateTimeUI();
		}

		// Token: 0x060010E0 RID: 4320 RVA: 0x0003BB6C File Offset: 0x00039D6C
		public void ConfirmSaveButton()
		{
			if (this.currentLevelType == 2)
			{
				UIScreen.Focus(this.ukaTrialSettingsScreen);
				return;
			}
			this.ConfirmSaveActual();
		}

		// Token: 0x060010E1 RID: 4321 RVA: 0x0003BB8C File Offset: 0x00039D8C
		public void ConfirmSaveActual()
		{
			if (this.currentLevelType == 2)
			{
				this.SetBronzeTime();
				this.SetSilverTime();
				this.SetGoldTime();
			}
			UIScreen.Focus(this.editorHUD);
			LevelSerializer.instance.SaveLevelButton(this.saveInputField.text ?? "");
		}

		// Token: 0x060010E2 RID: 4322 RVA: 0x0003BBE0 File Offset: 0x00039DE0
		public void CheckForEnableSave()
		{
			if (string.IsNullOrEmpty(this.saveInputField.text))
			{
				this.saveButton.interactable = false;
				this.exportButton.interactable = false;
				return;
			}
			this.saveButton.interactable = true;
			this.exportButton.interactable = true;
		}

		// Token: 0x060010E3 RID: 4323 RVA: 0x0003BC30 File Offset: 0x00039E30
		public void ExportLevelHook()
		{
			this.ConfirmSaveActual();
			LevelSerializer.instance.ExportLevel(this.saveInputField.text);
		}

		// Token: 0x060010E4 RID: 4324 RVA: 0x0003BC50 File Offset: 0x00039E50
		public void SetBronzeTime()
		{
			float num;
			if (float.TryParse(this.bronzeInputfield.text, out num))
			{
				this.timeTrialBronze = (int)(num / Time.fixedUnscaledDeltaTime);
				this.bronzeInputfield.SetTextWithoutNotify(string.Format("{0:0.##}", (float)this.timeTrialBronze * Time.fixedUnscaledDeltaTime));
				return;
			}
			TMP_Text tmp_Text = this.bronzeInputfield.placeholder as TMP_Text;
			if (tmp_Text != null && float.TryParse(tmp_Text.text, out num))
			{
				this.timeTrialBronze = (int)(num / Time.fixedUnscaledDeltaTime);
			}
			else
			{
				Debug.LogWarning(string.Format("Couldn't parse placeholder text for {0}", this.bronzeInputfield), this.bronzeInputfield.placeholder);
				this.timeTrialBronze = 0;
			}
			this.bronzeInputfield.SetTextWithoutNotify("");
		}

		// Token: 0x060010E5 RID: 4325 RVA: 0x0003BD14 File Offset: 0x00039F14
		public void SetSilverTime()
		{
			float num;
			if (float.TryParse(this.silverInputfield.text, out num))
			{
				this.timeTrialSilver = (int)(num / Time.fixedUnscaledDeltaTime);
				this.silverInputfield.SetTextWithoutNotify(string.Format("{0:0.##}", (float)this.timeTrialSilver * Time.fixedUnscaledDeltaTime));
				return;
			}
			TMP_Text tmp_Text = this.silverInputfield.placeholder as TMP_Text;
			if (tmp_Text != null && float.TryParse(tmp_Text.text, out num))
			{
				this.timeTrialSilver = (int)(num / Time.fixedUnscaledDeltaTime);
			}
			else
			{
				Debug.LogWarning(string.Format("Couldn't parse placeholder text for {0}", this.silverInputfield), this.silverInputfield.placeholder);
				this.timeTrialSilver = 0;
			}
			this.silverInputfield.SetTextWithoutNotify("");
		}

		// Token: 0x060010E6 RID: 4326 RVA: 0x0003BDD8 File Offset: 0x00039FD8
		public void SetGoldTime()
		{
			float num;
			if (float.TryParse(this.goldInputfield.text, out num))
			{
				this.timeTrialGold = (int)(num / Time.fixedUnscaledDeltaTime);
				this.goldInputfield.SetTextWithoutNotify(string.Format("{0:0.##}", (float)this.timeTrialGold * Time.fixedUnscaledDeltaTime));
				return;
			}
			TMP_Text tmp_Text = this.goldInputfield.placeholder as TMP_Text;
			if (tmp_Text != null && float.TryParse(tmp_Text.text, out num))
			{
				this.timeTrialGold = (int)(num / Time.fixedUnscaledDeltaTime);
			}
			else
			{
				Debug.LogWarning(string.Format("Couldn't parse placeholder text for {0}", this.goldInputfield), this.goldInputfield.placeholder);
				this.timeTrialGold = 0;
			}
			this.goldInputfield.SetTextWithoutNotify("");
		}

		// Token: 0x060010E7 RID: 4327 RVA: 0x0003BE9C File Offset: 0x0003A09C
		public void CycleItemContent()
		{
			if (this.currentContent < this.content.Length - 1)
			{
				this.currentContent++;
			}
			else
			{
				this.currentContent = 0;
			}
			for (int i = 0; i < this.content.Length; i++)
			{
				this.content[i].SetActive(false);
				this.shiftButtonImages[i].gameObject.SetActive(false);
			}
			this.content[this.currentContent].SetActive(true);
			this.shiftButtonImages[this.currentContent].gameObject.SetActive(true);
		}

		// Token: 0x060010E8 RID: 4328 RVA: 0x0003BF34 File Offset: 0x0003A134
		public void CycleSceneryContent()
		{
			if (this.currentSceneryContent < this.sceneryContent.Length - 1)
			{
				this.currentSceneryContent++;
			}
			else
			{
				this.currentSceneryContent = 0;
			}
			for (int i = 0; i < this.sceneryContent.Length; i++)
			{
				this.sceneryContent[i].gameObject.SetActive(false);
			}
			this.sceneryContent[this.currentSceneryContent].SetActive(true);
		}

		// Token: 0x060010E9 RID: 4329 RVA: 0x0003BFA4 File Offset: 0x0003A1A4
		public void CycleWeatherContent()
		{
			if (this.initialWeather < this.weatherContent.Length - 1)
			{
				this.initialWeather++;
			}
			else
			{
				this.initialWeather = 0;
			}
			for (int i = 0; i < this.weatherContent.Length; i++)
			{
				this.weatherContent[i].SetActive(false);
			}
			this.weatherContent[this.initialWeather].SetActive(true);
		}

		// Token: 0x060010EA RID: 4330 RVA: 0x0003C010 File Offset: 0x0003A210
		public void CycleSkybox()
		{
			if (this.currentSkybox < LevelResourcesManager.instance.skyboxMaterials.Count - 1)
			{
				this.currentSkybox++;
			}
			else
			{
				this.currentSkybox = 0;
			}
			RenderSettings.skybox = LevelResourcesManager.instance.skyboxMaterials[this.currentSkybox];
		}

		// Token: 0x060010EB RID: 4331 RVA: 0x0003C067 File Offset: 0x0003A267
		public void SetSkyboxContent(int index)
		{
			this.currentSkybox = index;
			RenderSettings.skybox = LevelResourcesManager.instance.skyboxMaterials[this.currentSkybox];
		}

		// Token: 0x060010EC RID: 4332 RVA: 0x0003C08C File Offset: 0x0003A28C
		public void SetSceneryContent(int index)
		{
			this.currentSceneryContent = index;
			for (int i = 0; i < this.sceneryContent.Length; i++)
			{
				this.sceneryContent[i].SetActive(false);
			}
			this.sceneryContent[this.currentSceneryContent].SetActive(true);
		}

		// Token: 0x060010ED RID: 4333 RVA: 0x0003C0D4 File Offset: 0x0003A2D4
		public void SetWeatherContent(int index)
		{
			if (LevelManager.instance.inEditorMode)
			{
				this.currentWeather = index;
				this.rollbackWeather = index;
				this.initialWeather = index;
			}
			else
			{
				this.currentWeather = index;
			}
			for (int i = 0; i < this.weatherContent.Length; i++)
			{
				this.weatherContent[i].SetActive(false);
			}
			this.weatherContent[this.currentWeather].SetActive(true);
		}

		// Token: 0x060010EE RID: 4334 RVA: 0x0003C143 File Offset: 0x0003A343
		public void SetWeatherRollback()
		{
			this.rollbackWeather = this.currentWeather;
		}

		// Token: 0x060010EF RID: 4335 RVA: 0x0003C151 File Offset: 0x0003A351
		public void RecallWeatherRollback()
		{
			this.SetWeatherContent(this.rollbackWeather);
		}

		// Token: 0x060010F0 RID: 4336 RVA: 0x0003C160 File Offset: 0x0003A360
		public void ResetWeather()
		{
			this.SetWeatherContent(this.rollbackWeather = (this.currentWeather = this.initialWeather));
		}

		// Token: 0x060010F1 RID: 4337 RVA: 0x0003C18B File Offset: 0x0003A38B
		public void SetActiveFolder(string newFolder)
		{
			LevelSerializer.SetActiveFolder(newFolder);
		}

		// Token: 0x060010F2 RID: 4338 RVA: 0x0003C194 File Offset: 0x0003A394
		public void CreateAvailableLevelButtons()
		{
			foreach (string text in LevelSerializer.instance.AllLoadedLevels())
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this.loadLevelButtonPrefab);
				gameObject.transform.SetParent(this.userCreatedButtonHolder, false);
				LoadLevelUIButton componentInChildren = gameObject.GetComponentInChildren<LoadLevelUIButton>();
				componentInChildren.levelName = text;
				componentInChildren.text.text = text;
			}
		}

		// Token: 0x060010F3 RID: 4339 RVA: 0x0003C214 File Offset: 0x0003A414
		public void CreateButtonsForList(List<string> list, Transform holder)
		{
			foreach (string text in list)
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this.loadLevelButtonPrefab);
				gameObject.transform.SetParent(holder, false);
				LoadLevelUIButton componentInChildren = gameObject.GetComponentInChildren<LoadLevelUIButton>();
				componentInChildren.levelName = text;
				componentInChildren.text.text = text;
			}
		}

		// Token: 0x060010F4 RID: 4340 RVA: 0x0003C28C File Offset: 0x0003A48C
		public void SetOverlayButtons()
		{
			this.saveDialogueButton.gameObject.SetActive(LevelManager.instance.inEditorMode);
			this.loadDialogueButton.gameObject.SetActive(LevelManager.instance.inEditorMode);
			this.newLevelButton.gameObject.SetActive(LevelManager.instance.inEditorMode);
		}

		// Token: 0x060010F5 RID: 4341 RVA: 0x0003C2E8 File Offset: 0x0003A4E8
		public void ClearObjectSelection()
		{
			if (this.favsButtonContext)
			{
				this.favsButtonContext.ClearObject();
				int item = this.favsButtons.Select((DynamicLevelObjButton b, int i) => new ValueTuple<DynamicLevelObjButton, int>(b, i)).First(([TupleElementNames(new string[]
				{
					"b",
					"i"
				})] ValueTuple<DynamicLevelObjButton, int> b) => b.Item1 == this.favsButtonContext).Item2;
				this.favsPalette.objIds[item] = "";
			}
			this.favsButtonContext = null;
			this.levelObjSelectionToggleContext = null;
		}

		// Token: 0x060010F6 RID: 4342 RVA: 0x0003C370 File Offset: 0x0003A570
		public void ConfirmObjSelection()
		{
			if (this.levelObjSelectionToggleContext)
			{
				if (this.favsButtonContext)
				{
					this.favsButtonContext.Init(this.levelObjSelectionToggleContext.objName, this.levelObjSelectionToggleContext.objSprite, this.levelObjSelectionToggleContext.obj.flipIcon);
					this.favsButtonContext.PassGameObjectToPlaceHook();
					int item = this.favsButtons.Select((DynamicLevelObjButton b, int i) => new ValueTuple<DynamicLevelObjButton, int>(b, i)).First(([TupleElementNames(new string[]
					{
						"b",
						"i"
					})] ValueTuple<DynamicLevelObjButton, int> b) => b.Item1 == this.favsButtonContext).Item2;
					this.favsPalette.objIds[item] = this.levelObjSelectionToggleContext.objName;
				}
				else
				{
					LevelCreator.instance.PassGameObjectToPlace(this.levelObjSelectionToggleContext.objName);
				}
			}
			this.favsButtonContext = null;
			this.levelObjSelectionToggleContext = null;
		}

		// Token: 0x060010F7 RID: 4343 RVA: 0x0003C457 File Offset: 0x0003A657
		public void CancelObjSelection()
		{
			this.favsButtonContext = null;
			this.levelObjSelectionToggleContext = null;
		}

		// Token: 0x060010F8 RID: 4344 RVA: 0x0003C468 File Offset: 0x0003A668
		public void PerformSearchHook()
		{
			string text = this.searchInputField.text;
			if (this.lastSearchQuery == null || this.lastSearchQuery != text)
			{
				LevelResourcesManager.instance.database.Search(text);
				this.lastSearchQuery = text;
			}
		}

		// Token: 0x060010F9 RID: 4345 RVA: 0x0003C4B0 File Offset: 0x0003A6B0
		public void OnObjSelectionScreenFocused()
		{
			bool active = this.favsButtonContext != null;
			this.objSelectionBackBtn.SetActive(active);
			this.objSelectionClearBtn.SetActive(active);
		}

		// Token: 0x04000AE0 RID: 2784
		public static LevelInterfaceManager instance;

		// Token: 0x04000AE1 RID: 2785
		public bool mouseOverUI;

		// Token: 0x04000AE2 RID: 2786
		public GameObject playIconGO;

		// Token: 0x04000AE3 RID: 2787
		public GameObject editorIconGO;

		// Token: 0x04000AE4 RID: 2788
		public Button playEditButton;

		// Token: 0x04000AE5 RID: 2789
		public Button saveDialogueButton;

		// Token: 0x04000AE6 RID: 2790
		public Button loadDialogueButton;

		// Token: 0x04000AE7 RID: 2791
		public Button newLevelButton;

		// Token: 0x04000AE8 RID: 2792
		public Button leaveButton;

		// Token: 0x04000AE9 RID: 2793
		public Toggle drawToggle;

		// Token: 0x04000AEA RID: 2794
		public Toggle deleteToggle;

		// Token: 0x04000AEB RID: 2795
		public Transform userCreatedButtonHolder;

		// Token: 0x04000AEC RID: 2796
		public Transform flashbackTapesButtonHolder;

		// Token: 0x04000AED RID: 2797
		public Transform ukaTrialsButtonHolder;

		// Token: 0x04000AEE RID: 2798
		public GameObject loadLevelButtonPrefab;

		// Token: 0x04000AEF RID: 2799
		public LevelStats levelStats;

		// Token: 0x04000AF0 RID: 2800
		[Header("---Save Screen---")]
		public TMP_InputField saveInputField;

		// Token: 0x04000AF1 RID: 2801
		public TMP_InputField levelAuthorInputField;

		// Token: 0x04000AF2 RID: 2802
		public TMP_Dropdown musicDropdown;

		// Token: 0x04000AF3 RID: 2803
		public TMP_Dropdown levelTypeDropdown;

		// Token: 0x04000AF4 RID: 2804
		public Button exportButton;

		// Token: 0x04000AF5 RID: 2805
		public Button saveButton;

		// Token: 0x04000AF6 RID: 2806
		public Button musicTestButton;

		// Token: 0x04000AF7 RID: 2807
		public AudioSource testMusicAudioSource;

		// Token: 0x04000AF8 RID: 2808
		public Image testMusicIcon;

		// Token: 0x04000AF9 RID: 2809
		public Sprite testMusicSprite;

		// Token: 0x04000AFA RID: 2810
		public Sprite stopMusicSprite;

		// Token: 0x04000AFB RID: 2811
		public GameObject editorOverlay;

		// Token: 0x04000AFC RID: 2812
		[Header("---Editor HUD---")]
		public UIScreen editorHUD;

		// Token: 0x04000AFD RID: 2813
		public UIScreen welcomeScreen;

		// Token: 0x04000AFE RID: 2814
		public UIScreen flashbackResults;

		// Token: 0x04000AFF RID: 2815
		public UIScreen dynamicResults;

		// Token: 0x04000B00 RID: 2816
		public UIScreen ukaTrialResults;

		// Token: 0x04000B01 RID: 2817
		public WarningScreen warningScreen;

		// Token: 0x04000B02 RID: 2818
		public ObjectInfoPanel objectInfoPanel;

		// Token: 0x04000B03 RID: 2819
		[Header("---Uka Trial Settings---")]
		public UIScreen ukaTrialSettingsScreen;

		// Token: 0x04000B04 RID: 2820
		public TMP_InputField bronzeInputfield;

		// Token: 0x04000B05 RID: 2821
		public TMP_InputField silverInputfield;

		// Token: 0x04000B06 RID: 2822
		public TMP_InputField goldInputfield;

		// Token: 0x04000B07 RID: 2823
		[Header("---Other---")]
		public GameObject boxCollectionObject;

		// Token: 0x04000B08 RID: 2824
		public GameObject timeTrialObject;

		// Token: 0x04000B09 RID: 2825
		public TMP_Text boxesText;

		// Token: 0x04000B0A RID: 2826
		public TMP_Text trialTimeText;

		// Token: 0x04000B0B RID: 2827
		public TMP_FontAsset timetrialFontDefault;

		// Token: 0x04000B0C RID: 2828
		public TMP_FontAsset timetrialFontPaused;

		// Token: 0x04000B0D RID: 2829
		public AudioSource clockTickSource;

		// Token: 0x04000B0E RID: 2830
		public TMP_InputField searchInputField;

		// Token: 0x04000B0F RID: 2831
		public Button searchButton;

		// Token: 0x04000B10 RID: 2832
		[Header("---Scroll Holders---")]
		public Transform crateScrollHolder;

		// Token: 0x04000B11 RID: 2833
		public Transform blocksScrollHolder;

		// Token: 0x04000B12 RID: 2834
		public Transform hazardScrollHolder;

		// Token: 0x04000B13 RID: 2835
		public Transform gameplayScrollHolder;

		// Token: 0x04000B14 RID: 2836
		public Transform enemiesScrollHolder;

		// Token: 0x04000B15 RID: 2837
		public Transform favouritesScrollHolder;

		// Token: 0x04000B16 RID: 2838
		[Header("---Object Selection Screen---")]
		public UIScreen levelObjectSelectionScreen;

		// Token: 0x04000B17 RID: 2839
		public Transform objSelectionGridHolder;

		// Token: 0x04000B18 RID: 2840
		public GameObject objSelectionBackBtn;

		// Token: 0x04000B19 RID: 2841
		public GameObject objSelectionClearBtn;

		// Token: 0x04000B1B RID: 2843
		[Header("------")]
		public ObjectPalette favsPalette;

		// Token: 0x04000B1C RID: 2844
		public DynamicLevelObjButton[] favsButtons;

		// Token: 0x04000B1D RID: 2845
		public DynamicLevelObjButton favsButtonContext;

		// Token: 0x04000B1E RID: 2846
		public LevelObjSelectionToggle levelObjSelectionToggleContext;

		// Token: 0x04000B1F RID: 2847
		public int maxBoxCount;

		// Token: 0x04000B20 RID: 2848
		public bool timeTrialStarted;

		// Token: 0x04000B21 RID: 2849
		[HideInInspector]
		public bool startedTrial;

		// Token: 0x04000B22 RID: 2850
		public int ticksElapsed;

		// Token: 0x04000B23 RID: 2851
		public int pauseTicks;

		// Token: 0x04000B24 RID: 2852
		public Image[] shiftButtonImages;

		// Token: 0x04000B25 RID: 2853
		public GameObject[] content;

		// Token: 0x04000B26 RID: 2854
		public GameObject[] sceneryContent;

		// Token: 0x04000B27 RID: 2855
		public GameObject[] weatherContent;

		// Token: 0x04000B28 RID: 2856
		private int currentContent;

		// Token: 0x04000B29 RID: 2857
		public int currentSceneryContent;

		// Token: 0x04000B2A RID: 2858
		public int initialWeather;

		// Token: 0x04000B2B RID: 2859
		public int rollbackWeather;

		// Token: 0x04000B2C RID: 2860
		public int currentWeather;

		// Token: 0x04000B2D RID: 2861
		public int initialMusic;

		// Token: 0x04000B2E RID: 2862
		public int rollbackMusic;

		// Token: 0x04000B2F RID: 2863
		public int currentMusic;

		// Token: 0x04000B30 RID: 2864
		public int currentSkybox;

		// Token: 0x04000B31 RID: 2865
		public int currentLevelType;

		// Token: 0x04000B32 RID: 2866
		public int timeTrialBronze;

		// Token: 0x04000B33 RID: 2867
		public int timeTrialSilver;

		// Token: 0x04000B34 RID: 2868
		public int timeTrialGold;

		// Token: 0x04000B35 RID: 2869
		private bool playingJukebox;

		// Token: 0x04000B39 RID: 2873
		private SpecialGem specialGem;

		// Token: 0x04000B3A RID: 2874
		private bool checkedForSpecialGem;

		// Token: 0x04000B3B RID: 2875
		private CrystalPickup allCratesGem;

		// Token: 0x04000B3C RID: 2876
		private bool checkedForAllCratesGem;

		// Token: 0x04000B3D RID: 2877
		private string lastSearchQuery;
	}
}
