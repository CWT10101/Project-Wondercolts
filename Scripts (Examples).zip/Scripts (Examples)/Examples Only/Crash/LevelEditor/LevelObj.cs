﻿using System;
using System.IO;
using UnityEngine;
using UnityEngine.Serialization;

namespace LevelEditor
{
	// Token: 0x020001AF RID: 431
	public class LevelObj : MonoBehaviour
	{
		// Token: 0x17000434 RID: 1076
		// (get) Token: 0x060010FD RID: 4349 RVA: 0x0003C53C File Offset: 0x0003A73C
		// (set) Token: 0x060010FE RID: 4350 RVA: 0x0003C544 File Offset: 0x0003A744
		public bool IsSingularInstance { get; private set; }

		// Token: 0x1400001C RID: 28
		// (add) Token: 0x060010FF RID: 4351 RVA: 0x0003C550 File Offset: 0x0003A750
		// (remove) Token: 0x06001100 RID: 4352 RVA: 0x0003C588 File Offset: 0x0003A788
		public event Action<LevelObj> OnObjDeleted;

		// Token: 0x06001101 RID: 4353 RVA: 0x0003C5C0 File Offset: 0x0003A7C0
		private void OnDestroy()
		{
			if (base.gameObject.scene.isLoaded)
			{
				Action<LevelObj> onObjDeleted = this.OnObjDeleted;
				if (onObjDeleted != null)
				{
					onObjDeleted(this);
				}
				ObjectMetadata[] metadata = this.GetMetadata();
				for (int i = 0; i < metadata.Length; i++)
				{
					metadata[i].OnDeleted(this);
				}
			}
		}

		// Token: 0x06001102 RID: 4354 RVA: 0x0003C614 File Offset: 0x0003A814
		public void UpdateTile(Tile[,] grid)
		{
			Vector3 vector = grid[this.gridPosX, this.gridPosY].Position;
			vector += this.worldPositionOffset;
			base.transform.position = vector;
		}

		// Token: 0x06001103 RID: 4355 RVA: 0x0003C654 File Offset: 0x0003A854
		public void SetPlayMode(bool play)
		{
			this.gameplayVis.SetActive(play);
			this.editorVis.SetActive(!play);
			Entity componentInChildren = this.gameplayVis.GetComponentInChildren<Entity>(true);
			if (componentInChildren != null)
			{
				componentInChildren.ResetEntity();
			}
		}

		// Token: 0x06001104 RID: 4356 RVA: 0x0003C692 File Offset: 0x0003A892
		public void Select(bool inTransit = false)
		{
			Outline componentInChildren = this.editorVis.GetComponentInChildren<Outline>();
			componentInChildren.enabled = true;
			componentInChildren.OutlineColor = (inTransit ? LevelResourcesManager.instance.selectionColorTransit : LevelResourcesManager.instance.selectionColorNormal);
			componentInChildren.OutlineMode = (inTransit ? Outline.Mode.OutlineAll : Outline.Mode.OutlineVisible);
		}

		// Token: 0x06001105 RID: 4357 RVA: 0x0003C6D1 File Offset: 0x0003A8D1
		public void Deselect()
		{
			this.editorVis.GetComponentInChildren<Outline>().enabled = false;
		}

		// Token: 0x06001106 RID: 4358 RVA: 0x0003C6E4 File Offset: 0x0003A8E4
		public void SetOutline()
		{
			this.editorOutlineVis.SetActive(this.activatorConnections > 0);
			this.editorSprite.color = new Color(this.editorSprite.color.r, this.editorSprite.color.g, this.editorSprite.color.b, (this.activatorConnections > 0) ? 0.5f : 1f);
			Crate componentInChildren = base.GetComponentInChildren<Crate>(true);
			if (componentInChildren != null)
			{
				componentInChildren.startAsOutlineCrate = (this.activatorConnections > 0);
				if (this.activatorConnections > 0)
				{
					componentInChildren.SetOutlineMode();
					return;
				}
				componentInChildren.SetTangibleMode();
			}
		}

		// Token: 0x06001107 RID: 4359 RVA: 0x0003C78C File Offset: 0x0003A98C
		public ObjectMetadata[] GetMetadata()
		{
			if (this.metaArr == null)
			{
				this.metaArr = base.GetComponents<ObjectMetadata>();
				this.metaHash = 0;
				foreach (ObjectMetadata objectMetadata in this.metaArr)
				{
					this.metaHash ^= objectMetadata.GetHashCode();
				}
			}
			return this.metaArr;
		}

		// Token: 0x06001108 RID: 4360 RVA: 0x0003C7E6 File Offset: 0x0003A9E6
		public int GetMetadataHash()
		{
			if (this.metaArr == null)
			{
				this.GetMetadata();
			}
			return this.metaHash;
		}

		// Token: 0x06001109 RID: 4361 RVA: 0x0003C800 File Offset: 0x0003AA00
		public void Serialize(BinaryWriter bw)
		{
			bw.Write(this.obj_ID);
			bw.Write((short)this.gridPosX);
			bw.Write((short)this.gridPosY);
			ObjectMetadata[] metadata = this.GetMetadata();
			bw.Write(metadata.Length != 0);
			if (metadata.Length != 0)
			{
				long position = bw.BaseStream.Position;
				bw.Write(0);
				for (int i = 0; i < metadata.Length; i++)
				{
					metadata[i].Serialize(bw);
				}
				short num = (short)(bw.BaseStream.Position - (position + 2L));
				bw.BaseStream.Position = position;
				bw.Write(num);
				bw.BaseStream.Seek((long)num, SeekOrigin.Current);
			}
		}

		// Token: 0x0600110A RID: 4362 RVA: 0x0003C8A7 File Offset: 0x0003AAA7
		public void Deserialize(SaveableLevelObject obj)
		{
		}

		// Token: 0x0600110B RID: 4363 RVA: 0x0003C8AC File Offset: 0x0003AAAC
		public static SaveableLevelObject Deserialize(byte version, BinaryReader br)
		{
			if (version == 1)
			{
				throw new NotImplementedException();
			}
			if (version == 2 || version == 3 || version == 4)
			{
				SaveableLevelObject saveableLevelObject = new SaveableLevelObject();
				saveableLevelObject.obj_ID = br.ReadString();
				saveableLevelObject.posX = (int)br.ReadInt16();
				saveableLevelObject.posY = (int)br.ReadInt16();
				if (br.ReadBoolean())
				{
					saveableLevelObject.metaStream = new MemoryStream();
					short num = br.ReadInt16();
					byte[] buffer = new byte[(int)num];
					br.Read(buffer, 0, (int)num);
					saveableLevelObject.metaStream.Write(buffer, 0, (int)num);
				}
				else if (version == 2 && saveableLevelObject.obj_ID == "Obj_TNT")
				{
					saveableLevelObject.metaStream = new MemoryStream();
					saveableLevelObject.metaStream.WriteByte(0);
				}
				return saveableLevelObject;
			}
			Debug.LogError("Unknown version " + version.ToString());
			return null;
		}

		// Token: 0x0600110C RID: 4364 RVA: 0x0003C97D File Offset: 0x0003AB7D
		private void OnDrawGizmosSelected()
		{
			Gizmos.color = Color.cyan;
			Gizmos.matrix = base.transform.localToWorldMatrix;
			Gizmos.DrawWireCube(this.objBounds.center, this.objBounds.size);
		}

		// Token: 0x0600110D RID: 4365 RVA: 0x0003C9B4 File Offset: 0x0003ABB4
		public override string ToString()
		{
			return string.Format("{0} @ ({1}, {2})", this.obj_ID, this.gridPosX, this.gridPosY);
		}

		// Token: 0x04000B3F RID: 2879
		public string obj_instanceGroup;

		// Token: 0x04000B40 RID: 2880
		public string obj_ID;

		// Token: 0x04000B41 RID: 2881
		[FormerlySerializedAs("obj_class")]
		public string obj_category;

		// Token: 0x04000B42 RID: 2882
		public Sprite obj_Icon;

		// Token: 0x04000B43 RID: 2883
		public Sprite Obj_IconCocoVariant;

		// Token: 0x04000B44 RID: 2884
		public bool flipIcon;

		// Token: 0x04000B45 RID: 2885
		public int gridPosX;

		// Token: 0x04000B46 RID: 2886
		public int gridPosY;

		// Token: 0x04000B47 RID: 2887
		public GameObject editorVis;

		// Token: 0x04000B48 RID: 2888
		public GameObject gameplayVis;

		// Token: 0x04000B49 RID: 2889
		public GameObject editorOutlineVis;

		// Token: 0x04000B4A RID: 2890
		public SpriteRenderer editorSprite;

		// Token: 0x04000B4B RID: 2891
		public bool isBreakable;

		// Token: 0x04000B4C RID: 2892
		public Vector3 worldPositionOffset;

		// Token: 0x04000B4D RID: 2893
		public Bounds objBounds = new Bounds(Vector3.zero, Vector3.one);

		// Token: 0x04000B4E RID: 2894
		public bool excludeFromEditor3D;

		// Token: 0x04000B4F RID: 2895
		public bool excludeFromEditor2D;

		// Token: 0x04000B51 RID: 2897
		public byte activatorConnections;

		// Token: 0x04000B52 RID: 2898
		private ObjectMetadata[] metaArr;

		// Token: 0x04000B53 RID: 2899
		private int metaHash;
	}
}
