﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace LevelEditor
{
	// Token: 0x020001B2 RID: 434
	public class LevelObjSelectionToggle : MonoBehaviour
	{
		// Token: 0x17000435 RID: 1077
		// (get) Token: 0x06001113 RID: 4371 RVA: 0x0003CACA File Offset: 0x0003ACCA
		public string objName
		{
			get
			{
				return this.obj.obj_ID;
			}
		}

		// Token: 0x17000436 RID: 1078
		// (get) Token: 0x06001114 RID: 4372 RVA: 0x0003CAD7 File Offset: 0x0003ACD7
		public Sprite objSprite
		{
			get
			{
				return this.GetSprite();
			}
		}

		// Token: 0x06001115 RID: 4373 RVA: 0x0003CADF File Offset: 0x0003ACDF
		private Sprite GetSprite()
		{
			if (this.obj.Obj_IconCocoVariant == null)
			{
				return this.obj.obj_Icon;
			}
			if (CrashAnimator.Skin != 0)
			{
				return this.obj.Obj_IconCocoVariant;
			}
			return this.obj.obj_Icon;
		}

		// Token: 0x06001116 RID: 4374 RVA: 0x0003CB20 File Offset: 0x0003AD20
		public void Init(LevelObj obj, bool flipIcon = false)
		{
			base.gameObject.name = "LevelObjSelectionToggle:" + obj.obj_ID;
			this.toggle.group = base.GetComponentInParent<ToggleGroup>(true);
			this.obj = obj;
			Sprite sprite;
			if (CrashAnimator.Skin != 0 && obj.Obj_IconCocoVariant != null)
			{
				sprite = obj.Obj_IconCocoVariant;
			}
			else
			{
				sprite = obj.obj_Icon;
			}
			this.objImage.sprite = sprite;
			if (flipIcon)
			{
				this.objImage.transform.localScale = new Vector3(-1f, 1f, 1f);
			}
		}

		// Token: 0x06001117 RID: 4375 RVA: 0x0003CBB9 File Offset: 0x0003ADB9
		public void SetToggleHook()
		{
			LevelInterfaceManager.instance.levelObjSelectionToggleContext = this;
		}

		// Token: 0x04000B5A RID: 2906
		public Image objImage;

		// Token: 0x04000B5B RID: 2907
		[HideInInspector]
		public LevelObj obj;

		// Token: 0x04000B5C RID: 2908
		public Toggle toggle;
	}
}
