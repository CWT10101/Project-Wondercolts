﻿using System;
using System.Linq;
using UnityEngine;

namespace LevelEditor
{
	// Token: 0x020001C0 RID: 448
	public class SelectTool : EditorTool
	{
		// Token: 0x17000448 RID: 1096
		// (get) Token: 0x0600116B RID: 4459 RVA: 0x0003DFAA File Offset: 0x0003C1AA
		public override bool PrimaryIsContinuous
		{
			get
			{
				return !this.subTool || this.subTool.PrimaryIsContinuous;
			}
		}

		// Token: 0x17000449 RID: 1097
		// (get) Token: 0x0600116C RID: 4460 RVA: 0x0003DFC6 File Offset: 0x0003C1C6
		public override bool SecondaryIsContinuous
		{
			get
			{
				return !this.subTool || this.subTool.SecondaryIsContinuous;
			}
		}

		// Token: 0x0600116D RID: 4461 RVA: 0x0003DFE4 File Offset: 0x0003C1E4
		public override void PrimaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
			if (this.subTool == null)
			{
				if (this.cancelAction)
				{
					if (phase == EditorTool.ToolPhase.End)
					{
						this.cancelAction = false;
					}
					return;
				}
				if (Selection.instance.InTransit)
				{
					Tile tile;
					bool tileAtMouse = LevelCreator.GetTileAtMouse(out tile);
					if (phase == EditorTool.ToolPhase.Begin)
					{
						if (tileAtMouse)
						{
							this.firstSelectedTile = (this.prevHoveredTile = tile);
							this.canDrag = true;
						}
						this.prevDragPos = LevelCreator.MousePos;
						this.dragTarget = Selection.instance.Transit.position;
						return;
					}
					if (phase == EditorTool.ToolPhase.Hold)
					{
						this.dragTarget += LevelCreator.MousePos - this.prevDragPos;
						Selection.instance.Transit.position = new Vector3(Mathf.Round(this.dragTarget.x - this.transitOffset.x) + this.transitOffset.x, Mathf.Round(this.dragTarget.y - this.transitOffset.y) + this.transitOffset.y, 0f);
						this.prevDragPos = LevelCreator.MousePos;
						if (this.canDrag)
						{
							if (timeActive >= this.dragTimeout)
							{
								this.cancelAction = true;
								Selection.CommitTransit();
								return;
							}
							if (tile != this.firstSelectedTile)
							{
								this.canDrag = false;
								return;
							}
						}
					}
					else if (phase == EditorTool.ToolPhase.End)
					{
						Selection.instance.Transit.transform.position = new Vector3(Mathf.Round(this.dragTarget.x - this.transitOffset.x) + this.transitOffset.x, Mathf.Round(this.dragTarget.y - this.transitOffset.y) + this.transitOffset.y, 0f);
						return;
					}
				}
				else
				{
					if (phase == EditorTool.ToolPhase.End)
					{
						if (this.canDrag && timeActive < this.dragTimeout)
						{
							Selection.DeselectAll();
						}
						else if (this.firstSelectedTile == this.prevHoveredTile && (this.firstSelectedTile == null || this.firstSelectedTile.placedObj == null))
						{
							Selection.DeselectAll();
						}
						LevelInterfaceManager.instance.objectInfoPanel.SetContext(Selection.Enumerate());
						this.firstSelectedTile = (this.prevHoveredTile = null);
						return;
					}
					Tile tile2;
					bool tileAtMouse2 = LevelCreator.GetTileAtMouse(out tile2);
					if (phase == EditorTool.ToolPhase.Begin && tileAtMouse2)
					{
						this.firstSelectedTile = (this.prevHoveredTile = tile2);
						if (tile2.placedObj)
						{
							if (Selection.Contains(tile2.placedObj))
							{
								this.canDrag = true;
							}
							else
							{
								this.canDrag = false;
								Selection.DeselectAll();
								Selection.Include(tile2.placedObj);
							}
						}
					}
					if (phase == EditorTool.ToolPhase.Hold && this.firstSelectedTile != null)
					{
						if (this.prevHoveredTile != tile2)
						{
							this.canDrag = false;
							Selection.DeselectAll();
							Selection.Include(from t in GridManager.instance.GetArea(this.firstSelectedTile.posX, this.firstSelectedTile.posY, tile2.posX, tile2.posY)
							select t.placedObj into o
							where o
							select o);
							this.prevHoveredTile = tile2;
							return;
						}
						if (this.canDrag && timeActive >= this.dragTimeout)
						{
							this.canDrag = false;
							Selection.MoveToTransit();
							Vector3 position = Selection.instance.Transit.transform.position;
							this.transitOffset = new Vector2(position.x % 1f, position.y % 1f);
							this.cancelAction = true;
							Debug.LogWarning("Hold Action");
							return;
						}
					}
				}
			}
			else
			{
				this.subTool.PrimaryAction(phase, timeActive);
			}
		}

		// Token: 0x0600116E RID: 4462 RVA: 0x0003E3A8 File Offset: 0x0003C5A8
		public override void SecondaryAction(EditorTool.ToolPhase phase, float timeActive)
		{
			if (this.subTool == null)
			{
				if (Selection.instance.InTransit)
				{
					Selection.CancelTransit();
					return;
				}
				Tile tile;
				if (LevelCreator.GetTileAtMouse(out tile) && tile.placedObj)
				{
					Selection.Exclude(tile.placedObj);
					LevelInterfaceManager.instance.objectInfoPanel.SetContext(Selection.Enumerate());
					return;
				}
			}
			else
			{
				this.subTool.SecondaryAction(phase, timeActive);
			}
		}

		// Token: 0x0600116F RID: 4463 RVA: 0x0003E418 File Offset: 0x0003C618
		public override void OnToolDisabled()
		{
			if (this.subTool)
			{
				this.subTool.OnToolDisabled();
				this.subTool = null;
			}
			if (Selection.instance.InTransit)
			{
				Selection.CancelTransit();
			}
			Selection.DeselectAll();
			if (LevelInterfaceManager.instance)
			{
				LevelInterfaceManager.instance.objectInfoPanel.SetContext(null);
			}
		}

		// Token: 0x06001170 RID: 4464 RVA: 0x0003E478 File Offset: 0x0003C678
		public void SetSubTool(EditorTool tool)
		{
			SubTool<SelectTool> subTool = tool as SubTool<SelectTool>;
			if (subTool != null)
			{
				if (this.subTool == subTool)
				{
					if (this.subTool)
					{
						this.subTool.OnToolDisabled();
					}
					this.subTool = null;
					return;
				}
				if (this.subTool)
				{
					this.subTool.OnToolDisabled();
				}
				this.subTool = subTool;
				if (this.subTool)
				{
					this.subTool.OnToolEnabled();
					return;
				}
			}
			else
			{
				Debug.LogWarning(string.Format("{0} type mismatch: {1} should be {2}", tool, tool.GetType(), typeof(SubTool<SelectTool>)));
			}
		}

		// Token: 0x04000B7E RID: 2942
		private SubTool<SelectTool> subTool;

		// Token: 0x04000B7F RID: 2943
		private Tile firstSelectedTile;

		// Token: 0x04000B80 RID: 2944
		private Tile prevHoveredTile;

		// Token: 0x04000B81 RID: 2945
		private bool canDrag;

		// Token: 0x04000B82 RID: 2946
		private bool cancelAction;

		// Token: 0x04000B83 RID: 2947
		private readonly float dragTimeout = 0.5f;

		// Token: 0x04000B84 RID: 2948
		private Vector3 prevDragPos;

		// Token: 0x04000B85 RID: 2949
		private Vector3 dragTarget;

		// Token: 0x04000B86 RID: 2950
		private Vector2 transitOffset;
	}
}
