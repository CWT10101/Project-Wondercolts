﻿using System;
using UnityEngine;

namespace LevelEditor
{
	// Token: 0x020001A9 RID: 425
	public class GizmoStyle
	{
		// Token: 0x04000ABF RID: 2751
		public Color32? color;
	}
}
