﻿using System;
using System.Collections.Generic;
using System.IO;

namespace LevelEditor
{
	// Token: 0x020001B5 RID: 437
	[Serializable]
	public struct ObjectPalette
	{
		// Token: 0x0600111D RID: 4381 RVA: 0x0003CC58 File Offset: 0x0003AE58
		public void Serialize(BinaryWriter bw)
		{
			bw.Write(this.objIds.Length);
			for (int i = 0; i < this.objIds.Length; i++)
			{
				bw.Write(this.objIds[i]);
			}
		}

		// Token: 0x0600111E RID: 4382 RVA: 0x0003CC94 File Offset: 0x0003AE94
		public void Deserialize(BinaryReader br)
		{
			int num = br.ReadInt32();
			this.objIds = new string[num];
			for (int i = 0; i < num; i++)
			{
				string text = br.ReadString();
				this.objIds[i] = text;
			}
		}

		// Token: 0x0600111F RID: 4383 RVA: 0x0003CCD0 File Offset: 0x0003AED0
		public IEnumerator<LevelObj> GetEnumerator()
		{
			foreach (string objID in this.objIds)
			{
				LevelObj levelObj;
				try
				{
					levelObj = LevelResourcesManager.instance.GetObjBase(objID).objPrefab.GetComponent<LevelObj>();
				}
				catch
				{
					levelObj = null;
				}
				yield return levelObj;
			}
			string[] array = null;
			yield break;
		}

		// Token: 0x04000B69 RID: 2921
		public string[] objIds;
	}
}
