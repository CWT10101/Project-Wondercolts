﻿using System;
using Cinemachine;
using Rewired;
using UnityEngine;
using UnityEngine.EventSystems;

namespace LevelEditor
{
	// Token: 0x020001AD RID: 429
	public class LevelEditorCamera : MonoBehaviour
	{
		// Token: 0x060010AB RID: 4267 RVA: 0x0003A9A8 File Offset: 0x00038BA8
		private void Awake()
		{
			LevelEditorCamera.instance = this;
		}

		// Token: 0x060010AC RID: 4268 RVA: 0x0003A9B0 File Offset: 0x00038BB0
		private void Start()
		{
			this.editorCam.m_Lens.OrthographicSize = this.startingZoom;
			this.rw = ReInput.players.GetPlayer(0);
		}

		// Token: 0x060010AD RID: 4269 RVA: 0x0003A9DC File Offset: 0x00038BDC
		private void Update()
		{
			if (LevelManager.instance.inEditorMode && UIScreen.activeScreen == LevelInterfaceManager.instance.editorHUD && !EventSystem.current.IsPointerOverGameObject())
			{
				if (this.rw.GetButtonDown("Pan"))
				{
					this.lastMousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
				}
				if (this.rw.GetButton("Pan"))
				{
					Vector3 a = Camera.main.ScreenToWorldPoint(Input.mousePosition);
					Vector3 vector = a - this.lastMousePos;
					this.editorCamTarget.Translate(-vector.x, -vector.y, 0f);
					this.lastMousePos = a;
				}
				Vector2 axis2D = this.rw.GetAxis2D("PanHorizontal", "PanVertical");
				if (axis2D.sqrMagnitude > 0f)
				{
					this.editorCamTarget.Translate(axis2D.x * this.panSpeed * Time.unscaledDeltaTime, axis2D.y * this.panSpeed * Time.unscaledDeltaTime, 0f);
				}
				float axis = this.rw.GetAxis("Zoom");
				this.ZoomCamera(axis, this.orthoZoomSpeed);
			}
		}

		// Token: 0x060010AE RID: 4270 RVA: 0x0003AB13 File Offset: 0x00038D13
		public void ToggleOrthographicCam(bool ortho)
		{
			this.mainCamera.orthographic = ortho;
		}

		// Token: 0x060010AF RID: 4271 RVA: 0x0003AB21 File Offset: 0x00038D21
		private void ZoomCamera(float offset, float speed)
		{
			if (offset == 0f)
			{
				return;
			}
			this.editorCam.m_Lens.OrthographicSize = Mathf.Clamp(this.editorCam.m_Lens.OrthographicSize - offset * speed, this.minZoom, this.maxZoom);
		}

		// Token: 0x04000AD3 RID: 2771
		public static LevelEditorCamera instance;

		// Token: 0x04000AD4 RID: 2772
		public Camera mainCamera;

		// Token: 0x04000AD5 RID: 2773
		public CinemachineVirtualCameraBase playCam;

		// Token: 0x04000AD6 RID: 2774
		public CinemachineVirtualCamera editorCam;

		// Token: 0x04000AD7 RID: 2775
		public Transform crashCamTarget;

		// Token: 0x04000AD8 RID: 2776
		public Transform editorCamTarget;

		// Token: 0x04000AD9 RID: 2777
		public float orthoZoomSpeed = 1f;

		// Token: 0x04000ADA RID: 2778
		public float startingZoom = 8f;

		// Token: 0x04000ADB RID: 2779
		public float minZoom = 3f;

		// Token: 0x04000ADC RID: 2780
		public float maxZoom = 15f;

		// Token: 0x04000ADD RID: 2781
		[Header("Camera Panning")]
		public float panSpeed = 0.05f;

		// Token: 0x04000ADE RID: 2782
		private Vector3 lastMousePos;

		// Token: 0x04000ADF RID: 2783
		private Player rw;
	}
}
