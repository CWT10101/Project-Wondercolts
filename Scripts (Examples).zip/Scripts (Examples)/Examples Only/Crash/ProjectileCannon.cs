﻿using System;
using System.Linq;
using UnityEngine;

// Token: 0x02000103 RID: 259
public class ProjectileCannon : Entity, IMetadataReceiver<ProjectileMetadata>, IMetadataReceiver<SpeedMetadata>, IMetadataReceiver<ShootsOneMetadata>
{
	// Token: 0x170000FF RID: 255
	// (get) Token: 0x060007E4 RID: 2020 RVA: 0x00021791 File Offset: 0x0001F991
	public Vector3 ColliderCenter
	{
		get
		{
			return base.transform.TransformPoint(this.coll.center);
		}
	}

	// Token: 0x060007E5 RID: 2021 RVA: 0x000217A9 File Offset: 0x0001F9A9
	private void OnEnable()
	{
		if (!this.shootsOnce)
		{
			this.TryPushToStack();
		}
		this.spawnedProjectile = null;
		this.shooting = false;
	}

	// Token: 0x060007E6 RID: 2022 RVA: 0x000217C8 File Offset: 0x0001F9C8
	private void FixedUpdate()
	{
		if (this.shootsOnce && this.spawnedProjectile)
		{
			return;
		}
		if (this.shooting)
		{
			return;
		}
		if (this.shootsOnce)
		{
			foreach (Collider collider in Physics.OverlapSphere(this.collider.bounds.center, this.triggerRadius))
			{
				Debug.DrawLine(this.collider.bounds.center, collider.bounds.center, new Color(0f, 1f, 0f, 0.1f), Time.fixedDeltaTime);
				CrashController crashController;
				if (collider.TryGetComponent<CrashController>(out crashController))
				{
					Debug.DrawLine(this.collider.bounds.center, collider.bounds.center, new Color(0f, 1f, 0f), Time.fixedDeltaTime);
					RaycastHit raycastHit = (from h in Physics.RaycastAll(this.collider.bounds.center, collider.bounds.center - this.ColliderCenter, this.triggerRadius, -1, QueryTriggerInteraction.Ignore)
					orderby h.distance
					where h.collider.gameObject != base.gameObject
					select h).FirstOrDefault<RaycastHit>();
					if (raycastHit.collider == collider)
					{
						Debug.DrawLine(this.collider.bounds.center, raycastHit.point, new Color(1f, 0f, 0f), 1f);
						this.animator.SetTrigger("Shoot");
						this.TryPushToStack();
						return;
					}
				}
			}
			return;
		}
		this.animator.SetTrigger("Shoot");
	}

	// Token: 0x060007E7 RID: 2023 RVA: 0x000219AA File Offset: 0x0001FBAA
	public void SetShootingTrue()
	{
		this.shooting = true;
	}

	// Token: 0x060007E8 RID: 2024 RVA: 0x000219B4 File Offset: 0x0001FBB4
	public void SpawnProjectile()
	{
		if (Level.instance)
		{
			this.spawnedProjectile = Object.Instantiate<Projectile>(this.projectilePrefab, this.spawnNode.position + base.transform.TransformVector(this.projectilePrefab.spawnOffset), this.spawnNode.rotation, Level.instance.transform);
		}
		else if (LevelManager.instance)
		{
			this.spawnedProjectile = Object.Instantiate<Projectile>(this.projectilePrefab, this.spawnNode.position + base.transform.TransformVector(this.projectilePrefab.spawnOffset), this.spawnNode.rotation, LevelManager.instance.projectileHolder);
		}
		else
		{
			this.spawnedProjectile = Object.Instantiate<Projectile>(this.projectilePrefab, this.spawnNode.position + base.transform.TransformVector(this.projectilePrefab.spawnOffset), this.spawnNode.rotation);
		}
		this.PostProcessProjectile(this.spawnedProjectile);
		if (!string.IsNullOrEmpty(this.fireSFX))
		{
			AudioManager.Play(this.fireSFX, AudioManager.MixerTarget.SFX, new Vector3?(this.spawnNode.position), null);
		}
		this.shooting = false;
	}

	// Token: 0x060007E9 RID: 2025 RVA: 0x00021B00 File Offset: 0x0001FD00
	protected virtual void PostProcessProjectile(Projectile p)
	{
	}

	// Token: 0x060007EA RID: 2026 RVA: 0x00021B02 File Offset: 0x0001FD02
	public override void ResetEntity()
	{
		base.ResetEntity();
		this.spawnedProjectile = null;
		this.shooting = false;
	}

	// Token: 0x060007EB RID: 2027 RVA: 0x00021B18 File Offset: 0x0001FD18
	public void ProcessMetadata(ProjectileMetadata meta)
	{
		this.projectilePrefab = this.potentialProjectiles[(int)meta.projectileIndex];
	}

	// Token: 0x060007EC RID: 2028 RVA: 0x00021B30 File Offset: 0x0001FD30
	public void ProcessMetadata(SpeedMetadata meta)
	{
		float num = 0.5f;
		float num2 = 1.5f;
		this.animator.speed = (float)meta.speed / 5f * (num2 - num) + num;
	}

	// Token: 0x060007ED RID: 2029 RVA: 0x00021B67 File Offset: 0x0001FD67
	public void ProcessMetadata(ShootsOneMetadata meta)
	{
		this.shootsOnce = meta.shootsOnce;
	}

	// Token: 0x040005CB RID: 1483
	public BoxCollider coll;

	// Token: 0x040005CC RID: 1484
	public Transform spawnNode;

	// Token: 0x040005CD RID: 1485
	public Projectile projectilePrefab;

	// Token: 0x040005CE RID: 1486
	public string fireSFX;

	// Token: 0x040005CF RID: 1487
	public Animator animator;

	// Token: 0x040005D0 RID: 1488
	public float triggerRadius = 7f;

	// Token: 0x040005D1 RID: 1489
	public bool shootsOnce;

	// Token: 0x040005D2 RID: 1490
	public Projectile[] potentialProjectiles;

	// Token: 0x040005D3 RID: 1491
	public GameObject[] projectilePreVisuals;

	// Token: 0x040005D4 RID: 1492
	private bool shooting;

	// Token: 0x040005D5 RID: 1493
	private Projectile spawnedProjectile;
}
