﻿using System;
using System.IO;
using LevelEditor;
using UnityEngine;

// Token: 0x0200002E RID: 46
public class PhaseMetadata : ObjectMetadata
{
	// Token: 0x17000037 RID: 55
	// (get) Token: 0x06000117 RID: 279 RVA: 0x00006484 File Offset: 0x00004684
	// (set) Token: 0x06000118 RID: 280 RVA: 0x0000648C File Offset: 0x0000468C
	public bool RequiresData { get; private set; }

	// Token: 0x17000038 RID: 56
	// (get) Token: 0x06000119 RID: 281 RVA: 0x00006495 File Offset: 0x00004695
	// (set) Token: 0x0600011A RID: 282 RVA: 0x0000649D File Offset: 0x0000469D
	public bool HasData { get; private set; }

	// Token: 0x17000039 RID: 57
	// (get) Token: 0x0600011B RID: 283 RVA: 0x000064A6 File Offset: 0x000046A6
	// (set) Token: 0x0600011C RID: 284 RVA: 0x000064AE File Offset: 0x000046AE
	public byte Value { get; private set; }

	// Token: 0x1700003A RID: 58
	// (get) Token: 0x0600011D RID: 285 RVA: 0x000064B7 File Offset: 0x000046B7
	// (set) Token: 0x0600011E RID: 286 RVA: 0x000064BF File Offset: 0x000046BF
	public byte Steps { get; private set; }

	// Token: 0x1700003B RID: 59
	// (get) Token: 0x0600011F RID: 287 RVA: 0x000064C8 File Offset: 0x000046C8
	public float NormalizedValue
	{
		get
		{
			return (float)this.Value / (float)this.Steps;
		}
	}

	// Token: 0x1700003C RID: 60
	// (get) Token: 0x06000120 RID: 288 RVA: 0x000064D9 File Offset: 0x000046D9
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x1700003D RID: 61
	// (get) Token: 0x06000121 RID: 289 RVA: 0x000064DC File Offset: 0x000046DC
	public override int Signature
	{
		get
		{
			return string.Format("{0}|{1}|{2}", "PhaseMetadata", this.RequiresData, this.Steps).GetHashCode();
		}
	}

	// Token: 0x1700003E RID: 62
	// (get) Token: 0x06000122 RID: 290 RVA: 0x00006508 File Offset: 0x00004708
	public override int ValueHash
	{
		get
		{
			if (!this.HasData)
			{
				return 0;
			}
			return (int)this.Value;
		}
	}

	// Token: 0x06000123 RID: 291 RVA: 0x0000651A File Offset: 0x0000471A
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.HasData);
		if (this.HasData)
		{
			bw.Write(this.Value);
		}
	}

	// Token: 0x06000124 RID: 292 RVA: 0x0000653C File Offset: 0x0000473C
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.HasData = br.ReadBoolean();
		this.Value = (this.HasData ? br.ReadByte() : 0);
	}

	// Token: 0x06000125 RID: 293 RVA: 0x00006564 File Offset: 0x00004764
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<PhaseMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<PhaseMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x06000126 RID: 294 RVA: 0x00006590 File Offset: 0x00004790
	public void SetData(byte value)
	{
		this.HasData = true;
		this.Value = value;
	}

	// Token: 0x06000127 RID: 295 RVA: 0x000065A0 File Offset: 0x000047A0
	public void ClearData()
	{
		if (this.RequiresData)
		{
			Debug.LogWarning(base.gameObject.name + " requires PhaseMetadata data and should not be cleared", base.gameObject);
			return;
		}
		this.HasData = false;
		this.Value = 0;
	}
}
