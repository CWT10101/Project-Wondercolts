﻿using System;
using UnityEngine;

// Token: 0x02000055 RID: 85
public class PlaySoundFromSource : MonoBehaviour
{
	// Token: 0x06000221 RID: 545 RVA: 0x00009804 File Offset: 0x00007A04
	public void PlaySoundFromAudioSource(int index)
	{
		if (this.sources[0].isActiveAndEnabled)
		{
			int num;
			if (this.sources[0].isPlaying)
			{
				num = 1;
			}
			else
			{
				num = 0;
			}
			this.sources[num].clip = this.clips[index];
			this.sources[num].Play();
		}
	}

	// Token: 0x0400012E RID: 302
	public AudioSource[] sources;

	// Token: 0x0400012F RID: 303
	public AudioClip[] clips;
}
