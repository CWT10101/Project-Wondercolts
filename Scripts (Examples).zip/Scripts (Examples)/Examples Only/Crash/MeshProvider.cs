﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000E2 RID: 226
public class MeshProvider
{
	// Token: 0x060006E8 RID: 1768 RVA: 0x0001D850 File Offset: 0x0001BA50
	public MeshProvider()
	{
		this.mesh = new Mesh
		{
			vertices = new Vector3[]
			{
				new Vector3(-0.5f, -0.5f, 0f),
				new Vector3(0.5f, -0.5f, 0f),
				new Vector3(-0.5f, 0.5f, 0f),
				new Vector3(0.5f, 0.5f, 0f)
			},
			triangles = new int[]
			{
				0,
				2,
				1,
				2,
				3,
				1
			},
			normals = new Vector3[]
			{
				Vector3.back,
				Vector3.back,
				Vector3.back,
				Vector3.back
			}
		};
		this.SetMeshUVsFullRect();
	}

	// Token: 0x060006E9 RID: 1769 RVA: 0x0001D950 File Offset: 0x0001BB50
	public MeshProvider(byte tilesW, byte tilesH, byte fps, bool topToBottom, Func<float> timeProvider) : this()
	{
		this.timeProvider = timeProvider;
		this.uvOperation = (this.texStartsFromTop ? new Action(this.SetMeshUVsTop) : new Action(this.SetMeshUVsBottom));
		this.uvOperation();
	}

	// Token: 0x060006EA RID: 1770 RVA: 0x0001D99E File Offset: 0x0001BB9E
	public MeshProvider(Sprite spr) : this()
	{
		this.sprite = spr;
		this.uvOperation = new Action(this.SetMeshUVsSprite);
		this.uvOperation();
	}

	// Token: 0x060006EB RID: 1771 RVA: 0x0001D9CA File Offset: 0x0001BBCA
	public void AssignMesh(MeshFilter filter)
	{
		filter.sharedMesh = this.mesh;
	}

	// Token: 0x060006EC RID: 1772 RVA: 0x0001D9D8 File Offset: 0x0001BBD8
	public void AssignMeshes(IEnumerable<MeshFilter> filters)
	{
		foreach (MeshFilter meshFilter in filters)
		{
			meshFilter.sharedMesh = this.mesh;
		}
	}

	// Token: 0x060006ED RID: 1773 RVA: 0x0001DA24 File Offset: 0x0001BC24
	public void UseSpriteRect(Sprite spr)
	{
		this.sprite = spr;
		this.UpdateMesh();
	}

	// Token: 0x060006EE RID: 1774 RVA: 0x0001DA33 File Offset: 0x0001BC33
	public void UpdateMesh()
	{
		Action action = this.uvOperation;
		if (action == null)
		{
			return;
		}
		action();
	}

	// Token: 0x060006EF RID: 1775 RVA: 0x0001DA48 File Offset: 0x0001BC48
	private void SetMeshUVsFullRect()
	{
		this.uvs[0] = new Vector2(0f, 0f);
		this.uvs[1] = new Vector2(1f, 0f);
		this.uvs[2] = new Vector2(0f, 1f);
		this.uvs[3] = new Vector2(1f, 1f);
		this.mesh.uv = this.uvs;
	}

	// Token: 0x060006F0 RID: 1776 RVA: 0x0001DAD4 File Offset: 0x0001BCD4
	private void SetMeshUVsSprite()
	{
		if (this.sprite == null)
		{
			this.SetMeshUVsFullRect();
			return;
		}
		Rect rect = this.sprite.rect;
		float num = 1f / (float)this.sprite.texture.width;
		float num2 = 1f / (float)this.sprite.texture.height;
		this.uvs[0] = new Vector2(rect.xMin * num, rect.yMin * num2);
		this.uvs[1] = new Vector2(rect.xMax * num, rect.yMin * num2);
		this.uvs[2] = new Vector2(rect.xMin * num, rect.yMax * num2);
		this.uvs[3] = new Vector2(rect.xMax * num, rect.yMax * num2);
		this.mesh.uv = this.uvs;
	}

	// Token: 0x060006F1 RID: 1777 RVA: 0x0001DBD0 File Offset: 0x0001BDD0
	private void SetMeshUVsBottom()
	{
		int num = (int)(this.timeProvider() * (float)this.texFramesPerSec);
		float num2 = (float)num % (float)this.texTilesW / (float)this.texTilesW;
		float num3 = Mathf.Floor((float)num / (float)this.texTilesW) / (float)this.texTilesH;
		float num4 = 1f / (float)this.texTilesW;
		float num5 = 1f / (float)this.texTilesH;
		this.uvs[0] = new Vector2(num2, num3);
		this.uvs[1] = new Vector2(num2 + num4, num3);
		this.uvs[2] = new Vector2(num2, num3 + num5);
		this.uvs[3] = new Vector2(num2 + num4, num3 + num5);
		this.mesh.uv = this.uvs;
	}

	// Token: 0x060006F2 RID: 1778 RVA: 0x0001DC9C File Offset: 0x0001BE9C
	private void SetMeshUVsTop()
	{
		int num = (int)(this.timeProvider() * (float)this.texFramesPerSec);
		float num2 = (float)num % (float)this.texTilesW / (float)this.texTilesW;
		float num3 = ((float)(this.texTilesH - 1) - Mathf.Floor((float)num / (float)this.texTilesW)) / (float)this.texTilesH;
		float num4 = 1f / (float)this.texTilesW;
		float num5 = 1f / (float)this.texTilesH;
		this.uvs[0] = new Vector2(num2, num3);
		this.uvs[1] = new Vector2(num2 + num4, num3);
		this.uvs[2] = new Vector2(num2, num3 + num5);
		this.uvs[3] = new Vector2(num2 + num4, num3 + num5);
		this.mesh.uv = this.uvs;
	}

	// Token: 0x04000540 RID: 1344
	private byte texTilesW;

	// Token: 0x04000541 RID: 1345
	private byte texTilesH;

	// Token: 0x04000542 RID: 1346
	private byte texFramesPerSec;

	// Token: 0x04000543 RID: 1347
	private bool texStartsFromTop;

	// Token: 0x04000544 RID: 1348
	private Mesh mesh;

	// Token: 0x04000545 RID: 1349
	private readonly Vector2[] uvs = new Vector2[4];

	// Token: 0x04000546 RID: 1350
	private Action uvOperation;

	// Token: 0x04000547 RID: 1351
	private Func<float> timeProvider;

	// Token: 0x04000548 RID: 1352
	private Sprite sprite;
}
