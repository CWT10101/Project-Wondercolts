﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;

// Token: 0x02000146 RID: 326
public class ActionOnSelect : MonoBehaviour, ISelectHandler, IEventSystemHandler, IDeselectHandler
{
	// Token: 0x060009AC RID: 2476 RVA: 0x00027298 File Offset: 0x00025498
	private void Awake()
	{
		HoverOverSelectable @object;
		if (base.TryGetComponent<HoverOverSelectable>(out @object))
		{
			this.onSelect.AddListener(new UnityAction(@object.ListenerHovered));
			this.onDeselect.AddListener(new UnityAction(@object.ListenerDefault));
		}
	}

	// Token: 0x060009AD RID: 2477 RVA: 0x000272DD File Offset: 0x000254DD
	public void OnDeselect(BaseEventData eventData)
	{
		this.onDeselect.Invoke();
	}

	// Token: 0x060009AE RID: 2478 RVA: 0x000272EA File Offset: 0x000254EA
	public void OnSelect(BaseEventData eventData)
	{
		this.onSelect.Invoke();
	}

	// Token: 0x04000707 RID: 1799
	public UnityEvent onSelect;

	// Token: 0x04000708 RID: 1800
	public UnityEvent onDeselect;
}
