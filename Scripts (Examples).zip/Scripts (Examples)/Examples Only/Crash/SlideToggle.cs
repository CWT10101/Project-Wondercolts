﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

// Token: 0x02000165 RID: 357
[RequireComponent(typeof(Toggle))]
public class SlideToggle : MonoBehaviour
{
	// Token: 0x06000A3B RID: 2619 RVA: 0x00028E00 File Offset: 0x00027000
	private void Awake()
	{
		this.toggle = base.GetComponent<Toggle>();
		this.toggle.onValueChanged.AddListener(new UnityAction<bool>(this.AnimateToggle));
	}

	// Token: 0x06000A3C RID: 2620 RVA: 0x00028E2A File Offset: 0x0002702A
	public void AnimateToggle(bool state)
	{
		this.animator.SetBool("isOn", state);
		if (state)
		{
			this.background.color = this.offColour;
			return;
		}
		this.background.color = this.onColour;
	}

	// Token: 0x0400075B RID: 1883
	public Image background;

	// Token: 0x0400075C RID: 1884
	public Color offColour;

	// Token: 0x0400075D RID: 1885
	public Color onColour;

	// Token: 0x0400075E RID: 1886
	private Toggle toggle;

	// Token: 0x0400075F RID: 1887
	public Animator animator;
}
