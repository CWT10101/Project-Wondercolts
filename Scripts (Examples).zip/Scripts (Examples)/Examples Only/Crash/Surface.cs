﻿using System;
using UnityEngine;

// Token: 0x0200012F RID: 303
public class Surface : MonoBehaviour
{
	// Token: 0x17000116 RID: 278
	// (get) Token: 0x06000904 RID: 2308 RVA: 0x0002556C File Offset: 0x0002376C
	// (set) Token: 0x06000905 RID: 2309 RVA: 0x00025574 File Offset: 0x00023774
	public Surface.Material Type { get; private set; }

	// Token: 0x02000237 RID: 567
	public enum Material
	{
		// Token: 0x04000D7C RID: 3452
		Generic,
		// Token: 0x04000D7D RID: 3453
		Snow,
		// Token: 0x04000D7E RID: 3454
		Stone,
		// Token: 0x04000D7F RID: 3455
		Metal
	}
}
