﻿using System;
using UnityEngine;

// Token: 0x02000058 RID: 88
public class AreaFollow : MonoBehaviour
{
	// Token: 0x06000228 RID: 552 RVA: 0x0000991E File Offset: 0x00007B1E
	private void LateUpdate()
	{
		this.follower.transform.position = base.transform.TransformPoint(this.area.ClosestPoint(base.transform.InverseTransformPoint(this.target.position)));
	}

	// Token: 0x06000229 RID: 553 RVA: 0x0000995C File Offset: 0x00007B5C
	private void OnDrawGizmosSelected()
	{
		Gizmos.color = Color.yellow;
		Gizmos.matrix = Matrix4x4.TRS(base.transform.position, base.transform.rotation, base.transform.lossyScale);
		Gizmos.DrawWireCube(this.area.center, this.area.size);
	}

	// Token: 0x04000132 RID: 306
	public Transform follower;

	// Token: 0x04000133 RID: 307
	public Transform target;

	// Token: 0x04000134 RID: 308
	public Bounds area;
}
