﻿using System;
using System.Collections;
using System.Collections.Generic;
using Cinemachine;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

// Token: 0x02000110 RID: 272
public class ScreenCanvas : MonoBehaviour
{
	// Token: 0x1700010C RID: 268
	// (get) Token: 0x06000855 RID: 2133 RVA: 0x0002319F File Offset: 0x0002139F
	// (set) Token: 0x06000856 RID: 2134 RVA: 0x000231A6 File Offset: 0x000213A6
	public static ScreenCanvas instance { get; private set; }

	// Token: 0x06000857 RID: 2135 RVA: 0x000231AE File Offset: 0x000213AE
	private void Awake()
	{
		ScreenCanvas.instance = this;
	}

	// Token: 0x06000858 RID: 2136 RVA: 0x000231B6 File Offset: 0x000213B6
	private void Start()
	{
		this.CreateTapeButtons();
		this.crashCreatorButton.gameObject.SetActive(true);
		this.CheckVisitedCreator();
	}

	// Token: 0x06000859 RID: 2137 RVA: 0x000231D5 File Offset: 0x000213D5
	public void CheckVisitedCreator()
	{
		if (SaveData.Info.visitedCreator)
		{
			this.userCreatedTapesButton.gameObject.SetActive(true);
			this.CreateUserTapeButtons();
			return;
		}
		this.userCreatedTapesButton.gameObject.SetActive(false);
	}

	// Token: 0x0600085A RID: 2138 RVA: 0x0002320C File Offset: 0x0002140C
	public void SetPageText()
	{
		this.userPageText.text = string.Format("{0}/{1}", this.currentPage, this.MaxPages());
	}

	// Token: 0x0600085B RID: 2139 RVA: 0x00023239 File Offset: 0x00021439
	public void NextPage()
	{
		if (this.currentPage < this.MaxPages())
		{
			this.currentPage++;
		}
		else
		{
			this.currentPage = 1;
		}
		this.SetUserTapeButtons();
	}

	// Token: 0x0600085C RID: 2140 RVA: 0x00023266 File Offset: 0x00021466
	public void PreviousPage()
	{
		if (this.currentPage > 1)
		{
			this.currentPage--;
		}
		else
		{
			this.currentPage = this.MaxPages();
		}
		this.SetUserTapeButtons();
	}

	// Token: 0x0600085D RID: 2141 RVA: 0x00023294 File Offset: 0x00021494
	public void SetUserTapeButtons()
	{
		this.SetPageText();
		foreach (UserTapeButton userTapeButton in this.userTapeButtons)
		{
			userTapeButton.gameObject.SetActive(false);
		}
		for (int i = (this.currentPage - 1) * 4; i < Mathf.Min((this.currentPage - 1) * 4 + 4, LevelSerializer.instance.userCreatedList.Count); i++)
		{
			if (this.userTapeButtons[i] != null)
			{
				this.userTapeButtons[i].gameObject.SetActive(true);
			}
		}
	}

	// Token: 0x0600085E RID: 2142 RVA: 0x00023350 File Offset: 0x00021550
	public void StopUsing(CinemachineVirtualCameraBase newCam)
	{
		this.SetInUse(false);
		this.SetScreen(false);
		CameraManager.instance.SetVCam(newCam);
		CrashController.instance.enabled = true;
	}

	// Token: 0x0600085F RID: 2143 RVA: 0x00023376 File Offset: 0x00021576
	public int MaxPages()
	{
		return Mathf.CeilToInt((float)LevelSerializer.instance.userCreatedList.Count / 4f);
	}

	// Token: 0x06000860 RID: 2144 RVA: 0x00023394 File Offset: 0x00021594
	public void CreateTapeButtons()
	{
		bool flag = false;
		int num = 0;
		for (int i = 0; i < 10; i++)
		{
			if (SaveData.Info.lvlTapes[i])
			{
				flag = true;
				FlashbackTapeButton flashbackTapeButton = Object.Instantiate<FlashbackTapeButton>(this.flashbackTapeButtonPrefab, this.flashbackTapeButtonHolder);
				flashbackTapeButton.SetData(i);
				if (i >= 5)
				{
					this.flashbackTapeButtonHolder2.gameObject.SetActive(true);
					flashbackTapeButton.transform.SetParent(this.flashbackTapeButtonHolder2);
				}
				num++;
			}
		}
		for (int j = 0; j < Mathf.Min(num, 10); j++)
		{
			this.tapeProps[j].SetActive(true);
		}
		if (!flag)
		{
			this.noTapesObj.SetActive(true);
		}
	}

	// Token: 0x06000861 RID: 2145 RVA: 0x0002343C File Offset: 0x0002163C
	public void CreateUserTapeButtons()
	{
		if (SaveData.Info.visitedCreator)
		{
			this.userTapeButtons.Clear();
			this.userTapeButtonHolder.DestroyChildrenWithComponent<UserTapeButton>();
			for (int i = 0; i < LevelSerializer.instance.userCreatedList.Count; i++)
			{
				UserTapeButton userTapeButton = Object.Instantiate<UserTapeButton>(this.userTapeButtonPrefab, this.userTapeButtonHolder);
				this.userTapeButtons.Add(userTapeButton);
				userTapeButton.SetData(LevelSerializer.instance.userCreatedList[i]);
				userTapeButton.gameObject.SetActive(false);
			}
			this.pageNavigationHolder.transform.SetAsLastSibling();
			this.SetUserTapeButtons();
		}
	}

	// Token: 0x06000862 RID: 2146 RVA: 0x000234DE File Offset: 0x000216DE
	public void PromptDeleteLevel(string levelstr)
	{
		this.confirmDeleteObj.SetActive(true);
		this.levelContext = levelstr;
	}

	// Token: 0x06000863 RID: 2147 RVA: 0x000234F3 File Offset: 0x000216F3
	public void DeleteUserTapeHook()
	{
		LevelSerializer.instance.DeleteLevel(this.levelContext);
		this.confirmDeleteObj.SetActive(false);
	}

	// Token: 0x06000864 RID: 2148 RVA: 0x00023511 File Offset: 0x00021711
	public void CancelLevelDeletionHook()
	{
		this.levelContext = null;
		this.confirmDeleteObj.SetActive(false);
	}

	// Token: 0x06000865 RID: 2149 RVA: 0x00023526 File Offset: 0x00021726
	public void SetScreen(bool activeScreen)
	{
		this.screenAnimator.SetBool("isActive", activeScreen);
	}

	// Token: 0x06000866 RID: 2150 RVA: 0x0002353C File Offset: 0x0002173C
	public void CameraTriggerCheck(CinemachineVirtualCameraBase vcam)
	{
		if (!this.inUse && CrashController.instance.animator.currentState == CrashController.instance.animator.idleObj)
		{
			this.SetScreen(true);
			CameraManager.instance.SetVCam(vcam);
			this.SetInUse(true);
		}
	}

	// Token: 0x06000867 RID: 2151 RVA: 0x0002358F File Offset: 0x0002178F
	public void SetInUse(bool isUsing)
	{
		this.inUse = isUsing;
	}

	// Token: 0x06000868 RID: 2152 RVA: 0x00023598 File Offset: 0x00021798
	public void ImportLevelHook()
	{
		LevelSerializer.instance.ImportLevel();
	}

	// Token: 0x06000869 RID: 2153 RVA: 0x000235A4 File Offset: 0x000217A4
	public void RefreshUserLevels()
	{
		LevelSerializer.instance.ReloadUserLevels();
		this.CreateUserTapeButtons();
		CustomWarpRoomCanvas.LevelsDirty = true;
	}

	// Token: 0x0600086A RID: 2154 RVA: 0x000235BC File Offset: 0x000217BC
	public void LaunchFlashbackLevel(int index)
	{
		base.StartCoroutine(this.WaitAndLoadFlashback(index));
	}

	// Token: 0x0600086B RID: 2155 RVA: 0x000235CC File Offset: 0x000217CC
	public void LaunchUserLevel(string lvlName)
	{
		base.StartCoroutine(this.WaitAndLoadUserLevel(lvlName));
	}

	// Token: 0x0600086C RID: 2156 RVA: 0x000235DC File Offset: 0x000217DC
	public virtual IEnumerator WaitAndLoadFlashback(int index)
	{
		InterfaceManager.instance.fadeScreen.FulLFade(Color.black, 0.75f);
		LevelSerializer.SetActiveFolder("Flashback-Tapes");
		LevelSerializer.instance.loadOnPlayString = string.Format("Flashback0{0}", index);
		LevelSerializer.instance.tapeIndex = index;
		yield return new WaitForSeconds(0.5f);
		SceneManager.LoadScene("Editor");
		yield break;
	}

	// Token: 0x0600086D RID: 2157 RVA: 0x000235EB File Offset: 0x000217EB
	public virtual IEnumerator WaitAndLoadUserLevel(string lvlName)
	{
		InterfaceManager.instance.fadeScreen.FulLFade(Color.black, 0.75f);
		LevelSerializer.SetActiveFolder("User-Created");
		LevelSerializer.instance.loadOnPlayString = lvlName;
		yield return new WaitForSeconds(0.5f);
		SceneManager.LoadScene("Editor");
		yield break;
	}

	// Token: 0x04000615 RID: 1557
	public Transform flashbackTapeButtonHolder;

	// Token: 0x04000616 RID: 1558
	public Transform userTapeButtonHolder;

	// Token: 0x04000617 RID: 1559
	public Transform flashbackTapeButtonHolder2;

	// Token: 0x04000618 RID: 1560
	public Animator screenAnimator;

	// Token: 0x04000619 RID: 1561
	public FlashbackTapeButton flashbackTapeButtonPrefab;

	// Token: 0x0400061A RID: 1562
	public GameObject noTapesObj;

	// Token: 0x0400061B RID: 1563
	public UserTapeButton userTapeButtonPrefab;

	// Token: 0x0400061C RID: 1564
	public UserFolderButton userFolderButtonPrefab;

	// Token: 0x0400061D RID: 1565
	public Button crashCreatorButton;

	// Token: 0x0400061E RID: 1566
	public Button userCreatedTapesButton;

	// Token: 0x0400061F RID: 1567
	public float waitTime = 1f;

	// Token: 0x04000620 RID: 1568
	public bool inUse;

	// Token: 0x04000621 RID: 1569
	public GameObject confirmDeleteObj;

	// Token: 0x04000622 RID: 1570
	[Header("User Created Screen Stuff")]
	public TMP_Text userPageText;

	// Token: 0x04000623 RID: 1571
	public GameObject pageNavigationHolder;

	// Token: 0x04000624 RID: 1572
	private int currentPage = 1;

	// Token: 0x04000625 RID: 1573
	public List<UserTapeButton> userTapeButtons = new List<UserTapeButton>();

	// Token: 0x04000626 RID: 1574
	public GameObject[] tapeProps;

	// Token: 0x04000627 RID: 1575
	public Transform props;

	// Token: 0x04000628 RID: 1576
	private string levelContext;
}
