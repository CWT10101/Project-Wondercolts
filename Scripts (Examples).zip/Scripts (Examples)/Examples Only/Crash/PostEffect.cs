﻿using System;
using UnityEngine;

// Token: 0x02000047 RID: 71
public class PostEffect : MonoBehaviour
{
	// Token: 0x060001E5 RID: 485 RVA: 0x00008D10 File Offset: 0x00006F10
	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		Graphics.Blit(source, destination, this.material);
	}

	// Token: 0x04000104 RID: 260
	[SerializeField]
	private Material material;
}
