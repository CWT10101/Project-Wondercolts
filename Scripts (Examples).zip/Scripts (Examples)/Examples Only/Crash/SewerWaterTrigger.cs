﻿using System;
using UnityEngine;

// Token: 0x02000113 RID: 275
public class SewerWaterTrigger : DeathTrigger
{
	// Token: 0x06000875 RID: 2165 RVA: 0x000236D8 File Offset: 0x000218D8
	private void Start()
	{
		this.waterProp = new MaterialPropertyBlock();
		this.waterProp.SetColor("_Color", this.electrifiedColor);
		this.waterProp.SetColor("_IntersectionColor", this.electrifiedEdgeColor);
		this.envProp = new MaterialPropertyBlock();
		this.envProp.SetColor("_LightColor", this.electrifiedLightColor);
		this.eelProp = new MaterialPropertyBlock();
		this.eelProp.SetInteger("_Zapping", 1);
	}

	// Token: 0x06000876 RID: 2166 RVA: 0x0002375C File Offset: 0x0002195C
	private void FixedUpdate()
	{
		if (this.eelInWater)
		{
			if (this.timer < this.stateLength)
			{
				this.timer += Time.deltaTime;
			}
			else
			{
				this.SwitchState();
				this.timer = 0f;
			}
			this.SetVisual(this.isDangerous && this.visualStateCurve.Evaluate(this.timer / this.stateLength) >= 0.5f);
			if (this.eelRen)
			{
				this.SetVisualEel(this.isDangerous && this.visualStateCurve.Evaluate((this.timer + Time.fixedDeltaTime * 2f) / this.stateLength) >= 0.5f);
			}
		}
	}

	// Token: 0x06000877 RID: 2167 RVA: 0x00023828 File Offset: 0x00021A28
	public void SwitchState()
	{
		this.isDangerous = !this.isDangerous;
		if (this.isDangerous)
		{
			if (this.audiosource)
			{
				this.audiosource.Play();
				return;
			}
			AudioManager.Play("SFX_ElectricEel", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		}
	}

	// Token: 0x06000878 RID: 2168 RVA: 0x0002388C File Offset: 0x00021A8C
	private void SetVisual(bool electrified)
	{
		this.ren.SetPropertyBlock(electrified ? this.waterProp : null);
		if (this.environmentRens != null)
		{
			Renderer[] array = this.environmentRens;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].SetPropertyBlock(electrified ? this.envProp : null);
			}
		}
	}

	// Token: 0x06000879 RID: 2169 RVA: 0x000238E1 File Offset: 0x00021AE1
	private void SetVisualEel(bool electrified)
	{
		this.eelRen.SetPropertyBlock(electrified ? this.eelProp : null);
	}

	// Token: 0x0600087A RID: 2170 RVA: 0x000238FC File Offset: 0x00021AFC
	public override void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			if (!string.IsNullOrEmpty(this.sfxClip))
			{
				AudioManager.Play(this.sfxClip, AudioManager.MixerTarget.SFX, new Vector3?(crashController.transform.position), null);
			}
			if (this.effect != null)
			{
				Object.Instantiate<GameObject>(this.effect, crashController.transform.position, Quaternion.identity);
			}
			if (this.isDangerous && this.eelInWater)
			{
				crashController.TakeDamage(0);
			}
		}
	}

	// Token: 0x0600087B RID: 2171 RVA: 0x00023988 File Offset: 0x00021B88
	private void OnTriggerStay(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			if (this.isDangerous && this.eelInWater)
			{
				crashController.TakeDamage(0);
				return;
			}
			if (crashController.animator.currentState == crashController.animator.spinObj && crashController.animator.TimeSinceStateChanged < Time.fixedDeltaTime / 2f)
			{
				if (!string.IsNullOrEmpty(this.sfxClip))
				{
					AudioManager.Play(this.sfxClip, AudioManager.MixerTarget.SFX, new Vector3?(crashController.transform.position), null);
				}
				if (this.effect != null)
				{
					Object.Instantiate<GameObject>(this.effect, crashController.transform.position, Quaternion.identity);
				}
			}
		}
	}

	// Token: 0x0600087C RID: 2172 RVA: 0x00023A50 File Offset: 0x00021C50
	private void OnTriggerExit(Collider other)
	{
		CrashController crashController;
		if (this.exitSplash && other.TryGetComponent<CrashController>(out crashController))
		{
			if (!string.IsNullOrEmpty(this.sfxClip))
			{
				AudioManager.Play(this.sfxClip, AudioManager.MixerTarget.SFX, new Vector3?(crashController.transform.position), null);
			}
			if (this.effect != null)
			{
				Object.Instantiate<GameObject>(this.effect, crashController.transform.position, Quaternion.identity);
			}
		}
	}

	// Token: 0x0400062F RID: 1583
	public Renderer ren;

	// Token: 0x04000630 RID: 1584
	public Renderer[] environmentRens;

	// Token: 0x04000631 RID: 1585
	public Renderer eelRen;

	// Token: 0x04000632 RID: 1586
	public AnimationCurve visualStateCurve;

	// Token: 0x04000633 RID: 1587
	private float timer;

	// Token: 0x04000634 RID: 1588
	public float stateLength = 3f;

	// Token: 0x04000635 RID: 1589
	public bool isDangerous;

	// Token: 0x04000636 RID: 1590
	public bool eelInWater;

	// Token: 0x04000637 RID: 1591
	[ColorUsage(true, true)]
	public Color electrifiedColor = Color.white;

	// Token: 0x04000638 RID: 1592
	[ColorUsage(true, true)]
	public Color electrifiedEdgeColor = Color.white;

	// Token: 0x04000639 RID: 1593
	[ColorUsage(false, true)]
	public Color electrifiedLightColor = Color.white;

	// Token: 0x0400063A RID: 1594
	public bool exitSplash = true;

	// Token: 0x0400063B RID: 1595
	public AudioSource audiosource;

	// Token: 0x0400063C RID: 1596
	private MaterialPropertyBlock waterProp;

	// Token: 0x0400063D RID: 1597
	private MaterialPropertyBlock envProp;

	// Token: 0x0400063E RID: 1598
	private MaterialPropertyBlock eelProp;
}
