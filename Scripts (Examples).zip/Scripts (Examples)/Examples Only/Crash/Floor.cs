﻿using System;
using Cinemachine;
using UnityEngine;

// Token: 0x020000BD RID: 189
public class Floor : MonoBehaviour
{
	// Token: 0x0400043B RID: 1083
	public Transform cameraPoint;

	// Token: 0x0400043C RID: 1084
	public Transform platformPoint;

	// Token: 0x0400043D RID: 1085
	public Transform screenCanvasPoint;

	// Token: 0x0400043E RID: 1086
	public Transform screenPropsTargets;

	// Token: 0x0400043F RID: 1087
	public CinemachineVirtualCameraBase primaryCamera;
}
