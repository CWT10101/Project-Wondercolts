﻿using System;
using UnityEngine;

// Token: 0x02000054 RID: 84
public class PlaySound : MonoBehaviour
{
	// Token: 0x0600021F RID: 543 RVA: 0x000097D4 File Offset: 0x000079D4
	public virtual void Play(string clip)
	{
		AudioManager.Play(clip, AudioManager.MixerTarget.SFX, null, null);
	}
}
