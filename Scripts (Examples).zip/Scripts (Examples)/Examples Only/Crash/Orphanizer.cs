﻿using System;
using UnityEngine;

// Token: 0x02000152 RID: 338
public class Orphanizer : MonoBehaviour
{
	// Token: 0x060009E5 RID: 2533 RVA: 0x00027C74 File Offset: 0x00025E74
	private void Awake()
	{
		base.transform.SetParent(null);
	}
}
