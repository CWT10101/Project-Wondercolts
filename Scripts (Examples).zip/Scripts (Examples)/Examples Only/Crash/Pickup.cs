﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x020000F7 RID: 247
public abstract class Pickup : Entity, ISpin
{
	// Token: 0x170000FA RID: 250
	// (get) Token: 0x0600079B RID: 1947 RVA: 0x0002024B File Offset: 0x0001E44B
	public Vector3 StartPosition
	{
		get
		{
			if (this._startPosition == null)
			{
				this._startPosition = new Vector3?(base.transform.localPosition);
			}
			return this._startPosition.Value;
		}
	}

	// Token: 0x0600079C RID: 1948 RVA: 0x0002027B File Offset: 0x0001E47B
	private void OnEnable()
	{
		base.transform.localPosition = this.StartPosition;
		base.StartCoroutine(this.InvincibilityFrames(0.5f));
	}

	// Token: 0x0600079D RID: 1949 RVA: 0x000202A0 File Offset: 0x0001E4A0
	public IEnumerator InvincibilityFrames(float seconds)
	{
		yield return new WaitForSeconds(seconds);
		this.hasIFrames = false;
		yield break;
	}

	// Token: 0x0600079E RID: 1950 RVA: 0x000202B6 File Offset: 0x0001E4B6
	protected virtual void Start()
	{
		if (Level.instance)
		{
			this.shouldRollback &= (Time.timeSinceLevelLoad <= 0f);
		}
	}

	// Token: 0x0600079F RID: 1951 RVA: 0x000202E0 File Offset: 0x0001E4E0
	public virtual void OnTriggerEnter(Collider other)
	{
		PickupHandler pickupHandler;
		if (other.TryGetComponent<PickupHandler>(out pickupHandler))
		{
			this.Despawn();
		}
	}

	// Token: 0x060007A0 RID: 1952 RVA: 0x00020300 File Offset: 0x0001E500
	public virtual void Despawn()
	{
		if (!string.IsNullOrEmpty(this.pickupSFX))
		{
			AudioManager.Play(this.pickupSFX, AudioManager.MixerTarget.SFX, null, null);
		}
		if (this.collectEffect)
		{
			Object.Instantiate<GameObject>(this.collectEffect, base.transform.position, Quaternion.identity);
		}
		base.DisableEntity();
		if (this.shouldRollback)
		{
			this.TryPushToStack();
		}
	}

	// Token: 0x060007A1 RID: 1953 RVA: 0x00020376 File Offset: 0x0001E576
	public virtual void Spin(CrashController crash)
	{
		this.SpinAway(crash.transform, true, false);
	}

	// Token: 0x060007A2 RID: 1954 RVA: 0x00020388 File Offset: 0x0001E588
	public void SpinAway(Transform source, bool planarize = true, bool bypassIFrames = false)
	{
		Pickup.<>c__DisplayClass14_0 CS$<>8__locals1 = new Pickup.<>c__DisplayClass14_0();
		CS$<>8__locals1.<>4__this = this;
		if (this.canSpin && (!this.hasIFrames || bypassIFrames))
		{
			this.canSpin = false;
			if (this.collider)
			{
				this.collider.enabled = false;
			}
			AudioManager.Play("SFX_KnockAway", AudioManager.MixerTarget.SFX, null, null);
			CS$<>8__locals1.dir = (planarize ? Vector3.ProjectOnPlane(base.transform.position - source.position, Vector3.up).normalized : (base.transform.position - source.position).normalized);
			base.StartCoroutine(CS$<>8__locals1.<SpinAway>g__SpinAway|0());
		}
	}

	// Token: 0x040005A5 RID: 1445
	private bool hasIFrames = true;

	// Token: 0x040005A6 RID: 1446
	private bool canSpin = true;

	// Token: 0x040005A7 RID: 1447
	public GameObject collectEffect;

	// Token: 0x040005A8 RID: 1448
	public string pickupSFX;

	// Token: 0x040005A9 RID: 1449
	private Vector3? _startPosition;

	// Token: 0x040005AA RID: 1450
	public bool shouldRollback = true;
}
