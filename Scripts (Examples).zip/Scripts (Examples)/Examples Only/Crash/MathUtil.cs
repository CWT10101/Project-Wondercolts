﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x0200014F RID: 335
public static class MathUtil
{
	// Token: 0x060009CF RID: 2511 RVA: 0x00027889 File Offset: 0x00025A89
	public static float Remap(this float value, float srcMin, float srcMax, float destMin, float destMax, bool clamp = false)
	{
		if (clamp)
		{
			value = Mathf.Clamp(value, srcMin, srcMax);
		}
		return (value - srcMin) / (srcMax - srcMin) * (destMax - destMin) + destMin;
	}

	// Token: 0x060009D0 RID: 2512 RVA: 0x000278A7 File Offset: 0x00025AA7
	public static uint GCD(uint a, uint b)
	{
		while (a != 0U && b != 0U)
		{
			if (a > b)
			{
				a %= b;
			}
			else
			{
				b %= a;
			}
		}
		return a | b;
	}

	// Token: 0x060009D1 RID: 2513 RVA: 0x000278C4 File Offset: 0x00025AC4
	public static string Ratio(uint n, uint d)
	{
		uint num = MathUtil.GCD(n, d);
		return string.Format("{0}:{1}", n / num, d / num);
	}

	// Token: 0x060009D2 RID: 2514 RVA: 0x000278F3 File Offset: 0x00025AF3
	public static string Ratio(Resolution res)
	{
		return MathUtil.Ratio((uint)res.width, (uint)res.height);
	}

	// Token: 0x060009D3 RID: 2515 RVA: 0x00027908 File Offset: 0x00025B08
	public static bool InRange(Vector3 src, Vector3 dest, float range)
	{
		return MathUtil.<InRange>g__Abs|4_0(src.x - dest.x) <= range && MathUtil.<InRange>g__Abs|4_0(src.y - dest.y) <= range && MathUtil.<InRange>g__Abs|4_0(src.z - dest.z) <= range && (src - dest).sqrMagnitude <= range * range;
	}

	// Token: 0x060009D4 RID: 2516 RVA: 0x00027974 File Offset: 0x00025B74
	public static bool InRange(Vector2 src, Vector2 dest, float range)
	{
		return MathUtil.<InRange>g__Abs|5_0(src.x - dest.x) <= range && MathUtil.<InRange>g__Abs|5_0(src.y - dest.y) <= range && (src - dest).sqrMagnitude <= range * range;
	}

	// Token: 0x060009D5 RID: 2517 RVA: 0x000279C8 File Offset: 0x00025BC8
	public static bool InRange(float srcX, float srcY, float destX, float destY, float range)
	{
		if (MathUtil.<InRange>g__Abs|6_0(srcX - destX) > range)
		{
			return false;
		}
		if (MathUtil.<InRange>g__Abs|6_0(srcY - destY) > range)
		{
			return false;
		}
		float num = srcX - destX;
		float num2 = srcY - destY;
		return num * num + num2 + num2 <= range * range;
	}

	// Token: 0x060009D6 RID: 2518 RVA: 0x00027A08 File Offset: 0x00025C08
	public static bool HasLineOfSight(Vector3 origin, Vector3 destination, Transform source, Transform target, float maxRange)
	{
		return MathUtil.HasLineOfSight(origin, destination, source, target, maxRange, -1, QueryTriggerInteraction.UseGlobal);
	}

	// Token: 0x060009D7 RID: 2519 RVA: 0x00027A1C File Offset: 0x00025C1C
	public static bool HasLineOfSight(Vector3 origin, Vector3 destination, Transform source, Transform target, float maxRange, LayerMask mask)
	{
		return MathUtil.HasLineOfSight(origin, destination, source, target, maxRange, mask, QueryTriggerInteraction.UseGlobal);
	}

	// Token: 0x060009D8 RID: 2520 RVA: 0x00027A2C File Offset: 0x00025C2C
	public static bool HasLineOfSight(Vector3 origin, Vector3 destination, Transform source, Transform target, float maxRange, LayerMask mask, QueryTriggerInteraction queryTriggers)
	{
		IOrderedEnumerable<RaycastHit> orderedEnumerable = from h in Physics.RaycastAll(origin, (destination - origin).normalized, maxRange, mask, queryTriggers)
		orderby h.distance
		select h;
		int num = 0;
		Vector3 start = origin;
		foreach (RaycastHit raycastHit in orderedEnumerable)
		{
			Debug.DrawLine(start, raycastHit.point, Color.HSVToRGB(0.16f, 1f, (num % 2 == 0) ? 0.75f : 0.25f), 0f, false);
			start = raycastHit.point;
			num++;
		}
		using (IEnumerator<RaycastHit> enumerator = orderedEnumerable.GetEnumerator())
		{
			IL_101:
			while (enumerator.MoveNext())
			{
				RaycastHit raycastHit2 = enumerator.Current;
				Transform transform = raycastHit2.transform;
				while (transform != null)
				{
					if (transform == source)
					{
						goto IL_101;
					}
					if (transform == target)
					{
						return true;
					}
					transform = transform.parent;
				}
				return false;
			}
		}
		return false;
	}

	// Token: 0x060009D9 RID: 2521 RVA: 0x00027B74 File Offset: 0x00025D74
	public static float Sigmoid(this float x, float halfPoint)
	{
		return 2f / (1f + Mathf.Pow(Mathf.Pow(0.33333334f, -1f / halfPoint), -x)) - 1f;
	}

	// Token: 0x060009DA RID: 2522 RVA: 0x00027BA0 File Offset: 0x00025DA0
	public static float Sigmoid100(this float x)
	{
		return x.Sigmoid(20.754751f);
	}

	// Token: 0x060009DB RID: 2523 RVA: 0x00027BAD File Offset: 0x00025DAD
	public static float Sigmoid1(this float x)
	{
		return x.Sigmoid(0.2075472f);
	}

	// Token: 0x060009DC RID: 2524 RVA: 0x00027BBA File Offset: 0x00025DBA
	[CompilerGenerated]
	internal static float <InRange>g__Abs|4_0(float v)
	{
		if (v >= 0f)
		{
			return v;
		}
		return -v;
	}

	// Token: 0x060009DD RID: 2525 RVA: 0x00027BC8 File Offset: 0x00025DC8
	[CompilerGenerated]
	internal static float <InRange>g__Abs|5_0(float v)
	{
		if (v >= 0f)
		{
			return v;
		}
		return -v;
	}

	// Token: 0x060009DE RID: 2526 RVA: 0x00027BD6 File Offset: 0x00025DD6
	[CompilerGenerated]
	internal static float <InRange>g__Abs|6_0(float v)
	{
		if (v >= 0f)
		{
			return v;
		}
		return -v;
	}
}
