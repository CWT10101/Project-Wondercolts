﻿using System;

// Token: 0x02000012 RID: 18
public class FSFile : FSObject
{
	// Token: 0x0600004B RID: 75 RVA: 0x00003712 File Offset: 0x00001912
	public FSFile(string name, FSFolder folder) : base(name, folder)
	{
	}
}
