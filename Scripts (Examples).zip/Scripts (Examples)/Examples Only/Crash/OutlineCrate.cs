﻿using System;
using UnityEngine;

// Token: 0x020000F4 RID: 244
public class OutlineCrate : MonoBehaviour
{
	// Token: 0x06000788 RID: 1928 RVA: 0x0001FF54 File Offset: 0x0001E154
	public void Activate()
	{
		AudioManager.Play("SFX_ExclamationCrate", new Vector3?(base.transform.position), new Vector2?(new Vector2(0.98f, 1.02f)));
		Object.Instantiate<Crate>(this.prefab, base.transform.position, base.transform.rotation, base.transform.parent);
		Object.Destroy(base.gameObject);
	}

	// Token: 0x0400059D RID: 1437
	public Crate prefab;
}
