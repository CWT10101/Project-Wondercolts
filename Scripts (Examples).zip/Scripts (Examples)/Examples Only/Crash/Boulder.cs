﻿using System;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000075 RID: 117
public class Boulder : Entity
{
	// Token: 0x17000092 RID: 146
	// (get) Token: 0x0600034F RID: 847 RVA: 0x0000E8CD File Offset: 0x0000CACD
	// (set) Token: 0x06000350 RID: 848 RVA: 0x0000E8D5 File Offset: 0x0000CAD5
	public bool IsRolling { get; private set; }

	// Token: 0x06000351 RID: 849 RVA: 0x0000E8DE File Offset: 0x0000CADE
	private void Start()
	{
		this._startPos = base.transform.position;
		this.path = this.pathContainer.GetComponentsInChildren<BoulderPathNode>();
	}

	// Token: 0x06000352 RID: 850 RVA: 0x0000E904 File Offset: 0x0000CB04
	private void FixedUpdate()
	{
		if (this.IsRolling)
		{
			float num = this.moveSpeed * Time.fixedDeltaTime;
			float num2 = Vector3.Distance(base.transform.position, this.path[this._index].transform.position);
			if (num > num2)
			{
				base.transform.position = this.path[this._index].transform.position;
				if (this._index + 1 >= this.path.Length)
				{
					this.RunTriggers();
					this.IsRolling = false;
					CrashController.instance.animator.SetRunMode(this.IsRolling);
					this.audio.Stop();
					return;
				}
				this.RunTriggers();
				this._index++;
				num -= num2;
			}
			Vector3 normalized = (this.path[this._index].transform.position - base.transform.position).normalized;
			base.transform.position += normalized * num;
			this.visual.transform.Rotate(Vector3.Cross(Vector3.up, normalized), this.rotateSpeed * Time.fixedDeltaTime, Space.World);
			Vector3 normalized2 = Vector3.ProjectOnPlane(normalized, Vector3.up).normalized;
			foreach (Collider collider in Physics.OverlapBox(base.transform.TransformPoint(this.collisionArea.center), this.collisionArea.extents, Quaternion.LookRotation(normalized2)))
			{
				Crate crate;
				CrashController crashController;
				if (collider.TryGetComponent<Crate>(out crate))
				{
					crate.Break();
				}
				else if (collider.TryGetComponent<CrashController>(out crashController))
				{
					crashController.Die(this.crashDeathEffectIndex);
				}
			}
		}
	}

	// Token: 0x06000353 RID: 851 RVA: 0x0000EAD0 File Offset: 0x0000CCD0
	private void RunTriggers()
	{
		UnityEvent evt = this.path[this._index].evt;
		if (evt != null)
		{
			evt.Invoke();
		}
		if (!string.IsNullOrEmpty(this.path[this._index].Trigger))
		{
			foreach (string text in this.path[this._index].Trigger.Split(',', StringSplitOptions.None))
			{
				base.SendMessage(text.Trim());
			}
		}
	}

	// Token: 0x06000354 RID: 852 RVA: 0x0000EB4C File Offset: 0x0000CD4C
	public override void ResetEntity()
	{
		base.ResetEntity();
		base.transform.position = this._startPos;
		this.visual.transform.rotation = Quaternion.identity;
		this._index = 0;
		this.IsRolling = false;
		CrashController.instance.animator.SetRunMode(this.IsRolling);
		this.audio.Stop();
	}

	// Token: 0x06000355 RID: 853 RVA: 0x0000EBB4 File Offset: 0x0000CDB4
	public void StartRolling()
	{
		if (this.IsRolling || this._index != 0)
		{
			return;
		}
		this.IsRolling = true;
		CrashController.instance.animator.SetRunMode(this.IsRolling);
		this.audio.Play();
		AudioManager.PlayMusic("EgyptChaseBGM", 0f);
		this.TryPushToStack();
	}

	// Token: 0x06000356 RID: 854 RVA: 0x0000EC10 File Offset: 0x0000CE10
	public void SlamSFX()
	{
		AudioManager.Play("SFX_BoulderImpact", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
	}

	// Token: 0x06000357 RID: 855 RVA: 0x0000EC42 File Offset: 0x0000CE42
	public void ShakeCam()
	{
		Debug.Log("Shake");
	}

	// Token: 0x06000358 RID: 856 RVA: 0x0000EC4E File Offset: 0x0000CE4E
	public void Dust(Transform target)
	{
		Object.Instantiate<GameObject>(this.dustPrefab, target.position, Quaternion.identity);
	}

	// Token: 0x04000225 RID: 549
	public AudioSource audio;

	// Token: 0x04000226 RID: 550
	public Transform pathContainer;

	// Token: 0x04000227 RID: 551
	private BoulderPathNode[] path;

	// Token: 0x04000228 RID: 552
	public GameObject dustPrefab;

	// Token: 0x04000229 RID: 553
	public float moveSpeed = 1f;

	// Token: 0x0400022A RID: 554
	public float rotateSpeed = 1f;

	// Token: 0x0400022B RID: 555
	public Bounds collisionArea = new Bounds(Vector3.zero, Vector3.one);

	// Token: 0x0400022D RID: 557
	public int crashDeathEffectIndex;

	// Token: 0x0400022E RID: 558
	private Vector3 _startPos;

	// Token: 0x0400022F RID: 559
	private int _index;
}
