﻿using System;
using LevelEditor;
using UnityEngine;

// Token: 0x020000F8 RID: 248
[DefaultExecutionOrder(10)]
public class PickupHandler : MonoBehaviour
{
	// Token: 0x060007A4 RID: 1956 RVA: 0x00020478 File Offset: 0x0001E678
	private void Start()
	{
		this.wumpa = (int)SaveData.Info.wumpa;
		InterfaceManager.instance.hudTrack.ClearGems();
		InterfaceManager.instance.hudTrack.SetWumpaText(this.wumpa);
		InterfaceManager.instance.hudTrack.SetLivesText();
		if (Level.instance)
		{
			InterfaceManager.instance.hudTrack.crateElement.SetActive(true);
			InterfaceManager.instance.hudTrack.crateCollectionText.text = string.Format("{0:00}/{1:00}", Level.instance.cratesCollected, Level.instance.crateCount);
		}
		else
		{
			InterfaceManager.instance.hudTrack.crateElement.SetActive(false);
		}
		InterfaceManager.instance.hudTrack.SetKillsText();
		InterfaceManager.instance.hudTrack.SetDeathsText();
	}

	// Token: 0x060007A5 RID: 1957 RVA: 0x0002055C File Offset: 0x0001E75C
	public void CollectWumpa()
	{
		this.wumpa++;
		if (this.wumpa > 99)
		{
			Object.Instantiate<WorldLerpUI>(this.lifePickupZoop, base.transform.position, Quaternion.identity);
			InterfaceManager.instance.hudTrack.ShowLives();
			AudioManager.Play("SFX_Life", AudioManager.MixerTarget.UI, null, null);
			this.wumpa = 0;
		}
		InterfaceManager.instance.hudTrack.SetWumpaText(this.wumpa);
		AudioManager.Play("SFX_CollectWumpa2", AudioManager.MixerTarget.UI, null, null);
	}

	// Token: 0x060007A6 RID: 1958 RVA: 0x00020604 File Offset: 0x0001E804
	public void CollectBonusWumpa()
	{
		this.bonusWumpa++;
		if (this.bonusWumpa > 99)
		{
			Object.Instantiate<WorldLerpUI>(this.lifePickupZoop, base.transform.position, Quaternion.identity);
			AudioManager.Play("SFX_Life", AudioManager.MixerTarget.UI, null, null);
			this.bonusWumpa = 0;
		}
		InterfaceManager.instance.bonusWumpaCount.text = string.Format("{0:00}", this.bonusWumpa);
		AudioManager.Play("SFX_CollectWumpa2", AudioManager.MixerTarget.UI, null, null);
	}

	// Token: 0x060007A7 RID: 1959 RVA: 0x000206AC File Offset: 0x0001E8AC
	public void TransferBonusWumpa()
	{
		InterfaceManager.instance.hudTrack.ShowWumpa();
		this.bonusWumpa--;
		this.UpdateBonusWumpaUI();
		this.CollectWumpa();
	}

	// Token: 0x060007A8 RID: 1960 RVA: 0x000206D8 File Offset: 0x0001E8D8
	public void TransferBonusLife()
	{
		InterfaceManager.instance.hudTrack.ShowLives();
		this.bonusLives--;
		this.UpdateBonusLivesUI();
		this.CollectLife();
		AudioManager.Play("SFX_Life", AudioManager.MixerTarget.UI, null, null);
	}

	// Token: 0x060007A9 RID: 1961 RVA: 0x0002072C File Offset: 0x0001E92C
	public void LoseBonusWumpa()
	{
		if (this.bonusWumpa > 0)
		{
			this.bonusWumpa--;
		}
		this.UpdateBonusWumpaUI();
	}

	// Token: 0x060007AA RID: 1962 RVA: 0x0002074B File Offset: 0x0001E94B
	public void LoseBonusLife()
	{
		if (this.bonusLives > 0)
		{
			this.bonusLives--;
		}
		this.UpdateBonusLivesUI();
	}

	// Token: 0x060007AB RID: 1963 RVA: 0x0002076A File Offset: 0x0001E96A
	public void UpdateBonusUI()
	{
		this.UpdateBonusLivesUI();
		this.UpdateBonusWumpaUI();
	}

	// Token: 0x060007AC RID: 1964 RVA: 0x00020778 File Offset: 0x0001E978
	public void UpdateBonusLivesUI()
	{
		InterfaceManager.instance.bonusLivesCount.text = string.Format("{0:0}", this.bonusLives);
	}

	// Token: 0x060007AD RID: 1965 RVA: 0x0002079E File Offset: 0x0001E99E
	public void UpdateBonusWumpaUI()
	{
		if (this.bonusWumpa < 0)
		{
			Debug.LogError("Negative wumpa");
		}
		InterfaceManager.instance.bonusWumpaCount.text = string.Format("{0:00}", this.bonusWumpa);
	}

	// Token: 0x060007AE RID: 1966 RVA: 0x000207D7 File Offset: 0x0001E9D7
	public void CollectBonusLife()
	{
		if (this.bonusLives < 99)
		{
			this.bonusLives++;
			InterfaceManager.instance.bonusLivesCount.text = string.Format("{0:0}", this.bonusLives);
		}
	}

	// Token: 0x060007AF RID: 1967 RVA: 0x00020815 File Offset: 0x0001EA15
	public void CollectLife()
	{
		if (SaveData.Info.lives < 99)
		{
			SaveDataInfo info = SaveData.Info;
			info.lives += 1;
			SaveData.Autosave();
			InterfaceManager.instance.hudTrack.SetLivesText();
		}
	}

	// Token: 0x060007B0 RID: 1968 RVA: 0x0002084C File Offset: 0x0001EA4C
	public void LoseLife()
	{
		if (Time.timeScale == 0f)
		{
			CrashSpawner.instance.RespawnCrash(CrashController.instance, 0f, null);
			return;
		}
		if (SaveData.Info.lives == 0)
		{
			InterfaceManager.instance.gameOverScreen.gameObject.SetActive(true);
			SaveData.Info.lives = 5;
			SaveData.Autosave();
			InterfaceManager.instance.hudTrack.SetLivesText();
			if (this.currentMask != null)
			{
				this.LoseMask(true);
				return;
			}
		}
		else
		{
			SaveDataInfo info = SaveData.Info;
			info.lives -= 1;
			this.deaths++;
			SaveData.Autosave();
			InterfaceManager.instance.hudTrack.SetLivesText();
			InterfaceManager.instance.hudTrack.ShowLives();
			InterfaceManager.instance.hudTrack.SetDeathsText();
			if (LevelInterfaceManager.instance)
			{
				NoDeathGem noDeathGem = LevelInterfaceManager.instance.GetSpecialGem() as NoDeathGem;
				if (noDeathGem != null)
				{
					noDeathGem.gameObject.SetActive(false);
				}
			}
			if (CrashSpawner.instance)
			{
				CrashSpawner.instance.RespawnCrash(CrashController.instance, 2f, null);
			}
		}
	}

	// Token: 0x060007B1 RID: 1969 RVA: 0x00020974 File Offset: 0x0001EB74
	public void CollectAku(Aku akuPickup)
	{
		if (this.currentMask == null)
		{
			this.currentMask = akuPickup;
			akuPickup.SetTarget(base.transform);
			if (Level.instance)
			{
				LevelSerializer.instance.akuHitCounter = 1;
				return;
			}
		}
		else
		{
			Aku aku = this.currentMask as Aku;
			if (aku != null)
			{
				aku.Upgrade(true);
				Object.Destroy(akuPickup.gameObject);
				if (Level.instance)
				{
					LevelSerializer.instance.akuHitCounter = 2;
					return;
				}
			}
			else
			{
				this.LoseMask(true);
				this.currentMask = akuPickup;
				akuPickup.SetTarget(base.transform);
			}
		}
	}

	// Token: 0x060007B2 RID: 1970 RVA: 0x00020A0D File Offset: 0x0001EC0D
	public void CollectUka(Uka ukaPickup)
	{
		if (this.currentMask)
		{
			this.LoseMask(true);
		}
		this.currentMask = ukaPickup;
		ukaPickup.SetTarget(base.transform);
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x00020A38 File Offset: 0x0001EC38
	public void LoseMask(bool playSFX = true)
	{
		if (this.currentMask)
		{
			Aku aku = this.currentMask as Aku;
			if (aku != null)
			{
				aku.CancelInvincibleMode();
				if (LevelSerializer.instance)
				{
					LevelSerializer.instance.akuHitCounter = 0;
				}
			}
			if (playSFX)
			{
				AudioManager.Play(CrashAudio.Hurt, AudioManager.MixerTarget.UI, null, null);
				AudioManager.Play("SFX_LoseMask", AudioManager.MixerTarget.UI, null, null);
				AudioManager.Play("SFX_LoseMask2", AudioManager.MixerTarget.UI, null, null);
			}
			Object.Destroy(this.currentMask.gameObject);
			this.currentMask = null;
		}
	}

	// Token: 0x060007B4 RID: 1972 RVA: 0x00020AF8 File Offset: 0x0001ECF8
	public bool HurtMask()
	{
		if (!(this.currentMask != null))
		{
			return false;
		}
		Aku aku = this.currentMask as Aku;
		if (aku == null)
		{
			this.LoseMask(true);
			return true;
		}
		if (aku.hitCounter > 1)
		{
			aku.Downgrade();
			if (LevelSerializer.instance)
			{
				LevelSerializer.instance.akuHitCounter = 1;
			}
			return false;
		}
		this.LoseMask(true);
		return true;
	}

	// Token: 0x040005AB RID: 1451
	public int wumpa;

	// Token: 0x040005AC RID: 1452
	public int bonusLives;

	// Token: 0x040005AD RID: 1453
	public int bonusWumpa;

	// Token: 0x040005AE RID: 1454
	public int deaths;

	// Token: 0x040005AF RID: 1455
	public GameObject invincibilityMask;

	// Token: 0x040005B0 RID: 1456
	[ReadOnly]
	public Mask currentMask;

	// Token: 0x040005B1 RID: 1457
	[ReadOnly]
	public FireflyFollower currentFirefly;

	// Token: 0x040005B2 RID: 1458
	public WorldLerpUI lifePickupZoop;

	// Token: 0x040005B3 RID: 1459
	public WorldLerpUI wumpaPickupZoop;
}
