﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000105 RID: 261
[DefaultExecutionOrder(10)]
public class RedCrate : ColourCrate
{
	// Token: 0x17000101 RID: 257
	// (get) Token: 0x060007FB RID: 2043 RVA: 0x00021CEA File Offset: 0x0001FEEA
	public override bool AddsToBoxCount
	{
		get
		{
			return false;
		}
	}

	// Token: 0x17000102 RID: 258
	// (get) Token: 0x060007FC RID: 2044 RVA: 0x00021CED File Offset: 0x0001FEED
	public static HashSet<RedCrate> Crates { get; } = new HashSet<RedCrate>();

	// Token: 0x060007FD RID: 2045 RVA: 0x00021CF4 File Offset: 0x0001FEF4
	protected override void OnEnable()
	{
		base.OnEnable();
		RedCrate.Crates.Add(this);
		this.SetSolid(!SwitchCrate.IsSwitchedOn, true);
	}

	// Token: 0x060007FE RID: 2046 RVA: 0x00021D17 File Offset: 0x0001FF17
	private void OnDisable()
	{
		RedCrate.Crates.Remove(this);
	}
}
