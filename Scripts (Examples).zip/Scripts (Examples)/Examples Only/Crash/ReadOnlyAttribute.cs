﻿using System;
using UnityEngine;

// Token: 0x0200005A RID: 90
[AttributeUsage(AttributeTargets.Field, Inherited = true)]
public class ReadOnlyAttribute : PropertyAttribute
{
}
