﻿using System;
using UnityEngine;

// Token: 0x02000072 RID: 114
public class RooTNT : Projectile, ITouchTop, ITouchSide
{
	// Token: 0x1700008D RID: 141
	// (get) Token: 0x0600032C RID: 812 RVA: 0x0000DCBC File Offset: 0x0000BEBC
	public Vector3 ColliderCenter
	{
		get
		{
			return this.collider.bounds.center;
		}
	}

	// Token: 0x1700008E RID: 142
	// (get) Token: 0x0600032D RID: 813 RVA: 0x0000DCDC File Offset: 0x0000BEDC
	public bool InstantDetonation
	{
		get
		{
			return this.animator == null;
		}
	}

	// Token: 0x0600032E RID: 814 RVA: 0x0000DCEA File Offset: 0x0000BEEA
	protected override void FixedUpdate()
	{
	}

	// Token: 0x0600032F RID: 815 RVA: 0x0000DCEC File Offset: 0x0000BEEC
	public void Light(byte fuse = 9)
	{
		RooTNT.<>c__DisplayClass9_0 CS$<>8__locals1 = new RooTNT.<>c__DisplayClass9_0();
		CS$<>8__locals1.<>4__this = this;
		CS$<>8__locals1.fuse = fuse;
		if (this.InstantDetonation)
		{
			this.Explode();
			return;
		}
		base.StartCoroutine(CS$<>8__locals1.<Light>g__Delay|0());
	}

	// Token: 0x06000330 RID: 816 RVA: 0x0000DD29 File Offset: 0x0000BF29
	private void PlayFromTime(float time)
	{
		this.animator.PlayInFixedTime("Countdown", 0, time);
	}

	// Token: 0x06000331 RID: 817 RVA: 0x0000DD40 File Offset: 0x0000BF40
	public virtual void Explode()
	{
		foreach (Collider collider in Physics.OverlapSphere(base.transform.position + new Vector3(0f, 0.5f, 0f), this.explosionRadius))
		{
			CrashController crashController;
			if (collider.TryGetComponent<CrashController>(out crashController))
			{
				crashController.TakeDamage(this.crashDeathIndex);
			}
			Enemy enemy;
			if (collider.TryGetComponent<Enemy>(out enemy))
			{
				enemy.Explode(base.transform);
			}
		}
		Object.Instantiate<Explosion>(this.explosion, this.ColliderCenter, Quaternion.identity, LevelManager.instance.projectileHolder).size = this.explosionRadius;
		if (this.explosionEffect)
		{
			Object.Instantiate<GameObject>(this.explosionEffect, base.transform.position, Quaternion.identity, LevelManager.instance.projectileHolder);
		}
		Object.Destroy(base.gameObject);
	}

	// Token: 0x06000332 RID: 818 RVA: 0x0000DE24 File Offset: 0x0000C024
	public void PlayCountdownSFX()
	{
		AudioManager.Play("SFX_TNTBeep", new Vector3?(base.transform.position), null);
	}

	// Token: 0x06000333 RID: 819 RVA: 0x0000DE55 File Offset: 0x0000C055
	public void TouchTop(CrashController crash)
	{
		if (this.InstantDetonation)
		{
			this.Explode();
		}
	}

	// Token: 0x06000334 RID: 820 RVA: 0x0000DE65 File Offset: 0x0000C065
	public void TouchSide(CrashController crash)
	{
		if (this.InstantDetonation)
		{
			this.Explode();
		}
	}

	// Token: 0x04000202 RID: 514
	[SerializeField]
	private Animator animator;

	// Token: 0x04000203 RID: 515
	[SerializeField]
	private Explosion explosion;

	// Token: 0x04000204 RID: 516
	[SerializeField]
	private GameObject explosionEffect;

	// Token: 0x04000205 RID: 517
	[SerializeField]
	private float explosionRadius = 3f;
}
