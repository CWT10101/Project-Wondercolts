﻿using System;

// Token: 0x020000D0 RID: 208
public interface ITouchSide
{
	// Token: 0x0600061C RID: 1564
	void TouchSide(CrashController crash);
}
