﻿using System;
using UnityEngine;

// Token: 0x02000149 RID: 329
public static class BoundsUtil
{
	// Token: 0x060009B7 RID: 2487 RVA: 0x0002747C File Offset: 0x0002567C
	public static Bounds RelativeTo(this Bounds bounds, Bounds other)
	{
		return new Bounds(bounds.center - other.center, bounds.size);
	}

	// Token: 0x060009B8 RID: 2488 RVA: 0x0002749D File Offset: 0x0002569D
	public static Bounds RelativeFrom(this Bounds bounds, Bounds other)
	{
		return new Bounds(other.center - bounds.center, bounds.size);
	}
}
