﻿using System;
using UnityEngine;

// Token: 0x020000D2 RID: 210
public class JumpingEnemy : BasicEnemy
{
	// Token: 0x0600061E RID: 1566 RVA: 0x0001A952 File Offset: 0x00018B52
	protected override void OnEnable()
	{
		base.OnEnable();
		this._t = this.jumpDelay;
	}

	// Token: 0x0600061F RID: 1567 RVA: 0x0001A966 File Offset: 0x00018B66
	public override void ResetEntity()
	{
		base.ResetEntity();
		this._t = this.jumpDelay;
		this.speed = 0f;
		this._wasGrounded = false;
		this._jumped = false;
		this._turning = false;
	}

	// Token: 0x06000620 RID: 1568 RVA: 0x0001A99A File Offset: 0x00018B9A
	private void TurnAround()
	{
		if (this._turning)
		{
			return;
		}
		this._turning = true;
		this.animator.Play(this.turnAroundAnimationState);
	}

	// Token: 0x06000621 RID: 1569 RVA: 0x0001A9C0 File Offset: 0x00018BC0
	private void Jump()
	{
		this._jumped = true;
		this.animator.Play(this.jumpAnimationState);
		Vector3 vector = Vector3.Lerp(base.transform.forward, Vector3.up, this.jumpUpness).normalized * this.jumpStrength;
		this.speed = Vector3.Scale(vector, new Vector3(1f, 0f, 1f)).magnitude;
		this.fallMomentum = vector.y;
	}

	// Token: 0x06000622 RID: 1570 RVA: 0x0001AA48 File Offset: 0x00018C48
	protected override void FixedUpdate()
	{
		base.FixedUpdate();
		if (this._turning && this.animator.GetCurrentAnimatorStateInfo(0).normalizedTime >= 1f && !this.animator.IsInTransition(0))
		{
			this._turning = false;
			this._dir *= -1f;
			base.transform.rotation = Quaternion.LookRotation(this._dir);
			this.Jump();
		}
		if (!this._wasGrounded && this.controller.isGrounded)
		{
			this.speed = 0f;
			if (this._jumped)
			{
				this._jumped = false;
				this.animator.Play(this.idleAnimationState);
				this._t = this.jumpDelay;
			}
			else
			{
				this.Jump();
			}
		}
		else if (!this.controller.isGrounded)
		{
			this._t = 0f;
		}
		if (this._t > 0f)
		{
			this._t -= Time.fixedDeltaTime;
			if (this._t <= 0f)
			{
				this._t = 0f;
				this.TurnAround();
			}
		}
		this._wasGrounded = this.controller.isGrounded;
	}

	// Token: 0x04000476 RID: 1142
	public string idleAnimationState = "Idle";

	// Token: 0x04000477 RID: 1143
	public string jumpAnimationState = "Jump";

	// Token: 0x04000478 RID: 1144
	public string turnAroundAnimationState = "Turn 180";

	// Token: 0x04000479 RID: 1145
	public float jumpStrength = 10f;

	// Token: 0x0400047A RID: 1146
	public float jumpUpness = 0.5f;

	// Token: 0x0400047B RID: 1147
	public float jumpDelay = 2f;

	// Token: 0x0400047C RID: 1148
	private float _t;

	// Token: 0x0400047D RID: 1149
	private bool _wasGrounded;

	// Token: 0x0400047E RID: 1150
	private bool _jumped;

	// Token: 0x0400047F RID: 1151
	private bool _turning;
}
