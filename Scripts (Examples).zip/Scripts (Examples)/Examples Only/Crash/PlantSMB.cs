﻿using System;
using UnityEngine;

// Token: 0x02000052 RID: 82
public class PlantSMB : StateMachineBehaviour
{
	// Token: 0x06000218 RID: 536 RVA: 0x000096E8 File Offset: 0x000078E8
	public override void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
	{
		animator.GetComponent<PlantEnemy>().ResetAttack();
	}
}
