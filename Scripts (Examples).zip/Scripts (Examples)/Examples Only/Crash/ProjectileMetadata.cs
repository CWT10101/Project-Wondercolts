﻿using System;
using System.Collections.Generic;
using System.IO;
using LevelEditor;

// Token: 0x0200002F RID: 47
public class ProjectileMetadata : ObjectMetadata
{
	// Token: 0x1700003F RID: 63
	// (get) Token: 0x06000129 RID: 297 RVA: 0x000065E1 File Offset: 0x000047E1
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000040 RID: 64
	// (get) Token: 0x0600012A RID: 298 RVA: 0x000065E4 File Offset: 0x000047E4
	public override int Signature
	{
		get
		{
			return this.CalculateSignature();
		}
	}

	// Token: 0x17000041 RID: 65
	// (get) Token: 0x0600012B RID: 299 RVA: 0x000065EC File Offset: 0x000047EC
	public override int ValueHash
	{
		get
		{
			return (int)this.projectileIndex;
		}
	}

	// Token: 0x0600012C RID: 300 RVA: 0x000065F4 File Offset: 0x000047F4
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<ProjectileMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<ProjectileMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x0600012D RID: 301 RVA: 0x00006620 File Offset: 0x00004820
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.projectileIndex = br.ReadByte();
	}

	// Token: 0x0600012E RID: 302 RVA: 0x0000662E File Offset: 0x0000482E
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.projectileIndex);
	}

	// Token: 0x0600012F RID: 303 RVA: 0x0000663C File Offset: 0x0000483C
	private int CalculateSignature()
	{
		if (this.signature == 0)
		{
			this.signature = "ProjectileMetadata".GetHashCode();
			foreach (string text in this.projectileOptions)
			{
				this.signature ^= text.GetHashCode();
			}
		}
		return this.signature;
	}

	// Token: 0x04000096 RID: 150
	public byte projectileIndex;

	// Token: 0x04000097 RID: 151
	public List<string> projectileOptions;

	// Token: 0x04000098 RID: 152
	private int signature;
}
