﻿using System;
using UnityEngine;

// Token: 0x02000045 RID: 69
[RequireComponent(typeof(Camera))]
[ExecuteInEditMode]
public class PSXEffects : MonoBehaviour
{
	// Token: 0x060001C8 RID: 456 RVA: 0x00007BBC File Offset: 0x00005DBC
	private void Awake()
	{
		if (Application.isPlaying)
		{
			QualitySettings.vSyncCount = 0;
		}
		QualitySettings.antiAliasing = 0;
		this.cfuStatus = "PSXEffects v" + this.version.ToString();
		base.GetComponent<Camera>().depthTextureMode |= DepthTextureMode.Depth;
		if (!this.downscale)
		{
			this.customRes = new Vector2Int(Screen.width / this.resolutionFactor, Screen.height / this.resolutionFactor);
		}
		this.rt = new RenderTexture(this.customRes.x, this.customRes.y, 16, RenderTextureFormat.ARGB32);
		this.rt.filterMode = FilterMode.Point;
		string[] array = new string[]
		{
			"_AffineMapping",
			"_DrawDistance",
			"_VertexSnappingDetail",
			"_Offset",
			"_DarkMax",
			"_SubtractFade",
			"_WorldSpace",
			"_CamPos",
			"_ShadowType",
			"_AffineBounds"
		};
		this.propIds = new int[array.Length];
		for (int i = 0; i < array.Length; i++)
		{
			this.propIds[i] = Shader.PropertyToID(array[i]);
		}
		this.UpdateProperties();
	}

	// Token: 0x060001C9 RID: 457 RVA: 0x00007CF0 File Offset: 0x00005EF0
	private void Start()
	{
		this.UpdateProperties();
	}

	// Token: 0x060001CA RID: 458 RVA: 0x00007CF8 File Offset: 0x00005EF8
	private void Update()
	{
		if (!this.downscale)
		{
			this.customRes = new Vector2Int(Screen.width / this.resolutionFactor, Screen.height / this.resolutionFactor);
		}
		if (this.prevCustomRes != this.customRes)
		{
			this.rt = new RenderTexture(this.customRes.x, this.customRes.y, 16, RenderTextureFormat.ARGB32);
			this.rt.filterMode = FilterMode.Point;
		}
		if (Application.isEditor && !Application.isPlaying)
		{
			this.UpdateProperties();
		}
		Application.targetFrameRate = this.limitFramerate;
		this.prevCustomRes = this.customRes;
	}

	// Token: 0x060001CB RID: 459 RVA: 0x00007DA8 File Offset: 0x00005FA8
	private void LateUpdate()
	{
		if (this.snapCamera && Application.isPlaying)
		{
			if (base.transform.parent == null || !base.transform.parent.name.Contains("CameraRealPosition"))
			{
				GameObject gameObject = new GameObject("CameraRealPosition");
				gameObject.transform.position = base.transform.position;
				if (base.transform.parent)
				{
					gameObject.transform.SetParent(base.transform.parent);
				}
				base.transform.SetParent(gameObject.transform);
			}
			Vector3 vector = base.transform.parent.position;
			vector /= this.camInaccuracy;
			vector = new Vector3(Mathf.Round(vector.x), Mathf.Round(vector.y), Mathf.Round(vector.z));
			vector *= this.camInaccuracy;
			base.transform.position = vector;
			return;
		}
		if (base.transform.parent != null && base.transform.parent.name.Contains("CameraRealPosition"))
		{
			Object.Destroy(base.transform.parent.gameObject);
		}
	}

	// Token: 0x060001CC RID: 460 RVA: 0x00007EF8 File Offset: 0x000060F8
	public void UpdateProperties()
	{
		if (this.affineMapping)
		{
			Shader.EnableKeyword("AFFINE_MAPPING");
		}
		else
		{
			Shader.DisableKeyword("AFFINE_MAPPING");
		}
		if (this.clampAffine)
		{
			Shader.EnableKeyword("CLAMP_AFFINE");
		}
		else
		{
			Shader.DisableKeyword("CLAMP_AFFINE");
		}
		Shader.SetGlobalFloat(this.propIds[1], this.polygonalDrawDistance);
		Shader.SetGlobalInt(this.propIds[2], (int)((float)this.vertexInaccuracy * 0.5f));
		Shader.SetGlobalInt(this.propIds[3], this.polygonInaccuracy);
		Shader.SetGlobalFloat(this.propIds[5], (float)this.subtractFade * 0.01f);
		Shader.SetGlobalFloat("_AffineBounds", this.affineBounds);
		if (this.worldSpaceSnapping)
		{
			Shader.EnableKeyword("WORLD_SPACE_SNAPPING");
		}
		else
		{
			Shader.DisableKeyword("WORLD_SPACE_SNAPPING");
		}
		Shader.SetGlobalFloat(this.propIds[7], this.camSnapping ? 1f : 0f);
		if (this.shadowType == 0)
		{
			Shader.EnableKeyword("SHADOW_DEFAULT");
			Shader.DisableKeyword("SHADOW_PSX");
		}
		else
		{
			Shader.DisableKeyword("SHADOW_DEFAULT");
			Shader.EnableKeyword("SHADOW_PSX");
		}
		if (this.postProcessing)
		{
			if (this.postProcessingMat == null)
			{
				this.postProcessingMat = new Material(Shader.Find("Hidden/PS1PostProcessing"));
				return;
			}
			this.postProcessingMat.SetFloat("_ColorDepth", Mathf.Pow(2f, (float)this.colorDepth));
			this.postProcessingMat.SetFloat("_Scanlines", (float)(this.scanlines ? 1 : 0));
			this.postProcessingMat.SetFloat("_ScanlineIntensity", (float)this.scanlineIntensity * 0.01f);
			this.postProcessingMat.SetTexture("_DitherTex", this.ditherTexture);
			this.postProcessingMat.SetFloat("_Dithering", (float)(this.dithering ? 1 : 0));
			this.postProcessingMat.SetFloat("_DitherThreshold", this.ditherThreshold);
			this.postProcessingMat.SetFloat("_DitherIntensity", (float)this.ditherIntensity * 0.01f);
			this.postProcessingMat.SetFloat("_ResX", (float)this.customRes.x);
			this.postProcessingMat.SetFloat("_ResY", (float)this.customRes.y);
			this.postProcessingMat.SetFloat("_FavorRed", this.favorRed);
			this.postProcessingMat.SetFloat("_SLDirection", (float)(this.verticalScanlines ? 1 : 0));
			if (this.ditherSky)
			{
				this.postProcessingMat.EnableKeyword("DITHER_SKY");
			}
			else
			{
				this.postProcessingMat.DisableKeyword("DITHER_SKY");
			}
			if (this.ditherType == 0)
			{
				this.postProcessingMat.EnableKeyword("DITHER_SLOW");
				this.postProcessingMat.DisableKeyword("DITHER_FAST");
				this.postProcessingMat.DisableKeyword("DITHER_TEX");
			}
			else if (this.ditherType == 1)
			{
				this.postProcessingMat.EnableKeyword("DITHER_FAST");
				this.postProcessingMat.DisableKeyword("DITHER_SLOW");
				this.postProcessingMat.DisableKeyword("DITHER_TEX");
			}
			else if (this.ditherType == 2)
			{
				this.postProcessingMat.EnableKeyword("DITHER_TEX");
				this.postProcessingMat.DisableKeyword("DITHER_SLOW");
				this.postProcessingMat.DisableKeyword("DITHER_FAST");
			}
			if (this.scanlines)
			{
				this.postProcessingMat.EnableKeyword("SCANLINES_ON");
				return;
			}
			this.postProcessingMat.DisableKeyword("SCANLINES_ON");
		}
	}

	// Token: 0x060001CD RID: 461 RVA: 0x0000827C File Offset: 0x0000647C
	public void SnapCamera()
	{
		Vector3 vector = base.transform.position;
		vector /= this.camInaccuracy;
		vector = new Vector3(Mathf.Round(vector.x), Mathf.Round(vector.y), Mathf.Round(vector.z));
		vector *= this.camInaccuracy;
		base.transform.position = vector;
	}

	// Token: 0x060001CE RID: 462 RVA: 0x000082E4 File Offset: 0x000064E4
	private void OnDrawGizmos()
	{
		if (this.snapCamera)
		{
			Gizmos.color = new Color(1f, 0f, 0f, 0.5f);
			if (base.transform.parent != null)
			{
				Gizmos.DrawSphere(base.transform.parent.position, 0.5f);
			}
		}
	}

	// Token: 0x060001CF RID: 463 RVA: 0x00008344 File Offset: 0x00006544
	private void OnRenderImage(RenderTexture src, RenderTexture dst)
	{
		if (!this.postProcessing)
		{
			if (src != null)
			{
				src.filterMode = FilterMode.Point;
			}
			if (this.skipFrames < 1 || Time.frameCount % this.skipFrames == 0)
			{
				Graphics.Blit(src, this.rt);
			}
			Graphics.Blit(this.rt, dst);
			return;
		}
		if (this.customRes.x > 2 && this.customRes.y > 2)
		{
			if (src != null)
			{
				src.filterMode = FilterMode.Point;
			}
			if (this.skipFrames < 1 || Time.frameCount % this.skipFrames == 0)
			{
				Graphics.Blit(src, this.rt);
			}
			Graphics.Blit(this.rt, dst, this.postProcessingMat);
			return;
		}
		this.customRes.x = 2;
		this.customRes.y = 2;
	}

	// Token: 0x060001D0 RID: 464 RVA: 0x00008414 File Offset: 0x00006614
	private void OnDestroy()
	{
		Shader.EnableKeyword("AFFINE_MAPPING");
		Shader.SetGlobalFloat("_DrawDistance", 0f);
		Shader.SetGlobalInt("_VertexSnappingDetail", 1);
		Shader.SetGlobalInt("_Offset", 2);
		Shader.SetGlobalFloat("_SubtractFade", 0f);
		Shader.EnableKeyword("WORLD_SPACE_SNAPPING");
		Shader.SetGlobalFloat("_CamPos", 1f);
		Shader.EnableKeyword("SHADOW_DEFAULT");
		Shader.DisableKeyword("SHADOW_PSX");
	}

	// Token: 0x040000D2 RID: 210
	public Version version = new Version("1.18.4");

	// Token: 0x040000D3 RID: 211
	public string cfuStatus = "PSXEffects";

	// Token: 0x040000D4 RID: 212
	public bool[] sections = new bool[]
	{
		true,
		true,
		true,
		false
	};

	// Token: 0x040000D5 RID: 213
	public Vector2Int customRes = new Vector2Int(620, 480);

	// Token: 0x040000D6 RID: 214
	public int resolutionFactor = 1;

	// Token: 0x040000D7 RID: 215
	public int limitFramerate = -1;

	// Token: 0x040000D8 RID: 216
	public int skipFrames;

	// Token: 0x040000D9 RID: 217
	public bool affineMapping = true;

	// Token: 0x040000DA RID: 218
	public bool clampAffine;

	// Token: 0x040000DB RID: 219
	public float affineBounds;

	// Token: 0x040000DC RID: 220
	public float polygonalDrawDistance;

	// Token: 0x040000DD RID: 221
	public int vertexInaccuracy = 30;

	// Token: 0x040000DE RID: 222
	public int polygonInaccuracy = 2;

	// Token: 0x040000DF RID: 223
	public int colorDepth = 5;

	// Token: 0x040000E0 RID: 224
	public bool scanlines;

	// Token: 0x040000E1 RID: 225
	public int scanlineIntensity = 5;

	// Token: 0x040000E2 RID: 226
	public Texture2D ditherTexture;

	// Token: 0x040000E3 RID: 227
	public bool dithering = true;

	// Token: 0x040000E4 RID: 228
	public float ditherThreshold = 1f;

	// Token: 0x040000E5 RID: 229
	public int ditherIntensity = 12;

	// Token: 0x040000E6 RID: 230
	public int maxDarkness = 20;

	// Token: 0x040000E7 RID: 231
	public int subtractFade;

	// Token: 0x040000E8 RID: 232
	public float favorRed = 1f;

	// Token: 0x040000E9 RID: 233
	public bool worldSpaceSnapping;

	// Token: 0x040000EA RID: 234
	public bool postProcessing = true;

	// Token: 0x040000EB RID: 235
	public bool verticalScanlines = true;

	// Token: 0x040000EC RID: 236
	public float shadowIntensity = 0.5f;

	// Token: 0x040000ED RID: 237
	public bool downscale;

	// Token: 0x040000EE RID: 238
	public bool snapCamera;

	// Token: 0x040000EF RID: 239
	public float camInaccuracy = 0.05f;

	// Token: 0x040000F0 RID: 240
	public bool camSnapping;

	// Token: 0x040000F1 RID: 241
	public int shadowType;

	// Token: 0x040000F2 RID: 242
	public bool ditherSky;

	// Token: 0x040000F3 RID: 243
	public int ditherType = 1;

	// Token: 0x040000F4 RID: 244
	private Material postProcessingMat;

	// Token: 0x040000F5 RID: 245
	private RenderTexture rt;

	// Token: 0x040000F6 RID: 246
	private Vector2 prevCustomRes;

	// Token: 0x040000F7 RID: 247
	private int[] propIds;
}
