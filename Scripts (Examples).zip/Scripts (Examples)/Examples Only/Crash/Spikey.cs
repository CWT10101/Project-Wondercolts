﻿using System;
using UnityEngine;

// Token: 0x02000128 RID: 296
public class Spikey : Entity, IMetadataReceiver<PhaseMetadata>
{
	// Token: 0x17000112 RID: 274
	// (get) Token: 0x060008DC RID: 2268 RVA: 0x00024B73 File Offset: 0x00022D73
	private float PhaseOffset
	{
		get
		{
			return this.phase * 2f;
		}
	}

	// Token: 0x060008DD RID: 2269 RVA: 0x00024B84 File Offset: 0x00022D84
	public void FixedUpdate()
	{
		float num = (Time.timeSinceLevelLoad - Time.fixedDeltaTime) * this.frequency + this.PhaseOffset;
		float num2 = Time.timeSinceLevelLoad * this.frequency + this.PhaseOffset;
		if (num % 1f < this.playExtendTime && num2 % 1f >= this.playExtendTime)
		{
			this.extendSrc.Play();
		}
		else if (num % 1f < this.playRetractTime && num2 % 1f >= this.playRetractTime)
		{
			this.retractSrc.Play();
		}
		base.transform.localPosition = this.amplitude * this.movementCurve.Evaluate(Time.timeSinceLevelLoad * this.frequency + this.PhaseOffset) * Vector3.up;
	}

	// Token: 0x060008DE RID: 2270 RVA: 0x00024C4D File Offset: 0x00022E4D
	public void ProcessMetadata(PhaseMetadata meta)
	{
		this.phase = meta.NormalizedValue;
	}

	// Token: 0x04000671 RID: 1649
	public AnimationCurve movementCurve;

	// Token: 0x04000672 RID: 1650
	public AudioSource extendSrc;

	// Token: 0x04000673 RID: 1651
	public AudioSource retractSrc;

	// Token: 0x04000674 RID: 1652
	public float frequency = 0.5f;

	// Token: 0x04000675 RID: 1653
	public float amplitude = 3f;

	// Token: 0x04000676 RID: 1654
	public float phase;

	// Token: 0x04000677 RID: 1655
	public float playExtendTime = 0.3f;

	// Token: 0x04000678 RID: 1656
	public float playRetractTime = 0.7f;
}
