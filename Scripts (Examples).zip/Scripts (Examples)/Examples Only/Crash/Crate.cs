﻿using System;
using System.Collections;
using LevelEditor;
using UnityEngine;

// Token: 0x0200008E RID: 142
[DefaultExecutionOrder(-5)]
public abstract class Crate : Entity, IPostEnable, IPlatform, IMetadataReceiver<CanFallMetadata>
{
	// Token: 0x170000B1 RID: 177
	// (get) Token: 0x0600042D RID: 1069
	public abstract bool AddsToBoxCount { get; }

	// Token: 0x14000001 RID: 1
	// (add) Token: 0x0600042E RID: 1070 RVA: 0x00013764 File Offset: 0x00011964
	// (remove) Token: 0x0600042F RID: 1071 RVA: 0x0001379C File Offset: 0x0001199C
	public event Action onBreak;

	// Token: 0x170000B2 RID: 178
	// (get) Token: 0x06000430 RID: 1072 RVA: 0x000137D1 File Offset: 0x000119D1
	// (set) Token: 0x06000431 RID: 1073 RVA: 0x000137D9 File Offset: 0x000119D9
	public bool CanFall { get; protected set; } = true;

	// Token: 0x170000B3 RID: 179
	// (get) Token: 0x06000432 RID: 1074 RVA: 0x000137E2 File Offset: 0x000119E2
	// (set) Token: 0x06000433 RID: 1075 RVA: 0x000137EA File Offset: 0x000119EA
	public bool IsFalling { get; private set; }

	// Token: 0x170000B4 RID: 180
	// (get) Token: 0x06000434 RID: 1076 RVA: 0x000137F4 File Offset: 0x000119F4
	public Vector3 ColliderCenter
	{
		get
		{
			if (!this.coll)
			{
				return base.transform.position + new Vector3(0f, 0.5f, 0f);
			}
			return base.transform.TransformPoint(this.coll.center);
		}
	}

	// Token: 0x170000B5 RID: 181
	// (get) Token: 0x06000435 RID: 1077 RVA: 0x00013849 File Offset: 0x00011A49
	public Vector3 StartPosition
	{
		get
		{
			if (this._startPosition == null)
			{
				this._startPosition = new Vector3?(base.transform.localPosition);
			}
			return this._startPosition.Value;
		}
	}

	// Token: 0x06000436 RID: 1078 RVA: 0x00013879 File Offset: 0x00011A79
	protected virtual void OnEnable()
	{
		this.IsFalling = false;
		base.transform.localPosition = this.StartPosition;
		this.fallDelta = 0f;
	}

	// Token: 0x06000437 RID: 1079 RVA: 0x0001389E File Offset: 0x00011A9E
	private void OnDisable()
	{
		this.fallState = null;
		this.IsFalling = false;
	}

	// Token: 0x06000438 RID: 1080 RVA: 0x000138B0 File Offset: 0x00011AB0
	public virtual void OnPostEnable()
	{
		Crate crate;
		if (this.isBroken && this.CrateCheck(out crate))
		{
			crate.Fall(0f);
		}
	}

	// Token: 0x06000439 RID: 1081 RVA: 0x000138DC File Offset: 0x00011ADC
	protected virtual void FixedUpdate()
	{
		if (this.IsFalling && this.fallState != null)
		{
			IEnumerator enumerator = this.fallState;
			if (!this.fallState.MoveNext() && this.fallState == enumerator)
			{
				this.fallState = null;
			}
		}
	}

	// Token: 0x0600043A RID: 1082 RVA: 0x0001391D File Offset: 0x00011B1D
	public virtual void Break()
	{
		this.ForceBreak();
	}

	// Token: 0x0600043B RID: 1083 RVA: 0x00013928 File Offset: 0x00011B28
	public virtual void ForceBreak()
	{
		if (this.isBroken)
		{
			Debug.LogWarning("Trying to break a broken box", this);
			return;
		}
		this.isBroken = true;
		this.TryPushToStack();
		this.coll.enabled = false;
		BrokenCrate brokenCrate = Object.Instantiate<BrokenCrate>(ResourceManager.instance.brokenCrate, base.transform.position, base.transform.rotation);
		brokenCrate.crateCol = this.brokenBoxCol;
		brokenCrate.SetColour(this.brokenBoxCol);
		if (this.AddsToBoxCount && Level.instance != null)
		{
			Level.instance.AddCrateCollected(this);
		}
		if (this.AddsToBoxCount && LevelInterfaceManager.instance != null)
		{
			LevelInterfaceManager.instance.AddCrateCollected(this);
		}
		this.visual.SetActive(false);
		Crate crate;
		if (this.CrateCheck(out crate))
		{
			crate.Fall(0f);
		}
		this.OnBreak();
	}

	// Token: 0x0600043C RID: 1084 RVA: 0x00013A05 File Offset: 0x00011C05
	protected void OnBreak()
	{
		Action action = this.onBreak;
		if (action == null)
		{
			return;
		}
		action();
	}

	// Token: 0x0600043D RID: 1085 RVA: 0x00013A18 File Offset: 0x00011C18
	public void SetOutlineColor(Color col)
	{
		SpriteRenderer[] componentsInChildren = this.outlineVis.GetComponentsInChildren<SpriteRenderer>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].color = col;
		}
	}

	// Token: 0x0600043E RID: 1086 RVA: 0x00013A4C File Offset: 0x00011C4C
	public virtual void SetOutlineMode()
	{
		this.visual.SetActive(false);
		this.outlineVis.SetActive(true);
		this.collider.enabled = (this.coll.enabled = false);
		if (this.fallState != null)
		{
			this.IsFalling = false;
		}
	}

	// Token: 0x0600043F RID: 1087 RVA: 0x00013A9C File Offset: 0x00011C9C
	public virtual void SetTangibleMode()
	{
		this.visual.SetActive(true);
		this.outlineVis.SetActive(false);
		this.collider.enabled = (this.coll.enabled = true);
		AudioManager.Play("SFX_ExclamationCrate", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), new Vector2?(new Vector2(0.98f, 1.02f)));
		if (this.fallState != null)
		{
			this.IsFalling = true;
		}
	}

	// Token: 0x06000440 RID: 1088 RVA: 0x00013B1A File Offset: 0x00011D1A
	public virtual void Fall(float withVelocity = 0f)
	{
		if (!this.CanFall)
		{
			return;
		}
		if (this.IsFalling)
		{
			return;
		}
		this.IsFalling = true;
		this.fallState = this.FallRoutine(withVelocity);
	}

	// Token: 0x06000441 RID: 1089 RVA: 0x00013B42 File Offset: 0x00011D42
	protected virtual void LandOnCrash()
	{
		this.Break();
	}

	// Token: 0x06000442 RID: 1090 RVA: 0x00013B4A File Offset: 0x00011D4A
	protected virtual void Settle()
	{
	}

	// Token: 0x06000443 RID: 1091 RVA: 0x00013B4C File Offset: 0x00011D4C
	protected bool IsAbove(CrashController crash)
	{
		return this.collider.ClosestPoint(crash.controller.ClosestPoint(this.collider.bounds.center)).y - this.collider.bounds.max.y >= 0f;
	}

	// Token: 0x06000444 RID: 1092 RVA: 0x00013BAC File Offset: 0x00011DAC
	protected bool IsBelow(CrashController crash)
	{
		return this.collider.ClosestPoint(crash.controller.ClosestPoint(this.collider.bounds.center)).y - this.collider.bounds.min.y <= 0f;
	}

	// Token: 0x06000445 RID: 1093 RVA: 0x00013C0C File Offset: 0x00011E0C
	protected bool IsBeside(CrashController crash)
	{
		return this.collider.ClosestPoint(crash.controller.ClosestPoint(this.collider.bounds.center)).XZ().Max() >= 0.5f;
	}

	// Token: 0x06000446 RID: 1094 RVA: 0x00013C58 File Offset: 0x00011E58
	protected bool CheckGap(CrashController crash)
	{
		if (crash.animator.TimeSinceStateChanged < 0.1f)
		{
			return false;
		}
		if (crash.LastMoveDelta.XZ().magnitude < crash.EffectiveSpeed * 0.95f)
		{
			return false;
		}
		Vector3 direction = -crash.LastMoveDelta.normalized;
		RaycastHit raycastHit;
		return !Physics.Raycast(this.coll.bounds.center, direction, out raycastHit, 1f, 1, QueryTriggerInteraction.Ignore);
	}

	// Token: 0x06000447 RID: 1095 RVA: 0x00013CD6 File Offset: 0x00011ED6
	private IEnumerator FallRoutine(float withVelocity)
	{
		if (withVelocity == 0f)
		{
			float t = 0.2f;
			while (t > 0f)
			{
				t -= Time.fixedDeltaTime;
				yield return null;
			}
		}
		Crate crate;
		if (this.CrateCheck(out crate))
		{
			crate.Fall(0f);
		}
		this.fallDelta = withVelocity;
		while (!this.isBroken)
		{
			this.fallDelta += Time.fixedDeltaTime;
			if (this.fallDelta > 1f)
			{
				this.fallDelta = 1f;
			}
			RaycastHit raycastHit2;
			if (this.fallDelta < 0f)
			{
				RaycastHit raycastHit;
				if (Physics.BoxCast(this.ColliderCenter, Vector3.Scale(this.coll.size, new Vector3(0.4f, 0.5f, 0.4f)), Vector3.up, out raycastHit, base.transform.rotation, -this.fallDelta, -1, QueryTriggerInteraction.Ignore) && !raycastHit.collider.GetComponentInParent<CrashController>())
				{
					base.transform.Translate(Vector3.up * raycastHit.distance, Space.World);
					this.fallDelta = 0f;
				}
				else
				{
					base.transform.Translate(Vector3.down * this.fallDelta, Space.World);
				}
			}
			else if (Physics.BoxCast(this.ColliderCenter, Vector3.Scale(this.coll.size, new Vector3(0.4f, 0.5f, 0.4f)), Vector3.down, out raycastHit2, base.transform.rotation, this.fallDelta, -1, QueryTriggerInteraction.Ignore) && (!raycastHit2.collider.TryGetComponent<Crate>(out crate) || !crate.IsFalling))
			{
				CrashController crashController;
				if (raycastHit2.collider.TryGetComponent<CrashController>(out crashController))
				{
					this.IsFalling = false;
					this.LandOnCrash();
					yield break;
				}
				Debug.Log(base.gameObject.name + " landed on " + raycastHit2.collider.gameObject.name, base.gameObject);
				this.fallDelta = raycastHit2.distance;
				base.transform.Translate(Vector3.down * this.fallDelta, Space.World);
				yield return null;
				break;
			}
			else
			{
				base.transform.Translate(Vector3.down * this.fallDelta, Space.World);
			}
			yield return null;
		}
		this.IsFalling = false;
		this.fallDelta = 0f;
		if (!this.isBroken)
		{
			this.Settle();
		}
		yield break;
	}

	// Token: 0x06000448 RID: 1096 RVA: 0x00013CEC File Offset: 0x00011EEC
	public bool CrateCheck(out Crate crate)
	{
		RaycastHit raycastHit;
		if (Physics.Raycast(this.ColliderCenter, Vector3.up, out raycastHit, 1f, 1, QueryTriggerInteraction.Ignore) && raycastHit.collider.TryGetComponent<Crate>(out crate) && !crate.isBroken && !crate.IsFalling)
		{
			return true;
		}
		crate = null;
		return false;
	}

	// Token: 0x06000449 RID: 1097 RVA: 0x00013D3C File Offset: 0x00011F3C
	public override void ResetEntity()
	{
		if (this.isBroken)
		{
			if (this.AddsToBoxCount && Level.instance)
			{
				Level.instance.RemoveCrateCollected(this);
			}
			if (this.AddsToBoxCount && LevelInterfaceManager.instance)
			{
				LevelInterfaceManager.instance.RemoveCrateCollected(this);
			}
		}
		this.visual.SetActive(true);
		this.coll.enabled = true;
		this.isBroken = false;
		this.IsFalling = false;
		base.ResetEntity();
		if (this.startAsOutlineCrate)
		{
			this.SetOutlineMode();
		}
	}

	// Token: 0x0600044A RID: 1098 RVA: 0x00013DC9 File Offset: 0x00011FC9
	public Vector3 GetNextPosition()
	{
		return base.transform.position + Vector3.down * this.fallDelta;
	}

	// Token: 0x0600044B RID: 1099 RVA: 0x00013DEB File Offset: 0x00011FEB
	public void GetDelta(Transform tf, out Vector3 positionDelta)
	{
		positionDelta = Vector3.down * this.fallDelta;
	}

	// Token: 0x0600044C RID: 1100 RVA: 0x00013E03 File Offset: 0x00012003
	public virtual void OnEnter(Transform tf)
	{
	}

	// Token: 0x0600044D RID: 1101 RVA: 0x00013E05 File Offset: 0x00012005
	public virtual void OnExit(Transform tf)
	{
	}

	// Token: 0x0600044E RID: 1102 RVA: 0x00013E07 File Offset: 0x00012007
	public void ProcessMetadata(CanFallMetadata meta)
	{
		this.CanFall = meta.value;
	}

	// Token: 0x040002F6 RID: 758
	public BoxCollider coll;

	// Token: 0x040002F7 RID: 759
	public Color brokenBoxCol = Color.white;

	// Token: 0x040002FA RID: 762
	private float fallDelta;

	// Token: 0x040002FB RID: 763
	private IEnumerator fallState;

	// Token: 0x040002FC RID: 764
	protected Vector3? _startPosition;

	// Token: 0x040002FD RID: 765
	public bool startAsOutlineCrate;

	// Token: 0x040002FE RID: 766
	public GameObject outlineVis;

	// Token: 0x040002FF RID: 767
	public bool isBroken;
}
