﻿using System;
using Cinemachine;
using UnityEngine;

// Token: 0x020000B1 RID: 177
public class ExamplePlayerCamera : MonoBehaviour
{
	// Token: 0x06000587 RID: 1415 RVA: 0x0001888A File Offset: 0x00016A8A
	private void Start()
	{
		this._orientation = 0;
	}

	// Token: 0x06000588 RID: 1416 RVA: 0x00018894 File Offset: 0x00016A94
	private void Update()
	{
		this._playerForward = base.transform.forward;
		this._playerForward.Set(this._playerForward.x, 0f, this._playerForward.z);
		if (this._orientation != 1 && this.IsLookingForward())
		{
			this._orientation = 1;
			this.CameraForward.Priority = 2;
			this.CameraBackwards.Priority = 1;
			return;
		}
		if (this._orientation != -1 && this.IsLookingBackwards())
		{
			this._orientation = -1;
			this.CameraForward.Priority = 1;
			this.CameraBackwards.Priority = 2;
		}
	}

	// Token: 0x06000589 RID: 1417 RVA: 0x00018939 File Offset: 0x00016B39
	private bool IsLookingForward()
	{
		return Vector3.Dot(this._playerForward, this.MainCamera.transform.forward) > 0.1f;
	}

	// Token: 0x0600058A RID: 1418 RVA: 0x0001895D File Offset: 0x00016B5D
	private bool IsLookingBackwards()
	{
		return Vector3.Dot(this._playerForward, this.MainCamera.transform.forward) <= -0.1f;
	}

	// Token: 0x040003E8 RID: 1000
	[SerializeField]
	private GameObject MainCamera;

	// Token: 0x040003E9 RID: 1001
	[SerializeField]
	private CinemachineVirtualCamera CameraForward;

	// Token: 0x040003EA RID: 1002
	[SerializeField]
	private CinemachineVirtualCamera CameraBackwards;

	// Token: 0x040003EB RID: 1003
	private Vector3 _playerForward;

	// Token: 0x040003EC RID: 1004
	private int _orientation;
}
