﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000085 RID: 133
public static class CollisionMask
{
	// Token: 0x17000099 RID: 153
	// (get) Token: 0x060003AD RID: 941 RVA: 0x0000F8E0 File Offset: 0x0000DAE0
	private static Dictionary<int, int> Masks { get; } = new Dictionary<int, int>();

	// Token: 0x1700009A RID: 154
	// (get) Token: 0x060003AE RID: 942 RVA: 0x0000F8E7 File Offset: 0x0000DAE7
	private static Dictionary<string, int> MaskNames { get; } = new Dictionary<string, int>();

	// Token: 0x060003AF RID: 943 RVA: 0x0000F8F0 File Offset: 0x0000DAF0
	public static int Get(int layer)
	{
		int num;
		if (!CollisionMask.Masks.TryGetValue(layer, out num))
		{
			num = -1;
			for (int i = 0; i < 32; i++)
			{
				if (Physics.GetIgnoreLayerCollision(layer, i))
				{
					num ^= 1 << i;
				}
			}
			CollisionMask.Masks[layer] = num;
		}
		return num;
	}

	// Token: 0x060003B0 RID: 944 RVA: 0x0000F93C File Offset: 0x0000DB3C
	public static int Get(string layerName)
	{
		int num;
		if (!CollisionMask.MaskNames.TryGetValue(layerName, out num))
		{
			num = LayerMask.NameToLayer(layerName);
			CollisionMask.MaskNames[layerName] = num;
		}
		return CollisionMask.Get(num);
	}
}
