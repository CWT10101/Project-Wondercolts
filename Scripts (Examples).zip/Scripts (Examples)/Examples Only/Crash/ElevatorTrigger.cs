﻿using System;
using UnityEngine;

// Token: 0x020000A8 RID: 168
public class ElevatorTrigger : MonoBehaviour
{
	// Token: 0x0600052B RID: 1323 RVA: 0x00017099 File Offset: 0x00015299
	private void OnDisable()
	{
		this.active = false;
	}

	// Token: 0x0600052C RID: 1324 RVA: 0x000170A4 File Offset: 0x000152A4
	private void FixedUpdate()
	{
		CrashController instance = CrashController.instance;
		if (instance != null)
		{
			if (this.trigger.ClosestPoint(instance.transform.position) == instance.transform.position)
			{
				if (this.active)
				{
					if (this.goUp)
					{
						this.platform.GoUp();
						return;
					}
					this.platform.GoDown();
					return;
				}
			}
			else if (!this.active)
			{
				this.active = true;
			}
		}
	}

	// Token: 0x040003A6 RID: 934
	public ElevatorPlatform platform;

	// Token: 0x040003A7 RID: 935
	public Collider trigger;

	// Token: 0x040003A8 RID: 936
	public bool goUp;

	// Token: 0x040003A9 RID: 937
	private bool active;
}
