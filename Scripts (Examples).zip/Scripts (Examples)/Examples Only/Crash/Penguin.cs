﻿using System;
using UnityEngine;

// Token: 0x020000F6 RID: 246
public class Penguin : BasicEnemy
{
	// Token: 0x170000F9 RID: 249
	// (get) Token: 0x06000791 RID: 1937 RVA: 0x000200B3 File Offset: 0x0001E2B3
	// (set) Token: 0x06000792 RID: 1938 RVA: 0x000200BC File Offset: 0x0001E2BC
	public bool IsSpinning
	{
		get
		{
			return this._spinning;
		}
		set
		{
			if (this._spinning != value)
			{
				base.OnSlide = (base.OnSpin = (value ? Enemy.InteractionResponse.HurtCrash : Enemy.InteractionResponse.DieSpin));
				this._spinning = value;
			}
		}
	}

	// Token: 0x06000793 RID: 1939 RVA: 0x000200EF File Offset: 0x0001E2EF
	protected override void Awake()
	{
		base.Awake();
		this._cachedSpeed = this.speed;
	}

	// Token: 0x06000794 RID: 1940 RVA: 0x00020104 File Offset: 0x0001E304
	protected override void FixedUpdate()
	{
		if (this.isDead)
		{
			return;
		}
		base.FixedUpdate();
		if (!this.IsSpinning)
		{
			if (this.timer < this.stateLength)
			{
				this.timer += Time.deltaTime;
				return;
			}
			this.StartSpinning();
			this.timer -= this.stateLength;
		}
	}

	// Token: 0x06000795 RID: 1941 RVA: 0x00020162 File Offset: 0x0001E362
	public override void ResetEntity()
	{
		base.ResetEntity();
		this.IsSpinning = false;
		if (this.speed == 0f)
		{
			this.speed = this._cachedSpeed;
		}
		this.timer = 0f;
	}

	// Token: 0x06000796 RID: 1942 RVA: 0x00020198 File Offset: 0x0001E398
	public void StartSpinning()
	{
		this.IsSpinning = true;
		this.animator.SetTrigger("Spin");
		AudioManager.Play("SFX_PenguinSpin", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		this.speed = 0f;
	}

	// Token: 0x06000797 RID: 1943 RVA: 0x000201EC File Offset: 0x0001E3EC
	public void StopSpinning()
	{
		this.IsSpinning = false;
	}

	// Token: 0x06000798 RID: 1944 RVA: 0x000201F8 File Offset: 0x0001E3F8
	public void ShakeHead()
	{
		AudioManager.Play("SFX_PenguinShake", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
	}

	// Token: 0x06000799 RID: 1945 RVA: 0x0002022A File Offset: 0x0001E42A
	public void RecoverFromSpin()
	{
		this.speed = this._cachedSpeed;
	}

	// Token: 0x040005A1 RID: 1441
	private bool _spinning;

	// Token: 0x040005A2 RID: 1442
	private float timer;

	// Token: 0x040005A3 RID: 1443
	public float stateLength = 3f;

	// Token: 0x040005A4 RID: 1444
	private float _cachedSpeed;
}
