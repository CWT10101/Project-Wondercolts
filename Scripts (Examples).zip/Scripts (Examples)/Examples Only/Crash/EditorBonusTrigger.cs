﻿using System;
using LevelEditor;
using UnityEngine;

// Token: 0x020000A5 RID: 165
public class EditorBonusTrigger : BlockTrigger
{
	// Token: 0x06000513 RID: 1299 RVA: 0x000168B5 File Offset: 0x00014AB5
	public override void Triggered()
	{
		base.Triggered();
		this.SetBonus(this.EnableBonus);
	}

	// Token: 0x06000514 RID: 1300 RVA: 0x000168C9 File Offset: 0x00014AC9
	private void OnDisable()
	{
		this.SetBonus(false);
		EditorBonusTrigger.endedBonus = false;
		EditorBonusTrigger.routineRunning = false;
		BonusManager.instance.ShowBonusUI(false);
	}

	// Token: 0x06000515 RID: 1301 RVA: 0x000168EC File Offset: 0x00014AEC
	public void SetBonus(bool inBonus)
	{
		if (EditorBonusTrigger.routineRunning)
		{
			return;
		}
		if (!BonusManager.instance.bonusComplete)
		{
			BonusManager.instance.ResetBonusCrates();
			BonusManager.instance.inBonus = inBonus;
			CrashController.instance.inBonus = inBonus;
			if (inBonus)
			{
				InterfaceManager.instance.bonusCrateCount.text = string.Format("{0:00}/{1:00}", LevelInterfaceManager.instance.boxesCollected, LevelInterfaceManager.instance.maxBoxCount);
				BonusManager.instance.ShowBonusUI(true);
			}
			else if (!this.EnableBonus && base.isActiveAndEnabled)
			{
				EditorBonusTrigger.<>c__DisplayClass5_0 CS$<>8__locals1 = new EditorBonusTrigger.<>c__DisplayClass5_0();
				CS$<>8__locals1.pickups = CrashController.instance.pickupHandler;
				BonusManager.instance.AwardBonusPickups(0.1f);
				BonusManager.instance.bonusComplete = true;
				EditorBonusTrigger.routineRunning = true;
				base.StartCoroutine(CS$<>8__locals1.<SetBonus>g__ArbitraryPause|0());
			}
			else
			{
				BonusManager.instance.ShowBonusUI(false);
			}
		}
		else
		{
			BonusManager.instance.ShowBonusUI(false);
		}
		Debug.Log(string.Format("Set Bonus UI Called ({0} was passed in), the result was:{1}", inBonus, InterfaceManager.instance.bonusUI.activeSelf));
	}

	// Token: 0x04000394 RID: 916
	public bool EnableBonus = true;

	// Token: 0x04000395 RID: 917
	public static bool endedBonus;

	// Token: 0x04000396 RID: 918
	public static bool routineRunning;
}
