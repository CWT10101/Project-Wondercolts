﻿using System;
using UnityEngine;

// Token: 0x02000083 RID: 131
public static class Clock
{
	// Token: 0x17000098 RID: 152
	// (get) Token: 0x060003A3 RID: 931 RVA: 0x0000F7A9 File Offset: 0x0000D9A9
	public static float SynchronizedTime
	{
		get
		{
			return Time.timeSinceLevelLoad - Clock._crashSpawnTime;
		}
	}

	// Token: 0x060003A4 RID: 932 RVA: 0x0000F7B6 File Offset: 0x0000D9B6
	public static void SetCrashSpawnTime()
	{
		Clock._crashSpawnTime = Time.timeSinceLevelLoad;
	}

	// Token: 0x060003A5 RID: 933 RVA: 0x0000F7C2 File Offset: 0x0000D9C2
	public static void SetTimeScale(float value)
	{
		Time.timeScale = value;
		Clock.TimeScale = value;
	}

	// Token: 0x060003A6 RID: 934 RVA: 0x0000F7D0 File Offset: 0x0000D9D0
	public static void ResetTimeScale()
	{
		Clock.SetTimeScale(1f);
	}

	// Token: 0x0400026B RID: 619
	private static float _crashSpawnTime = 0f;

	// Token: 0x0400026C RID: 620
	public static float TimeScale = 1f;
}
