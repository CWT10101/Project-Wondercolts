﻿using System;
using System.IO;
using LevelEditor;

// Token: 0x0200002A RID: 42
public class KongQuickThrowMetadata : ObjectMetadata
{
	// Token: 0x1700002B RID: 43
	// (get) Token: 0x060000FB RID: 251 RVA: 0x000062DA File Offset: 0x000044DA
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x060000FC RID: 252 RVA: 0x000062DD File Offset: 0x000044DD
	public override int Signature
	{
		get
		{
			return "KongQuickThrowMetadata".GetHashCode();
		}
	}

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x060000FD RID: 253 RVA: 0x000062E9 File Offset: 0x000044E9
	public override int ValueHash
	{
		get
		{
			if (!this.value)
			{
				return -1;
			}
			return 1;
		}
	}

	// Token: 0x060000FE RID: 254 RVA: 0x000062F8 File Offset: 0x000044F8
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<KongQuickThrowMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<KongQuickThrowMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x060000FF RID: 255 RVA: 0x00006324 File Offset: 0x00004524
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.value = br.ReadBoolean();
	}

	// Token: 0x06000100 RID: 256 RVA: 0x00006332 File Offset: 0x00004532
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.value);
	}

	// Token: 0x0400008E RID: 142
	public bool value;
}
