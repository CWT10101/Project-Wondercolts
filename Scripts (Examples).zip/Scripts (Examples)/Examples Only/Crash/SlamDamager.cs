﻿using System;
using UnityEngine;

// Token: 0x02000119 RID: 281
public class SlamDamager : MonoBehaviour
{
	// Token: 0x1700010D RID: 269
	// (get) Token: 0x06000894 RID: 2196 RVA: 0x00023E1B File Offset: 0x0002201B
	public CrashController Crash
	{
		get
		{
			if (this._crash == null)
			{
				this._crash = base.GetComponentInParent<CrashController>();
			}
			return this._crash;
		}
	}

	// Token: 0x06000895 RID: 2197 RVA: 0x00023E40 File Offset: 0x00022040
	private void OnTriggerEnter(Collider other)
	{
		ISlam slam;
		if (other.TryGetComponent<ISlam>(out slam))
		{
			slam.Slam(this.Crash);
		}
	}

	// Token: 0x06000896 RID: 2198 RVA: 0x00023E64 File Offset: 0x00022064
	private void OnCollisionEnter(Collision collision)
	{
		ISlam slam;
		if (collision.gameObject.TryGetComponent<ISlam>(out slam))
		{
			slam.Slam(this.Crash);
		}
	}

	// Token: 0x0400064B RID: 1611
	private CrashController _crash;
}
