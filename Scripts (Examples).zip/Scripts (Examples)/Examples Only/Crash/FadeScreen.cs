﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020000B4 RID: 180
public class FadeScreen : MonoBehaviour
{
	// Token: 0x06000594 RID: 1428 RVA: 0x00018B25 File Offset: 0x00016D25
	public void DisableObject()
	{
		base.gameObject.SetActive(false);
	}

	// Token: 0x06000595 RID: 1429 RVA: 0x00018B33 File Offset: 0x00016D33
	public void FadeToColour(Color col)
	{
		this.fadeImage.color = col;
		this.animator.gameObject.SetActive(true);
	}

	// Token: 0x06000596 RID: 1430 RVA: 0x00018B52 File Offset: 0x00016D52
	public void FadeToAlpha(Color col)
	{
		this.fadeImage.color = col;
		this.animator.SetTrigger("FadeOut");
	}

	// Token: 0x06000597 RID: 1431 RVA: 0x00018B70 File Offset: 0x00016D70
	public void FadeToAlpha()
	{
		this.animator.SetTrigger("FadeOut");
	}

	// Token: 0x06000598 RID: 1432 RVA: 0x00018B82 File Offset: 0x00016D82
	public void FulLFade(Color col, float length)
	{
		this.animator.gameObject.SetActive(true);
		base.StartCoroutine(this.FullFadeRoutine(col, length));
	}

	// Token: 0x06000599 RID: 1433 RVA: 0x00018BA4 File Offset: 0x00016DA4
	private IEnumerator FullFadeRoutine(Color col, float length)
	{
		this.FadeToColour(col);
		yield return new WaitForSeconds(length);
		this.FadeToAlpha();
		yield break;
	}

	// Token: 0x040003F4 RID: 1012
	public Image fadeImage;

	// Token: 0x040003F5 RID: 1013
	public Animator animator;
}
