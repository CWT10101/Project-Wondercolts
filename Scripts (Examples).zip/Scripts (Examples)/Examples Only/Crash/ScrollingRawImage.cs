﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000156 RID: 342
[RequireComponent(typeof(RawImage))]
public class ScrollingRawImage : MonoBehaviour
{
	// Token: 0x060009F2 RID: 2546 RVA: 0x00027E3A File Offset: 0x0002603A
	private void Awake()
	{
		this.rawImage = base.GetComponent<RawImage>();
	}

	// Token: 0x060009F3 RID: 2547 RVA: 0x00027E48 File Offset: 0x00026048
	private void Update()
	{
		this.xVal += Time.unscaledDeltaTime * this.xSpeed;
		this.yVal += Time.unscaledDeltaTime * this.ySpeed;
		this.rawImage.uvRect = new Rect(this.xVal, this.yVal, this.rawImage.uvRect.width, this.rawImage.uvRect.height);
	}

	// Token: 0x04000724 RID: 1828
	private RawImage rawImage;

	// Token: 0x04000725 RID: 1829
	public float xSpeed;

	// Token: 0x04000726 RID: 1830
	public float ySpeed;

	// Token: 0x04000727 RID: 1831
	private float xVal;

	// Token: 0x04000728 RID: 1832
	private float yVal;
}
