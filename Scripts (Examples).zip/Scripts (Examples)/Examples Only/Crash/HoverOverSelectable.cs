﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Token: 0x0200014E RID: 334
[RequireComponent(typeof(Selectable))]
public class HoverOverSelectable : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler, IPointerClickHandler
{
	// Token: 0x060009C2 RID: 2498 RVA: 0x000276BB File Offset: 0x000258BB
	private void Awake()
	{
		this.SetDefaultScale();
		this.selectable = base.GetComponent<Selectable>();
	}

	// Token: 0x060009C3 RID: 2499 RVA: 0x000276CF File Offset: 0x000258CF
	private void OnEnable()
	{
	}

	// Token: 0x060009C4 RID: 2500 RVA: 0x000276D1 File Offset: 0x000258D1
	public void SetDefaultScale()
	{
		this.defaultScale = Vector3.one;
	}

	// Token: 0x060009C5 RID: 2501 RVA: 0x000276E0 File Offset: 0x000258E0
	public Vector3 GetDefaultScale()
	{
		if (this.childText)
		{
			this.childText.font = InterfaceManager.instance.unselectedFont;
		}
		return base.transform.localScale = this.defaultScale;
	}

	// Token: 0x060009C6 RID: 2502 RVA: 0x00027723 File Offset: 0x00025923
	public Vector3 SetHoveredScale()
	{
		if (this.childText)
		{
			this.childText.font = InterfaceManager.instance.selectedFont;
		}
		return this.GetHoveredScale();
	}

	// Token: 0x060009C7 RID: 2503 RVA: 0x00027750 File Offset: 0x00025950
	public Vector3 GetHoveredScale()
	{
		return base.transform.localScale = this.hoveredScale;
	}

	// Token: 0x060009C8 RID: 2504 RVA: 0x00027771 File Offset: 0x00025971
	public void ListenerHovered()
	{
		this.SetHoveredScale();
	}

	// Token: 0x060009C9 RID: 2505 RVA: 0x0002777A File Offset: 0x0002597A
	public void ListenerDefault()
	{
		this.GetDefaultScale();
	}

	// Token: 0x060009CA RID: 2506 RVA: 0x00027783 File Offset: 0x00025983
	public void OnPointerClick(PointerEventData eventData)
	{
		base.transform.localScale = this.defaultScale;
	}

	// Token: 0x060009CB RID: 2507 RVA: 0x00027798 File Offset: 0x00025998
	public void OnPointerEnter(PointerEventData eventData)
	{
		if (this.selectable.IsInteractable())
		{
			this.isHovered = true;
			base.transform.localScale = this.SetHoveredScale();
		}
		ActionOnSelect actionOnSelect;
		if (base.TryGetComponent<ActionOnSelect>(out actionOnSelect) && this.selectable.IsInteractable())
		{
			actionOnSelect.OnSelect(null);
		}
	}

	// Token: 0x060009CC RID: 2508 RVA: 0x000277E8 File Offset: 0x000259E8
	public void OnPointerExit(PointerEventData eventData)
	{
		if (this.selectable.IsInteractable())
		{
			this.isHovered = false;
			base.transform.localScale = this.GetDefaultScale();
			ActionOnSelect actionOnSelect;
			if (base.TryGetComponent<ActionOnSelect>(out actionOnSelect))
			{
				actionOnSelect.OnDeselect(null);
			}
			if (this.childText)
			{
				this.childText.font = InterfaceManager.instance.unselectedFont;
			}
		}
	}

	// Token: 0x060009CD RID: 2509 RVA: 0x0002784D File Offset: 0x00025A4D
	private void OnDisable()
	{
		this.isHovered = false;
		base.transform.localScale = this.GetDefaultScale();
	}

	// Token: 0x04000714 RID: 1812
	public Vector3 hoveredScale = new Vector3(1.1f, 1.1f, 1.1f);

	// Token: 0x04000715 RID: 1813
	private Vector3 defaultScale;

	// Token: 0x04000716 RID: 1814
	[HideInInspector]
	public bool isHovered;

	// Token: 0x04000717 RID: 1815
	private Selectable selectable;

	// Token: 0x04000718 RID: 1816
	public TMP_Text childText;
}
