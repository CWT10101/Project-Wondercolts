﻿using System;
using UnityEngine;

// Token: 0x02000116 RID: 278
public class SiblingSetter : MonoBehaviour
{
	// Token: 0x06000884 RID: 2180 RVA: 0x00023CD7 File Offset: 0x00021ED7
	private void Awake()
	{
		this.SetSkin();
	}

	// Token: 0x06000885 RID: 2181 RVA: 0x00023CE0 File Offset: 0x00021EE0
	public void SetSkin()
	{
		GameObject[] array = this.bandicoots;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(false);
		}
		this.bandicoots[CrashAnimator.Skin].SetActive(true);
	}

	// Token: 0x04000648 RID: 1608
	public GameObject[] bandicoots;
}
