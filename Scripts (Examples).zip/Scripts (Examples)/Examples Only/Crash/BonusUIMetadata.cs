﻿using System;
using System.IO;
using LevelEditor;

// Token: 0x02000024 RID: 36
public class BonusUIMetadata : ObjectMetadata
{
	// Token: 0x17000015 RID: 21
	// (get) Token: 0x060000B9 RID: 185 RVA: 0x000059DC File Offset: 0x00003BDC
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x060000BA RID: 186 RVA: 0x000059DF File Offset: 0x00003BDF
	public override int Signature
	{
		get
		{
			return "BonusUIMetadata".GetHashCode();
		}
	}

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x060000BB RID: 187 RVA: 0x000059EB File Offset: 0x00003BEB
	public override int ValueHash
	{
		get
		{
			if (!this.value)
			{
				return -1;
			}
			return 1;
		}
	}

	// Token: 0x060000BC RID: 188 RVA: 0x000059F8 File Offset: 0x00003BF8
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<BonusUIMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<BonusUIMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x060000BD RID: 189 RVA: 0x00005A24 File Offset: 0x00003C24
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.value = br.ReadBoolean();
	}

	// Token: 0x060000BE RID: 190 RVA: 0x00005A32 File Offset: 0x00003C32
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.value);
	}

	// Token: 0x04000082 RID: 130
	public bool value;
}
