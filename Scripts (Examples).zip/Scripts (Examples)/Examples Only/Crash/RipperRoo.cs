﻿using System;
using UnityEngine;

// Token: 0x02000071 RID: 113
public class RipperRoo : CreatorBoss, IMetadataReceiver<ProjectileMetadata>
{
	// Token: 0x1700008A RID: 138
	// (get) Token: 0x0600031A RID: 794 RVA: 0x0000D764 File Offset: 0x0000B964
	public override IMover Mover
	{
		get
		{
			IMover result;
			if ((result = this._mover) == null)
			{
				result = (this._mover = base.gameObject.AddComponent<CCMover>().Init(this.cc, true));
			}
			return result;
		}
	}

	// Token: 0x1700008B RID: 139
	// (get) Token: 0x0600031B RID: 795 RVA: 0x0000D79C File Offset: 0x0000B99C
	public override BossPhase[] Phases
	{
		get
		{
			BossPhase[] result;
			if ((result = this._phases) == null)
			{
				result = (this._phases = this.CreatePhases(this.maxHPSetting));
			}
			return result;
		}
	}

	// Token: 0x1700008C RID: 140
	// (get) Token: 0x0600031C RID: 796 RVA: 0x0000D7C8 File Offset: 0x0000B9C8
	public override BossPhase FallbackPhase
	{
		get
		{
			BossPhase result;
			if ((result = this._fallbackPhase) == null)
			{
				result = (this._fallbackPhase = this.CreateFallbackPhase());
			}
			return result;
		}
	}

	// Token: 0x0600031D RID: 797 RVA: 0x0000D7F0 File Offset: 0x0000B9F0
	private BossPhase[] CreatePhases(int count)
	{
		BossPhase[] array = new BossPhase[count];
		for (int i = 0; i < count; i++)
		{
			array[i] = this.CreatePhase(i);
		}
		return array;
	}

	// Token: 0x0600031E RID: 798 RVA: 0x0000D81C File Offset: 0x0000BA1C
	private BossPhase CreatePhase(int phaseIndex)
	{
		return new BossPhase("Phase " + phaseIndex.ToString())
		{
			PhaseEnter = delegate(CreatorBoss self, BossPhase ctx)
			{
				if (phaseIndex == 0)
				{
					self.SetVelocity_X(this.startsFlipped ? this.movementSpeed : (-this.movementSpeed));
				}
			},
			PhaseExit = delegate(CreatorBoss self, BossPhase ctx)
			{
				this.SetVulnerableOff();
				this.isDangerous = false;
				if (!self.isDead)
				{
					this.animator.Play(this.animTakeDamage);
				}
				AudioManager.Play(this.hitSound, AudioManager.MixerTarget.SFX, new Vector3?(this.collider.bounds.center), null);
				AudioManager.Play(this.hurtSound, AudioManager.MixerTarget.SFX, new Vector3?(this.collider.bounds.center), null);
				this.SetVelocity(0f, 0f);
			},
			Evaluate = delegate(CreatorBoss self, BossPhase ctx)
			{
				if (self.Velocity.x != 0f)
				{
					this.transform.rotation = Quaternion.RotateTowards(this.transform.rotation, Quaternion.LookRotation(Vector3.right * Mathf.Sign(self.Velocity.x)), 720f * Time.fixedDeltaTime);
				}
				if (self.MoveResult.Grounded)
				{
					RipperRoo.HandleCrashCollision(self.MoveResult);
					if (this.IsAnimationState(this.animTakeDamage))
					{
						if (this.IsAnimationFinished())
						{
							this.Recover();
							return;
						}
					}
					else
					{
						if (this.IsAnimationState(this.animBounce))
						{
							this.animator.Play(this.animBounce, 0, 0f);
							this.bounceAudio.PlayAudio();
							this.TryPutTNT();
							self.SetVelocity_Y(this.bounceImpulse);
							return;
						}
						if (this.IsAnimationState(this.animDizzyEnd) && this.IsAnimationFinished())
						{
							this.Recover();
							return;
						}
					}
				}
				else
				{
					if (self.MoveResult.Wall)
					{
						RipperRoo.HandleCrashCollision(self.MoveResult);
						self.SetVelocity_X(-self.Velocity.x);
					}
					self.AddVelocity_Y(-this.gravityForce * Time.fixedDeltaTime);
				}
			}
		};
	}

	// Token: 0x0600031F RID: 799 RVA: 0x0000D890 File Offset: 0x0000BA90
	private static void HandleCrashCollision(IMover.MoveResult moveResult)
	{
		foreach (IMover.MoveHit moveHit in moveResult.Hits)
		{
			CrashController crashController;
			if (moveHit.Collider.TryGetComponent<CrashController>(out crashController))
			{
				crashController.TakeDamage(1);
				if (crashController.isDead)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000320 RID: 800 RVA: 0x0000D8DC File Offset: 0x0000BADC
	private BossPhase CreateFallbackPhase()
	{
		return new BossPhase("Fallback")
		{
			PhaseEnter = delegate(CreatorBoss self, BossPhase ctx)
			{
				this.animator.Play(this.animDefeated);
			},
			Evaluate = delegate(CreatorBoss self, BossPhase ctx)
			{
				if (self.MoveResult.Grounded)
				{
					if (self.Velocity != Vector2.zero)
					{
						self.SetVelocity(0f, 0f);
						return;
					}
				}
				else
				{
					self.AddVelocity_Y(-this.gravityForce * Time.fixedDeltaTime);
				}
			}
		};
	}

	// Token: 0x06000321 RID: 801 RVA: 0x0000D90C File Offset: 0x0000BB0C
	public override void TouchTop(CrashController crash)
	{
		crash.Bounce();
	}

	// Token: 0x06000322 RID: 802 RVA: 0x0000D914 File Offset: 0x0000BB14
	public void Recover()
	{
		this.wasHit = false;
		this.isDangerous = true;
		this.hitByExplosion = false;
		base.SetVelocity((base.transform.forward.x > 0f) ? this.movementSpeed : (-this.movementSpeed), this.bounceImpulse);
		this.animator.Play(this.animBounce, 0, 0f);
		this.bounceAudio.PlayAudio();
	}

	// Token: 0x06000323 RID: 803 RVA: 0x0000D98C File Offset: 0x0000BB8C
	private void TryPutTNT()
	{
		RaycastHit[] array = Physics.RaycastAll(base.transform.position, Vector3.down, 0.6f, 1, QueryTriggerInteraction.Ignore);
		if (array.Length == 0)
		{
			return;
		}
		foreach (RaycastHit raycastHit in array)
		{
			RooTNT rooTNT;
			if (raycastHit.collider.TryGetComponent<RooTNT>(out rooTNT))
			{
				return;
			}
		}
		RooTNT rooTNT2 = Object.Instantiate<RooTNT>(this.tntPrefabs[(int)this.tntPrefabIndex], new Vector3(Mathf.Round(base.transform.position.x), (float)((int)base.transform.position.y) - 0.5f, (float)((int)base.transform.position.z)), Quaternion.identity, LevelManager.instance.projectileHolder);
		if (this.lightTnt)
		{
			rooTNT2.Light(this.tntFuse);
		}
	}

	// Token: 0x06000324 RID: 804 RVA: 0x0000DA5F File Offset: 0x0000BC5F
	public override void ResetEntity()
	{
		base.ResetEntity();
		this._phases = null;
		this.hitByExplosion = false;
	}

	// Token: 0x06000325 RID: 805 RVA: 0x0000DA75 File Offset: 0x0000BC75
	protected override void OnEnable()
	{
		base.OnEnable();
		if (this.isDead)
		{
			this.animator.Play(this.animDefeated, 0, 1f);
		}
	}

	// Token: 0x06000326 RID: 806 RVA: 0x0000DA9C File Offset: 0x0000BC9C
	public override void Explode(Transform source)
	{
		if (base.IsAnimationState(this.animBounce) && !this.hitByExplosion)
		{
			this.hitByExplosion = true;
			base.SetVelocity(0f, 0f);
			this.animator.Play(this.animExplosionResponse, 0, 0f);
			AudioManager.Play(this.laughSound, AudioManager.MixerTarget.SFX, new Vector3?(this.collider.bounds.center), null);
		}
	}

	// Token: 0x06000327 RID: 807 RVA: 0x0000DB1C File Offset: 0x0000BD1C
	public void PlayDizzySFX()
	{
		AudioManager.Play(this.dizzySound, AudioManager.MixerTarget.SFX, new Vector3?(this.collider.bounds.center), null);
	}

	// Token: 0x06000328 RID: 808 RVA: 0x0000DB57 File Offset: 0x0000BD57
	public void ProcessMetadata(ProjectileMetadata meta)
	{
		this.tntPrefabIndex = meta.projectileIndex;
		this.lightTnt = !this.tntPrefabs[(int)this.tntPrefabIndex].InstantDetonation;
	}

	// Token: 0x040001E8 RID: 488
	[SerializeField]
	private RooTNT[] tntPrefabs;

	// Token: 0x040001E9 RID: 489
	[SerializeField]
	private CharacterController cc;

	// Token: 0x040001EA RID: 490
	[SerializeField]
	private PlayAudioSource bounceAudio;

	// Token: 0x040001EB RID: 491
	[SerializeField]
	private float movementSpeed = 1.5f;

	// Token: 0x040001EC RID: 492
	[SerializeField]
	private float bounceImpulse = 6.5f;

	// Token: 0x040001ED RID: 493
	[SerializeField]
	private float gravityForce = 10f;

	// Token: 0x040001EE RID: 494
	[SerializeField]
	private byte tntFuse = 9;

	// Token: 0x040001EF RID: 495
	[SerializeField]
	private bool lightTnt = true;

	// Token: 0x040001F0 RID: 496
	[SerializeField]
	private byte tntPrefabIndex;

	// Token: 0x040001F1 RID: 497
	private bool hitByExplosion;

	// Token: 0x040001F2 RID: 498
	[Header("Animations")]
	[SerializeField]
	private string animExplosionResponse = "ExplosionResponse";

	// Token: 0x040001F3 RID: 499
	[SerializeField]
	private string animExplosionImpact = "ExplosionImpact";

	// Token: 0x040001F4 RID: 500
	[SerializeField]
	private string animDizzyStart = "DizzyStart";

	// Token: 0x040001F5 RID: 501
	[SerializeField]
	private string animDizzyLoop = "DizzyLoop";

	// Token: 0x040001F6 RID: 502
	[SerializeField]
	private string animDizzyEnd = "DizzyEnd";

	// Token: 0x040001F7 RID: 503
	[SerializeField]
	private string animTakeDamage = "TakeDamage";

	// Token: 0x040001F8 RID: 504
	[SerializeField]
	private string animDefeated = "Defeated";

	// Token: 0x040001F9 RID: 505
	[SerializeField]
	private string animBounce = "Bounce";

	// Token: 0x040001FA RID: 506
	[Header("Sounds")]
	[SerializeField]
	private string hitSound = "SFX_RooPunch";

	// Token: 0x040001FB RID: 507
	[SerializeField]
	private string laughSound = "SFX_RooLaugh";

	// Token: 0x040001FC RID: 508
	[SerializeField]
	private string growlSound = "SFX_RooGrowl";

	// Token: 0x040001FD RID: 509
	[SerializeField]
	private string hurtSound = "SFX_RooHurt";

	// Token: 0x040001FE RID: 510
	[SerializeField]
	private string dizzySound = "SFX_RooDizzyBirds";

	// Token: 0x040001FF RID: 511
	private IMover _mover;

	// Token: 0x04000200 RID: 512
	private BossPhase[] _phases;

	// Token: 0x04000201 RID: 513
	private BossPhase _fallbackPhase;
}
