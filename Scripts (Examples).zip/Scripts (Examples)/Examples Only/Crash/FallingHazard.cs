﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x020000B6 RID: 182
public class FallingHazard : Entity
{
	// Token: 0x060005A5 RID: 1445 RVA: 0x00018D24 File Offset: 0x00016F24
	private void FixedUpdate()
	{
		if (this.fallState != null)
		{
			if (!this.fallState.MoveNext())
			{
				this.fallState = null;
				return;
			}
		}
		else
		{
			if (!Physics.Raycast(base.transform.position, Vector3.up, 1f, CollisionMask.Get(base.gameObject.layer), QueryTriggerInteraction.Ignore))
			{
				this.DoFall(true);
				return;
			}
			float distance = this.maxCastDistance;
			RaycastHit raycastHit;
			if (Physics.Raycast(base.transform.position, Vector3.down, out raycastHit, this.maxCastDistance, CollisionMask.Get(base.gameObject.layer), QueryTriggerInteraction.Ignore))
			{
				distance = raycastHit.distance;
			}
			Bounds bounds = new Bounds(new Vector3(base.transform.position.x, base.transform.position.y - distance / 2f, base.transform.position.z), new Vector3(this.boxCheckDiameter, distance, this.boxCheckDiameter));
			Vector3 vector = new Vector3(bounds.min.x, bounds.min.y, bounds.min.z);
			Vector3 vector2 = new Vector3(bounds.max.x, bounds.min.y, bounds.min.z);
			Vector3 vector3 = new Vector3(bounds.max.x, bounds.min.y, bounds.max.z);
			Vector3 vector4 = new Vector3(bounds.min.x, bounds.min.y, bounds.max.z);
			Debug.DrawLine(vector, vector2, Color.blue, Time.fixedDeltaTime);
			Debug.DrawLine(vector2, vector3, Color.red, Time.fixedDeltaTime);
			Debug.DrawLine(vector3, vector4, Color.yellow, Time.fixedDeltaTime);
			Debug.DrawLine(vector4, vector, Color.magenta, Time.fixedDeltaTime);
			Vector3 vector5 = new Vector3(bounds.min.x, bounds.max.y, bounds.min.z);
			Vector3 vector6 = new Vector3(bounds.max.x, bounds.max.y, bounds.min.z);
			Vector3 vector7 = new Vector3(bounds.max.x, bounds.max.y, bounds.max.z);
			Vector3 vector8 = new Vector3(bounds.min.x, bounds.max.y, bounds.max.z);
			Debug.DrawLine(vector5, vector6, Color.blue, Time.fixedDeltaTime);
			Debug.DrawLine(vector6, vector7, Color.red, Time.fixedDeltaTime);
			Debug.DrawLine(vector7, vector8, Color.yellow, Time.fixedDeltaTime);
			Debug.DrawLine(vector8, vector5, Color.magenta, Time.fixedDeltaTime);
			Debug.DrawLine(vector, vector5, Color.white, Time.fixedDeltaTime);
			Debug.DrawLine(vector2, vector6, Color.gray, Time.fixedDeltaTime);
			Debug.DrawLine(vector3, vector7, Color.green, Time.fixedDeltaTime);
			Debug.DrawLine(vector4, vector8, Color.cyan, Time.fixedDeltaTime);
			if (CrashController.instance.controller.bounds.Intersects(bounds))
			{
				this.DoFall(false);
			}
		}
	}

	// Token: 0x060005A6 RID: 1446 RVA: 0x00019076 File Offset: 0x00017276
	private void DoFall(bool instant = false)
	{
		if (this.fallState != null)
		{
			return;
		}
		this.TryPushToStack();
		this.fallState = this.Fall(instant);
	}

	// Token: 0x060005A7 RID: 1447 RVA: 0x00019094 File Offset: 0x00017294
	private IEnumerator Fall(bool instant)
	{
		float t;
		if (!instant)
		{
			if (this.animator)
			{
				this.animator.SetTrigger(this.prefallTriggerName);
			}
			AudioManager.Play(this.prefallAudio, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
			t = this.prefallDuration;
			while (t > 0f)
			{
				t -= Time.deltaTime;
				yield return null;
			}
		}
		this.falling = true;
		t = 0f;
		RaycastHit raycastHit;
		for (;;)
		{
			float num = Time.fixedDeltaTime * this.fallSpeed.Evaluate(t);
			t += Time.fixedDeltaTime;
			float num2 = Time.fixedDeltaTime * this.fallSpeed.Evaluate(t) + num;
			if (Physics.BoxCast(this.trigger.bounds.center + Vector3.up * num, this.trigger.bounds.extents, Vector3.down, out raycastHit, Quaternion.identity, num2, CollisionMask.Get(base.gameObject.layer), QueryTriggerInteraction.Ignore))
			{
				break;
			}
			base.transform.Translate(Vector3.down * num2, Space.World);
			yield return null;
		}
		base.transform.Translate(Vector3.down * raycastHit.distance, Space.World);
		CrashController componentInParent = raycastHit.collider.GetComponentInParent<CrashController>();
		TNTCrate tntcrate;
		if (componentInParent != null)
		{
			componentInParent.TakeDamage(this.deathEffectIndex);
		}
		else if (raycastHit.collider.TryGetComponent<TNTCrate>(out tntcrate) && this.shouldDestroyTNT)
		{
			tntcrate.Light();
		}
		this.Break();
		yield break;
		yield break;
	}

	// Token: 0x060005A8 RID: 1448 RVA: 0x000190AC File Offset: 0x000172AC
	private void Break()
	{
		if (this.breakPrefab)
		{
			Object.Instantiate<GameObject>(this.breakPrefab, base.transform.position, Quaternion.identity);
		}
		AudioManager.Play(this.breakAudio, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), new Vector2?(new Vector2(1f, 1.2f)));
		this.fallState = null;
		this.falling = false;
		base.DisableEntity();
		base.enabled = false;
	}

	// Token: 0x060005A9 RID: 1449 RVA: 0x0001912E File Offset: 0x0001732E
	public override void ResetEntity()
	{
		base.enabled = true;
		base.transform.localPosition = Vector3.zero;
		this.fallState = null;
		this.falling = false;
		base.ResetEntity();
	}

	// Token: 0x060005AA RID: 1450 RVA: 0x0001915C File Offset: 0x0001735C
	private void OnTriggerEnter(Collider other)
	{
		if (this.falling)
		{
			return;
		}
		CrashController componentInParent = other.GetComponentInParent<CrashController>();
		if (componentInParent != null)
		{
			componentInParent.TakeDamage(this.deathEffectIndex);
			this.Break();
		}
	}

	// Token: 0x040003FE RID: 1022
	public Animator animator;

	// Token: 0x040003FF RID: 1023
	public Collider trigger;

	// Token: 0x04000400 RID: 1024
	public GameObject breakPrefab;

	// Token: 0x04000401 RID: 1025
	public int deathEffectIndex;

	// Token: 0x04000402 RID: 1026
	public string prefallTriggerName = "Prefall";

	// Token: 0x04000403 RID: 1027
	public string prefallAudio = "SFX_IciclePrefall";

	// Token: 0x04000404 RID: 1028
	public string breakAudio = "SFX_IcicleBreak";

	// Token: 0x04000405 RID: 1029
	public float boxCheckDiameter = 2f;

	// Token: 0x04000406 RID: 1030
	public float maxCastDistance = 16f;

	// Token: 0x04000407 RID: 1031
	public float prefallDuration = 0.5f;

	// Token: 0x04000408 RID: 1032
	public AnimationCurve fallSpeed;

	// Token: 0x04000409 RID: 1033
	private IEnumerator fallState;

	// Token: 0x0400040A RID: 1034
	private bool falling;

	// Token: 0x0400040B RID: 1035
	public bool shouldDestroyTNT = true;
}
