﻿using System;
using LevelEditor;
using UnityEngine;

// Token: 0x0200013B RID: 315
public class TrialClockPickup : Pickup
{
	// Token: 0x0600095A RID: 2394 RVA: 0x0002628C File Offset: 0x0002448C
	public override void OnTriggerEnter(Collider other)
	{
		PickupHandler pickupHandler;
		if (other.TryGetComponent<PickupHandler>(out pickupHandler))
		{
			LevelInterfaceManager instance = LevelInterfaceManager.instance;
			if (instance != null)
			{
				instance.BeginTimeTrial();
			}
			this.Despawn();
		}
		base.OnTriggerEnter(other);
	}

	// Token: 0x0600095B RID: 2395 RVA: 0x000262BF File Offset: 0x000244BF
	public override void Spin(CrashController crash)
	{
	}
}
