﻿using System;
using UnityEngine;

// Token: 0x02000127 RID: 295
public class SpikedTurtle : BasicEnemy
{
	// Token: 0x060008D4 RID: 2260 RVA: 0x00024A29 File Offset: 0x00022C29
	protected override void Start()
	{
		if (this.speedRef == null)
		{
			this.speedRef = new float?(this.speed);
		}
		base.Start();
	}

	// Token: 0x060008D5 RID: 2261 RVA: 0x00024A50 File Offset: 0x00022C50
	public override void TouchTop(CrashController crash)
	{
		crash.Bounce();
		this.speed = 0f;
		if (!this.isFlipped)
		{
			this.isFlipped = true;
			this.animator.SetTrigger("Flip");
			AudioManager.Play("SFX_FlipTurtle", new Vector3?(base.transform.position), null);
		}
	}

	// Token: 0x060008D6 RID: 2262 RVA: 0x00024AB1 File Offset: 0x00022CB1
	public override void Spin(CrashController crash)
	{
		if (this.isFlipped)
		{
			this.SpinDeath(crash.transform);
			return;
		}
		base.Spin(crash);
	}

	// Token: 0x060008D7 RID: 2263 RVA: 0x00024AD0 File Offset: 0x00022CD0
	public override void ResetEntity()
	{
		if (this.speedRef == null)
		{
			this.speedRef = new float?(this.speed);
		}
		this.isFlipped = false;
		this.animator.SetTrigger("Reset");
		this.speed = this.speedRef.Value;
		base.ResetEntity();
	}

	// Token: 0x060008D8 RID: 2264 RVA: 0x00024B29 File Offset: 0x00022D29
	public override void Slide(CrashController crash)
	{
		if (this.isFlipped)
		{
			this.SpinDeath(crash.transform);
			return;
		}
		base.Slide(crash);
	}

	// Token: 0x060008D9 RID: 2265 RVA: 0x00024B47 File Offset: 0x00022D47
	public override void TouchSide(CrashController crash)
	{
		if (this.isFlipped)
		{
			return;
		}
		base.TouchSide(crash);
	}

	// Token: 0x060008DA RID: 2266 RVA: 0x00024B59 File Offset: 0x00022D59
	public override void TouchBottom(CrashController crash)
	{
		if (this.isFlipped)
		{
			return;
		}
		base.TouchBottom(crash);
	}

	// Token: 0x0400066F RID: 1647
	public bool isFlipped;

	// Token: 0x04000670 RID: 1648
	private float? speedRef;
}
