﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Cinemachine;
using LevelEditor;
using UnityEngine;

// Token: 0x0200008D RID: 141
public class CrashSpawner : MonoBehaviour
{
	// Token: 0x06000424 RID: 1060 RVA: 0x000134C6 File Offset: 0x000116C6
	private void Awake()
	{
		CrashSpawner.instance = this;
		this.startingPosition = this.crashSpawnPoint.position;
	}

	// Token: 0x06000425 RID: 1061 RVA: 0x000134DF File Offset: 0x000116DF
	private void Start()
	{
		if (this.spawnOnStart)
		{
			this.SpawnCrash();
		}
	}

	// Token: 0x06000426 RID: 1062 RVA: 0x000134F0 File Offset: 0x000116F0
	public void SpawnCrash()
	{
		CrashController crash = Object.Instantiate<CrashController>(ResourceManager.instance.crash, this.crashSpawnPoint.position, base.transform.rotation);
		if (CameraManager.instance)
		{
			CameraManager.instance.AssignTarget(crash);
		}
	}

	// Token: 0x06000427 RID: 1063 RVA: 0x0001353C File Offset: 0x0001173C
	public void MoveToSpawn(CrashController crash, Transform spawnPoint = null)
	{
		if (spawnPoint == null)
		{
			spawnPoint = this.crashSpawnPoint;
		}
		crash.controller.enabled = false;
		crash.transform.SetPositionAndRotation(spawnPoint.position, spawnPoint.rotation);
		crash.controller.enabled = true;
		CrashSpawner.ClearSpaceForCrash(crash);
	}

	// Token: 0x06000428 RID: 1064 RVA: 0x00013590 File Offset: 0x00011790
	private static void ClearSpaceForCrash(CrashController crash)
	{
		foreach (Crate crate in from c in Physics.OverlapBox(crash.controller.bounds.center, crash.controller.bounds.size * 0.49f, Quaternion.identity, 1, QueryTriggerInteraction.Ignore)
		select c.GetComponent<Crate>() into c
		where c
		select c)
		{
			crate.ForceBreak();
		}
	}

	// Token: 0x06000429 RID: 1065 RVA: 0x00013658 File Offset: 0x00011858
	public void RespawnCrash(CrashController crash, float lengthOfTime = 3f, Transform spawnPoint = null)
	{
		if (spawnPoint == null)
		{
			spawnPoint = this.crashSpawnPoint;
		}
		base.StartCoroutine(this.RespawnRoutine(crash, lengthOfTime, spawnPoint));
	}

	// Token: 0x0600042A RID: 1066 RVA: 0x0001367B File Offset: 0x0001187B
	private IEnumerator RespawnRoutine(CrashController crash, float time = 3f, Transform spawnPoint = null)
	{
		yield return new WaitForSeconds(time);
		InterfaceManager.instance.fadeScreen.FadeToColour(Color.black);
		yield return new WaitForSeconds(0.5f);
		SwitchCrate.RollbackSwitchState();
		if (LevelInterfaceManager.instance)
		{
			LevelInterfaceManager.instance.RecallWeatherRollback();
			LevelInterfaceManager.instance.RecallMusicRollback();
		}
		IEnumerator<Entity> enumerator = EntityTracker.PopCache();
		while (enumerator.MoveNext())
		{
			if (enumerator.Current)
			{
				enumerator.Current.ResetEntity();
			}
		}
		if (Level.instance)
		{
			Level.instance.gameObject.SetActive(false);
			Level.instance.gameObject.SetActive(true);
		}
		if (LevelManager.instance)
		{
			LevelManager.instance.levelObjectsHolder.gameObject.SetActive(false);
			LevelManager.instance.levelObjectsHolder.gameObject.SetActive(true);
			LevelManager.instance.projectileHolder.gameObject.SetActive(false);
			LevelManager.instance.projectileHolder.gameObject.SetActive(true);
			Physics.SyncTransforms();
			foreach (GameObject gameObject in LevelManager.instance.inSceneLevelObjects)
			{
				IPostEnable[] componentsInChildren = gameObject.GetComponentsInChildren<IPostEnable>();
				if (componentsInChildren != null)
				{
					IPostEnable[] array = componentsInChildren;
					for (int i = 0; i < array.Length; i++)
					{
						array[i].OnPostEnable();
					}
				}
			}
		}
		InterfaceManager.instance.hudTrack.SetKillsText();
		InterfaceManager.instance.bossUIHolder.SetActive(false);
		this.MoveToSpawn(crash, spawnPoint);
		crash.isInputLocked = false;
		crash.isDead = false;
		crash.controller.enabled = true;
		crash.ResetInternalState();
		Clock.SetCrashSpawnTime();
		yield return new WaitForSeconds(0.5f);
		if (Level.instance)
		{
			CinemachineBrain component = Camera.main.GetComponent<CinemachineBrain>();
			component.enabled = false;
			component.enabled = true;
		}
		InterfaceManager.instance.fadeScreen.FadeToAlpha();
		if (SaveData.Info.lives < 2 && Level.instance != null)
		{
			this.SpawnAkuAku(crash, spawnPoint, true, 1);
		}
		yield break;
	}

	// Token: 0x0600042B RID: 1067 RVA: 0x000136A0 File Offset: 0x000118A0
	public void SpawnAkuAku(CrashController crash, Transform spawnPoint, bool SFX = true, int hitCounter = 1)
	{
		Aku aku = Object.Instantiate<Aku>(ResourceManager.instance.aku, spawnPoint.transform.position + new Vector3(0f, 1f, 0f), Quaternion.identity);
		aku.SetTarget(crash.transform);
		aku.collider.enabled = false;
		if (SFX)
		{
			AudioManager.Play(aku.pickupSFX, AudioManager.MixerTarget.SFX, null, null);
		}
		crash.pickupHandler.CollectAku(aku);
		if (hitCounter > 1)
		{
			aku.Upgrade(false);
		}
	}

	// Token: 0x040002F1 RID: 753
	public static CrashSpawner instance;

	// Token: 0x040002F2 RID: 754
	public bool spawnOnStart = true;

	// Token: 0x040002F3 RID: 755
	public Transform crashSpawnPoint;

	// Token: 0x040002F4 RID: 756
	public Vector3 startingPosition = new Vector3(0f, 0.5f, 0f);
}
