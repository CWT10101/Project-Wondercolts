﻿using System;

// Token: 0x02000067 RID: 103
public class BossPhase
{
	// Token: 0x0600028E RID: 654 RVA: 0x0000B4D8 File Offset: 0x000096D8
	public BossPhase(string name)
	{
		this.Name = name;
	}

	// Token: 0x1700006E RID: 110
	// (get) Token: 0x0600028F RID: 655 RVA: 0x0000B4E7 File Offset: 0x000096E7
	public string Name { get; }

	// Token: 0x1700006F RID: 111
	// (get) Token: 0x06000290 RID: 656 RVA: 0x0000B4EF File Offset: 0x000096EF
	// (set) Token: 0x06000291 RID: 657 RVA: 0x0000B4F7 File Offset: 0x000096F7
	public BossPhase.EvalFunc PhaseEnter { get; set; }

	// Token: 0x17000070 RID: 112
	// (get) Token: 0x06000292 RID: 658 RVA: 0x0000B500 File Offset: 0x00009700
	// (set) Token: 0x06000293 RID: 659 RVA: 0x0000B508 File Offset: 0x00009708
	public BossPhase.EvalFunc Evaluate { get; set; }

	// Token: 0x17000071 RID: 113
	// (get) Token: 0x06000294 RID: 660 RVA: 0x0000B511 File Offset: 0x00009711
	// (set) Token: 0x06000295 RID: 661 RVA: 0x0000B519 File Offset: 0x00009719
	public BossPhase.EvalFunc PhaseExit { get; set; }

	// Token: 0x06000296 RID: 662 RVA: 0x0000B522 File Offset: 0x00009722
	public override string ToString()
	{
		return "[BossPhase] " + this.Name;
	}

	// Token: 0x020001EC RID: 492
	// (Invoke) Token: 0x0600129B RID: 4763
	public delegate void EvalFunc(CreatorBoss self, BossPhase ctx);
}
