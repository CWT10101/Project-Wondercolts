﻿using System;
using System.Collections;
using LevelEditor3D;
using UnityEngine;

// Token: 0x0200000B RID: 11
public class EditorLevelTrigger3D : MonoBehaviour
{
	// Token: 0x0600002E RID: 46 RVA: 0x000030C4 File Offset: 0x000012C4
	private void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController) && !this.isTriggered)
		{
			crashController.enabled = false;
			if (!string.IsNullOrEmpty(this.crashAnimState))
			{
				Transform transform = crashController.animator.transform.GetChild(0).Find(this.crashAnimState);
				if (transform)
				{
					Debug.Log(transform, transform);
					crashController.animator.SetState(transform.gameObject, false);
				}
				else
				{
					Debug.LogWarning("Didn't find " + this.crashAnimState);
				}
			}
			this.Trigger();
		}
	}

	// Token: 0x0600002F RID: 47 RVA: 0x00003154 File Offset: 0x00001354
	public void Trigger()
	{
		AudioManager.Play("SFX_WarpAreaTriggered", new Vector3?(base.transform.position), null);
		if (CrashController.instance.pickupHandler.currentMask != null)
		{
			CrashController.instance.pickupHandler.LoseMask(true);
		}
		base.StartCoroutine(this.WaitAndLoad());
	}

	// Token: 0x06000030 RID: 48 RVA: 0x000031B9 File Offset: 0x000013B9
	private IEnumerator WaitAndLoad()
	{
		yield return new WaitForSeconds(this.waitTime);
		CrashSpawner.instance.MoveToSpawn(CrashController.instance, null);
		LevelInterfaceManager3D.Instance.ToggleEditMode();
		yield break;
	}

	// Token: 0x0400002B RID: 43
	public float waitTime = 1f;

	// Token: 0x0400002C RID: 44
	public string crashAnimState = "";

	// Token: 0x0400002D RID: 45
	private bool isTriggered;
}
