﻿using System;
using UnityEngine;

// Token: 0x020000C3 RID: 195
public class HomingProjectile : Projectile
{
	// Token: 0x060005EA RID: 1514 RVA: 0x00019ED3 File Offset: 0x000180D3
	private void Start()
	{
		this.timeSpawned = Clock.SynchronizedTime;
	}

	// Token: 0x060005EB RID: 1515 RVA: 0x00019EE0 File Offset: 0x000180E0
	protected override void FixedUpdate()
	{
		base.FixedUpdate();
		if (this.is2d)
		{
			Vector3 vector = Vector3.RotateTowards(base.transform.forward, CrashController.instance.controller.bounds.center - base.transform.position, 3.1415927f * this.homingRate * Time.fixedDeltaTime, 0f);
			base.transform.rotation = Quaternion.LookRotation(vector, Vector3.Cross(vector, Vector3.forward));
			return;
		}
		Quaternion to = Quaternion.LookRotation(CrashController.instance.controller.bounds.center - base.transform.position);
		base.transform.rotation = Quaternion.RotateTowards(base.transform.rotation, to, 180f * this.homingRate * Time.fixedDeltaTime);
	}

	// Token: 0x0400044D RID: 1101
	public float homingRate = 1f;

	// Token: 0x0400044E RID: 1102
	public bool is2d = true;
}
