﻿using System;
using System.Collections.Generic;

// Token: 0x02000097 RID: 151
public interface IDBDescriptor<T>
{
	// Token: 0x170000BD RID: 189
	// (get) Token: 0x0600048D RID: 1165
	T Value { get; }

	// Token: 0x170000BE RID: 190
	// (get) Token: 0x0600048E RID: 1166
	string Name { get; }

	// Token: 0x170000BF RID: 191
	// (get) Token: 0x0600048F RID: 1167
	HashSet<string> Tags { get; }

	// Token: 0x170000C0 RID: 192
	// (get) Token: 0x06000490 RID: 1168
	bool IsSecret { get; }
}
