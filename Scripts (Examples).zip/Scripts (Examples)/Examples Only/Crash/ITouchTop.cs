﻿using System;

// Token: 0x020000D1 RID: 209
public interface ITouchTop
{
	// Token: 0x0600061D RID: 1565
	void TouchTop(CrashController crash);
}
