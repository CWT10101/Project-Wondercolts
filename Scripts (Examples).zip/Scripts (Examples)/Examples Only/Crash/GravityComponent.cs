﻿using System;
using UnityEngine;

// Token: 0x020000C0 RID: 192
public class GravityComponent : MonoBehaviour
{
	// Token: 0x060005DE RID: 1502 RVA: 0x00019D98 File Offset: 0x00017F98
	private void FixedUpdate()
	{
		if (this.gravity != 0f)
		{
			if (this.controller.isGrounded)
			{
				this.fallMomentum = -1f;
			}
			else
			{
				this.fallMomentum += this.gravity * Time.deltaTime;
			}
		}
		Vector3 a = new Vector3(0f, this.fallMomentum, 0f);
		this.controller.Move(a * Time.deltaTime);
	}

	// Token: 0x04000447 RID: 1095
	[SerializeField]
	private float gravity = -10f;

	// Token: 0x04000448 RID: 1096
	public float fallMomentum;

	// Token: 0x04000449 RID: 1097
	public CharacterController controller;
}
