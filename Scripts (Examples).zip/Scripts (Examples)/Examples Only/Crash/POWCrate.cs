﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using LevelEditor;
using UnityEngine;

// Token: 0x020000FD RID: 253
public class POWCrate : TNTCrate
{
	// Token: 0x060007CE RID: 1998 RVA: 0x000212DB File Offset: 0x0001F4DB
	public override void FallOn(CrashController crash)
	{
		if (crash != null)
		{
			crash.Bounce();
		}
		this.Light();
	}

	// Token: 0x060007CF RID: 1999 RVA: 0x000212F2 File Offset: 0x0001F4F2
	public override void TouchBottom(CrashController crash)
	{
		this.Light();
	}

	// Token: 0x060007D0 RID: 2000 RVA: 0x000212FA File Offset: 0x0001F4FA
	public override void Slide(CrashController crash)
	{
		if (!base.IsAbove(crash))
		{
			this.Light();
		}
	}

	// Token: 0x060007D1 RID: 2001 RVA: 0x0002130B File Offset: 0x0001F50B
	protected override void Settle()
	{
		this.Light();
	}

	// Token: 0x060007D2 RID: 2002 RVA: 0x00021313 File Offset: 0x0001F513
	public override void Light()
	{
		if (!this.lit)
		{
			this.lit = true;
			base.StartCoroutine(this.<Light>g__LightRoutine|4_0());
		}
	}

	// Token: 0x060007D3 RID: 2003 RVA: 0x00021334 File Offset: 0x0001F534
	public override void Explode()
	{
		this.countdownAnimator.SetTrigger("reset");
		if (this.isBroken)
		{
			Debug.LogWarning("Trying to break a broken box");
			return;
		}
		this.isBroken = true;
		this.TryPushToStack();
		this.coll.enabled = false;
		BrokenCrate brokenCrate = Object.Instantiate<BrokenCrate>(ResourceManager.instance.brokenCrate, base.transform.position, base.transform.rotation);
		brokenCrate.crateCol = this.brokenBoxCol;
		brokenCrate.SetColour(this.brokenBoxCol);
		if (this.AddsToBoxCount && Level.instance != null)
		{
			Level.instance.AddCrateCollected(this);
		}
		if (this.AddsToBoxCount && LevelInterfaceManager.instance != null)
		{
			LevelInterfaceManager.instance.AddCrateCollected(this);
		}
		this.visual.SetActive(false);
		Crate crate;
		if (base.CrateCheck(out crate))
		{
			crate.Fall(0f);
		}
		this.coll.enabled = false;
		Collider[] array = Physics.OverlapSphere(base.transform.position + new Vector3(0f, 0.5f, 0f), this.explosionRadius);
		for (int i = 0; i < array.Length; i++)
		{
			Enemy enemy;
			if (array[i].TryGetComponent<Enemy>(out enemy))
			{
				enemy.Explode(base.transform);
			}
		}
		this.spawnedExplosion = Object.Instantiate<Explosion>(this.explosion, base.ColliderCenter, Quaternion.identity);
		this.spawnedExplosion.size = this.explosionRadius;
		if (this.explosionEffect)
		{
			Object.Instantiate<GameObject>(this.explosionEffect, base.transform.position, Quaternion.identity);
		}
		this.lit = false;
	}

	// Token: 0x060007D5 RID: 2005 RVA: 0x000214E1 File Offset: 0x0001F6E1
	[CompilerGenerated]
	private IEnumerator <Light>g__LightRoutine|4_0()
	{
		yield return new WaitForSeconds(0.1f);
		this.Explode();
		yield break;
	}
}
