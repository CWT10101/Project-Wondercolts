﻿using System;
using UnityEngine;

// Token: 0x0200001A RID: 26
public class EditorStateVisual : MonoBehaviour, IMetadataReceiver<StateMetadata>
{
	// Token: 0x1700000A RID: 10
	// (get) Token: 0x06000069 RID: 105 RVA: 0x00003D45 File Offset: 0x00001F45
	// (set) Token: 0x0600006A RID: 106 RVA: 0x00003D4D File Offset: 0x00001F4D
	public SpriteRenderer Renderer { get; private set; }

	// Token: 0x1700000B RID: 11
	// (get) Token: 0x0600006B RID: 107 RVA: 0x00003D56 File Offset: 0x00001F56
	// (set) Token: 0x0600006C RID: 108 RVA: 0x00003D5E File Offset: 0x00001F5E
	public Sprite[] Visuals { get; private set; }

	// Token: 0x0600006D RID: 109 RVA: 0x00003D67 File Offset: 0x00001F67
	public void ProcessMetadata(StateMetadata meta)
	{
		this.Renderer.sprite = this.Visuals[(int)meta.state];
	}
}
