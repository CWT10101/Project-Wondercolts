﻿using System;
using UnityEngine;

// Token: 0x020000AC RID: 172
public class EnemyWithProjectile : BasicEnemy, IMetadataReceiver<SpeedMetadata>, IMetadataReceiver<ProjectileMetadata>
{
	// Token: 0x06000561 RID: 1377 RVA: 0x00018194 File Offset: 0x00016394
	protected override void FixedUpdate()
	{
		base.FixedUpdate();
		if (this.sightRange == -1)
		{
			return;
		}
		if (MathUtil.InRange(base.transform.position, CrashController.instance.transform.position, (float)this.sightRange))
		{
			this.animator.enabled = true;
			return;
		}
		this.animator.enabled = false;
	}

	// Token: 0x06000562 RID: 1378 RVA: 0x000181F4 File Offset: 0x000163F4
	public void SpawnProjectile()
	{
		if (this.isDead)
		{
			return;
		}
		Projectile p;
		if (Level.instance)
		{
			p = Object.Instantiate<Projectile>(this.projectilePrefab, this.spawnNode.position, this.spawnNode.rotation, Level.instance.transform);
		}
		else if (LevelManager.instance)
		{
			p = Object.Instantiate<Projectile>(this.projectilePrefab, this.spawnNode.position, this.spawnNode.rotation, LevelManager.instance.projectileHolder);
		}
		else
		{
			p = Object.Instantiate<Projectile>(this.projectilePrefab, this.spawnNode.position, this.spawnNode.rotation);
		}
		this.PostProcessProjectile(p);
		if (!string.IsNullOrEmpty(this.fireSFX))
		{
			AudioManager.Play(this.fireSFX, AudioManager.MixerTarget.SFX, new Vector3?(this.spawnNode.position), null);
		}
	}

	// Token: 0x06000563 RID: 1379 RVA: 0x000182DC File Offset: 0x000164DC
	public override void ProcessMetadata(SpeedMetadata meta)
	{
		float num = 0.5f;
		float num2 = 3f;
		this.animator.speed = (float)meta.speed / 5f * (num2 - num) + num;
	}

	// Token: 0x06000564 RID: 1380 RVA: 0x00018313 File Offset: 0x00016513
	protected virtual void PostProcessProjectile(Projectile p)
	{
	}

	// Token: 0x06000565 RID: 1381 RVA: 0x00018315 File Offset: 0x00016515
	public void ProcessMetadata(ProjectileMetadata meta)
	{
		this.projectilePrefab = this.potentialProjectiles[(int)meta.projectileIndex];
		if (this.projectilePreVisuals.Length != 0)
		{
			this.SetProjectilePrevisuals((int)meta.projectileIndex);
		}
	}

	// Token: 0x06000566 RID: 1382 RVA: 0x00018340 File Offset: 0x00016540
	private void SetProjectilePrevisuals(int index)
	{
		GameObject[] array = this.projectilePreVisuals;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(false);
		}
		this.projectilePreVisuals[index].SetActive(true);
	}

	// Token: 0x06000567 RID: 1383 RVA: 0x00018379 File Offset: 0x00016579
	private void OnDrawGizmosSelected()
	{
		if (this.sightRange != -1)
		{
			Gizmos.color = Color.yellow;
			Gizmos.DrawWireSphere(base.transform.position, (float)this.sightRange);
		}
	}

	// Token: 0x040003C7 RID: 967
	public Transform spawnNode;

	// Token: 0x040003C8 RID: 968
	public Projectile projectilePrefab;

	// Token: 0x040003C9 RID: 969
	public string fireSFX;

	// Token: 0x040003CA RID: 970
	public int sightRange = -1;

	// Token: 0x040003CB RID: 971
	public Projectile[] potentialProjectiles;

	// Token: 0x040003CC RID: 972
	public GameObject[] projectilePreVisuals;
}
