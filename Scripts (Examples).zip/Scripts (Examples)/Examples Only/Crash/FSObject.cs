﻿using System;

// Token: 0x02000014 RID: 20
public abstract class FSObject
{
	// Token: 0x17000007 RID: 7
	// (get) Token: 0x06000051 RID: 81 RVA: 0x0000378C File Offset: 0x0000198C
	public string Name { get; }

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x06000052 RID: 82 RVA: 0x00003794 File Offset: 0x00001994
	public FSFolder Folder { get; }

	// Token: 0x06000053 RID: 83 RVA: 0x0000379C File Offset: 0x0000199C
	protected FSObject(string name, FSFolder folder)
	{
		this.Name = name;
		this.Folder = folder;
	}

	// Token: 0x06000054 RID: 84 RVA: 0x000037B4 File Offset: 0x000019B4
	public string GetPath()
	{
		if (this.Folder == null)
		{
			return null;
		}
		string path = this.Folder.GetPath();
		if (path != null)
		{
			return path + "\\" + this.Name;
		}
		return this.Name;
	}
}
