﻿using System;
using UnityEngine;

// Token: 0x02000099 RID: 153
public class DeathEffectBridge : MonoBehaviour
{
	// Token: 0x06000498 RID: 1176 RVA: 0x00014CAA File Offset: 0x00012EAA
	public void DisableObject()
	{
		base.gameObject.SetActive(false);
	}
}
