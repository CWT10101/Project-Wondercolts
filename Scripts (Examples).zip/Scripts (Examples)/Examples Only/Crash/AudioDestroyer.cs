﻿using System;
using UnityEngine;

// Token: 0x02000148 RID: 328
public class AudioDestroyer : MonoBehaviour
{
	// Token: 0x060009B4 RID: 2484 RVA: 0x00027408 File Offset: 0x00025608
	private void Awake()
	{
		this.src = base.GetComponent<AudioSource>();
	}

	// Token: 0x060009B5 RID: 2485 RVA: 0x00027418 File Offset: 0x00025618
	private void Update()
	{
		if (this.src == null)
		{
			this.src = base.GetComponent<AudioSource>();
		}
		if (this.src.timeSamples == this.src.clip.samples || !this.src.isPlaying)
		{
			Object.Destroy(base.gameObject);
		}
	}

	// Token: 0x04000709 RID: 1801
	private AudioSource src;
}
