﻿using System;
using UnityEngine;

// Token: 0x02000065 RID: 101
public abstract class Boss : Enemy
{
	// Token: 0x06000281 RID: 641
	protected abstract void PerformLogic();

	// Token: 0x1700006D RID: 109
	// (get) Token: 0x06000282 RID: 642
	protected abstract BossPhase[] Phases { get; }

	// Token: 0x06000283 RID: 643 RVA: 0x0000B2F8 File Offset: 0x000094F8
	protected void LookTowardCrash(float degreesPerSecond, float dt = -1f)
	{
		if (dt == -1f)
		{
			dt = Time.deltaTime;
		}
		Quaternion to = Quaternion.LookRotation(Vector3.ProjectOnPlane(CrashController.instance.transform.position - base.transform.position, Vector3.up));
		base.transform.rotation = Quaternion.RotateTowards(base.transform.rotation, to, degreesPerSecond * dt);
	}

	// Token: 0x06000284 RID: 644 RVA: 0x0000B362 File Offset: 0x00009562
	protected void LookAtCrash()
	{
		this.LookTowardCrash(360f, 1f);
	}

	// Token: 0x06000285 RID: 645 RVA: 0x0000B374 File Offset: 0x00009574
	protected override void FixedUpdate()
	{
		this.PerformLogic();
	}

	// Token: 0x06000286 RID: 646 RVA: 0x0000B37C File Offset: 0x0000957C
	private void TakeDamage()
	{
		this.animator.SetTrigger("TakeDamage");
	}

	// Token: 0x06000287 RID: 647 RVA: 0x0000B38E File Offset: 0x0000958E
	protected override void OnEnable()
	{
		base.OnEnable();
		this.SetupHealthbar();
	}

	// Token: 0x06000288 RID: 648 RVA: 0x0000B39C File Offset: 0x0000959C
	public void SetupHealthbar()
	{
		Debug.LogWarning("Need to set the number of pieces in the healthbar to be dynamic based on this bosses HP count");
		InterfaceManager.instance.bossIcon.sprite = this.icon;
		UICornersGradient[] bossHP = InterfaceManager.instance.bossHP;
		for (int i = 0; i < bossHP.Length; i++)
		{
			bossHP[i].gameObject.SetActive(true);
		}
		InterfaceManager.instance.bossUIHolder.SetActive(true);
	}

	// Token: 0x06000289 RID: 649 RVA: 0x0000B400 File Offset: 0x00009600
	public void LoseHP()
	{
		this.currentHP--;
		for (int i = 0; i < InterfaceManager.instance.bossHP.Length; i++)
		{
			if (InterfaceManager.instance.bossHP[i].gameObject.activeSelf)
			{
				InterfaceManager.instance.bossHP[i].gameObject.SetActive(false);
			}
		}
		for (int j = 0; j < this.currentHP; j++)
		{
			InterfaceManager.instance.bossHP[j].gameObject.SetActive(true);
		}
		if (this.currentHP <= 0)
		{
			InterfaceManager.instance.bossIcon.gameObject.SetActive(false);
		}
	}

	// Token: 0x0600028A RID: 650 RVA: 0x0000B4A7 File Offset: 0x000096A7
	public override void ResetEntity()
	{
		base.ResetEntity();
	}

	// Token: 0x04000171 RID: 369
	public Sprite icon;

	// Token: 0x04000172 RID: 370
	public string bossName;

	// Token: 0x04000173 RID: 371
	public int currentHP = 3;
}
