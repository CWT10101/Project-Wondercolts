﻿using System;
using UnityEngine;

// Token: 0x020000E8 RID: 232
public class MultihitEnemy : BasicEnemy
{
	// Token: 0x170000F2 RID: 242
	// (get) Token: 0x06000716 RID: 1814 RVA: 0x0001E48D File Offset: 0x0001C68D
	public ref MultihitEnemy.Phase ActivePhase
	{
		get
		{
			return ref this.phases[this.activePhaseIndex];
		}
	}

	// Token: 0x06000717 RID: 1815 RVA: 0x0001E4A0 File Offset: 0x0001C6A0
	public override void TouchTop(CrashController crash)
	{
		this.SelectPhaseResponse(this.activePhaseIndex, this.ActivePhase.OnTouchTop, crash);
	}

	// Token: 0x06000718 RID: 1816 RVA: 0x0001E4BA File Offset: 0x0001C6BA
	public override void TouchSide(CrashController crash)
	{
		this.SelectPhaseResponse(this.activePhaseIndex, this.ActivePhase.OnTouchSide, crash);
	}

	// Token: 0x06000719 RID: 1817 RVA: 0x0001E4D4 File Offset: 0x0001C6D4
	public override void TouchBottom(CrashController crash)
	{
		this.SelectPhaseResponse(this.activePhaseIndex, this.ActivePhase.OnTouchBottom, crash);
	}

	// Token: 0x0600071A RID: 1818 RVA: 0x0001E4EE File Offset: 0x0001C6EE
	public override void Spin(CrashController crash)
	{
		this.SelectPhaseResponse(this.activePhaseIndex, this.ActivePhase.OnSpin, crash);
	}

	// Token: 0x0600071B RID: 1819 RVA: 0x0001E508 File Offset: 0x0001C708
	public override void Slam(CrashController crash)
	{
		this.SelectPhaseResponse(this.activePhaseIndex, this.ActivePhase.OnSlam, crash);
	}

	// Token: 0x0600071C RID: 1820 RVA: 0x0001E522 File Offset: 0x0001C722
	public override void Slide(CrashController crash)
	{
		this.SelectPhaseResponse(this.activePhaseIndex, this.ActivePhase.OnSlide, crash);
	}

	// Token: 0x0600071D RID: 1821 RVA: 0x0001E53C File Offset: 0x0001C73C
	private void SelectPhaseResponse(int phaseIndex, MultihitEnemy.Phase.InteractionResponse phaseResponse, CrashController crash)
	{
		if (this._iframes > 0)
		{
			return;
		}
		if (phaseResponse == (MultihitEnemy.Phase.InteractionResponse)0)
		{
			return;
		}
		if (phaseResponse.HasFlag(MultihitEnemy.Phase.InteractionResponse.Inherit))
		{
			this.SelectPhaseResponse(phaseIndex - 1, phaseResponse, crash);
		}
		if (phaseResponse.HasFlag(MultihitEnemy.Phase.InteractionResponse.NextPhase))
		{
			this.NextPhase();
		}
		if (phaseResponse.HasFlag(MultihitEnemy.Phase.InteractionResponse.HurtCrash) && !crash.TakeDamage(0))
		{
			this.Die(true);
		}
		if (phaseResponse.HasFlag(MultihitEnemy.Phase.InteractionResponse.BounceCrash))
		{
			crash.Bounce();
		}
		if (phaseResponse.HasFlag(MultihitEnemy.Phase.InteractionResponse.DeflectCrash))
		{
			crash.Deflect(base.transform);
		}
		if (phaseResponse.HasFlag(MultihitEnemy.Phase.InteractionResponse.DeflectSelf))
		{
			this.Deflect(crash.transform);
		}
		if (phaseResponse.HasFlag(MultihitEnemy.Phase.InteractionResponse.Die))
		{
			this.Die(crash);
		}
		if (phaseResponse.HasFlag(MultihitEnemy.Phase.InteractionResponse.DieSpin))
		{
			this.SpinDeath(crash.transform);
		}
	}

	// Token: 0x0600071E RID: 1822 RVA: 0x0001E650 File Offset: 0x0001C850
	private void Deflect(Transform other)
	{
		this.externalForce = Vector3.Scale(base.transform.position - other.position, new Vector3(1f, 0f, 1f)).normalized;
	}

	// Token: 0x0600071F RID: 1823 RVA: 0x0001E69A File Offset: 0x0001C89A
	protected void SetInitialPhase()
	{
		this.activePhaseIndex = 0;
		this.speed = this.ActivePhase.MovementSpeed;
	}

	// Token: 0x06000720 RID: 1824 RVA: 0x0001E6B4 File Offset: 0x0001C8B4
	public bool SetPhase(int index)
	{
		if (index < 0 || index >= this.phases.Length)
		{
			Debug.LogError(string.Format("Index out of range: {0}/{1}", index, this.phases.Length), base.gameObject);
			return false;
		}
		GameObject exitEffect = this.ActivePhase.ExitEffect;
		if (exitEffect != null && exitEffect != null)
		{
			Object.Instantiate<GameObject>(exitEffect, base.transform.position, base.transform.rotation);
		}
		if (!string.IsNullOrWhiteSpace(this.ActivePhase.HitSFX))
		{
			AudioManager.Play(this.ActivePhase.HitSFX, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		}
		this.activePhaseIndex = index;
		if (!string.IsNullOrWhiteSpace(this.ActivePhase.AnimationState))
		{
			this.animator.Play(this.ActivePhase.AnimationState);
		}
		this.speed = this.ActivePhase.MovementSpeed;
		if (this.ActivePhase.OnEntryBehavior != MultihitEnemy.Phase.EntryBehavior.Normal)
		{
			this._iframes = this.ActivePhase.IFrames;
			this.speed = 0f;
			if (this.ActivePhase.OnEntryBehavior != MultihitEnemy.Phase.EntryBehavior.Stun && this.ActivePhase.OnEntryBehavior == MultihitEnemy.Phase.EntryBehavior.Intangible)
			{
				base.gameObject.layer = LayerMask.NameToLayer("EntityCollide");
			}
		}
		else
		{
			this._iframes = 0;
		}
		return true;
	}

	// Token: 0x06000721 RID: 1825 RVA: 0x0001E810 File Offset: 0x0001CA10
	public void NextPhase()
	{
		if (!this.SetPhase(this.activePhaseIndex + 1))
		{
			this.BounceDeath(CrashController.instance);
		}
	}

	// Token: 0x06000722 RID: 1826 RVA: 0x0001E82D File Offset: 0x0001CA2D
	protected override void OnEnable()
	{
		this.SetInitialPhase();
		base.OnEnable();
		this._dir = base.Direction;
		base.transform.rotation = Quaternion.LookRotation(this._dir);
	}

	// Token: 0x06000723 RID: 1827 RVA: 0x0001E860 File Offset: 0x0001CA60
	protected override void FixedUpdate()
	{
		if (this.externalForce.sqrMagnitude > 0f)
		{
			this.externalForce = Vector3.MoveTowards(this.externalForce, Vector3.zero, Time.fixedDeltaTime * 2f);
		}
		if (this._iframes > 0)
		{
			base.DoMovement();
			this._iframes--;
			if (this._iframes <= 0)
			{
				base.gameObject.layer = LayerMask.NameToLayer("Entity");
				this.speed = this.ActivePhase.MovementSpeed;
				return;
			}
		}
		else
		{
			base.FixedUpdate();
		}
	}

	// Token: 0x06000724 RID: 1828 RVA: 0x0001E8F3 File Offset: 0x0001CAF3
	public override void ResetEntity()
	{
		this.fallMomentum = 0f;
		this._dir = base.Direction;
		base.transform.rotation = Quaternion.LookRotation(this._dir);
		base.ResetEntity();
	}

	// Token: 0x04000559 RID: 1369
	[Header("Multi-Hit properties")]
	public MultihitEnemy.Phase[] phases;

	// Token: 0x0400055A RID: 1370
	public int activePhaseIndex;

	// Token: 0x0400055B RID: 1371
	private int _iframes;

	// Token: 0x02000220 RID: 544
	[Serializable]
	public struct Phase
	{
		// Token: 0x170004C1 RID: 1217
		// (get) Token: 0x0600137A RID: 4986 RVA: 0x0004513E File Offset: 0x0004333E
		public readonly string AnimationState
		{
			get
			{
				return this._animationState;
			}
		}

		// Token: 0x170004C2 RID: 1218
		// (get) Token: 0x0600137B RID: 4987 RVA: 0x00045146 File Offset: 0x00043346
		public readonly GameObject ExitEffect
		{
			get
			{
				return this._exitEffect;
			}
		}

		// Token: 0x170004C3 RID: 1219
		// (get) Token: 0x0600137C RID: 4988 RVA: 0x0004514E File Offset: 0x0004334E
		public readonly string HitSFX
		{
			get
			{
				return this._hitSFX;
			}
		}

		// Token: 0x170004C4 RID: 1220
		// (get) Token: 0x0600137D RID: 4989 RVA: 0x00045156 File Offset: 0x00043356
		public readonly float MovementSpeed
		{
			get
			{
				return this._movementSpeed;
			}
		}

		// Token: 0x170004C5 RID: 1221
		// (get) Token: 0x0600137E RID: 4990 RVA: 0x0004515E File Offset: 0x0004335E
		public readonly MultihitEnemy.Phase.EntryBehavior OnEntryBehavior
		{
			get
			{
				return this._entryBehavior;
			}
		}

		// Token: 0x170004C6 RID: 1222
		// (get) Token: 0x0600137F RID: 4991 RVA: 0x00045166 File Offset: 0x00043366
		public readonly int IFrames
		{
			get
			{
				return this._iframes;
			}
		}

		// Token: 0x170004C7 RID: 1223
		// (get) Token: 0x06001380 RID: 4992 RVA: 0x0004516E File Offset: 0x0004336E
		public readonly MultihitEnemy.Phase.InteractionResponse OnTouchTop
		{
			get
			{
				return this._onTouchTop;
			}
		}

		// Token: 0x170004C8 RID: 1224
		// (get) Token: 0x06001381 RID: 4993 RVA: 0x00045176 File Offset: 0x00043376
		public readonly MultihitEnemy.Phase.InteractionResponse OnTouchSide
		{
			get
			{
				return this._onTouchSide;
			}
		}

		// Token: 0x170004C9 RID: 1225
		// (get) Token: 0x06001382 RID: 4994 RVA: 0x0004517E File Offset: 0x0004337E
		public readonly MultihitEnemy.Phase.InteractionResponse OnTouchBottom
		{
			get
			{
				return this._onTouchBottom;
			}
		}

		// Token: 0x170004CA RID: 1226
		// (get) Token: 0x06001383 RID: 4995 RVA: 0x00045186 File Offset: 0x00043386
		public readonly MultihitEnemy.Phase.InteractionResponse OnSpin
		{
			get
			{
				return this._onSpin;
			}
		}

		// Token: 0x170004CB RID: 1227
		// (get) Token: 0x06001384 RID: 4996 RVA: 0x0004518E File Offset: 0x0004338E
		public readonly MultihitEnemy.Phase.InteractionResponse OnSlam
		{
			get
			{
				return this._onSlam;
			}
		}

		// Token: 0x170004CC RID: 1228
		// (get) Token: 0x06001385 RID: 4997 RVA: 0x00045196 File Offset: 0x00043396
		public readonly MultihitEnemy.Phase.InteractionResponse OnSlide
		{
			get
			{
				return this._onSlide;
			}
		}

		// Token: 0x04000D1E RID: 3358
		[SerializeField]
		private string _animationState;

		// Token: 0x04000D1F RID: 3359
		[SerializeField]
		private GameObject _exitEffect;

		// Token: 0x04000D20 RID: 3360
		[SerializeField]
		private string _hitSFX;

		// Token: 0x04000D21 RID: 3361
		[SerializeField]
		private float _movementSpeed;

		// Token: 0x04000D22 RID: 3362
		[SerializeField]
		private MultihitEnemy.Phase.EntryBehavior _entryBehavior;

		// Token: 0x04000D23 RID: 3363
		[SerializeField]
		private int _iframes;

		// Token: 0x04000D24 RID: 3364
		[SerializeField]
		private MultihitEnemy.Phase.InteractionResponse _onTouchTop;

		// Token: 0x04000D25 RID: 3365
		[SerializeField]
		private MultihitEnemy.Phase.InteractionResponse _onTouchSide;

		// Token: 0x04000D26 RID: 3366
		[SerializeField]
		private MultihitEnemy.Phase.InteractionResponse _onTouchBottom;

		// Token: 0x04000D27 RID: 3367
		[SerializeField]
		private MultihitEnemy.Phase.InteractionResponse _onSpin;

		// Token: 0x04000D28 RID: 3368
		[SerializeField]
		private MultihitEnemy.Phase.InteractionResponse _onSlam;

		// Token: 0x04000D29 RID: 3369
		[SerializeField]
		private MultihitEnemy.Phase.InteractionResponse _onSlide;

		// Token: 0x020002A2 RID: 674
		[Flags]
		public enum InteractionResponse
		{
			// Token: 0x04000F18 RID: 3864
			Inherit = 1,
			// Token: 0x04000F19 RID: 3865
			HurtCrash = 2,
			// Token: 0x04000F1A RID: 3866
			BounceCrash = 4,
			// Token: 0x04000F1B RID: 3867
			DeflectCrash = 8,
			// Token: 0x04000F1C RID: 3868
			DeflectSelf = 16,
			// Token: 0x04000F1D RID: 3869
			NextPhase = 32,
			// Token: 0x04000F1E RID: 3870
			Die = 64,
			// Token: 0x04000F1F RID: 3871
			DieSpin = 128
		}

		// Token: 0x020002A3 RID: 675
		public enum EntryBehavior
		{
			// Token: 0x04000F21 RID: 3873
			Normal,
			// Token: 0x04000F22 RID: 3874
			Stun,
			// Token: 0x04000F23 RID: 3875
			Intangible
		}
	}
}
