﻿using System;
using System.Collections;
using Rewired;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x020000A6 RID: 166
public class ElevatorController : MonoBehaviour
{
	// Token: 0x170000D3 RID: 211
	// (get) Token: 0x06000517 RID: 1303 RVA: 0x00016A1C File Offset: 0x00014C1C
	// (set) Token: 0x06000518 RID: 1304 RVA: 0x00016A24 File Offset: 0x00014C24
	public UpDownPlatform Platform { get; private set; }

	// Token: 0x170000D4 RID: 212
	// (get) Token: 0x06000519 RID: 1305 RVA: 0x00016A2D File Offset: 0x00014C2D
	// (set) Token: 0x0600051A RID: 1306 RVA: 0x00016A35 File Offset: 0x00014C35
	public Transform CameraTarget { get; private set; }

	// Token: 0x0600051B RID: 1307 RVA: 0x00016A40 File Offset: 0x00014C40
	private void Start()
	{
		this.rw = ReInput.players.GetPlayer(0);
		this.CameraTarget.position = this.Platform.CurrentFloor.platformPoint.position;
		this.Platform.onStoppedMoving.AddListener(new UnityAction(this.OnPlatformStopped));
	}

	// Token: 0x0600051C RID: 1308 RVA: 0x00016A9C File Offset: 0x00014C9C
	private void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (!this.crashPresent && other.TryGetComponent<CrashController>(out crashController))
		{
			this.crashPresent = true;
			this.canTrigger = true;
			if (this.Platform.CurrentFloor is CustomWarpRoom)
			{
				this.CameraTarget.rotation = Quaternion.identity;
			}
			else
			{
				this.CameraTarget.LookAt(crashController.transform);
			}
			UnityEvent unityEvent = this.onEnter;
			if (unityEvent == null)
			{
				return;
			}
			unityEvent.Invoke();
		}
	}

	// Token: 0x0600051D RID: 1309 RVA: 0x00016B10 File Offset: 0x00014D10
	private void OnTriggerExit(Collider other)
	{
		CrashController crashController;
		if (this.crashPresent && other.TryGetComponent<CrashController>(out crashController))
		{
			this.crashPresent = false;
			this.canTrigger = false;
			CameraManager.instance.SetVCam(this.Platform.CurrentFloor.primaryCamera);
			UnityEvent unityEvent = this.onExit;
			if (unityEvent == null)
			{
				return;
			}
			unityEvent.Invoke();
		}
	}

	// Token: 0x0600051E RID: 1310 RVA: 0x00016B68 File Offset: 0x00014D68
	private void OnTriggerStay(Collider other)
	{
		CrashController crashController;
		if (this.canTrigger && other.TryGetComponent<CrashController>(out crashController) && crashController.animator.currentState == crashController.animator.idleObj && crashController.animator.TimeSinceStateChanged > 0.5f)
		{
			this.controlsActive = true;
			crashController.animator.SetState(crashController.animator.elevatorObj, false);
			this.canTrigger = false;
		}
	}

	// Token: 0x0600051F RID: 1311 RVA: 0x00016BDC File Offset: 0x00014DDC
	private void Update()
	{
		if (this.controlsActive && this.Platform.FloorDelta == 0)
		{
			if (this.dir != 1 && this.rw.GetAxisRaw("Vertical") > 0.5f)
			{
				this.dir = (this.Platform.CanGoUp ? 1 : 0);
				CrashController.instance.animator.elevatorAnim.animator.SetInteger("Direction", this.dir);
				return;
			}
			if (this.dir != -1 && this.rw.GetAxisRaw("Vertical") < -0.5f)
			{
				this.dir = (this.Platform.CanGoDown ? -1 : 0);
				CrashController.instance.animator.elevatorAnim.animator.SetInteger("Direction", this.dir);
				return;
			}
			if (this.dir != 0 && this.rw.GetButton("Jump"))
			{
				if (this.dir > 0)
				{
					this.Platform.GoUp();
				}
				else if (this.dir < 0)
				{
					this.Platform.GoDown();
				}
				base.StartCoroutine(this.MoveCameraTarget());
				return;
			}
			if (this.rw.GetButtonDown("Crouch"))
			{
				this.dir = 0;
				CrashController.instance.animator.elevatorAnim.animator.SetInteger("Direction", this.dir);
				base.StartCoroutine(this.FreeCrash());
			}
		}
	}

	// Token: 0x06000520 RID: 1312 RVA: 0x00016D58 File Offset: 0x00014F58
	private void OnPlatformStopped()
	{
		if (this.dir > 0 && !this.Platform.CanGoUp)
		{
			this.dir = 0;
			CrashController.instance.animator.elevatorAnim.animator.SetInteger("Direction", this.dir);
		}
		else if (this.dir < 0 && !this.Platform.CanGoDown)
		{
			this.dir = 0;
			CrashController.instance.animator.elevatorAnim.animator.SetInteger("Direction", this.dir);
		}
		if (this.Platform.CurrentFloor is CustomWarpRoom)
		{
			if (this.Platform.camTriggers)
			{
				this.Platform.camTriggers.SetActive(false);
				return;
			}
		}
		else if (this.Platform.camTriggers)
		{
			this.Platform.camTriggers.SetActive(true);
		}
	}

	// Token: 0x06000521 RID: 1313 RVA: 0x00016E42 File Offset: 0x00015042
	private IEnumerator MoveCameraTarget()
	{
		yield return new WaitForSeconds(1.5f);
		this.CameraTarget.position = this.Platform.NextFloor.platformPoint.position;
		if (this.Platform.NextFloor is CustomWarpRoom)
		{
			this.CameraTarget.rotation = Quaternion.identity;
		}
		WarpRoom.inCustomWarpRoom = (this.Platform.NextFloor is CustomWarpRoom);
		WarpRoom.instance.SetScreenCanvasTF(this.Platform.NextFloor);
		yield break;
	}

	// Token: 0x06000522 RID: 1314 RVA: 0x00016E51 File Offset: 0x00015051
	private IEnumerator FreeCrash()
	{
		this.controlsActive = false;
		yield return new WaitForSeconds(0.5f);
		CrashController.instance.animator.SetState(CrashController.instance.animator.idleObj, false);
		yield break;
	}

	// Token: 0x04000399 RID: 921
	public UnityEvent onEnter;

	// Token: 0x0400039A RID: 922
	public UnityEvent onExit;

	// Token: 0x0400039B RID: 923
	private bool controlsActive;

	// Token: 0x0400039C RID: 924
	private bool canTrigger;

	// Token: 0x0400039D RID: 925
	private bool crashPresent;

	// Token: 0x0400039E RID: 926
	private int dir;

	// Token: 0x0400039F RID: 927
	private Player rw;
}
