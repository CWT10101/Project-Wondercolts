﻿using System;
using UnityEngine;

// Token: 0x0200009B RID: 155
public class DeathTrigger : MonoBehaviour
{
	// Token: 0x060004A5 RID: 1189 RVA: 0x00014E0E File Offset: 0x0001300E
	private void Awake()
	{
		if (this.collider == null)
		{
			this.collider = base.GetComponent<Collider>();
		}
	}

	// Token: 0x060004A6 RID: 1190 RVA: 0x00014E2C File Offset: 0x0001302C
	private void FixedUpdate()
	{
		int num = Physics.OverlapBoxNonAlloc(this.collider.bounds.center, this.collider.bounds.extents, this.hitColliders, base.transform.rotation, -1, QueryTriggerInteraction.Ignore);
		if (num > 0)
		{
			for (int i = 0; i < num; i++)
			{
				Crate crate;
				if (this.hitColliders[i].TryGetComponent<Crate>(out crate) && crate.IsFalling)
				{
					crate.ForceBreak();
				}
			}
			for (int i = 0; i < this.hitColliders.Length; i++)
			{
				this.hitColliders[i] = null;
			}
		}
	}

	// Token: 0x060004A7 RID: 1191 RVA: 0x00014EC4 File Offset: 0x000130C4
	public virtual void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			if (!string.IsNullOrEmpty(this.sfxClip))
			{
				AudioManager.Play(this.sfxClip, AudioManager.MixerTarget.SFX, new Vector3?(crashController.transform.position), null);
			}
			if (this.effect != null)
			{
				Object.Instantiate<GameObject>(this.effect, crashController.transform.position, Quaternion.identity);
			}
			crashController.Die(this.deathEffectIndex);
			return;
		}
		CreatorBoss creatorBoss;
		if (other.TryGetComponent<CreatorBoss>(out creatorBoss))
		{
			creatorBoss.TakeDamage();
			if (creatorBoss.HP > 0)
			{
				creatorBoss.Teleport();
				return;
			}
			creatorBoss.Die(true);
			return;
		}
		else
		{
			Enemy enemy;
			if (other.TryGetComponent<Enemy>(out enemy))
			{
				enemy.Die(true);
				return;
			}
			Projectile projectile;
			if (other.TryGetComponent<Projectile>(out projectile))
			{
				Object.Destroy(projectile.gameObject);
			}
			return;
		}
	}

	// Token: 0x04000341 RID: 833
	public string sfxClip;

	// Token: 0x04000342 RID: 834
	public GameObject effect;

	// Token: 0x04000343 RID: 835
	public Collider collider;

	// Token: 0x04000344 RID: 836
	private Collider[] hitColliders = new Collider[16];

	// Token: 0x04000345 RID: 837
	public int deathEffectIndex;
}
