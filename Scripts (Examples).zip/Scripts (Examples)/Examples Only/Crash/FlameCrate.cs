﻿using System;
using UnityEngine;

// Token: 0x020000B8 RID: 184
public class FlameCrate : BasicCrate, IMetadataReceiver<PhaseMetadata>
{
	// Token: 0x170000DF RID: 223
	// (get) Token: 0x060005B4 RID: 1460 RVA: 0x0001940A File Offset: 0x0001760A
	public override bool AddsToBoxCount
	{
		get
		{
			return true;
		}
	}

	// Token: 0x170000E0 RID: 224
	// (get) Token: 0x060005B5 RID: 1461 RVA: 0x0001940D File Offset: 0x0001760D
	private float CycleLength
	{
		get
		{
			return this.durationOff + this.durationOn;
		}
	}

	// Token: 0x060005B6 RID: 1462 RVA: 0x0001941C File Offset: 0x0001761C
	private void Start()
	{
		this._m = new Mesh
		{
			vertices = new Vector3[]
			{
				new Vector3(-0.5f, -0.5f, 0f),
				new Vector3(0.5f, -0.5f, 0f),
				new Vector3(-0.5f, 0.5f, 0f),
				new Vector3(0.5f, 0.5f, 0f)
			},
			triangles = new int[]
			{
				0,
				2,
				1,
				2,
				3,
				1
			},
			normals = new Vector3[]
			{
				Vector3.back,
				Vector3.back,
				Vector3.back,
				Vector3.back
			}
		};
		this.uvOperation = (this.texStartsFromTop ? new Action(this.SetMeshUVsTop) : new Action(this.SetMeshUVsBottom));
		this.uvOperation();
		MeshFilter[] array = this.flames;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].sharedMesh = this._m;
		}
	}

	// Token: 0x060005B7 RID: 1463 RVA: 0x00019558 File Offset: 0x00017758
	protected override void FixedUpdate()
	{
		base.FixedUpdate();
		if (this.isBroken)
		{
			return;
		}
		if (!this.visual.activeSelf)
		{
			return;
		}
		float num = this.offset * this.CycleLength;
		float num2 = Clock.SynchronizedTime + num - Time.fixedDeltaTime;
		float num3 = Clock.SynchronizedTime + num;
		num2 %= this.CycleLength;
		num3 %= this.CycleLength;
		this.onVis.SetActive(num3 > this.durationOff);
		this.hitTriggerObject.SetActive(num3 > this.durationOff);
		this.offVis.SetActive(num3 < this.durationOff);
		this.uvOperation();
		MeshFilter[] array = this.flames;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].transform.parent.localScale = Vector3.one * this.flameScaleCurve.Evaluate(num3);
		}
		this.lightSource.radius = this.lightRadiusCurve.Evaluate(num3);
		if (num2 < this.igniteAudioTime && num3 >= this.igniteAudioTime)
		{
			this.igniteAudioSrc.Play();
			return;
		}
		if (num2 < this.flameAudioTime && num3 >= this.flameAudioTime)
		{
			this.flameAudioSrc.Play();
		}
	}

	// Token: 0x060005B8 RID: 1464 RVA: 0x00019693 File Offset: 0x00017893
	public override void ForceBreak()
	{
		base.ForceBreak();
		this.lightSource.radius = 0f;
	}

	// Token: 0x060005B9 RID: 1465 RVA: 0x000196AC File Offset: 0x000178AC
	private void SetMeshUVsBottom()
	{
		int num = (int)(Clock.SynchronizedTime * (float)this.texFramesPerSec);
		float num2 = (float)num % (float)this.texTilesW / (float)this.texTilesW;
		float num3 = Mathf.Floor((float)num / (float)this.texTilesW) / (float)this.texTilesH;
		float num4 = 1f / (float)this.texTilesW;
		float num5 = 1f / (float)this.texTilesH;
		this.uvs[0] = new Vector2(num2, num3);
		this.uvs[1] = new Vector2(num2 + num4, num3);
		this.uvs[2] = new Vector2(num2, num3 + num5);
		this.uvs[3] = new Vector2(num2 + num4, num3 + num5);
		this._m.uv = this.uvs;
	}

	// Token: 0x060005BA RID: 1466 RVA: 0x00019774 File Offset: 0x00017974
	private void SetMeshUVsTop()
	{
		int num = (int)(Clock.SynchronizedTime * (float)this.texFramesPerSec);
		float num2 = (float)num % (float)this.texTilesW / (float)this.texTilesW;
		float num3 = ((float)(this.texTilesH - 1) - Mathf.Floor((float)num / (float)this.texTilesW)) / (float)this.texTilesH;
		float num4 = 1f / (float)this.texTilesW;
		float num5 = 1f / (float)this.texTilesH;
		this.uvs[0] = new Vector2(num2, num3);
		this.uvs[1] = new Vector2(num2 + num4, num3);
		this.uvs[2] = new Vector2(num2, num3 + num5);
		this.uvs[3] = new Vector2(num2 + num4, num3 + num5);
		this._m.uv = this.uvs;
	}

	// Token: 0x060005BB RID: 1467 RVA: 0x00019849 File Offset: 0x00017A49
	public void ProcessMetadata(PhaseMetadata meta)
	{
		this.offset = meta.NormalizedValue;
	}

	// Token: 0x04000413 RID: 1043
	public GameObject offVis;

	// Token: 0x04000414 RID: 1044
	public GameObject onVis;

	// Token: 0x04000415 RID: 1045
	public GameObject hitTriggerObject;

	// Token: 0x04000416 RID: 1046
	public MeshFilter[] flames;

	// Token: 0x04000417 RID: 1047
	public LightSource lightSource;

	// Token: 0x04000418 RID: 1048
	public AudioSource igniteAudioSrc;

	// Token: 0x04000419 RID: 1049
	public AudioSource flameAudioSrc;

	// Token: 0x0400041A RID: 1050
	public AnimationCurve flameScaleCurve;

	// Token: 0x0400041B RID: 1051
	public AnimationCurve lightRadiusCurve;

	// Token: 0x0400041C RID: 1052
	public float durationOn;

	// Token: 0x0400041D RID: 1053
	public float durationOff;

	// Token: 0x0400041E RID: 1054
	public float igniteAudioTime;

	// Token: 0x0400041F RID: 1055
	public float flameAudioTime;

	// Token: 0x04000420 RID: 1056
	public float offset;

	// Token: 0x04000421 RID: 1057
	public byte texTilesW = 8;

	// Token: 0x04000422 RID: 1058
	public byte texTilesH = 4;

	// Token: 0x04000423 RID: 1059
	public byte texFramesPerSec = 20;

	// Token: 0x04000424 RID: 1060
	public bool texStartsFromTop = true;

	// Token: 0x04000425 RID: 1061
	private Mesh _m;

	// Token: 0x04000426 RID: 1062
	private readonly Vector2[] uvs = new Vector2[4];

	// Token: 0x04000427 RID: 1063
	private Action uvOperation;
}
