﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x020000EE RID: 238
public class NitroBounceCrate : NitroCrate, ICrateBouncer, IMetadataReceiver<StateMetadata>
{
	// Token: 0x06000742 RID: 1858 RVA: 0x0001EAF4 File Offset: 0x0001CCF4
	protected override void OnEnable()
	{
		base.OnEnable();
		this._bounceCountRollback = this.startingBounceCount;
		this._isNitroRollback = false;
	}

	// Token: 0x06000743 RID: 1859 RVA: 0x0001EB0F File Offset: 0x0001CD0F
	public override void TryPushToStack()
	{
		if (!EntityTracker.IsOnStack(this))
		{
			this._bounceCountRollback = this.bounceCount;
			this._isNitroRollback = this.isNitro;
		}
		base.TryPushToStack();
	}

	// Token: 0x06000744 RID: 1860 RVA: 0x0001EB37 File Offset: 0x0001CD37
	public override void FallOn(CrashController crash)
	{
		if (!this.isNitro)
		{
			this.Bounce();
			crash.ArrowBounce(true);
			return;
		}
		if (this.canChangeState)
		{
			base.FallOn(crash);
		}
	}

	// Token: 0x06000745 RID: 1861 RVA: 0x0001EB5E File Offset: 0x0001CD5E
	private void Bounce()
	{
		this.ChangeState();
		this.countdownAnimator.SetTrigger("Bounce");
	}

	// Token: 0x06000746 RID: 1862 RVA: 0x0001EB76 File Offset: 0x0001CD76
	public override void Slam(CrashController crash)
	{
		if (!this.isNitro)
		{
			if (!base.IsBelow(crash))
			{
				this.Bounce();
				crash.ArrowBounce(true);
				return;
			}
		}
		else if (this.canChangeState)
		{
			base.Slam(crash);
		}
	}

	// Token: 0x06000747 RID: 1863 RVA: 0x0001EBA6 File Offset: 0x0001CDA6
	public override void Explode()
	{
		if (this.isNitro)
		{
			base.Explode();
		}
	}

	// Token: 0x06000748 RID: 1864 RVA: 0x0001EBB6 File Offset: 0x0001CDB6
	public override void Spin(CrashController crash)
	{
		if (this.isNitro)
		{
			base.Spin(crash);
			return;
		}
		if (base.IsAbove(crash) && !crash.WasGrounded)
		{
			this.Bounce();
		}
	}

	// Token: 0x06000749 RID: 1865 RVA: 0x0001EBDF File Offset: 0x0001CDDF
	public override void Slide(CrashController crash)
	{
		if (this.isNitro)
		{
			base.Slide(crash);
			return;
		}
		if (base.IsAbove(crash) && base.CheckGap(crash))
		{
			this.Bounce();
			crash.ArrowBounce(true);
		}
	}

	// Token: 0x0600074A RID: 1866 RVA: 0x0001EC10 File Offset: 0x0001CE10
	public override void TouchBottom(CrashController crash)
	{
		if (this.isNitro)
		{
			base.TouchBottom(crash);
		}
	}

	// Token: 0x0600074B RID: 1867 RVA: 0x0001EC21 File Offset: 0x0001CE21
	public override void TouchTop(CrashController crash)
	{
		if (this.isNitro)
		{
			base.TouchTop(crash);
		}
	}

	// Token: 0x0600074C RID: 1868 RVA: 0x0001EC32 File Offset: 0x0001CE32
	public override void TouchSide(CrashController crash)
	{
		if (this.isNitro)
		{
			base.TouchSide(crash);
		}
	}

	// Token: 0x0600074D RID: 1869 RVA: 0x0001EC44 File Offset: 0x0001CE44
	public void ChangeState()
	{
		this.TryPushToStack();
		if (this.canChangeState && this.bounceCount < this.states.Length - 1)
		{
			this.bounceCount++;
			GameObject[] array = this.states;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].SetActive(false);
			}
			this.states[this.bounceCount].SetActive(true);
			if (this.bounceCount == 3)
			{
				this.SpawnNitro();
			}
			this.canChangeState = false;
			base.StartCoroutine(this.<ChangeState>g__UnlockState|18_0());
		}
	}

	// Token: 0x0600074E RID: 1870 RVA: 0x0001ECD4 File Offset: 0x0001CED4
	public void SpawnNitro()
	{
		this.isNitro = true;
		BrokenCrate brokenCrate = Object.Instantiate<BrokenCrate>(ResourceManager.instance.brokenCrate, base.transform.position, base.transform.rotation);
		brokenCrate.crateCol = Color.grey;
		brokenCrate.SetColour(Color.grey);
	}

	// Token: 0x0600074F RID: 1871 RVA: 0x0001ED24 File Offset: 0x0001CF24
	public void ResetState()
	{
		this.canChangeState = true;
		this.isNitro = this._isNitroRollback;
		this.bounceCount = this._bounceCountRollback;
		GameObject[] array = this.states;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(false);
		}
		this.states[this.bounceCount].SetActive(true);
		this.countdownAnimator.SetTrigger("reset");
	}

	// Token: 0x06000750 RID: 1872 RVA: 0x0001ED91 File Offset: 0x0001CF91
	public override void ResetEntity()
	{
		base.ResetEntity();
		this.ResetState();
	}

	// Token: 0x06000751 RID: 1873 RVA: 0x0001ED9F File Offset: 0x0001CF9F
	public void ProcessMetadata(StateMetadata meta)
	{
		this.startingBounceCount = (int)(2 - meta.state);
		this._bounceCountRollback = this.startingBounceCount;
	}

	// Token: 0x06000752 RID: 1874 RVA: 0x0001EDBC File Offset: 0x0001CFBC
	public void BounceCrate(Crate crate)
	{
		if (this.isNitro)
		{
			base.Explode();
			return;
		}
		this.Bounce();
		AudioManager.Play("SFX_CrateBounce", new Vector3?(crate.transform.position), new Vector2?(Vector2.one * (0.8f + Mathf.Min(0.5f, 0.1f))));
		crate.Fall(-25f * Time.fixedUnscaledDeltaTime);
	}

	// Token: 0x06000754 RID: 1876 RVA: 0x0001EE3D File Offset: 0x0001D03D
	[CompilerGenerated]
	private IEnumerator <ChangeState>g__UnlockState|18_0()
	{
		yield return new WaitForFixedUpdate();
		this.canChangeState = true;
		yield break;
	}

	// Token: 0x04000561 RID: 1377
	public GameObject[] states;

	// Token: 0x04000562 RID: 1378
	public int startingBounceCount;

	// Token: 0x04000563 RID: 1379
	public int bounceCount;

	// Token: 0x04000564 RID: 1380
	public bool isNitro;

	// Token: 0x04000565 RID: 1381
	private int _bounceCountRollback;

	// Token: 0x04000566 RID: 1382
	private bool _isNitroRollback;

	// Token: 0x04000567 RID: 1383
	private bool canChangeState = true;
}
