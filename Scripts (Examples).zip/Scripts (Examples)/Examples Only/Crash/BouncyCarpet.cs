﻿using System;
using UnityEngine;

// Token: 0x02000079 RID: 121
public class BouncyCarpet : Entity, IFallOn, ITouchTop, ISlam, ISpin, ISlide
{
	// Token: 0x0600036C RID: 876 RVA: 0x0000EEAD File Offset: 0x0000D0AD
	private void FixedUpdate()
	{
		this.playerCollider.enabled = (CrashController.instance.transform.position.y - base.transform.position.y >= 0f);
	}

	// Token: 0x0600036D RID: 877 RVA: 0x0000EEE9 File Offset: 0x0000D0E9
	public void FallOn(CrashController crash)
	{
		this.Bounce(crash);
	}

	// Token: 0x0600036E RID: 878 RVA: 0x0000EEF2 File Offset: 0x0000D0F2
	public void Slam(CrashController crash)
	{
		this.Bounce(crash);
	}

	// Token: 0x0600036F RID: 879 RVA: 0x0000EEFB File Offset: 0x0000D0FB
	public void TouchTop(CrashController crash)
	{
		if (!crash.WasGrounded)
		{
			this.Bounce(crash);
		}
	}

	// Token: 0x06000370 RID: 880 RVA: 0x0000EF0C File Offset: 0x0000D10C
	public void Spin(CrashController crash)
	{
	}

	// Token: 0x06000371 RID: 881 RVA: 0x0000EF0E File Offset: 0x0000D10E
	public void Slide(CrashController crash)
	{
		if (this.IsAbove(crash) && this.CheckGap(crash))
		{
			this.Bounce(crash);
		}
	}

	// Token: 0x06000372 RID: 882 RVA: 0x0000EF2C File Offset: 0x0000D12C
	private void Bounce(CrashController crash)
	{
		AudioManager.Play(this.sfx, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		crash.ArrowBounce(false);
		if (this.anim)
		{
			this.anim.SetTrigger("Bounce");
		}
	}

	// Token: 0x06000373 RID: 883 RVA: 0x0000EF84 File Offset: 0x0000D184
	protected bool IsAbove(CrashController crash)
	{
		return this.collider.ClosestPoint(crash.controller.ClosestPoint(this.collider.bounds.center)).y - this.collider.bounds.max.y >= 0f;
	}

	// Token: 0x06000374 RID: 884 RVA: 0x0000EFE4 File Offset: 0x0000D1E4
	protected bool CheckGap(CrashController crash)
	{
		if (this.neverGap)
		{
			return false;
		}
		if (crash.animator.TimeSinceStateChanged < 0.1f)
		{
			return false;
		}
		Vector3 direction = -crash.LastMoveDelta.normalized;
		RaycastHit raycastHit;
		return !Physics.Raycast(this.collider.bounds.center, direction, out raycastHit, 1f, 1, QueryTriggerInteraction.Ignore);
	}

	// Token: 0x04000243 RID: 579
	public Collider playerCollider;

	// Token: 0x04000244 RID: 580
	public Collider entityCollider;

	// Token: 0x04000245 RID: 581
	public string sfx = "SFX_BounceCarpet";

	// Token: 0x04000246 RID: 582
	public Animator anim;

	// Token: 0x04000247 RID: 583
	public bool neverGap;
}
