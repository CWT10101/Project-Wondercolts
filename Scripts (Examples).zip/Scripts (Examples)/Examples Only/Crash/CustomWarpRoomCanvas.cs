﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Cinemachine;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Token: 0x02000093 RID: 147
public class CustomWarpRoomCanvas : MonoBehaviour
{
	// Token: 0x170000BB RID: 187
	// (get) Token: 0x0600046A RID: 1130 RVA: 0x000142DE File Offset: 0x000124DE
	// (set) Token: 0x0600046B RID: 1131 RVA: 0x000142E6 File Offset: 0x000124E6
	public bool CanTrigger { get; set; }

	// Token: 0x170000BC RID: 188
	// (get) Token: 0x0600046C RID: 1132 RVA: 0x000142EF File Offset: 0x000124EF
	// (set) Token: 0x0600046D RID: 1133 RVA: 0x000142F6 File Offset: 0x000124F6
	public static bool LevelsDirty { get; set; }

	// Token: 0x0600046E RID: 1134 RVA: 0x00014300 File Offset: 0x00012500
	private void Start()
	{
		CustomWarpRoomLevelInput[] array = this.inputFields;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].CheckForLevel(false);
		}
		this.InitDropdown();
		this.SetInUse(false);
	}

	// Token: 0x0600046F RID: 1135 RVA: 0x00014338 File Offset: 0x00012538
	public void SetInUse(bool isUsing)
	{
		this.inUse = isUsing;
		this.cg.interactable = this.inUse;
		this.cg2.interactable = this.inUse;
	}

	// Token: 0x06000470 RID: 1136 RVA: 0x00014364 File Offset: 0x00012564
	public void CameraTriggerCheck(CinemachineVirtualCameraBase vcam)
	{
		if (this.CanTrigger && !this.inUse && CrashController.instance.animator.currentState == CrashController.instance.animator.idleObj)
		{
			CameraManager.instance.SetVCam(vcam);
			this.SetInUse(true);
			CrashController.instance.enabled = false;
			this.CanTrigger = false;
		}
	}

	// Token: 0x06000471 RID: 1137 RVA: 0x000143CA File Offset: 0x000125CA
	public void BackToMain()
	{
		this.OpenScreen(0);
		this.inputFields[this.currentInputIndex].CheckForLevel(false);
		this.currentInputIndex = -1;
	}

	// Token: 0x06000472 RID: 1138 RVA: 0x000143F0 File Offset: 0x000125F0
	public void OpenScreen(int index)
	{
		this.inputScreen.SetActive(false);
		this.selectionScreen.SetActive(false);
		if (index == 0)
		{
			this.inputScreen.SetActive(true);
			return;
		}
		if (CustomWarpRoomCanvas.LevelsDirty)
		{
			this.InitDropdown();
			CustomWarpRoomCanvas.LevelsDirty = false;
		}
		this.selectionScreen.SetActive(true);
		this.dropdown.Select();
	}

	// Token: 0x06000473 RID: 1139 RVA: 0x0001444F File Offset: 0x0001264F
	public void InitDropdown()
	{
		this.dropdown.ClearOptions();
		this.dropdown.AddOptions(LevelSerializer.instance.userCreatedList);
	}

	// Token: 0x06000474 RID: 1140 RVA: 0x00014474 File Offset: 0x00012674
	public void SetDropdown(int index)
	{
		this.currentInputIndex = index;
		this.dropdownNumberText.text = string.Format("{0}", index + 1);
		this.OpenScreen(1);
		int num = this.dropdown.options.FindIndex((TMP_Dropdown.OptionData o) => o.text == this.inputFields[index].inputfield.text);
		if (num != -1)
		{
			this.dropdown.SetValueWithoutNotify(num);
		}
	}

	// Token: 0x06000475 RID: 1141 RVA: 0x000144F7 File Offset: 0x000126F7
	public void UpdateInputfield()
	{
		this.inputFields[this.currentInputIndex].inputfield.text = LevelSerializer.instance.userCreatedList[this.dropdown.value];
	}

	// Token: 0x06000476 RID: 1142 RVA: 0x0001452C File Offset: 0x0001272C
	public void SetRandomLevels()
	{
		List<int> list = LevelSerializer.instance.userCreatedList.Select((string s, int i) => i).ToList<int>();
		foreach (CustomWarpRoomLevelInput customWarpRoomLevelInput in this.inputFields)
		{
			if (list.Count > 0)
			{
				int index = Random.Range(0, list.Count);
				customWarpRoomLevelInput.SetRandomLevel(list[index]);
				list.RemoveAt(index);
			}
			else
			{
				customWarpRoomLevelInput.inputfield.text = "";
			}
		}
		this.TickConfirm();
	}

	// Token: 0x06000477 RID: 1143 RVA: 0x000145CC File Offset: 0x000127CC
	public void TickConfirm()
	{
		WarpRoom.instance.customWarpRoom.warpSphere.gameObject.SetActive(false);
		CustomWarpRoomLevelInput[] array = this.inputFields;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SwitchLight(false, false);
		}
		this.cg.interactable = false;
		base.StartCoroutine(this.<TickConfirm>g__Routine|28_0());
	}

	// Token: 0x06000478 RID: 1144 RVA: 0x0001462B File Offset: 0x0001282B
	public void ExitScreen(CinemachineVirtualCameraBase newCam)
	{
		CameraManager.instance.SetVCam(newCam);
		CrashController.instance.enabled = true;
		this.SetInUse(false);
		EventSystem.current.SetSelectedGameObject(null);
	}

	// Token: 0x0600047A RID: 1146 RVA: 0x00014664 File Offset: 0x00012864
	[CompilerGenerated]
	private IEnumerator <TickConfirm>g__Routine|28_0()
	{
		try
		{
			foreach (CustomWarpRoomLevelInput input in this.inputFields)
			{
				input.SetFlash(true);
				yield return new WaitForSeconds(0.33f);
				input.CheckForLevel(true);
				input.SetFlash(false);
				input = null;
			}
			CustomWarpRoomLevelInput[] array = null;
		}
		finally
		{
			this.cg.interactable = true;
		}
		yield break;
		yield break;
	}

	// Token: 0x04000311 RID: 785
	public CanvasGroup cg;

	// Token: 0x04000312 RID: 786
	public CanvasGroup cg2;

	// Token: 0x04000313 RID: 787
	public CustomWarpRoomLevelInput[] inputFields;

	// Token: 0x04000314 RID: 788
	public Button tickButton;

	// Token: 0x04000315 RID: 789
	public Button exitButton;

	// Token: 0x04000316 RID: 790
	private bool inUse;

	// Token: 0x04000317 RID: 791
	public GameObject inputScreen;

	// Token: 0x04000318 RID: 792
	public GameObject selectionScreen;

	// Token: 0x04000319 RID: 793
	public TMP_Dropdown dropdown;

	// Token: 0x0400031A RID: 794
	public TMP_Text dropdownNumberText;

	// Token: 0x0400031B RID: 795
	private int currentInputIndex = -1;
}
