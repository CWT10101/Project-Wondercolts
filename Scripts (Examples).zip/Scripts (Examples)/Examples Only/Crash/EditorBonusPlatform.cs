﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using LevelEditor;
using UnityEngine;

// Token: 0x020000A4 RID: 164
public class EditorBonusPlatform : Entity, IPlatform, IMetadataReceiver<EndpointMetadata>, IMetadataReceiver<SpeedMetadata>, IMetadataReceiver<OneWayMetadata>, IPlayModeCallback, IMetadataReceiver<MusicMetadata>, IMetadataReceiver<BonusUIMetadata>
{
	// Token: 0x170000D1 RID: 209
	// (get) Token: 0x060004FB RID: 1275 RVA: 0x00016023 File Offset: 0x00014223
	public float TimeSinceActivated
	{
		get
		{
			if (this.timeActivated != -1f)
			{
				return Clock.SynchronizedTime - this.timeActivated;
			}
			return float.NegativeInfinity;
		}
	}

	// Token: 0x170000D2 RID: 210
	// (get) Token: 0x060004FC RID: 1276 RVA: 0x00016044 File Offset: 0x00014244
	public float T
	{
		get
		{
			return Mathf.Clamp01(this.useWorldspaceSpeed ? (this.TimeSinceActivated / Vector3.Distance(this.pointA.position, this.pointB.position) * this.worldspaceSpeed) : this.TimeSinceActivated);
		}
	}

	// Token: 0x060004FD RID: 1277 RVA: 0x00016084 File Offset: 0x00014284
	protected virtual void OnEnable()
	{
		this.occupants.Clear();
		this.timeLastTouched = -1f;
		this.timeActivated = -1f;
		this._scheduledLerpFunc = null;
		this.lerpFunc = null;
		this.lerpT = this._rollbackLerpT;
	}

	// Token: 0x060004FE RID: 1278 RVA: 0x000160C1 File Offset: 0x000142C1
	private void OnDisable()
	{
		this.SetBonusUI(false);
		if (this.setsBonusUI)
		{
			BonusManager.instance.bonusComplete = false;
			BonusManager.instance.ShowBonusUI(false);
		}
	}

	// Token: 0x060004FF RID: 1279 RVA: 0x000160E8 File Offset: 0x000142E8
	public void FixedUpdate()
	{
		this._delta = this.GetNextPosition() - base.transform.position;
		base.transform.position += this._delta;
		if (this._scheduledLerpFunc != null)
		{
			this.lerpFunc = this._scheduledLerpFunc;
			this._scheduledLerpFunc = null;
			this.timeActivated = Clock.SynchronizedTime;
			this.TryPushToStack();
		}
		if (this.lerpFinished)
		{
			if (this.lerpFunc == new EditorBonusPlatform.LerpFunction(this.LerpForward))
			{
				if (this.setsBonusUI)
				{
					if (!this.hasSetBonusUI)
					{
						this.hasSetBonusUI = true;
						this.SetBonusUI(true);
					}
					if (this.safetyWalls)
					{
						this.safetyWalls.SetActive(false);
					}
				}
				else if (BonusManager.instance.inBonus)
				{
					this.SetBonusUI(false);
					if (this.safetyWalls)
					{
						this.safetyWalls.SetActive(false);
					}
				}
			}
			else if (this.lerpFunc == new EditorBonusPlatform.LerpFunction(this.LerpBackward) && this.setsBonusUI)
			{
				this.SetBonusUI(false);
				if (this.safetyWalls)
				{
					this.safetyWalls.SetActive(false);
				}
			}
			this.lerpFinished = false;
			this.lerpFunc = null;
		}
		foreach (Transform transform in this.occupants.Keys.ToArray<Transform>())
		{
			Dictionary<Transform, uint> dictionary = this.occupants;
			Transform key = transform;
			uint num = dictionary[key];
			dictionary[key] = num + 1U;
		}
	}

	// Token: 0x06000500 RID: 1280 RVA: 0x00016274 File Offset: 0x00014474
	public override void RememberState()
	{
		if (this.lerpFunc == new EditorBonusPlatform.LerpFunction(this.LerpForward))
		{
			this._rollbackLerpT = 1f;
			return;
		}
		if (this.lerpFunc == new EditorBonusPlatform.LerpFunction(this.LerpBackward))
		{
			this._rollbackLerpT = 0f;
			return;
		}
		this._rollbackLerpT = this.lerpT;
	}

	// Token: 0x06000501 RID: 1281 RVA: 0x000162D7 File Offset: 0x000144D7
	private Vector3 LerpForward(Vector3 a, Vector3 b, float t)
	{
		this.lerpT = Mathf.Clamp01(t);
		if (this.lerpT == 1f)
		{
			this.lerpFinished = true;
		}
		return Vector3.Lerp(a, b, this.lerpT);
	}

	// Token: 0x06000502 RID: 1282 RVA: 0x00016306 File Offset: 0x00014506
	private Vector3 LerpBackward(Vector3 a, Vector3 b, float t)
	{
		this.lerpT = Mathf.Clamp01(1f - t);
		if (this.lerpT == 0f)
		{
			this.lerpFinished = true;
		}
		return Vector3.Lerp(a, b, this.lerpT);
	}

	// Token: 0x06000503 RID: 1283 RVA: 0x0001633C File Offset: 0x0001453C
	public Vector3 GetNextPosition()
	{
		if (this.pointA == null || this.pointB == null)
		{
			return base.transform.position;
		}
		if (this.lerpFunc != null)
		{
			return this.lerpFunc(this.pointA.position, this.pointB.position, this.T);
		}
		if (this.lerpT != 0f)
		{
			return this.pointB.position;
		}
		return this.pointA.position;
	}

	// Token: 0x06000504 RID: 1284 RVA: 0x000163C8 File Offset: 0x000145C8
	public void GetDelta(Transform tf, out Vector3 positionDelta)
	{
		uint num;
		if (this.occupants.TryGetValue(tf, out num) && num <= 1U && this.setsBonusUI && (this.lerpT == 0f || (this.lerpT == 1f && !this.isOneWay)))
		{
			positionDelta = this._delta + new Vector3(base.transform.position.x - tf.position.x, 0f, 0f);
			return;
		}
		positionDelta = this._delta;
	}

	// Token: 0x06000505 RID: 1285 RVA: 0x0001645C File Offset: 0x0001465C
	public virtual void OnEnter(Transform tf)
	{
		if (this.occupants.ContainsKey(tf))
		{
			return;
		}
		if (this.lerpFunc == null && Clock.SynchronizedTime - this.timeLastTouched > Time.fixedDeltaTime)
		{
			this.occupants.Add(tf, 0U);
			if (this.safetyWalls && (this.setsBonusUI || BonusManager.instance.inBonus) && this.worldspaceSpeed > 0f && this.pointB != null && (this.lerpT == 0f || (this.lerpT == 1f && !this.isOneWay)))
			{
				this.safetyWalls.SetActive(true);
			}
			if (this.lerpT == 0f)
			{
				this._scheduledLerpFunc = new EditorBonusPlatform.LerpFunction(this.LerpForward);
				return;
			}
			if (this.lerpT == 1f)
			{
				if (!this.isOneWay)
				{
					this._scheduledLerpFunc = new EditorBonusPlatform.LerpFunction(this.LerpBackward);
					return;
				}
			}
			else
			{
				Debug.LogWarning(string.Format("{0} is in an invalid state", this), this);
			}
		}
	}

	// Token: 0x06000506 RID: 1286 RVA: 0x00016569 File Offset: 0x00014769
	public virtual void OnExit(Transform tf)
	{
		if (this.occupants.Remove(tf))
		{
			this.timeLastTouched = Clock.SynchronizedTime;
			this._scheduledLerpFunc = null;
		}
	}

	// Token: 0x06000507 RID: 1287 RVA: 0x0001658C File Offset: 0x0001478C
	public override void ResetEntity()
	{
		this.timeActivated = -1f;
		this.lerpT = this._rollbackLerpT;
		this.lerpFunc = null;
		this._delta = default(Vector3);
		base.transform.position = this.GetNextPosition();
		BonusManager.instance.bonusComplete = false;
		this.hasSetBonusUI = false;
		if (this.safetyWalls)
		{
			this.safetyWalls.SetActive(false);
		}
		base.ResetEntity();
	}

	// Token: 0x06000508 RID: 1288 RVA: 0x00016608 File Offset: 0x00014808
	public virtual void PlayModeChanged(bool isPlaying)
	{
		this._rollbackLerpT = 0f;
		this.timeActivated = -1f;
		this.lerpFunc = null;
		this.lerpT = 0f;
		this._delta = default(Vector3);
		base.transform.localPosition = Vector3.zero;
		if (isPlaying)
		{
			BonusManager.instance.ShowBonusUI(false);
		}
		BonusManager.instance.bonusComplete = false;
		this.hasSetBonusUI = false;
	}

	// Token: 0x06000509 RID: 1289 RVA: 0x0001667C File Offset: 0x0001487C
	public void SetBonusUI(bool setBonus)
	{
		if (BonusManager.instance.bonusComplete)
		{
			return;
		}
		if (setBonus)
		{
			if (BonusManager.instance.inBonus)
			{
				EditorBonusPlatform.<SetBonusUI>g__FinishBonus|35_0();
			}
			else
			{
				EditorBonusPlatform.<SetBonusUI>g__StartBonus|35_1();
			}
		}
		else if (BonusManager.instance.inBonus)
		{
			EditorBonusPlatform.<SetBonusUI>g__FinishBonus|35_0();
		}
		Debug.Log(string.Format("Set Bonus UI Called ({0} was passed in), the result was:{1}", setBonus, InterfaceManager.instance.bonusUI.activeSelf));
	}

	// Token: 0x0600050A RID: 1290 RVA: 0x000166F0 File Offset: 0x000148F0
	public void ProcessMetadata(EndpointMetadata meta)
	{
		if (meta.HasData)
		{
			Transform transform = base.transform.parent.Find("A");
			Transform transform2 = base.transform.parent.Find("B");
			if (transform == null)
			{
				GameObject gameObject = new GameObject("A");
				gameObject.transform.SetParent(base.transform.parent);
				transform = gameObject.transform;
			}
			transform.localPosition = Vector3.zero;
			this.pointA = transform;
			if (transform2 == null)
			{
				GameObject gameObject2 = new GameObject("B");
				gameObject2.transform.SetParent(base.transform.parent);
				transform2 = gameObject2.transform;
			}
			transform2.position = meta.Position;
			this.pointB = transform2;
			return;
		}
		this.pointA = null;
		this.pointB = null;
	}

	// Token: 0x0600050B RID: 1291 RVA: 0x000167D0 File Offset: 0x000149D0
	public void ProcessMetadata(SpeedMetadata meta)
	{
		this.worldspaceSpeed = (float)meta.speed;
	}

	// Token: 0x0600050C RID: 1292 RVA: 0x000167DF File Offset: 0x000149DF
	public void SetMusic(int index)
	{
		LevelInterfaceManager.instance.SetMusicForLevel(index);
	}

	// Token: 0x0600050D RID: 1293 RVA: 0x000167EC File Offset: 0x000149EC
	public void ProcessMetadata(MusicMetadata meta)
	{
		this.musicToSet = (int)meta.musicIndex;
	}

	// Token: 0x0600050E RID: 1294 RVA: 0x000167FA File Offset: 0x000149FA
	public void ProcessMetadata(OneWayMetadata meta)
	{
		this.isOneWay = meta.value;
	}

	// Token: 0x0600050F RID: 1295 RVA: 0x00016808 File Offset: 0x00014A08
	public void ProcessMetadata(BonusUIMetadata meta)
	{
		this.setsBonusUI = meta.value;
	}

	// Token: 0x06000511 RID: 1297 RVA: 0x0001684B File Offset: 0x00014A4B
	[CompilerGenerated]
	internal static void <SetBonusUI>g__FinishBonus|35_0()
	{
		BonusManager.instance.inBonus = false;
		CrashController.instance.inBonus = false;
		PickupHandler pickupHandler = CrashController.instance.pickupHandler;
		BonusManager.instance.AwardBonusPickups(0.1f);
		BonusManager.instance.bonusComplete = true;
	}

	// Token: 0x06000512 RID: 1298 RVA: 0x00016888 File Offset: 0x00014A88
	[CompilerGenerated]
	internal static void <SetBonusUI>g__StartBonus|35_1()
	{
		BonusManager.instance.ResetBonusCrates();
		BonusManager.instance.inBonus = true;
		CrashController.instance.inBonus = true;
		BonusManager.instance.ShowBonusUI(true);
	}

	// Token: 0x04000382 RID: 898
	public Transform pointA;

	// Token: 0x04000383 RID: 899
	public Transform pointB;

	// Token: 0x04000384 RID: 900
	public bool useWorldspaceSpeed;

	// Token: 0x04000385 RID: 901
	public float worldspaceSpeed = 1f;

	// Token: 0x04000386 RID: 902
	public bool isOneWay;

	// Token: 0x04000387 RID: 903
	[HideInInspector]
	public int musicToSet;

	// Token: 0x04000388 RID: 904
	public GameObject safetyWalls;

	// Token: 0x04000389 RID: 905
	public bool setsBonusUI;

	// Token: 0x0400038A RID: 906
	private bool hasSetBonusUI;

	// Token: 0x0400038B RID: 907
	protected Vector3 _delta;

	// Token: 0x0400038C RID: 908
	private float timeActivated = -1f;

	// Token: 0x0400038D RID: 909
	private EditorBonusPlatform.LerpFunction lerpFunc;

	// Token: 0x0400038E RID: 910
	private float lerpT;

	// Token: 0x0400038F RID: 911
	private EditorBonusPlatform.LerpFunction _scheduledLerpFunc;

	// Token: 0x04000390 RID: 912
	private bool lerpFinished;

	// Token: 0x04000391 RID: 913
	private readonly Dictionary<Transform, uint> occupants = new Dictionary<Transform, uint>(1);

	// Token: 0x04000392 RID: 914
	private float timeLastTouched = -1f;

	// Token: 0x04000393 RID: 915
	private float _rollbackLerpT;

	// Token: 0x0200020A RID: 522
	// (Invoke) Token: 0x0600131C RID: 4892
	private delegate Vector3 LerpFunction(Vector3 a, Vector3 b, float t);
}
