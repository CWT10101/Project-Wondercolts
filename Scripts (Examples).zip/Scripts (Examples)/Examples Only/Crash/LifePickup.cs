﻿using System;
using UnityEngine;

// Token: 0x020000D6 RID: 214
public class LifePickup : Pickup
{
	// Token: 0x06000648 RID: 1608 RVA: 0x0001B61C File Offset: 0x0001981C
	public override void OnTriggerEnter(Collider other)
	{
		PickupHandler pickupHandler;
		if (other.TryGetComponent<PickupHandler>(out pickupHandler))
		{
			if (!CrashController.instance.inBonus)
			{
				InterfaceManager.instance.hudTrack.ShowLives();
			}
			AudioManager.Play(this.pickupSFX, AudioManager.MixerTarget.UI, null, null);
			this.Despawn();
		}
	}
}
