﻿using System;
using System.IO;
using LevelEditor;

// Token: 0x02000032 RID: 50
public class ShootsOneMetadata : ObjectMetadata
{
	// Token: 0x17000049 RID: 73
	// (get) Token: 0x06000142 RID: 322 RVA: 0x00006864 File Offset: 0x00004A64
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x1700004A RID: 74
	// (get) Token: 0x06000143 RID: 323 RVA: 0x00006867 File Offset: 0x00004A67
	public override int Signature
	{
		get
		{
			return "ShootsOneMetadata".GetHashCode();
		}
	}

	// Token: 0x1700004B RID: 75
	// (get) Token: 0x06000144 RID: 324 RVA: 0x00006873 File Offset: 0x00004A73
	public override int ValueHash
	{
		get
		{
			if (!this.shootsOnce)
			{
				return -1;
			}
			return 1;
		}
	}

	// Token: 0x06000145 RID: 325 RVA: 0x00006880 File Offset: 0x00004A80
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<ShootsOneMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<ShootsOneMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x06000146 RID: 326 RVA: 0x000068AC File Offset: 0x00004AAC
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.shootsOnce = br.ReadBoolean();
	}

	// Token: 0x06000147 RID: 327 RVA: 0x000068BA File Offset: 0x00004ABA
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.shootsOnce);
	}

	// Token: 0x0400009D RID: 157
	public bool shootsOnce;
}
