﻿using System;
using UnityEngine;

// Token: 0x020000E6 RID: 230
public class MovingEnemy : Enemy
{
	// Token: 0x06000708 RID: 1800 RVA: 0x0001DF59 File Offset: 0x0001C159
	protected override void FixedUpdate()
	{
		base.FixedUpdate();
		base.transform.position = this.GetNextPosition();
	}

	// Token: 0x06000709 RID: 1801 RVA: 0x0001DF72 File Offset: 0x0001C172
	public virtual Vector3 GetNextPosition()
	{
		return Vector3.Lerp(this.pointA.position, this.pointB.position, this.speedCurve.Evaluate(Time.time));
	}

	// Token: 0x0600070A RID: 1802 RVA: 0x0001DFA0 File Offset: 0x0001C1A0
	private void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			if (crashController.animator.currentState == crashController.animator.spinObj || crashController.animator.currentState == crashController.animator.slideObj)
			{
				return;
			}
			crashController.TakeDamage(0);
		}
	}

	// Token: 0x0400054A RID: 1354
	public Transform pointA;

	// Token: 0x0400054B RID: 1355
	public Transform pointB;

	// Token: 0x0400054C RID: 1356
	public AnimationCurve speedCurve;
}
