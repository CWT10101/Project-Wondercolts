﻿using System;
using UnityEngine;

// Token: 0x0200014D RID: 333
public class FollowTarget : MonoBehaviour
{
	// Token: 0x060009C0 RID: 2496 RVA: 0x0002768E File Offset: 0x0002588E
	private void Update()
	{
		if (this.target)
		{
			base.transform.position = this.target.position;
		}
	}

	// Token: 0x04000713 RID: 1811
	public Transform target;
}
