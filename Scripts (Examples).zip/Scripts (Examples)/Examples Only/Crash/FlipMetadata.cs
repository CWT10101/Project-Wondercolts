﻿using System;
using System.IO;
using LevelEditor;
using UnityEngine;

// Token: 0x02000029 RID: 41
public class FlipMetadata : ObjectMetadata
{
	// Token: 0x17000028 RID: 40
	// (get) Token: 0x060000F4 RID: 244 RVA: 0x00006226 File Offset: 0x00004426
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x060000F5 RID: 245 RVA: 0x00006229 File Offset: 0x00004429
	public override int Signature
	{
		get
		{
			return "FlipMetadata".GetHashCode();
		}
	}

	// Token: 0x1700002A RID: 42
	// (get) Token: 0x060000F6 RID: 246 RVA: 0x00006235 File Offset: 0x00004435
	public override int ValueHash
	{
		get
		{
			if (!this.isFlipped)
			{
				return -1;
			}
			return 1;
		}
	}

	// Token: 0x060000F7 RID: 247 RVA: 0x00006244 File Offset: 0x00004444
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<FlipMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<FlipMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
		obj.editorVis.transform.localEulerAngles = (obj.gameplayVis.transform.localEulerAngles = (this.isFlipped ? new Vector3(0f, 180f, 0f) : Vector3.zero));
	}

	// Token: 0x060000F8 RID: 248 RVA: 0x000062B6 File Offset: 0x000044B6
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.isFlipped = br.ReadBoolean();
	}

	// Token: 0x060000F9 RID: 249 RVA: 0x000062C4 File Offset: 0x000044C4
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.isFlipped);
	}

	// Token: 0x0400008D RID: 141
	public bool isFlipped;
}
