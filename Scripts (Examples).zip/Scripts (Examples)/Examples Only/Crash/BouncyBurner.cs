﻿using System;
using UnityEngine;

// Token: 0x02000078 RID: 120
public class BouncyBurner : Entity, IFallOn, ISpin, IMetadataReceiver<PhaseMetadata>
{
	// Token: 0x17000094 RID: 148
	// (get) Token: 0x06000365 RID: 869 RVA: 0x0000ED92 File Offset: 0x0000CF92
	private float CycleLength
	{
		get
		{
			return this.durationOff + this.durationOn;
		}
	}

	// Token: 0x06000366 RID: 870 RVA: 0x0000EDA1 File Offset: 0x0000CFA1
	private void Awake()
	{
		this.particleBaseScale = this.hazardParticle.transform.localScale;
	}

	// Token: 0x06000367 RID: 871 RVA: 0x0000EDBC File Offset: 0x0000CFBC
	private void FixedUpdate()
	{
		float num = this.offset * this.CycleLength;
		float num2 = Clock.SynchronizedTime + num - Time.fixedDeltaTime;
		float num3 = Clock.SynchronizedTime + num;
		num2 %= this.CycleLength;
		num3 %= this.CycleLength;
		this.hazard.SetActive(num3 > this.durationOff);
		this.hazardParticle.transform.localScale = this.particleBaseScale * this.particleScaleCurve.Evaluate(num3);
		this.lightSource.radius = this.lightRadiusCurve.Evaluate(num3);
		if (num2 < this.igniteAudioTime && num3 >= this.igniteAudioTime)
		{
			this.igniteAudioSrc.Play();
			return;
		}
		if (num2 < this.flameAudioTime && num3 >= this.flameAudioTime)
		{
			this.flameAudioSrc.Play();
		}
	}

	// Token: 0x06000368 RID: 872 RVA: 0x0000EE8C File Offset: 0x0000D08C
	public void FallOn(CrashController crash)
	{
		crash.ArrowBounce(true);
	}

	// Token: 0x06000369 RID: 873 RVA: 0x0000EE95 File Offset: 0x0000D095
	public void Spin(CrashController crash)
	{
	}

	// Token: 0x0600036A RID: 874 RVA: 0x0000EE97 File Offset: 0x0000D097
	public void ProcessMetadata(PhaseMetadata meta)
	{
		this.offset = meta.NormalizedValue;
	}

	// Token: 0x04000236 RID: 566
	public GameObject hazard;

	// Token: 0x04000237 RID: 567
	public ParticleSystem hazardParticle;

	// Token: 0x04000238 RID: 568
	public LightSource lightSource;

	// Token: 0x04000239 RID: 569
	public AudioSource igniteAudioSrc;

	// Token: 0x0400023A RID: 570
	public AudioSource flameAudioSrc;

	// Token: 0x0400023B RID: 571
	public AnimationCurve particleScaleCurve;

	// Token: 0x0400023C RID: 572
	public AnimationCurve lightRadiusCurve;

	// Token: 0x0400023D RID: 573
	public float durationOn;

	// Token: 0x0400023E RID: 574
	public float durationOff;

	// Token: 0x0400023F RID: 575
	public float igniteAudioTime;

	// Token: 0x04000240 RID: 576
	public float flameAudioTime;

	// Token: 0x04000241 RID: 577
	public float offset;

	// Token: 0x04000242 RID: 578
	private Vector3 particleBaseScale;
}
