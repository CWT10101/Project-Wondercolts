﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using Cinemachine;
using LevelEditor;
using UnityEngine;

// Token: 0x02000063 RID: 99
public class BonusManager : MonoBehaviour
{
	// Token: 0x06000267 RID: 615 RVA: 0x0000AC70 File Offset: 0x00008E70
	private void Awake()
	{
		BonusManager.instance = this;
	}

	// Token: 0x06000268 RID: 616 RVA: 0x0000AC78 File Offset: 0x00008E78
	public void ShowBonusUI(bool show)
	{
		InterfaceManager.instance.ShowBonusUI(show);
		if (LevelInterfaceManager.instance)
		{
			if (!show)
			{
				LevelInterfaceManager.instance.boxCollectionObject.SetActive(LevelInterfaceManager.instance.currentLevelType != 2 && LevelInterfaceManager.instance.maxBoxCount > 0);
				return;
			}
			LevelInterfaceManager.instance.boxCollectionObject.SetActive(false);
		}
	}

	// Token: 0x06000269 RID: 617 RVA: 0x0000ACDC File Offset: 0x00008EDC
	public void AwardBonusPickups(float waitTime)
	{
		BonusManager.<>c__DisplayClass16_0 CS$<>8__locals1 = new BonusManager.<>c__DisplayClass16_0();
		CS$<>8__locals1.waitTime = waitTime;
		CS$<>8__locals1.<>4__this = this;
		CS$<>8__locals1.pickups = CrashController.instance.pickupHandler;
		base.StartCoroutine(CS$<>8__locals1.<AwardBonusPickups>g__WumpaRoutine|0());
		base.StartCoroutine(CS$<>8__locals1.<AwardBonusPickups>g__LivesRoutine|1());
		base.StartCoroutine(CS$<>8__locals1.<AwardBonusPickups>g__WaitAndDisableUI|2());
	}

	// Token: 0x0600026A RID: 618 RVA: 0x0000AD34 File Offset: 0x00008F34
	public void LoseBonusPickups(float waitTime)
	{
		BonusManager.<>c__DisplayClass17_0 CS$<>8__locals1 = new BonusManager.<>c__DisplayClass17_0();
		CS$<>8__locals1.waitTime = waitTime;
		CS$<>8__locals1.<>4__this = this;
		base.StartCoroutine(CS$<>8__locals1.<LoseBonusPickups>g__WumpaRoutine|0());
		base.StartCoroutine(CS$<>8__locals1.<LoseBonusPickups>g__LivesRoutine|1());
	}

	// Token: 0x0600026B RID: 619 RVA: 0x0000AD70 File Offset: 0x00008F70
	public void OnBonusStartPlatform(bool followCrash = true)
	{
		if (!this.bonusComplete && !this.inBonus)
		{
			foreach (TNTCrate tntcrate in Level.instance.GetComponentsInChildren<TNTCrate>())
			{
				if (tntcrate.lit)
				{
					tntcrate.Explode();
				}
			}
			this.SetBonusCrateCount();
			this.bonusLevelObj.SetActive(true);
			this.endPlatform.transform.parent.gameObject.SetActive(true);
			if (followCrash)
			{
				CameraManager.instance.SetVCam(this.bonusCam);
			}
			else
			{
				Camera.main.GetComponent<CinemachineBrain>().enabled = false;
				base.StartCoroutine(BonusManager.<OnBonusStartPlatform>g__FadeRoutine|18_0());
			}
			this.startPlatform.SetActive();
			this.startPlatform.SetSafetyWallsEnabled(true);
			CrashController.instance.inBonus = true;
			CrashController.instance.locomotionOnly = true;
			EntityTracker.SetCache();
			this.inBonus = true;
		}
	}

	// Token: 0x0600026C RID: 620 RVA: 0x0000AE55 File Offset: 0x00009055
	public void AddBonusCrate()
	{
		this.currentCrates++;
		this.SetBonusCrateCount();
	}

	// Token: 0x0600026D RID: 621 RVA: 0x0000AE6B File Offset: 0x0000906B
	public void ResetBonusCrates()
	{
		this.currentCrates = 0;
		this.SetBonusCrateCount();
	}

	// Token: 0x0600026E RID: 622 RVA: 0x0000AE7A File Offset: 0x0000907A
	public void ResetBonusLivesAndWumpa()
	{
		InterfaceManager.instance.bonusWumpaCount.text = string.Format("{0}", 0);
		InterfaceManager.instance.bonusLivesCount.text = string.Format("{0}", 0);
	}

	// Token: 0x0600026F RID: 623 RVA: 0x0000AEBC File Offset: 0x000090BC
	public void SetBonusCrateCount()
	{
		if (Level.instance)
		{
			InterfaceManager.instance.bonusCrateCount.text = string.Format("{0:00}/{1}", this.currentCrates, this.crateCount);
			return;
		}
		if (LevelManager.instance)
		{
			InterfaceManager.instance.bonusCrateCount.text = string.Format("{0:00}/{1:00}", LevelInterfaceManager.instance.boxesCollected, LevelInterfaceManager.instance.maxBoxCount);
		}
	}

	// Token: 0x06000270 RID: 624 RVA: 0x0000AF48 File Offset: 0x00009148
	public void StartBonus(bool followedCrash = true)
	{
		if (!followedCrash)
		{
			InterfaceManager.instance.fadeScreen.FadeToAlpha();
			Camera.main.GetComponent<CinemachineBrain>().enabled = true;
		}
		CameraManager.instance.SetVCam(this.bonusCam);
		this.ShowBonusUI(true);
		this.SetBonusCrateCount();
		this.invisibleSideWalls.SetActive(true);
		this.bonusDeathTriggerObj.SetActive(true);
		this.startPlatform.SetSafetyWallsEnabled(false);
		CrashController.instance.locomotionOnly = false;
		AudioManager.PlayMusic(this.bonusMusic, 1f);
	}

	// Token: 0x06000271 RID: 625 RVA: 0x0000AFD4 File Offset: 0x000091D4
	public void OnBonusEndPlatform(bool followCrash = true)
	{
		if (!this.bonusComplete)
		{
			foreach (TNTCrate tntcrate in base.GetComponentsInChildren<TNTCrate>())
			{
				if (tntcrate.lit)
				{
					tntcrate.Explode();
				}
			}
			this.SetBonusCrateCount();
			this.bonusComplete = true;
			this.startPlatform.gameObject.SetActive(false);
			this.inBonus = false;
			CrashController.instance.inBonus = false;
			this.AwardBonusPickups(0.1f);
			CrashController.instance.locomotionOnly = true;
			this.invisibleSideWalls.SetActive(false);
			this.bonusDeathTriggerObj.SetActive(false);
			this.endPlatform.SetActive();
			this.endPlatform.SetSafetyWallsEnabled(true);
			if (!followCrash)
			{
				Camera.main.GetComponent<CinemachineBrain>().enabled = false;
				base.StartCoroutine(this.<OnBonusEndPlatform>g__FadeRoutine|24_0());
			}
		}
	}

	// Token: 0x06000272 RID: 626 RVA: 0x0000B0A8 File Offset: 0x000092A8
	public void EndBonus(bool followedCrash = true)
	{
		AudioManager.SwapMusic(1f);
		this.ShowBonusUI(false);
		this.bonusLevelObj.SetActive(false);
		CameraManager.instance.SetVCam(this.mainCam);
		this.endPlatform.SetSafetyWallsEnabled(false);
		CrashController.instance.locomotionOnly = false;
		this.SetBonusCheckpoint();
	}

	// Token: 0x06000273 RID: 627 RVA: 0x0000B101 File Offset: 0x00009301
	public void SetBonusCheckpoint()
	{
		CrashSpawner.instance.crashSpawnPoint.position = this.bonusRespawnPoint.position;
		EntityTracker.Dump();
	}

	// Token: 0x06000274 RID: 628 RVA: 0x0000B122 File Offset: 0x00009322
	public void BonusDeath(float length)
	{
		base.StartCoroutine(this.BonusDeathRoutine(length));
	}

	// Token: 0x06000275 RID: 629 RVA: 0x0000B132 File Offset: 0x00009332
	public IEnumerator BonusDeathRoutine(float length)
	{
		if (Level.instance)
		{
			this.LoseBonusPickups(0.025f);
			yield return new WaitForSeconds(length / 2f);
			InterfaceManager.instance.fadeScreen.FadeToColour(Color.black);
			yield return new WaitForSeconds(length / 2f);
			AudioManager.SwapMusic(1f);
			this.ResetBonusCrates();
			Level.instance.levelObject.SetActive(true);
			this.bonusLevelObj.SetActive(false);
			this.endPlatform.transform.parent.gameObject.SetActive(true);
			CameraManager.instance.SetVCam(this.mainCam);
			this.startPlatform.ResetTime();
			this.startPlatform.SetSafetyWallsEnabled(false);
			CrashController.instance.inBonus = false;
			this.invisibleSideWalls.SetActive(false);
			this.bonusDeathTriggerObj.SetActive(false);
			this.inBonus = false;
		}
		else if (LevelManager.instance)
		{
			this.LoseBonusPickups(0.05f);
			yield return new WaitForSeconds(length / 2f);
			this.ResetBonusCrates();
			CrashController.instance.inBonus = false;
			this.inBonus = false;
		}
		yield break;
	}

	// Token: 0x06000277 RID: 631 RVA: 0x0000B163 File Offset: 0x00009363
	[CompilerGenerated]
	internal static IEnumerator <OnBonusStartPlatform>g__FadeRoutine|18_0()
	{
		yield return new WaitForSeconds(1f);
		InterfaceManager.instance.fadeScreen.FadeToColour(Color.black);
		yield break;
	}

	// Token: 0x06000278 RID: 632 RVA: 0x0000B16B File Offset: 0x0000936B
	[CompilerGenerated]
	private IEnumerator <OnBonusEndPlatform>g__FadeRoutine|24_0()
	{
		yield return new WaitForSeconds(1f);
		InterfaceManager.instance.fadeScreen.FadeToColour(Color.black);
		yield return new WaitForSeconds(1f);
		CameraManager.instance.SetVCam(this.mainCam);
		InterfaceManager.instance.fadeScreen.FadeToAlpha();
		Camera.main.GetComponent<CinemachineBrain>().enabled = true;
		yield break;
	}

	// Token: 0x0400015F RID: 351
	public static BonusManager instance;

	// Token: 0x04000160 RID: 352
	public bool bonusComplete;

	// Token: 0x04000161 RID: 353
	public BonusPlatform startPlatform;

	// Token: 0x04000162 RID: 354
	public BonusPlatform endPlatform;

	// Token: 0x04000163 RID: 355
	public Transform bonusRespawnPoint;

	// Token: 0x04000164 RID: 356
	public GameObject bonusLevelObj;

	// Token: 0x04000165 RID: 357
	public GameObject invisibleSideWalls;

	// Token: 0x04000166 RID: 358
	public CinemachineVirtualCameraBase bonusCam;

	// Token: 0x04000167 RID: 359
	public CinemachineVirtualCameraBase mainCam;

	// Token: 0x04000168 RID: 360
	public GameObject bonusDeathTriggerObj;

	// Token: 0x04000169 RID: 361
	public bool inBonus;

	// Token: 0x0400016A RID: 362
	public int crateCount = 18;

	// Token: 0x0400016B RID: 363
	[HideInInspector]
	public int currentCrates;

	// Token: 0x0400016C RID: 364
	public string bonusMusic = "TawnaBonusBGM";
}
