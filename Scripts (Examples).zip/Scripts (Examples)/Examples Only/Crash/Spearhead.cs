﻿using System;
using UnityEngine;

// Token: 0x0200011C RID: 284
[DefaultExecutionOrder(10)]
public class Spearhead : MonoBehaviour
{
	// Token: 0x060008B3 RID: 2227 RVA: 0x00024570 File Offset: 0x00022770
	private void FixedUpdate()
	{
		this.trigger.enabled = (this.log.transform.localScale.y >= this.triggerThreshold);
		base.transform.localScale = this.scaleRef.InverseTransformVector(this.scaleVec);
	}

	// Token: 0x0400065A RID: 1626
	public Log log;

	// Token: 0x0400065B RID: 1627
	public Collider trigger;

	// Token: 0x0400065C RID: 1628
	public float triggerThreshold;

	// Token: 0x0400065D RID: 1629
	public Transform scaleRef;

	// Token: 0x0400065E RID: 1630
	public Vector3 scaleVec;
}
