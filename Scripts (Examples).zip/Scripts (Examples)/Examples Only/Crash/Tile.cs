﻿using System;
using LevelEditor;
using UnityEngine;

// Token: 0x0200003B RID: 59
public class Tile
{
	// Token: 0x17000062 RID: 98
	// (get) Token: 0x0600018C RID: 396 RVA: 0x000070BE File Offset: 0x000052BE
	public Vector3 Position { get; }

	// Token: 0x0600018D RID: 397 RVA: 0x000070C6 File Offset: 0x000052C6
	public Tile(int x, int y)
	{
		this.posX = x;
		this.posY = y;
		this.Position = new Vector3((float)x, (float)y, 0f);
	}

	// Token: 0x040000B7 RID: 183
	public int posX;

	// Token: 0x040000B8 RID: 184
	public int posY;

	// Token: 0x040000B9 RID: 185
	public LevelObj placedObj;
}
