﻿using System;
using System.IO;
using LevelEditor3D;
using TMPro;
using UnityEngine;

// Token: 0x0200000E RID: 14
public class LoadLevel3DButton : MonoBehaviour
{
	// Token: 0x0600003F RID: 63 RVA: 0x0000347F File Offset: 0x0000167F
	public void LoadLevel()
	{
		UIScreen.Focus(LevelInterfaceManager3D.Instance.editorHUD);
		LevelSerializer3D.LoadLevel(Path.Combine(LevelSerializer3D.InternalPath, this.levelName));
	}

	// Token: 0x04000035 RID: 53
	public TMP_Text text;

	// Token: 0x04000036 RID: 54
	public string levelName;
}
