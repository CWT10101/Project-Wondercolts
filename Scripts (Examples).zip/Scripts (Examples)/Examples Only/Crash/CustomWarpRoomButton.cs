﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x02000092 RID: 146
public class CustomWarpRoomButton : MonoBehaviour
{
	// Token: 0x170000B9 RID: 185
	// (get) Token: 0x0600045D RID: 1117 RVA: 0x00013FE0 File Offset: 0x000121E0
	private MaterialPropertyBlock MatProps
	{
		get
		{
			if (this._matProps == null)
			{
				this._matProps = new MaterialPropertyBlock();
			}
			return this._matProps;
		}
	}

	// Token: 0x170000BA RID: 186
	// (get) Token: 0x0600045E RID: 1118 RVA: 0x00013FFB File Offset: 0x000121FB
	private static int ButtonColorID
	{
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		get
		{
			return Shader.PropertyToID("_ButtonColor");
		}
	}

	// Token: 0x0600045F RID: 1119 RVA: 0x00014007 File Offset: 0x00012207
	private void Awake()
	{
		this.SetButtonColor(this.inactiveColour);
	}

	// Token: 0x06000460 RID: 1120 RVA: 0x00014015 File Offset: 0x00012215
	public void SetLevelString(string input)
	{
		this.levelString = input;
		this.validLevel = this.CheckForLevelExisting();
		this.SetButtonColor(this.validLevel ? this.defaultColour : this.inactiveColour);
	}

	// Token: 0x06000461 RID: 1121 RVA: 0x00014048 File Offset: 0x00012248
	private void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			this.PressDown();
		}
	}

	// Token: 0x06000462 RID: 1122 RVA: 0x00014068 File Offset: 0x00012268
	private void OnTriggerStay(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController) && this.validLevel)
		{
			WarpRoom.instance.customWarpRoom.overlayCanvas.timer = 3f;
		}
	}

	// Token: 0x06000463 RID: 1123 RVA: 0x000140A0 File Offset: 0x000122A0
	private void OnTriggerExit(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			this.Release();
		}
	}

	// Token: 0x06000464 RID: 1124 RVA: 0x000140C0 File Offset: 0x000122C0
	public void PressDown()
	{
		AudioManager.Play("SFX_WarpButtonClick", AudioManager.MixerTarget.SFX, null, null);
		this.SetButtonColor(this.validLevel ? this.pressedColour : this.inactivePressedColour);
		this.SetWarpSphere();
		if (this.validLevel)
		{
			LevelSerializer.LevelHeader header = LevelSerializer.GetHeader(this.levelString);
			WarpRoom.instance.customWarpRoom.overlayCanvas.ShowScreen(3, header);
			return;
		}
		WarpRoom.instance.customWarpRoom.overlayCanvas.timer = 0f;
	}

	// Token: 0x06000465 RID: 1125 RVA: 0x00014154 File Offset: 0x00012354
	public bool CheckForLevelExisting()
	{
		bool result = false;
		using (List<string>.Enumerator enumerator = LevelSerializer.instance.userCreatedList.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if (enumerator.Current == this.levelString)
				{
					result = true;
					break;
				}
			}
		}
		return result;
	}

	// Token: 0x06000466 RID: 1126 RVA: 0x000141B8 File Offset: 0x000123B8
	public void Release()
	{
		this.SetButtonColor(this.validLevel ? this.defaultColour : this.inactiveColour);
	}

	// Token: 0x06000467 RID: 1127 RVA: 0x000141D8 File Offset: 0x000123D8
	public void SetWarpSphere()
	{
		if (this.validLevel)
		{
			WarpRoom.instance.customWarpRoom.warpSphere.gameObject.SetActive(false);
			WarpRoom.instance.customWarpRoom.warpSphere.destination = this.levelString;
			AudioManager.Play("SFX_WarpSphereAppear", AudioManager.MixerTarget.SFX, null, null);
		}
		else
		{
			WarpRoom.instance.customWarpRoom.warpSphere.destination = "";
			if (WarpRoom.instance.customWarpRoom.warpSphere.gameObject.activeInHierarchy)
			{
				AudioManager.Play("SFX_WarpSphereDisappear", AudioManager.MixerTarget.SFX, null, null);
			}
		}
		WarpRoom.instance.customWarpRoom.warpSphere.gameObject.SetActive(this.validLevel);
	}

	// Token: 0x06000468 RID: 1128 RVA: 0x000142B2 File Offset: 0x000124B2
	public void SetButtonColor(Color c)
	{
		this.MatProps.SetColor(CustomWarpRoomButton.ButtonColorID, c);
		this.buttonMesh.SetPropertyBlock(this.MatProps);
	}

	// Token: 0x04000309 RID: 777
	public Color defaultColour;

	// Token: 0x0400030A RID: 778
	public Color pressedColour;

	// Token: 0x0400030B RID: 779
	public Color inactiveColour;

	// Token: 0x0400030C RID: 780
	public Color inactivePressedColour;

	// Token: 0x0400030D RID: 781
	public MeshRenderer buttonMesh;

	// Token: 0x0400030E RID: 782
	public string levelString;

	// Token: 0x0400030F RID: 783
	private bool validLevel;

	// Token: 0x04000310 RID: 784
	private MaterialPropertyBlock _matProps;
}
