﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200003E RID: 62
public class CameraMovement : MonoBehaviour
{
	// Token: 0x06000196 RID: 406 RVA: 0x000072BC File Offset: 0x000054BC
	private void Start()
	{
		this.cam = base.GetComponent<Camera>();
		Cursor.lockState = CursorLockMode.Locked;
		Cursor.visible = false;
		this.menuEnabled = false;
		this.menu.SetActive(this.menuEnabled);
	}

	// Token: 0x06000197 RID: 407 RVA: 0x000072F0 File Offset: 0x000054F0
	private void Update()
	{
		this.infoText.text = "";
		if (Input.GetKeyDown(KeyCode.Q))
		{
			this.menuEnabled = !this.menuEnabled;
			this.menu.SetActive(this.menuEnabled);
			Cursor.lockState = (this.menuEnabled ? CursorLockMode.None : CursorLockMode.Locked);
			Cursor.visible = this.menuEnabled;
		}
		if (!this.menuEnabled)
		{
			base.transform.Rotate(-Input.GetAxis("Mouse Y") * this.sensitivity, 0f, 0f);
			base.transform.parent.Rotate(0f, Input.GetAxis("Mouse X") * this.sensitivity, 0f);
			RaycastHit raycastHit;
			if (Physics.Raycast(this.cam.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f)), out raycastHit))
			{
				DemoInfo component = raycastHit.transform.GetComponent<DemoInfo>();
				if (component)
				{
					this.infoText.text = "- " + component.info + " -";
				}
				if (Input.GetKeyDown(KeyCode.E))
				{
					if (raycastHit.transform.name == "DMOn")
					{
						Object.FindObjectOfType<PlayerMovement>().ToggleDemoMode(true);
					}
					if (raycastHit.transform.name == "DMOff")
					{
						Object.FindObjectOfType<PlayerMovement>().ToggleDemoMode(false);
					}
				}
			}
		}
	}

	// Token: 0x040000C0 RID: 192
	public float sensitivity = 10f;

	// Token: 0x040000C1 RID: 193
	public Text infoText;

	// Token: 0x040000C2 RID: 194
	public GameObject menu;

	// Token: 0x040000C3 RID: 195
	private Camera cam;

	// Token: 0x040000C4 RID: 196
	private bool menuEnabled;
}
