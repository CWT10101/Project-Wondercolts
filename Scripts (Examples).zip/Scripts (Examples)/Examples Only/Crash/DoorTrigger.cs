﻿using System;
using UnityEngine;

// Token: 0x020000A1 RID: 161
public class DoorTrigger : MonoBehaviour
{
	// Token: 0x060004E6 RID: 1254 RVA: 0x00015A00 File Offset: 0x00013C00
	public void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (this.door.IsClosed && other.TryGetComponent<CrashController>(out crashController))
		{
			this.door.Open();
		}
	}

	// Token: 0x04000363 RID: 867
	public Door door;
}
