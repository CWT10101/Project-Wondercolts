﻿using System;
using System.Collections;
using LevelEditor;
using UnityEngine;

// Token: 0x0200004A RID: 74
public class Aku : Mask
{
	// Token: 0x060001F8 RID: 504 RVA: 0x00009020 File Offset: 0x00007220
	private void OnEnable()
	{
		if (LevelInterfaceManager.instance)
		{
			this.ToggleGhost(LevelInterfaceManager.instance.currentWeather == 3);
		}
	}

	// Token: 0x060001F9 RID: 505 RVA: 0x00009044 File Offset: 0x00007244
	public override void OnTriggerEnter(Collider other)
	{
		PickupHandler pickupHandler;
		if (other.TryGetComponent<PickupHandler>(out pickupHandler))
		{
			pickupHandler.CollectAku(this);
		}
		base.OnTriggerEnter(other);
	}

	// Token: 0x060001FA RID: 506 RVA: 0x0000906C File Offset: 0x0000726C
	public void ToggleGhost(bool isGhost)
	{
		if (isGhost)
		{
			Material[] sharedMaterials = this.defaultState.GetComponent<Renderer>().sharedMaterials;
			sharedMaterials[1] = this.GhostMaterial;
			this.defaultState.GetComponent<Renderer>().sharedMaterials = sharedMaterials;
			return;
		}
		Material[] sharedMaterials2 = this.defaultState.GetComponent<Renderer>().sharedMaterials;
		sharedMaterials2[1] = this.defaultMaterial;
		this.defaultState.GetComponent<Renderer>().sharedMaterials = sharedMaterials2;
	}

	// Token: 0x060001FB RID: 507 RVA: 0x000090D3 File Offset: 0x000072D3
	private void OnDestroy()
	{
		if (this.invincibileMode)
		{
			this.CancelInvincibleMode();
		}
	}

	// Token: 0x060001FC RID: 508 RVA: 0x000090E4 File Offset: 0x000072E4
	public void Upgrade(bool SFX = true)
	{
		if (this.hitCounter < 3)
		{
			if (SFX)
			{
				AudioManager.Play("SFX_CollectMask", AudioManager.MixerTarget.SFX, null, null);
			}
			this.hitCounter++;
			this.goldState.SetActive(true);
			this.defaultState.SetActive(false);
		}
		if (this.hitCounter == 3)
		{
			if (!this.invincibileMode)
			{
				this.EnableInvincibleMode();
				return;
			}
		}
		else
		{
			Debug.Log("Already fully Upgraded");
		}
	}

	// Token: 0x060001FD RID: 509 RVA: 0x00009163 File Offset: 0x00007363
	public void EnableInvincibleMode()
	{
		if (!this.invincibileMode)
		{
			base.StartCoroutine(this.InvincibleRoutine());
		}
	}

	// Token: 0x060001FE RID: 510 RVA: 0x0000917C File Offset: 0x0000737C
	public void CancelInvincibleMode()
	{
		if (!this.invincibileMode)
		{
			return;
		}
		AudioManager.PitchUnpauseMusic();
		this.invincibileMode = false;
		Shader.DisableKeyword("CRASH_STATE_INVINCIBLE");
		this.invincibilityAudioSource.Stop();
		InterfaceManager.UnsubscribeFromPause(new Action<bool>(this.OnPauseCallback));
		CrashController.instance.pickupHandler.invincibilityMask.SetActive(false);
	}

	// Token: 0x060001FF RID: 511 RVA: 0x000091D9 File Offset: 0x000073D9
	public IEnumerator InvincibleRoutine()
	{
		CrashController.instance.animator.SetState(CrashController.instance.animator.wearAkuObj, false);
		CrashController.instance.StopAscent();
		yield return new WaitForSeconds(0.75f);
		CrashController.instance.pickupHandler.invincibilityMask.SetActive(true);
		this.invincibileMode = true;
		this.visual.SetActive(false);
		AudioManager.PitchPauseMusic();
		InterfaceManager.SubscribeToPause(new Action<bool>(this.OnPauseCallback));
		this.invincibilityAudioSource.Play();
		Shader.EnableKeyword("CRASH_STATE_INVINCIBLE");
		float t = Time.time;
		while (this.invincibileMode && Time.time - t < this.invincibilityDuration)
		{
			yield return null;
		}
		if (Time.time - t >= this.invincibilityDuration)
		{
			this.invincibilityAudioSource.Stop();
		}
		Shader.DisableKeyword("CRASH_STATE_INVINCIBLE");
		AudioManager.PitchUnpauseMusic();
		InterfaceManager.UnsubscribeFromPause(new Action<bool>(this.OnPauseCallback));
		this.invincibileMode = false;
		this.visual.SetActive(true);
		CrashController.instance.pickupHandler.invincibilityMask.SetActive(false);
		this.Downgrade();
		yield break;
	}

	// Token: 0x06000200 RID: 512 RVA: 0x000091E8 File Offset: 0x000073E8
	private void OnPauseCallback(bool paused)
	{
		if (this.invincibilityAudioSource)
		{
			this.invincibilityAudioSource.pitch = (float)(paused ? 0 : 1);
		}
	}

	// Token: 0x06000201 RID: 513 RVA: 0x0000920C File Offset: 0x0000740C
	public void Downgrade()
	{
		if (this.hitCounter > 1)
		{
			AudioManager.Play("SFX_LoseMask", AudioManager.MixerTarget.SFX, null, null);
			this.hitCounter--;
			this.goldState.SetActive(false);
			this.defaultState.SetActive(true);
		}
		if (this.hitCounter == 2)
		{
			this.goldState.SetActive(true);
			this.defaultState.SetActive(false);
		}
	}

	// Token: 0x0400010A RID: 266
	public AudioSource invincibilityAudioSource;

	// Token: 0x0400010B RID: 267
	public GameObject defaultState;

	// Token: 0x0400010C RID: 268
	public GameObject goldState;

	// Token: 0x0400010D RID: 269
	public Material defaultMaterial;

	// Token: 0x0400010E RID: 270
	public Material GhostMaterial;

	// Token: 0x0400010F RID: 271
	public int hitCounter = 1;

	// Token: 0x04000110 RID: 272
	public bool invincibileMode;

	// Token: 0x04000111 RID: 273
	public float invincibilityDuration = 21f;
}
