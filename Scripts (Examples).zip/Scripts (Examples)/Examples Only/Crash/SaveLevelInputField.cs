﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200003A RID: 58
public class SaveLevelInputField : MonoBehaviour
{
	// Token: 0x0600018A RID: 394 RVA: 0x0000709F File Offset: 0x0000529F
	public void SaveLevel()
	{
		LevelSerializer.instance.SaveLevelButton(this.inputField.text);
	}

	// Token: 0x040000B6 RID: 182
	public TMP_InputField inputField;
}
