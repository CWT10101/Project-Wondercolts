﻿using System;
using UnityEngine;

// Token: 0x02000089 RID: 137
public class Conveyor : MonoBehaviour, IPlatform, IMetadataReceiver<SpeedMetadata>, IMetadataReceiver<FlipMetadata>
{
	// Token: 0x060003C5 RID: 965 RVA: 0x0000FCD4 File Offset: 0x0000DED4
	public void GetDelta(Transform tf, out Vector3 positionDelta)
	{
		positionDelta = base.transform.right * this.speed * Time.fixedDeltaTime;
	}

	// Token: 0x060003C6 RID: 966 RVA: 0x0000FCFC File Offset: 0x0000DEFC
	public Vector3 GetNextPosition()
	{
		return base.transform.position;
	}

	// Token: 0x060003C7 RID: 967 RVA: 0x0000FD09 File Offset: 0x0000DF09
	public void OnEnter(Transform tf)
	{
	}

	// Token: 0x060003C8 RID: 968 RVA: 0x0000FD0B File Offset: 0x0000DF0B
	public void OnExit(Transform tf)
	{
	}

	// Token: 0x060003C9 RID: 969 RVA: 0x0000FD10 File Offset: 0x0000DF10
	private void SetMats()
	{
		Material[] sharedMaterials = this.ren.sharedMaterials;
		sharedMaterials[this.beltMatIndex] = (this.flipValue ? ResourceManager.instance.conveyorBeltMatsBlue[(int)this.speedValue] : ResourceManager.instance.conveyorBeltMatsGreen[(int)this.speedValue]);
		this.ren.sharedMaterials = sharedMaterials;
	}

	// Token: 0x060003CA RID: 970 RVA: 0x0000FD69 File Offset: 0x0000DF69
	public void ProcessMetadata(SpeedMetadata meta)
	{
		this.speedValue = meta.speed;
		this.speed = (float)meta.speed;
		this.SetMats();
	}

	// Token: 0x060003CB RID: 971 RVA: 0x0000FD8A File Offset: 0x0000DF8A
	public void ProcessMetadata(FlipMetadata meta)
	{
		this.flipValue = meta.isFlipped;
		this.SetMats();
	}

	// Token: 0x0400027C RID: 636
	[SerializeField]
	private Renderer ren;

	// Token: 0x0400027D RID: 637
	[SerializeField]
	private int beltMatIndex;

	// Token: 0x0400027E RID: 638
	public float speed = 1f;

	// Token: 0x0400027F RID: 639
	private byte speedValue = 1;

	// Token: 0x04000280 RID: 640
	private bool flipValue;
}
