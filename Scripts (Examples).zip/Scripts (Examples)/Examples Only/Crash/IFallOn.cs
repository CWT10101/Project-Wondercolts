﻿using System;

// Token: 0x020000C6 RID: 198
public interface IFallOn
{
	// Token: 0x06000606 RID: 1542
	void FallOn(CrashController crash);
}
