﻿using System;
using UnityEngine;

// Token: 0x02000081 RID: 129
public class ClearGemSetter : PickupSetter
{
	// Token: 0x17000096 RID: 150
	// (get) Token: 0x06000398 RID: 920 RVA: 0x0000F685 File Offset: 0x0000D885
	public override Pickup Pickup
	{
		get
		{
			return this.clearGem;
		}
	}

	// Token: 0x17000097 RID: 151
	// (get) Token: 0x06000399 RID: 921 RVA: 0x0000F68D File Offset: 0x0000D88D
	// (set) Token: 0x0600039A RID: 922 RVA: 0x0000F695 File Offset: 0x0000D895
	public override bool Collected
	{
		get
		{
			return this.collected;
		}
		set
		{
			this.collected = value;
		}
	}

	// Token: 0x04000262 RID: 610
	[SerializeField]
	private CrystalPickup clearGem;

	// Token: 0x04000263 RID: 611
	[SerializeField]
	private bool collected;
}
