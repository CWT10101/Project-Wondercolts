﻿using System;
using UnityEngine;

// Token: 0x02000126 RID: 294
public class SpikedShellEnemy : BasicEnemy, IMetadataReceiver<PhaseMetadata>
{
	// Token: 0x17000111 RID: 273
	// (get) Token: 0x060008C9 RID: 2249 RVA: 0x00024855 File Offset: 0x00022A55
	// (set) Token: 0x060008CA RID: 2250 RVA: 0x00024860 File Offset: 0x00022A60
	public bool IsUp
	{
		get
		{
			return this._isUp;
		}
		set
		{
			if (value != this._isUp)
			{
				this._isUp = value;
				base.OnSlide = (this._isUp ? Enemy.InteractionResponse.HurtCrash : Enemy.InteractionResponse.DieSpin);
				base.OnSpin = (this._isUp ? Enemy.InteractionResponse.HurtCrash : Enemy.InteractionResponse.DieSpin);
				base.OnTouchTop = (base.OnSlam = (this._isUp ? Enemy.InteractionResponse.HurtCrash : Enemy.InteractionResponse.DieBounce));
				base.OnSlam = (this._isUp ? Enemy.InteractionResponse.HurtCrash : Enemy.InteractionResponse.Die);
			}
		}
	}

	// Token: 0x060008CB RID: 2251 RVA: 0x000248CE File Offset: 0x00022ACE
	protected override void OnEnable()
	{
		base.OnEnable();
		if (this.startOpen)
		{
			this.IsUp = true;
			this.SetState(true);
			this.animator.Play(this.openedAnimStateName);
		}
	}

	// Token: 0x060008CC RID: 2252 RVA: 0x000248FD File Offset: 0x00022AFD
	public override void TouchSide(CrashController crash)
	{
		if (this.IsUp)
		{
			this.HurtCrash(crash);
		}
	}

	// Token: 0x060008CD RID: 2253 RVA: 0x00024910 File Offset: 0x00022B10
	protected override void FixedUpdate()
	{
		base.FixedUpdate();
		if (!this.isDead)
		{
			if (this.timer < this.stateLength)
			{
				this.timer += Time.deltaTime;
				return;
			}
			this.SetState(!this.IsUp);
			this.timer = 0f;
		}
	}

	// Token: 0x060008CE RID: 2254 RVA: 0x00024966 File Offset: 0x00022B66
	public override void ResetEntity()
	{
		this.timer = 0f;
		this.IsUp = this.startOpen;
		base.ResetEntity();
	}

	// Token: 0x060008CF RID: 2255 RVA: 0x00024985 File Offset: 0x00022B85
	public void SetState(bool isOpen)
	{
		this.animator.SetBool("IsOpen", isOpen);
	}

	// Token: 0x060008D0 RID: 2256 RVA: 0x00024998 File Offset: 0x00022B98
	public bool SetIsUp(int isUp)
	{
		return this.IsUp = (isUp != 0);
	}

	// Token: 0x060008D1 RID: 2257 RVA: 0x000249B4 File Offset: 0x00022BB4
	public void PlaySFX()
	{
		if (!this.isDead)
		{
			AudioManager.Play(this.sfx, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		}
	}

	// Token: 0x060008D2 RID: 2258 RVA: 0x000249EF File Offset: 0x00022BEF
	public void ProcessMetadata(PhaseMetadata meta)
	{
		this.startOpen = (meta.Value > 0);
	}

	// Token: 0x04000669 RID: 1641
	public string sfx = "SFX_PorcupineTrigger";

	// Token: 0x0400066A RID: 1642
	[SerializeField]
	private string openedAnimStateName = "SpikeShell Opened";

	// Token: 0x0400066B RID: 1643
	private bool _isUp;

	// Token: 0x0400066C RID: 1644
	private float timer;

	// Token: 0x0400066D RID: 1645
	public float stateLength = 3f;

	// Token: 0x0400066E RID: 1646
	private bool startOpen;
}
