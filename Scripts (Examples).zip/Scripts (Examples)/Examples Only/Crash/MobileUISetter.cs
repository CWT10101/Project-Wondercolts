﻿using System;
using UnityEngine;

// Token: 0x02000150 RID: 336
public class MobileUISetter : MonoBehaviour
{
	// Token: 0x060009DF RID: 2527 RVA: 0x00027BE4 File Offset: 0x00025DE4
	private void Start()
	{
		this.SetObjects();
	}

	// Token: 0x060009E0 RID: 2528 RVA: 0x00027BEC File Offset: 0x00025DEC
	public void SetObjects()
	{
		for (int i = 0; i < this.mobileObjs.Length; i++)
		{
			this.mobileObjs[i].SetActive(false);
		}
		for (int j = 0; j < this.nonMobileObjs.Length; j++)
		{
			this.nonMobileObjs[j].SetActive(true);
		}
	}

	// Token: 0x04000719 RID: 1817
	public GameObject[] mobileObjs;

	// Token: 0x0400071A RID: 1818
	public GameObject[] nonMobileObjs;
}
