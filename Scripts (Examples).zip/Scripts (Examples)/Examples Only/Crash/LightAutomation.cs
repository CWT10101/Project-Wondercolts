﻿using System;
using UnityEngine;

// Token: 0x020000D7 RID: 215
public class LightAutomation : MonoBehaviour
{
	// Token: 0x0600064A RID: 1610 RVA: 0x0001B67B File Offset: 0x0001987B
	private void OnEnable()
	{
		this.t = Clock.SynchronizedTime;
		this.SetRadius();
	}

	// Token: 0x0600064B RID: 1611 RVA: 0x0001B68E File Offset: 0x0001988E
	private void OnDisable()
	{
		this.t = 0f;
		this.light.radius = 0f;
	}

	// Token: 0x0600064C RID: 1612 RVA: 0x0001B6AB File Offset: 0x000198AB
	private void FixedUpdate()
	{
		this.SetRadius();
	}

	// Token: 0x0600064D RID: 1613 RVA: 0x0001B6B3 File Offset: 0x000198B3
	private void SetRadius()
	{
		this.light.radius = this.radius.Evaluate(Clock.SynchronizedTime - this.t);
	}

	// Token: 0x040004A1 RID: 1185
	[SerializeField]
	private LightSource light;

	// Token: 0x040004A2 RID: 1186
	[SerializeField]
	private AnimationCurve radius;

	// Token: 0x040004A3 RID: 1187
	private float t;
}
