﻿using System;
using System.Collections;
using System.Collections.Generic;
using LevelEditor;
using UnityEngine;

// Token: 0x02000138 RID: 312
public class TimedActivatorCrate : ActivatorCrate, IMetadataReceiver<SpeedMetadata>, IMetadataReceiver<RangeMetadata>
{
	// Token: 0x06000943 RID: 2371 RVA: 0x00025E2C File Offset: 0x0002402C
	protected override void OnEnable()
	{
		base.OnEnable();
		foreach (Crate crate in this.crates)
		{
			crate.SetOutlineColor(Color.red);
		}
	}

	// Token: 0x06000944 RID: 2372 RVA: 0x00025E88 File Offset: 0x00024088
	private void OnDisable()
	{
		foreach (TimedActivatorCrate.TimerState timerState in this.timers)
		{
			Object.Destroy(timerState.visual.gameObject);
		}
		this.timers.Clear();
		this.activated = false;
	}

	// Token: 0x06000945 RID: 2373 RVA: 0x00025EF4 File Offset: 0x000240F4
	protected override IEnumerator ActivateRoutine()
	{
		List<KeyValuePair<float, Crate>> onTimes = new List<KeyValuePair<float, Crate>>();
		List<KeyValuePair<float, Crate>> offTimes = new List<KeyValuePair<float, Crate>>();
		for (int i = 0; i < this.crates.Count; i++)
		{
			onTimes.Add(new KeyValuePair<float, Crate>((float)i * this.waitTime, this.crates[i]));
			offTimes.Add(new KeyValuePair<float, Crate>((float)i * this.waitTime + this.activeDuration, this.crates[i]));
		}
		float tStart = Clock.SynchronizedTime;
		float totalTime = this.waitTime * (float)this.crates.Count + this.activeDuration;
		float t = 0f;
		float num = 0f;
		while (t <= totalTime)
		{
			float tNow = Clock.SynchronizedTime - tStart;
			int j;
			for (j = 0; j < onTimes.Count; j++)
			{
				if (onTimes[j].Key >= num)
				{
					break;
				}
			}
			while (j < onTimes.Count && onTimes[j].Key <= tNow)
			{
				Crate value = onTimes[j].Value;
				if (!value.isBroken)
				{
					value.SetTangibleMode();
					Object.Instantiate<GameObject>(ResourceManager.instance.timerFXPrefab, value.ColliderCenter, Quaternion.identity);
					TimedActivatorCrate.TimerState item = new TimedActivatorCrate.TimerState
					{
						timeCreated = tNow,
						crate = value,
						visual = Object.Instantiate<ActivatorTimerVisual>(ResourceManager.instance.timerCircle, value.ColliderCenter - Vector3.forward * 0.51f, Quaternion.identity, EditorGizmos.instance.canvas.transform)
					};
					this.timers.Add(item);
				}
				j++;
			}
			for (j = 0; j < offTimes.Count; j++)
			{
				if (offTimes[j].Key >= num)
				{
					break;
				}
			}
			while (j < offTimes.Count && offTimes[j].Key <= tNow)
			{
				Crate value2 = offTimes[j].Value;
				if (!value2.isBroken)
				{
					value2.SetOutlineMode();
					Crate crate;
					if (value2.CrateCheck(out crate))
					{
						crate.Fall(0f);
					}
					Object.Instantiate<GameObject>(ResourceManager.instance.timerFXPrefab, value2.ColliderCenter, Quaternion.identity);
				}
				j++;
			}
			foreach (TimedActivatorCrate.TimerState timerState in this.timers)
			{
				float num2 = (timerState.timeCreated + this.activeDuration - tNow) / this.activeDuration;
				timerState.visual.SetFillAmount(num2);
				timerState.visual.transform.position = timerState.crate.ColliderCenter - Vector3.forward * 0.51f;
				if (num2 <= 0f)
				{
					timerState.expired = true;
				}
			}
			this.timers.RemoveAll(delegate(TimedActivatorCrate.TimerState timer)
			{
				if (timer.expired || timer.crate.isBroken)
				{
					Object.Destroy(timer.visual.gameObject);
					return true;
				}
				return false;
			});
			yield return new WaitForFixedUpdate();
			t += Time.fixedDeltaTime;
			num = tNow;
		}
		if (this.iconAnimator)
		{
			this.iconAnimator.SetTrigger("Reset");
		}
		this.activated = false;
		yield break;
	}

	// Token: 0x06000946 RID: 2374 RVA: 0x00025F03 File Offset: 0x00024103
	public void ProcessMetadata(SpeedMetadata meta)
	{
		this.waitTime = (float)(1 << (int)(5 - meta.speed)) / 4f;
	}

	// Token: 0x06000947 RID: 2375 RVA: 0x00025F1F File Offset: 0x0002411F
	public void ProcessMetadata(RangeMetadata meta)
	{
		this.activeDuration = Mathf.Lerp(2f, 12f, (float)meta.range / 5f);
	}

	// Token: 0x040006C6 RID: 1734
	public float activeDuration = 5f;

	// Token: 0x040006C7 RID: 1735
	private readonly List<TimedActivatorCrate.TimerState> timers = new List<TimedActivatorCrate.TimerState>();

	// Token: 0x02000239 RID: 569
	private class TimerState
	{
		// Token: 0x04000D83 RID: 3459
		public ActivatorTimerVisual visual;

		// Token: 0x04000D84 RID: 3460
		public Crate crate;

		// Token: 0x04000D85 RID: 3461
		public float timeCreated;

		// Token: 0x04000D86 RID: 3462
		public bool expired;
	}
}
