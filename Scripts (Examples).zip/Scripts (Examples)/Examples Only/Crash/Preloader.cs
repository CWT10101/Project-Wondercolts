﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x020000FF RID: 255
public class Preloader : MonoBehaviour
{
	// Token: 0x060007D8 RID: 2008 RVA: 0x000215C8 File Offset: 0x0001F7C8
	private void Start()
	{
		base.StartCoroutine(this.Preload(this.lengthOfTime));
	}

	// Token: 0x060007D9 RID: 2009 RVA: 0x000215DD File Offset: 0x0001F7DD
	public IEnumerator Preload(float length)
	{
		yield return new WaitForSeconds(length - 1f);
		this.animator.SetTrigger("FadeOut");
		yield return new WaitForSeconds(1f);
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
		this.mainMenuAnimator.enabled = true;
		yield break;
	}

	// Token: 0x040005BF RID: 1471
	public float lengthOfTime = 3f;

	// Token: 0x040005C0 RID: 1472
	public Animator animator;

	// Token: 0x040005C1 RID: 1473
	public Animator mainMenuAnimator;
}
