﻿using System;

// Token: 0x0200001D RID: 29
public interface IPlayModeCallback
{
	// Token: 0x06000076 RID: 118
	void PlayModeChanged(bool isPlaying);
}
