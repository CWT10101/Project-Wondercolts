﻿using System;

// Token: 0x020000EC RID: 236
public class NaughtyCrate : Crate
{
	// Token: 0x170000F3 RID: 243
	// (get) Token: 0x06000730 RID: 1840 RVA: 0x0001E9AB File Offset: 0x0001CBAB
	public override bool AddsToBoxCount
	{
		get
		{
			return false;
		}
	}

	// Token: 0x06000731 RID: 1841 RVA: 0x0001E9AE File Offset: 0x0001CBAE
	public override void Break()
	{
		base.Break();
	}

	// Token: 0x06000732 RID: 1842 RVA: 0x0001E9B6 File Offset: 0x0001CBB6
	public override void ResetEntity()
	{
		base.ResetEntity();
	}
}
