﻿using System;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000076 RID: 118
public class BoulderPathNode : MonoBehaviour
{
	// Token: 0x17000093 RID: 147
	// (get) Token: 0x0600035A RID: 858 RVA: 0x0000EC9A File Offset: 0x0000CE9A
	// (set) Token: 0x0600035B RID: 859 RVA: 0x0000ECA2 File Offset: 0x0000CEA2
	public string Trigger { get; private set; }

	// Token: 0x04000230 RID: 560
	public UnityEvent evt;
}
