﻿using System;

// Token: 0x02000118 RID: 280
public class SlamCrate : BasicCrate
{
	// Token: 0x0600088C RID: 2188 RVA: 0x00023DF3 File Offset: 0x00021FF3
	public override void FallOn(CrashController crash)
	{
	}

	// Token: 0x0600088D RID: 2189 RVA: 0x00023DF5 File Offset: 0x00021FF5
	public override void TouchBottom(CrashController crash)
	{
	}

	// Token: 0x0600088E RID: 2190 RVA: 0x00023DF7 File Offset: 0x00021FF7
	public override void Spin(CrashController crash)
	{
	}

	// Token: 0x0600088F RID: 2191 RVA: 0x00023DF9 File Offset: 0x00021FF9
	public override void Slide(CrashController crash)
	{
	}

	// Token: 0x06000890 RID: 2192 RVA: 0x00023DFB File Offset: 0x00021FFB
	public override void Break()
	{
	}

	// Token: 0x06000891 RID: 2193 RVA: 0x00023DFD File Offset: 0x00021FFD
	protected override void LandOnCrash()
	{
		this.ForceBreak();
	}

	// Token: 0x06000892 RID: 2194 RVA: 0x00023E05 File Offset: 0x00022005
	public override void Slam(CrashController crash)
	{
		base.SpawnPickups();
		this.ForceBreak();
	}
}
