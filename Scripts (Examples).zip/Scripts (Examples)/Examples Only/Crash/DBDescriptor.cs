﻿using System;
using System.Collections.Generic;
using System.Linq;
using LevelEditor;
using UnityEngine;

// Token: 0x02000098 RID: 152
public class DBDescriptor : MonoBehaviour, IDBDescriptor<LevelObj>
{
	// Token: 0x170000C1 RID: 193
	// (get) Token: 0x06000491 RID: 1169 RVA: 0x00014BD8 File Offset: 0x00012DD8
	LevelObj IDBDescriptor<LevelObj>.Value
	{
		get
		{
			if (this._levelObj == null)
			{
				this._levelObj = base.GetComponent<LevelObj>();
			}
			return this._levelObj;
		}
	}

	// Token: 0x170000C2 RID: 194
	// (get) Token: 0x06000492 RID: 1170 RVA: 0x00014BFA File Offset: 0x00012DFA
	// (set) Token: 0x06000493 RID: 1171 RVA: 0x00014C02 File Offset: 0x00012E02
	public bool ExcludeFromDatabase { get; private set; }

	// Token: 0x170000C3 RID: 195
	// (get) Token: 0x06000494 RID: 1172 RVA: 0x00014C0C File Offset: 0x00012E0C
	string IDBDescriptor<LevelObj>.Name
	{
		get
		{
			string result;
			if ((result = this.objNameLower) == null)
			{
				result = (this.objNameLower = this._objName.ToLowerInvariant());
			}
			return result;
		}
	}

	// Token: 0x170000C4 RID: 196
	// (get) Token: 0x06000495 RID: 1173 RVA: 0x00014C38 File Offset: 0x00012E38
	HashSet<string> IDBDescriptor<LevelObj>.Tags
	{
		get
		{
			if (this._tagsSet == null)
			{
				this._tagsSet = new HashSet<string>(from t in this._tags
				select t.ToLowerInvariant());
			}
			return this._tagsSet;
		}
	}

	// Token: 0x170000C5 RID: 197
	// (get) Token: 0x06000496 RID: 1174 RVA: 0x00014C88 File Offset: 0x00012E88
	public bool IsSecret
	{
		get
		{
			return this.ExcludeFromDatabase && this._objName.Length > 0;
		}
	}

	// Token: 0x04000336 RID: 822
	private LevelObj _levelObj;

	// Token: 0x04000338 RID: 824
	[SerializeField]
	private string _objName;

	// Token: 0x04000339 RID: 825
	private string objNameLower;

	// Token: 0x0400033A RID: 826
	[SerializeField]
	private List<string> _tags;

	// Token: 0x0400033B RID: 827
	private HashSet<string> _tagsSet;
}
