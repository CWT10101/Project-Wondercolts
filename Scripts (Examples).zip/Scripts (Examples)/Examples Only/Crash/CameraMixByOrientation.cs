﻿using System;
using Cinemachine;
using UnityEngine;

// Token: 0x0200007D RID: 125
public class CameraMixByOrientation : MonoBehaviour
{
	// Token: 0x06000381 RID: 897 RVA: 0x0000F21D File Offset: 0x0000D41D
	private void Awake()
	{
		this.referenceVector.Normalize();
	}

	// Token: 0x06000382 RID: 898 RVA: 0x0000F22C File Offset: 0x0000D42C
	private void LateUpdate()
	{
		float num = this.Alignment();
		float num2 = num * 0.5f + 0.5f;
		float num3 = -num * 0.5f + 0.5f;
		num2 = Mathf.Lerp(this.mixCam.GetWeight(0), num2, 1f - Mathf.Exp(-this.smoothing * Time.deltaTime));
		num3 = Mathf.Lerp(this.mixCam.GetWeight(1), num3, 1f - Mathf.Exp(-this.smoothing * Time.deltaTime));
		this.mixCam.SetWeight(0, num2);
		this.mixCam.SetWeight(1, num3);
	}

	// Token: 0x06000383 RID: 899 RVA: 0x0000F2CC File Offset: 0x0000D4CC
	private float Alignment()
	{
		if (this.worldSpace)
		{
			return Vector3.Dot(this.referenceTf.forward, this.referenceVector);
		}
		return Vector3.Dot(this.referenceTf.forward, Vector3.ProjectOnPlane(Camera.main.transform.rotation * this.referenceVector, this.referenceTf.up).normalized);
	}

	// Token: 0x04000252 RID: 594
	public CinemachineMixingCamera mixCam;

	// Token: 0x04000253 RID: 595
	public Transform referenceTf;

	// Token: 0x04000254 RID: 596
	public Vector3 referenceVector = Vector3.forward;

	// Token: 0x04000255 RID: 597
	public bool worldSpace = true;

	// Token: 0x04000256 RID: 598
	public float smoothing = 1f;
}
