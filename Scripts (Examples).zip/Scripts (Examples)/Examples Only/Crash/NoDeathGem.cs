﻿using System;

// Token: 0x02000121 RID: 289
public class NoDeathGem : SpecialGem
{
}
