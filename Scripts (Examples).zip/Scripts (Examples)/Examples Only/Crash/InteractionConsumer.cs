﻿using System;
using UnityEngine;

// Token: 0x020000C7 RID: 199
public class InteractionConsumer : MonoBehaviour, ITouchTop, ITouchSide, ITouchBottom, IFallOn, ISlam, ISlide, ISpin
{
	// Token: 0x06000607 RID: 1543 RVA: 0x0001A866 File Offset: 0x00018A66
	public void FallOn(CrashController crash)
	{
	}

	// Token: 0x06000608 RID: 1544 RVA: 0x0001A868 File Offset: 0x00018A68
	public void Slam(CrashController crash)
	{
	}

	// Token: 0x06000609 RID: 1545 RVA: 0x0001A86A File Offset: 0x00018A6A
	public void Slide(CrashController crash)
	{
	}

	// Token: 0x0600060A RID: 1546 RVA: 0x0001A86C File Offset: 0x00018A6C
	public void Spin(CrashController crash)
	{
	}

	// Token: 0x0600060B RID: 1547 RVA: 0x0001A86E File Offset: 0x00018A6E
	public void TouchBottom(CrashController crash)
	{
	}

	// Token: 0x0600060C RID: 1548 RVA: 0x0001A870 File Offset: 0x00018A70
	public void TouchSide(CrashController crash)
	{
	}

	// Token: 0x0600060D RID: 1549 RVA: 0x0001A872 File Offset: 0x00018A72
	public void TouchTop(CrashController crash)
	{
	}
}
