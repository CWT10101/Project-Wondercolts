﻿using System;

// Token: 0x02000124 RID: 292
public abstract class SpecialGem : CrystalPickup
{
	// Token: 0x060008C5 RID: 2245 RVA: 0x000247E7 File Offset: 0x000229E7
	private void Awake()
	{
		if (Level.instance && SaveData.Info.lvlSpecialGems[Level.instance.index - 5])
		{
			this.collider.enabled = false;
			this.visual.SetActive(false);
		}
	}
}
