﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x02000073 RID: 115
public class TileFloorController : MonoBehaviour
{
	// Token: 0x06000336 RID: 822 RVA: 0x0000DE88 File Offset: 0x0000C088
	private void Awake()
	{
		foreach (Transform transform in this.tiles)
		{
			transform.position = new Vector3(transform.position.x, this.loweredHeight, transform.position.z);
		}
	}

	// Token: 0x06000337 RID: 823 RVA: 0x0000DED5 File Offset: 0x0000C0D5
	public void Randomize()
	{
		this.SetTilesRaised((from t in this.tiles
		where Random.value > 0.5f
		select t).ToArray<Transform>());
	}

	// Token: 0x06000338 RID: 824 RVA: 0x0000DF0C File Offset: 0x0000C10C
	public void RaisePlatformNorth()
	{
		this.SetTilesRaised(RuntimeHelpers.GetSubArray<Transform>(this.tiles, Range.EndAt(15)));
	}

	// Token: 0x06000339 RID: 825 RVA: 0x0000DF2B File Offset: 0x0000C12B
	public void RaisePlatformSouth()
	{
		this.SetTilesRaised(RuntimeHelpers.GetSubArray<Transform>(this.tiles, Range.StartAt(new Index(15, true))));
	}

	// Token: 0x0600033A RID: 826 RVA: 0x0000DF4B File Offset: 0x0000C14B
	public void LowerAll()
	{
		this.SetTilesRaised(Enumerable.Empty<Transform>());
	}

	// Token: 0x0600033B RID: 827 RVA: 0x0000DF58 File Offset: 0x0000C158
	public void SetTilesRaised(IEnumerable<Transform> tiles)
	{
		TileFloorController.<>c__DisplayClass9_0 CS$<>8__locals1 = new TileFloorController.<>c__DisplayClass9_0();
		CS$<>8__locals1.tiles = tiles;
		CS$<>8__locals1.<>4__this = this;
		base.StartCoroutine(CS$<>8__locals1.<SetTilesRaised>g__Routine|0());
	}

	// Token: 0x04000206 RID: 518
	[SerializeField]
	private Transform[] tiles;

	// Token: 0x04000207 RID: 519
	[SerializeField]
	private float raisedHeight = 0.5f;

	// Token: 0x04000208 RID: 520
	[SerializeField]
	private float loweredHeight = -9f;

	// Token: 0x04000209 RID: 521
	[SerializeField]
	private float moveRate = 5f;
}
