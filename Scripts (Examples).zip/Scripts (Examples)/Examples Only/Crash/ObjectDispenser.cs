﻿using System;
using UnityEngine;

// Token: 0x020000F1 RID: 241
public class ObjectDispenser : Entity, IPlayModeCallback
{
	// Token: 0x06000767 RID: 1895 RVA: 0x0001EF83 File Offset: 0x0001D183
	public void PlayModeChanged(bool isPlaying)
	{
		if (!isPlaying && this.dispensedObject)
		{
			Object.Destroy(this.dispensedObject);
			this.dispensedObject = null;
		}
	}

	// Token: 0x06000768 RID: 1896 RVA: 0x0001EFA7 File Offset: 0x0001D1A7
	public override void ResetEntity()
	{
		this.TryDispenseObject();
	}

	// Token: 0x06000769 RID: 1897 RVA: 0x0001EFAF File Offset: 0x0001D1AF
	public void TryDispenseObject()
	{
		if (this.dispensedObject == null)
		{
			this.dispensedObject = Object.Instantiate<GameObject>(this.objectToDispense, this.dispensePoint.position, Quaternion.Euler(this.orientation), base.transform);
		}
	}

	// Token: 0x0400056C RID: 1388
	public GameObject objectToDispense;

	// Token: 0x0400056D RID: 1389
	public Transform dispensePoint;

	// Token: 0x0400056E RID: 1390
	public Vector3 orientation;

	// Token: 0x0400056F RID: 1391
	private GameObject dispensedObject;
}
