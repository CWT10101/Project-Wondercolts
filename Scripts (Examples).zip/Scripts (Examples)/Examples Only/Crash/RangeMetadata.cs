﻿using System;
using System.IO;
using LevelEditor;

// Token: 0x02000030 RID: 48
public class RangeMetadata : ObjectMetadata
{
	// Token: 0x17000042 RID: 66
	// (get) Token: 0x06000131 RID: 305 RVA: 0x000066C4 File Offset: 0x000048C4
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000043 RID: 67
	// (get) Token: 0x06000132 RID: 306 RVA: 0x000066C7 File Offset: 0x000048C7
	public override int Signature
	{
		get
		{
			return "RangeMetadata".GetHashCode();
		}
	}

	// Token: 0x17000044 RID: 68
	// (get) Token: 0x06000133 RID: 307 RVA: 0x000066D3 File Offset: 0x000048D3
	public override int ValueHash
	{
		get
		{
			return (int)this.range;
		}
	}

	// Token: 0x06000134 RID: 308 RVA: 0x000066DB File Offset: 0x000048DB
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.range);
	}

	// Token: 0x06000135 RID: 309 RVA: 0x000066E9 File Offset: 0x000048E9
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.range = br.ReadByte();
	}

	// Token: 0x06000136 RID: 310 RVA: 0x000066F8 File Offset: 0x000048F8
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<RangeMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<RangeMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x04000099 RID: 153
	public byte range;
}
