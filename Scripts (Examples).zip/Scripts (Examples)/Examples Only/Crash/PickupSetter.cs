﻿using System;
using UnityEngine;

// Token: 0x020000F9 RID: 249
public abstract class PickupSetter : MonoBehaviour, IPlayModeCallback
{
	// Token: 0x170000FB RID: 251
	// (get) Token: 0x060007B6 RID: 1974
	public abstract Pickup Pickup { get; }

	// Token: 0x170000FC RID: 252
	// (get) Token: 0x060007B7 RID: 1975
	// (set) Token: 0x060007B8 RID: 1976
	public abstract bool Collected { get; set; }

	// Token: 0x060007B9 RID: 1977 RVA: 0x00020B65 File Offset: 0x0001ED65
	public virtual void PlayModeChanged(bool isPlaying)
	{
		this.Collected = false;
	}

	// Token: 0x060007BA RID: 1978 RVA: 0x00020B6E File Offset: 0x0001ED6E
	public virtual void Set(bool enabled)
	{
		this.Pickup.gameObject.SetActive(enabled);
	}
}
