﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x020000A0 RID: 160
public class Door : Entity
{
	// Token: 0x170000D0 RID: 208
	// (get) Token: 0x060004E1 RID: 1249 RVA: 0x0001596C File Offset: 0x00013B6C
	public bool IsClosed
	{
		get
		{
			return this.tActive == -1f;
		}
	}

	// Token: 0x060004E2 RID: 1250 RVA: 0x0001597B File Offset: 0x00013B7B
	public void Open()
	{
		if (this.IsClosed)
		{
			this.TryPushToStack();
			this.tActive = Time.time;
			UnityEvent unityEvent = this.onStarted;
			if (unityEvent != null)
			{
				unityEvent.Invoke();
			}
			base.StartCoroutine(this.<Open>g__Routine|8_0());
		}
	}

	// Token: 0x060004E3 RID: 1251 RVA: 0x000159B4 File Offset: 0x00013BB4
	public override void ResetEntity()
	{
		base.ResetEntity();
		this.tActive = -1f;
		base.transform.position = this.pointA.position;
	}

	// Token: 0x060004E5 RID: 1253 RVA: 0x000159F0 File Offset: 0x00013BF0
	[CompilerGenerated]
	private IEnumerator <Open>g__Routine|8_0()
	{
		while (this.tActive >= 0f)
		{
			float t = this.speedCurve.Evaluate(Time.time - this.tActive);
			if (Time.time - this.tActive >= this.speedCurve.keys[this.speedCurve.length - 1].time)
			{
				this.tActive = -2f;
				UnityEvent unityEvent = this.onFinished;
				if (unityEvent != null)
				{
					unityEvent.Invoke();
				}
			}
			base.transform.position = Vector3.Lerp(this.pointA.position, this.pointB.position, t);
			yield return new WaitForFixedUpdate();
		}
		yield break;
	}

	// Token: 0x0400035D RID: 861
	public UnityEvent onStarted;

	// Token: 0x0400035E RID: 862
	public UnityEvent onFinished;

	// Token: 0x0400035F RID: 863
	public Transform pointA;

	// Token: 0x04000360 RID: 864
	public Transform pointB;

	// Token: 0x04000361 RID: 865
	public AnimationCurve speedCurve;

	// Token: 0x04000362 RID: 866
	private float tActive = -1f;
}
