﻿using System;
using UnityEngine;

// Token: 0x020000CA RID: 202
public interface IPlatform
{
	// Token: 0x06000613 RID: 1555
	Vector3 GetNextPosition();

	// Token: 0x06000614 RID: 1556
	void GetDelta(Transform tf, out Vector3 positionDelta);

	// Token: 0x06000615 RID: 1557
	void OnEnter(Transform tf);

	// Token: 0x06000616 RID: 1558
	void OnExit(Transform tf);
}
