﻿using System;
using System.Collections.Generic;
using System.IO;
using LevelEditor;
using UnityEngine;

// Token: 0x02000033 RID: 51
public class SlotCrateMetadata : ObjectMetadata
{
	// Token: 0x1700004C RID: 76
	// (get) Token: 0x06000149 RID: 329 RVA: 0x000068D0 File Offset: 0x00004AD0
	public IReadOnlyList<bool> Values
	{
		get
		{
			return this.values;
		}
	}

	// Token: 0x1700004D RID: 77
	// (get) Token: 0x0600014A RID: 330 RVA: 0x000068D8 File Offset: 0x00004AD8
	public bool BecomesMetal
	{
		get
		{
			return this.becomesMetal;
		}
	}

	// Token: 0x1700004E RID: 78
	// (get) Token: 0x0600014B RID: 331 RVA: 0x000068E0 File Offset: 0x00004AE0
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x1700004F RID: 79
	// (get) Token: 0x0600014C RID: 332 RVA: 0x000068E3 File Offset: 0x00004AE3
	public override int Signature
	{
		get
		{
			return "SlotCrateMetadata".GetHashCode();
		}
	}

	// Token: 0x17000050 RID: 80
	// (get) Token: 0x0600014D RID: 333 RVA: 0x000068EF File Offset: 0x00004AEF
	public override int ValueHash
	{
		get
		{
			return this.valueHash;
		}
	}

	// Token: 0x0600014E RID: 334 RVA: 0x000068F7 File Offset: 0x00004AF7
	public void SetValue(int index, bool value)
	{
		if (this.values[index] == value)
		{
			return;
		}
		this.values[index] = value;
		this.valueHash ^= 1 << index;
	}

	// Token: 0x0600014F RID: 335 RVA: 0x00006921 File Offset: 0x00004B21
	public void SetBecomesMetal(bool value)
	{
		if (this.becomesMetal == value)
		{
			return;
		}
		this.becomesMetal = value;
		this.valueHash ^= int.MinValue;
	}

	// Token: 0x06000150 RID: 336 RVA: 0x00006948 File Offset: 0x00004B48
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write((byte)this.values.Length);
		for (int i = 0; i < this.values.Length; i++)
		{
			bw.Write(this.values[i]);
		}
		bw.Write(this.becomesMetal);
	}

	// Token: 0x06000151 RID: 337 RVA: 0x00006994 File Offset: 0x00004B94
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.valueHash = 0;
		this.values = new bool[(int)br.ReadByte()];
		for (int i = 0; i < this.values.Length; i++)
		{
			this.values[i] = br.ReadBoolean();
			if (this.values[i])
			{
				this.valueHash |= 1 << i;
			}
		}
		this.becomesMetal = br.ReadBoolean();
		if (this.becomesMetal)
		{
			this.valueHash |= int.MinValue;
		}
	}

	// Token: 0x06000152 RID: 338 RVA: 0x00006A20 File Offset: 0x00004C20
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<SlotCrateMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<SlotCrateMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x0400009E RID: 158
	[SerializeField]
	private bool[] values;

	// Token: 0x0400009F RID: 159
	[SerializeField]
	private bool becomesMetal;

	// Token: 0x040000A0 RID: 160
	private int valueHash;
}
