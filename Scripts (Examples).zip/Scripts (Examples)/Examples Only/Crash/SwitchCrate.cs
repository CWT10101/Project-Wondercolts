﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x02000132 RID: 306
public class SwitchCrate : Crate, IFallOn, ITouchBottom, ISpin, ISlam, ISlide
{
	// Token: 0x17000117 RID: 279
	// (get) Token: 0x0600090D RID: 2317 RVA: 0x000256F6 File Offset: 0x000238F6
	public override bool AddsToBoxCount
	{
		get
		{
			return false;
		}
	}

	// Token: 0x17000118 RID: 280
	// (get) Token: 0x0600090E RID: 2318 RVA: 0x000256F9 File Offset: 0x000238F9
	// (set) Token: 0x0600090F RID: 2319 RVA: 0x00025700 File Offset: 0x00023900
	public static bool IsSwitchedOn { get; private set; } = false;

	// Token: 0x17000119 RID: 281
	// (get) Token: 0x06000910 RID: 2320 RVA: 0x00025708 File Offset: 0x00023908
	// (set) Token: 0x06000911 RID: 2321 RVA: 0x0002570F File Offset: 0x0002390F
	public static bool IsSwitchingCurrently { get; private set; } = false;

	// Token: 0x1700011A RID: 282
	// (get) Token: 0x06000912 RID: 2322 RVA: 0x00025717 File Offset: 0x00023917
	// (set) Token: 0x06000913 RID: 2323 RVA: 0x0002571E File Offset: 0x0002391E
	public static bool IsSwitchOnAtCheckpoint { get; private set; } = false;

	// Token: 0x06000914 RID: 2324 RVA: 0x00025726 File Offset: 0x00023926
	public override void Break()
	{
		this.ToggleSwitchState();
	}

	// Token: 0x06000915 RID: 2325 RVA: 0x0002572E File Offset: 0x0002392E
	public override void ForceBreak()
	{
	}

	// Token: 0x06000916 RID: 2326 RVA: 0x00025730 File Offset: 0x00023930
	public static void StoreSwitchState()
	{
		SwitchCrate.IsSwitchOnAtCheckpoint = SwitchCrate.IsSwitchedOn;
	}

	// Token: 0x06000917 RID: 2327 RVA: 0x0002573C File Offset: 0x0002393C
	public static void RollbackSwitchState()
	{
		SwitchCrate.IsSwitchingCurrently = false;
		SwitchCrate.IsSwitchedOn = SwitchCrate.IsSwitchOnAtCheckpoint;
	}

	// Token: 0x06000918 RID: 2328 RVA: 0x0002574E File Offset: 0x0002394E
	public static void DefaultSwitchState()
	{
		SwitchCrate.IsSwitchingCurrently = false;
		SwitchCrate.IsSwitchedOn = false;
		SwitchCrate.IsSwitchOnAtCheckpoint = false;
	}

	// Token: 0x1700011B RID: 283
	// (get) Token: 0x06000919 RID: 2329 RVA: 0x00025762 File Offset: 0x00023962
	public static HashSet<SwitchCrate> Crates { get; } = new HashSet<SwitchCrate>();

	// Token: 0x0600091A RID: 2330 RVA: 0x00025769 File Offset: 0x00023969
	protected override void OnEnable()
	{
		base.OnEnable();
		SwitchCrate.Crates.Add(this);
		this.onVis.SetActive(SwitchCrate.IsSwitchedOn);
		this.offVis.SetActive(!SwitchCrate.IsSwitchedOn);
	}

	// Token: 0x0600091B RID: 2331 RVA: 0x000257A0 File Offset: 0x000239A0
	private void OnDisable()
	{
		SwitchCrate.Crates.Remove(this);
		if (this.runningCoroutine)
		{
			SwitchCrate.IsSwitchingCurrently = (this.runningCoroutine = false);
		}
	}

	// Token: 0x0600091C RID: 2332 RVA: 0x000257D0 File Offset: 0x000239D0
	public void FallOn(CrashController crash)
	{
		crash.Bounce();
		this.ToggleSwitchState();
	}

	// Token: 0x0600091D RID: 2333 RVA: 0x000257DE File Offset: 0x000239DE
	public void TouchBottom(CrashController crash)
	{
		this.ToggleSwitchState();
	}

	// Token: 0x0600091E RID: 2334 RVA: 0x000257E6 File Offset: 0x000239E6
	public void Spin(CrashController crash)
	{
		this.ToggleSwitchState();
	}

	// Token: 0x0600091F RID: 2335 RVA: 0x000257EE File Offset: 0x000239EE
	public void Slam(CrashController crash)
	{
		this.ToggleSwitchState();
	}

	// Token: 0x06000920 RID: 2336 RVA: 0x000257F6 File Offset: 0x000239F6
	public void Slide(CrashController crash)
	{
		if (!base.IsAbove(crash))
		{
			this.ToggleSwitchState();
		}
	}

	// Token: 0x06000921 RID: 2337 RVA: 0x00025807 File Offset: 0x00023A07
	public void ToggleSwitchState()
	{
		this.Switch(!SwitchCrate.IsSwitchedOn);
	}

	// Token: 0x06000922 RID: 2338 RVA: 0x00025818 File Offset: 0x00023A18
	public void Switch(bool switchOn)
	{
		if (SwitchCrate.IsSwitchingCurrently)
		{
			return;
		}
		SwitchCrate.IsSwitchingCurrently = (this.runningCoroutine = true);
		SwitchCrate.IsSwitchedOn = switchOn;
		AudioManager.Play("SFX_ActivatorCrate", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		base.StartCoroutine(this.<Switch>g__SwitchRoutine|34_0());
	}

	// Token: 0x06000925 RID: 2341 RVA: 0x0002589A File Offset: 0x00023A9A
	[CompilerGenerated]
	private IEnumerator <Switch>g__SwitchRoutine|34_0()
	{
		yield return new WaitForSeconds(0.5f);
		foreach (SwitchCrate switchCrate in SwitchCrate.Crates)
		{
			switchCrate.onVis.SetActive(SwitchCrate.IsSwitchedOn);
			switchCrate.offVis.SetActive(!SwitchCrate.IsSwitchedOn);
		}
		foreach (GreenCrate greenCrate in GreenCrate.Crates)
		{
			greenCrate.SetSolid(SwitchCrate.IsSwitchedOn, false);
		}
		foreach (RedCrate redCrate in RedCrate.Crates)
		{
			redCrate.SetSolid(!SwitchCrate.IsSwitchedOn, false);
		}
		yield return new WaitForFixedUpdate();
		SwitchCrate.IsSwitchingCurrently = (this.runningCoroutine = false);
		yield break;
	}

	// Token: 0x040006AA RID: 1706
	public GameObject onVis;

	// Token: 0x040006AB RID: 1707
	public GameObject offVis;

	// Token: 0x040006AF RID: 1711
	private bool runningCoroutine;

	// Token: 0x040006B0 RID: 1712
	public List<ColourCrate> colourCrates;
}
