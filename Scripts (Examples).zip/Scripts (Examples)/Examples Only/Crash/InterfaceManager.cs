﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using Rewired.UI.ControlMapper;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

// Token: 0x020000DE RID: 222
[DefaultExecutionOrder(-200)]
public class InterfaceManager : MonoBehaviour
{
	// Token: 0x060006A5 RID: 1701 RVA: 0x0001CB5D File Offset: 0x0001AD5D
	private void Awake()
	{
		InterfaceManager.instance = this;
		Object.DontDestroyOnLoad(base.gameObject);
	}

	// Token: 0x060006A6 RID: 1702 RVA: 0x0001CB70 File Offset: 0x0001AD70
	private void Start()
	{
		this.masterVol.SetValueWithoutNotify(AudioManager.GetFloatNormalized(AudioManager.mainVolumeParam));
		this.sfxVol.SetValueWithoutNotify(AudioManager.GetFloatNormalized(AudioManager.sfxVolumeParam));
		this.musicVol.SetValueWithoutNotify(AudioManager.GetFloatNormalized(AudioManager.musicVolumeParam));
		this.SetNicknameText();
		SceneManager.sceneLoaded += this.SetQuitButton;
		this.CheckLegacySave();
		this.loadGameButton.interactable = SaveData.SlotExists(SaveData.ContinueSlot);
	}

	// Token: 0x060006A7 RID: 1703 RVA: 0x0001CBEE File Offset: 0x0001ADEE
	public void InitMobileJoystickSlider()
	{
		this.mobileJoystickOpacitySlider.SetValueWithoutNotify(PlayerPrefs.GetFloat("JoystickOpacityPref", 1f));
		this.SetMobileJoystick();
	}

	// Token: 0x060006A8 RID: 1704 RVA: 0x0001CC10 File Offset: 0x0001AE10
	public void SetMobileJoystick()
	{
		this.exampleJoystickCanvasGroup.alpha = (this.mobileJoystickCanvasGroup.alpha = this.mobileJoystickOpacitySlider.value);
		PlayerPrefs.SetFloat("JoystickOpacityPref", this.mobileJoystickOpacitySlider.value);
	}

	// Token: 0x060006A9 RID: 1705 RVA: 0x0001CC58 File Offset: 0x0001AE58
	public void InitMobileScreenOrientation()
	{
		this.mobileOrientationDropdown.options.Clear();
		List<string> options = new List<string>
		{
			"Portrait",
			"LandscapeLeft",
			"LandscapeRight",
			"PortraitUpsideDown"
		};
		this.mobileOrientationDropdown.AddOptions(options);
		if (PlayerPrefs.HasKey("SetOrientation"))
		{
			this.mobileOrientationDropdown.value = PlayerPrefs.GetInt("SetOrientation");
			this.SetMobileScreenOrientation(PlayerPrefs.GetInt("SetOrientation"));
			return;
		}
		Screen.orientation = ScreenOrientation.LandscapeRight;
		this.mobileOrientationDropdown.value = 2;
	}

	// Token: 0x060006AA RID: 1706 RVA: 0x0001CCF8 File Offset: 0x0001AEF8
	public void SetMobileScreenOrientation(int index)
	{
		string text = this.mobileOrientationDropdown.options[index].text;
		Screen.orientation = (ScreenOrientation)Enum.Parse(typeof(ScreenOrientation), text);
		PlayerPrefs.SetInt("SetOrientation", index);
	}

	// Token: 0x060006AB RID: 1707 RVA: 0x0001CD44 File Offset: 0x0001AF44
	public void InitMobileButtonPosition()
	{
		float @float = PlayerPrefs.GetFloat("mobileButtonPosition", 75f);
		this.mobileButtonPositionSlider.SetValueWithoutNotify(@float);
		this.SetMobileButtonPosition(@float);
	}

	// Token: 0x060006AC RID: 1708 RVA: 0x0001CD74 File Offset: 0x0001AF74
	public void SetMobileButtonPosition(float offset)
	{
		float y = (this.DPadObj.transform as RectTransform).anchoredPosition.y;
		(this.DPadObj.transform as RectTransform).anchoredPosition = new Vector2(offset, y);
		(this.mobileJoystickObj.transform as RectTransform).anchoredPosition = new Vector2(offset, y);
		(this.faceButtonsObj.transform as RectTransform).anchoredPosition = new Vector2(-offset, y);
		(this.exampleDpadObj.transform as RectTransform).anchoredPosition = new Vector2(offset / 2f, y / 2f);
		(this.exampleJoystickObj.transform as RectTransform).anchoredPosition = new Vector2(offset / 2f, y / 2f);
		(this.exampleFaceButtonsObj.transform as RectTransform).anchoredPosition = new Vector2(-offset / 2f, y / 2f);
		PlayerPrefs.SetFloat("mobileButtonPosition", offset);
	}

	// Token: 0x060006AD RID: 1709 RVA: 0x0001CE78 File Offset: 0x0001B078
	public void InitMobileButtonScale()
	{
		float @float = PlayerPrefs.GetFloat("mobileButtonScale", 1f);
		this.mobileButtonScaleSlider.SetValueWithoutNotify(@float);
		this.SetMobileButtonScale(@float);
	}

	// Token: 0x060006AE RID: 1710 RVA: 0x0001CEA8 File Offset: 0x0001B0A8
	public void SetMobileButtonScale(float newScale)
	{
		Vector3 vector = new Vector3(newScale, newScale, newScale);
		this.DPadObj.transform.localScale = vector;
		this.mobileJoystickObj.transform.localScale = vector;
		this.faceButtonsObj.transform.localScale = vector;
		this.exampleDpadObj.transform.localScale = vector / 2f;
		this.exampleJoystickObj.transform.localScale = vector / 2f;
		this.exampleFaceButtonsObj.transform.localScale = vector / 2f;
		PlayerPrefs.SetFloat("mobileButtonScale", newScale);
	}

	// Token: 0x060006AF RID: 1711 RVA: 0x0001CF50 File Offset: 0x0001B150
	public void SetDPAD(bool enable)
	{
		this.mobileJoystickObj.SetActive(!enable);
		this.exampleJoystickObj.SetActive(!enable);
		this.DPadObj.SetActive(enable);
		this.exampleDpadObj.SetActive(enable);
		if (enable)
		{
			PlayerPrefs.SetInt("useDPAD", 1);
			return;
		}
		PlayerPrefs.SetInt("useDPAD", 0);
	}

	// Token: 0x060006B0 RID: 1712 RVA: 0x0001CFAD File Offset: 0x0001B1AD
	public void InitDPAD()
	{
		if (PlayerPrefs.GetInt("useDPAD", 0) == 1)
		{
			this.useDPADToggle.SetIsOnWithoutNotify(true);
			this.SetDPAD(true);
			return;
		}
		this.useDPADToggle.SetIsOnWithoutNotify(false);
		this.SetDPAD(false);
	}

	// Token: 0x060006B1 RID: 1713 RVA: 0x0001CFE4 File Offset: 0x0001B1E4
	public void SetNicknameText()
	{
		this.nicknameText.text = SaveData.Info.name;
	}

	// Token: 0x060006B2 RID: 1714 RVA: 0x0001CFFC File Offset: 0x0001B1FC
	private void CheckLegacySave()
	{
		byte b;
		if (SaveData.IsLegacySavePresent() && SaveData.GetEmptySlot(out b))
		{
			Debug.Log(string.Format("Moving legacy savefile to slot {0}", b));
			File.Move(SaveData.LegacySaveFilePath, SaveData.GetSavePath(b));
			if (SaveData.ContinueSlot == -1)
			{
				SaveData.ContinueSlot = (sbyte)b;
			}
		}
	}

	// Token: 0x060006B3 RID: 1715 RVA: 0x0001D050 File Offset: 0x0001B250
	public void SetQuitButton(Scene scene, LoadSceneMode sceneType)
	{
		if (SceneManager.GetActiveScene().name == "WarpRoom")
		{
			this.pauseScreenQuitButton.gameObject.SetActive(true);
			this.pauseScreenWarpRoomButton.gameObject.SetActive(false);
		}
		else
		{
			this.pauseScreenQuitButton.gameObject.SetActive(false);
			this.pauseScreenWarpRoomButton.gameObject.SetActive(true);
		}
		if (!(SceneManager.GetActiveScene().name == "Editor"))
		{
			this.pauseScreenBackToCPButton.gameObject.SetActive(false);
			this.pauseScreenRestartButton.gameObject.SetActive(false);
			return;
		}
		if (!string.IsNullOrEmpty(LevelSerializer.instance.loadOnPlayString))
		{
			this.pauseScreenBackToCPButton.gameObject.SetActive(true);
			this.pauseScreenRestartButton.gameObject.SetActive(true);
			return;
		}
		this.pauseScreenWarpRoomButton.gameObject.SetActive(false);
	}

	// Token: 0x060006B4 RID: 1716 RVA: 0x0001D13D File Offset: 0x0001B33D
	public void ShowBonusUI(bool show)
	{
		this.bonusUI.SetActive(show);
	}

	// Token: 0x060006B5 RID: 1717 RVA: 0x0001D14B File Offset: 0x0001B34B
	public void BackToCP()
	{
		CrashController.instance.Die(0);
		this.ResumeButton();
	}

	// Token: 0x060006B6 RID: 1718 RVA: 0x0001D15E File Offset: 0x0001B35E
	public void RetryEditorLevel()
	{
		CrashController.instance.Die(0);
		LevelManager.instance.LoadToPlay(LevelSerializer.activeFolder, LevelSerializer.instance.loadOnPlayString);
		this.ResumeButton();
	}

	// Token: 0x060006B7 RID: 1719 RVA: 0x0001D18A File Offset: 0x0001B38A
	public void LoadWarpRoom()
	{
		this.SetTitleAndAuthor("", "");
		LevelSerializer.instance.loadOnPlayString = null;
		LevelSerializer.instance.tapeIndex = -1;
		base.StartCoroutine(this.LoadWarpRoomRoutine());
	}

	// Token: 0x060006B8 RID: 1720 RVA: 0x0001D1C0 File Offset: 0x0001B3C0
	public void LoadMainMenu()
	{
		this.SetTitleAndAuthor("", "");
		LevelSerializer.instance.akuHitCounter = 0;
		LevelSerializer.instance.loadOnPlayString = null;
		LevelSerializer.instance.tapeIndex = -1;
		this.CheckContinueState();
		base.StartCoroutine(this.LoadMainMenuRoutine());
	}

	// Token: 0x060006B9 RID: 1721 RVA: 0x0001D214 File Offset: 0x0001B414
	private void CheckContinueState()
	{
		if (!SaveData.SlotExists(SaveData.ContinueSlot))
		{
			byte b;
			SaveData.ContinueSlot = (SaveData.GetExistingSlot(out b) ? ((sbyte)b) : -1);
		}
		this.loadGameButton.interactable = SaveData.SlotExists(SaveData.ContinueSlot);
	}

	// Token: 0x060006BA RID: 1722 RVA: 0x0001D255 File Offset: 0x0001B455
	public void ResumeButton()
	{
		InterfaceManager.Pause(false);
		if (CrashController.instance)
		{
			CrashController.instance.Resume();
		}
	}

	// Token: 0x14000003 RID: 3
	// (add) Token: 0x060006BB RID: 1723 RVA: 0x0001D274 File Offset: 0x0001B474
	// (remove) Token: 0x060006BC RID: 1724 RVA: 0x0001D2A8 File Offset: 0x0001B4A8
	private static event Action<bool> onPauseChanged;

	// Token: 0x060006BD RID: 1725 RVA: 0x0001D2DB File Offset: 0x0001B4DB
	public static void SubscribeToPause(Action<bool> callback)
	{
		InterfaceManager.onPauseChanged += callback;
	}

	// Token: 0x060006BE RID: 1726 RVA: 0x0001D2E3 File Offset: 0x0001B4E3
	public static void UnsubscribeFromPause(Action<bool> callback)
	{
		InterfaceManager.onPauseChanged -= callback;
	}

	// Token: 0x060006BF RID: 1727 RVA: 0x0001D2EC File Offset: 0x0001B4EC
	public static void Pause(bool isPaused)
	{
		if (isPaused)
		{
			AudioManager.PauseMusic();
			UIScreen.Focus(InterfaceManager.instance.PauseScreen);
			InterfaceManager.instance.SetPercentComplete(Mathf.FloorToInt(SaveData.Info.Progress * 100f));
			InterfaceManager.instance.StartCoroutine(InterfaceManager.<Pause>g__Routine|89_0());
		}
		else
		{
			AudioManager.UnpauseMusic();
			InterfaceManager.instance.audioScreen.Close();
			InterfaceManager.instance.graphicsScreen.Close();
			InterfaceManager.instance.optionsScreen.Close();
			InterfaceManager.instance.PauseScreen.Close();
			if (InterfaceManager.instance.controlMapper.isOpen)
			{
				InterfaceManager.instance.controlMapper.Close(true);
			}
			UIScreen.Focus(InterfaceManager.instance.HUD);
			Camera.main.rect = Rect.MinMaxRect(0f, 0f, 1f, 1f);
		}
		Action<bool> action = InterfaceManager.onPauseChanged;
		if (action == null)
		{
			return;
		}
		action(isPaused);
	}

	// Token: 0x060006C0 RID: 1728 RVA: 0x0001D3E8 File Offset: 0x0001B5E8
	public void SetCrashActive(bool active)
	{
		CrashController.instance.enabled = active;
	}

	// Token: 0x060006C1 RID: 1729 RVA: 0x0001D3F5 File Offset: 0x0001B5F5
	public void SetPercentComplete(int percent)
	{
		this.percentCompleteText.text = string.Format("{0}%", percent);
	}

	// Token: 0x060006C2 RID: 1730 RVA: 0x0001D412 File Offset: 0x0001B612
	public void NewGame()
	{
		SaveData.ActiveSlot = -1;
		SaveData.Reset();
		base.StartCoroutine(this.NewGameRoutine());
	}

	// Token: 0x060006C3 RID: 1731 RVA: 0x0001D42C File Offset: 0x0001B62C
	public void LoadGame()
	{
		SaveData.ActiveSlot = SaveData.ContinueSlot;
		SaveData.Load();
		base.StartCoroutine(this.LoadWarpRoomRoutine());
	}

	// Token: 0x060006C4 RID: 1732 RVA: 0x0001D44A File Offset: 0x0001B64A
	public void SetSaveSlot(int slot)
	{
		SaveData.ActiveSlot = (sbyte)slot;
	}

	// Token: 0x060006C5 RID: 1733 RVA: 0x0001D453 File Offset: 0x0001B653
	public void DeleteSaveSlot(int slot)
	{
		SaveData.Delete((byte)slot);
	}

	// Token: 0x060006C6 RID: 1734 RVA: 0x0001D45C File Offset: 0x0001B65C
	public IEnumerator LoadWarpRoomRoutine()
	{
		this.fadeScreen.FadeToColour(Color.black);
		yield return new WaitForSecondsRealtime(1f);
		Clock.ResetTimeScale();
		SceneManager.LoadScene("WarpRoom");
		if (this.bonusUI.activeSelf)
		{
			this.bonusUI.SetActive(false);
		}
		UIScreen.Focus(InterfaceManager.instance.HUD);
		this.fadeScreen.FadeToAlpha();
		yield break;
	}

	// Token: 0x060006C7 RID: 1735 RVA: 0x0001D46B File Offset: 0x0001B66B
	public IEnumerator LoadMainMenuRoutine()
	{
		this.fadeScreen.FadeToColour(Color.black);
		yield return new WaitForSecondsRealtime(1f);
		Clock.ResetTimeScale();
		SceneManager.LoadScene("MainMenu");
		if (this.bonusUI.activeSelf)
		{
			this.bonusUI.SetActive(false);
		}
		UIScreen.Focus(InterfaceManager.instance.mainMenuScreen);
		this.fadeScreen.FadeToAlpha();
		yield break;
	}

	// Token: 0x060006C8 RID: 1736 RVA: 0x0001D47A File Offset: 0x0001B67A
	public IEnumerator NewGameRoutine()
	{
		CrashAnimator.Skin = 0;
		this.fadeScreen.FadeToColour(Color.white);
		yield return new WaitForSecondsRealtime(1f);
		Clock.ResetTimeScale();
		SceneManager.LoadScene("NSanityBeach");
		if (this.bonusUI.activeSelf)
		{
			this.bonusUI.SetActive(false);
		}
		UIScreen.Focus(InterfaceManager.instance.HUD);
		this.fadeScreen.FadeToAlpha();
		yield break;
	}

	// Token: 0x060006C9 RID: 1737 RVA: 0x0001D489 File Offset: 0x0001B689
	public void SaveGame()
	{
		SaveData.Save();
	}

	// Token: 0x060006CA RID: 1738 RVA: 0x0001D490 File Offset: 0x0001B690
	public void SetTitleAndAuthor(string title, string author)
	{
		this.levelName.text = title;
		this.levelAuthor.text = author;
	}

	// Token: 0x060006CB RID: 1739 RVA: 0x0001D4AA File Offset: 0x0001B6AA
	public void OpenControlMapper()
	{
		this.controlMapper.Open();
	}

	// Token: 0x060006CC RID: 1740 RVA: 0x0001D4B7 File Offset: 0x0001B6B7
	public void TogglePostProcessing(bool toggle)
	{
		CameraManager.instance.SetPostProcessing(toggle);
	}

	// Token: 0x060006CD RID: 1741 RVA: 0x0001D4C4 File Offset: 0x0001B6C4
	public void ToggleFullscreenMode(bool toggle)
	{
		if (toggle)
		{
			Screen.SetResolution(1920, 1080, true);
			return;
		}
		Screen.SetResolution(640, 480, false);
	}

	// Token: 0x060006CE RID: 1742 RVA: 0x0001D4EA File Offset: 0x0001B6EA
	public void SetResolutionFactor(float factor)
	{
		CameraManager.instance.SetResolutionFactor((int)factor);
	}

	// Token: 0x060006CF RID: 1743 RVA: 0x0001D4F8 File Offset: 0x0001B6F8
	public void SetVertexInaccuracy(float factor)
	{
		CameraManager.instance.SetVertexInaccuracy((int)factor);
	}

	// Token: 0x060006D0 RID: 1744 RVA: 0x0001D506 File Offset: 0x0001B706
	public void SetColourDepth(float factor)
	{
		CameraManager.instance.SetColourDepth((int)factor);
	}

	// Token: 0x060006D1 RID: 1745 RVA: 0x0001D514 File Offset: 0x0001B714
	public void SetSubtractiveFade(float factor)
	{
		CameraManager.instance.SetSubtractiveFade((int)factor);
	}

	// Token: 0x060006D2 RID: 1746 RVA: 0x0001D522 File Offset: 0x0001B722
	public void ToggleAffineWarping(bool toggle)
	{
		CameraManager.instance.SetAffineWarping(toggle);
	}

	// Token: 0x060006D3 RID: 1747 RVA: 0x0001D52F File Offset: 0x0001B72F
	public void ToggleScanlines(bool toggle)
	{
		CameraManager.instance.SetScanlines(toggle);
	}

	// Token: 0x060006D4 RID: 1748 RVA: 0x0001D53C File Offset: 0x0001B73C
	public void ToggleDithering(bool toggle)
	{
		CameraManager.instance.SetDithering(toggle);
	}

	// Token: 0x060006D5 RID: 1749 RVA: 0x0001D549 File Offset: 0x0001B749
	public void SetVolumeMaster(float value)
	{
		AudioManager.SetVolumeMaster(value);
	}

	// Token: 0x060006D6 RID: 1750 RVA: 0x0001D551 File Offset: 0x0001B751
	public void SetVolumeSFX(float value)
	{
		AudioManager.SetVolumeSFX(value);
		AudioManager.SetVolumeUI(value);
	}

	// Token: 0x060006D7 RID: 1751 RVA: 0x0001D55F File Offset: 0x0001B75F
	public void SetVolumeMusic(float value)
	{
		AudioManager.SetVolumeMusic(value);
	}

	// Token: 0x060006D9 RID: 1753 RVA: 0x0001D56F File Offset: 0x0001B76F
	[CompilerGenerated]
	internal static IEnumerator <Pause>g__Routine|89_0()
	{
		yield return new WaitForEndOfFrame();
		Rect rect = InterfaceManager.instance.pausedViewportRT.rect;
		Vector3 vector = InterfaceManager.instance.pausedViewportRT.TransformPoint(rect.min);
		Vector3 vector2 = InterfaceManager.instance.pausedViewportRT.TransformPoint(rect.max);
		Camera.main.pixelRect = Rect.MinMaxRect(vector.x, vector.y, vector2.x, vector2.y);
		yield break;
	}

	// Token: 0x040004EA RID: 1258
	public static InterfaceManager instance;

	// Token: 0x040004EB RID: 1259
	public HUDTrack hudTrack;

	// Token: 0x040004EC RID: 1260
	public Canvas mainCanvas;

	// Token: 0x040004ED RID: 1261
	public GameObject bonusUI;

	// Token: 0x040004EE RID: 1262
	public TMP_Text bonusWumpaCount;

	// Token: 0x040004EF RID: 1263
	public TMP_Text bonusCrateCount;

	// Token: 0x040004F0 RID: 1264
	public TMP_Text bonusLivesCount;

	// Token: 0x040004F1 RID: 1265
	public TMP_Text levelName;

	// Token: 0x040004F2 RID: 1266
	public TMP_Text levelAuthor;

	// Token: 0x040004F3 RID: 1267
	public UIScreen HUD;

	// Token: 0x040004F4 RID: 1268
	public UIScreen PauseScreen;

	// Token: 0x040004F5 RID: 1269
	public Button pauseScreenQuitButton;

	// Token: 0x040004F6 RID: 1270
	public Button pauseScreenWarpRoomButton;

	// Token: 0x040004F7 RID: 1271
	public Button pauseScreenBackToCPButton;

	// Token: 0x040004F8 RID: 1272
	public Button pauseScreenRestartButton;

	// Token: 0x040004F9 RID: 1273
	public UIScreen optionsScreen;

	// Token: 0x040004FA RID: 1274
	public UIScreen graphicsScreen;

	// Token: 0x040004FB RID: 1275
	public UIScreen audioScreen;

	// Token: 0x040004FC RID: 1276
	public UIScreen trialInviteScreen;

	// Token: 0x040004FD RID: 1277
	public UIScreen mainMenuScreen;

	// Token: 0x040004FE RID: 1278
	public FadeScreen fadeScreen;

	// Token: 0x040004FF RID: 1279
	public SaveLoadScreen saveLoadScreen;

	// Token: 0x04000500 RID: 1280
	public DynamicConfirmScreen dynamicConfirmScreen;

	// Token: 0x04000501 RID: 1281
	public ConfirmSaveUI confirmSaveScreen;

	// Token: 0x04000502 RID: 1282
	public GameObject underwaterOverlay;

	// Token: 0x04000503 RID: 1283
	public GameObject darknessEditorOverlay;

	// Token: 0x04000504 RID: 1284
	public Button newGameButton;

	// Token: 0x04000505 RID: 1285
	public Button loadGameButton;

	// Token: 0x04000506 RID: 1286
	public RectTransform pausedViewportRT;

	// Token: 0x04000507 RID: 1287
	public GameOverScreen gameOverScreen;

	// Token: 0x04000508 RID: 1288
	public ControlMapper controlMapper;

	// Token: 0x04000509 RID: 1289
	public Slider masterVol;

	// Token: 0x0400050A RID: 1290
	public Slider sfxVol;

	// Token: 0x0400050B RID: 1291
	public Slider musicVol;

	// Token: 0x0400050C RID: 1292
	public TMP_Text nicknameText;

	// Token: 0x0400050D RID: 1293
	public TMP_Text percentCompleteText;

	// Token: 0x0400050E RID: 1294
	public TMP_FontAsset selectedFont;

	// Token: 0x0400050F RID: 1295
	public TMP_FontAsset unselectedFont;

	// Token: 0x04000510 RID: 1296
	public Toggle postProcessingToggle;

	// Token: 0x04000511 RID: 1297
	public Toggle ditheringToggle;

	// Token: 0x04000512 RID: 1298
	public Toggle scanlinesToggle;

	// Token: 0x04000513 RID: 1299
	public Toggle affineWarpingToggle;

	// Token: 0x04000514 RID: 1300
	public Slider vertexSlider;

	// Token: 0x04000515 RID: 1301
	public Slider resolutionSlider;

	// Token: 0x04000516 RID: 1302
	public Slider colourDpethSlider;

	// Token: 0x04000517 RID: 1303
	public Slider subtractiveFadeSlider;

	// Token: 0x04000518 RID: 1304
	[Header("---Mobile---")]
	public Slider mobileJoystickOpacitySlider;

	// Token: 0x04000519 RID: 1305
	public Slider mobileButtonScaleSlider;

	// Token: 0x0400051A RID: 1306
	public Slider mobileButtonPositionSlider;

	// Token: 0x0400051B RID: 1307
	public CanvasGroup mobileJoystickCanvasGroup;

	// Token: 0x0400051C RID: 1308
	public CanvasGroup exampleJoystickCanvasGroup;

	// Token: 0x0400051D RID: 1309
	public Toggle useDPADToggle;

	// Token: 0x0400051E RID: 1310
	public GameObject mobileJoystickObj;

	// Token: 0x0400051F RID: 1311
	public GameObject DPadObj;

	// Token: 0x04000520 RID: 1312
	public GameObject exampleJoystickObj;

	// Token: 0x04000521 RID: 1313
	public GameObject exampleDpadObj;

	// Token: 0x04000522 RID: 1314
	public GameObject faceButtonsObj;

	// Token: 0x04000523 RID: 1315
	public GameObject exampleFaceButtonsObj;

	// Token: 0x04000524 RID: 1316
	public TMP_Dropdown mobileOrientationDropdown;

	// Token: 0x04000525 RID: 1317
	[Header("---Boss UI---")]
	public GameObject bossUIHolder;

	// Token: 0x04000526 RID: 1318
	public Image bossIcon;

	// Token: 0x04000527 RID: 1319
	public UICornersGradient[] bossHP;
}
