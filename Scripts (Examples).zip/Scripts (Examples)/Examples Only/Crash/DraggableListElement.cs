﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;

// Token: 0x0200000D RID: 13
public class DraggableListElement : MonoBehaviour, IBeginDragHandler, IEventSystemHandler, IEndDragHandler, IDragHandler
{
	// Token: 0x17000003 RID: 3
	// (get) Token: 0x06000037 RID: 55 RVA: 0x000033AB File Offset: 0x000015AB
	// (set) Token: 0x06000038 RID: 56 RVA: 0x000033B3 File Offset: 0x000015B3
	public DraggableList List { get; private set; }

	// Token: 0x06000039 RID: 57 RVA: 0x000033BC File Offset: 0x000015BC
	public void Init(DraggableList list)
	{
		this.List = list;
	}

	// Token: 0x0600003A RID: 58 RVA: 0x000033C8 File Offset: 0x000015C8
	private void Start()
	{
		if (this.List == null)
		{
			DraggableList componentInParent = base.GetComponentInParent<DraggableList>();
			if (componentInParent != null)
			{
				this.Init(componentInParent);
				return;
			}
			Debug.LogError("ListElement has not been init", this);
		}
	}

	// Token: 0x0600003B RID: 59 RVA: 0x00003400 File Offset: 0x00001600
	public void OnBeginDrag(PointerEventData eventData)
	{
		if (eventData.button == PointerEventData.InputButton.Left)
		{
			this.visual.SetParent(this.List.transit);
		}
	}

	// Token: 0x0600003C RID: 60 RVA: 0x00003420 File Offset: 0x00001620
	public void OnDrag(PointerEventData eventData)
	{
		if (eventData.button == PointerEventData.InputButton.Left)
		{
			this.visual.position = Input.mousePosition;
		}
	}

	// Token: 0x0600003D RID: 61 RVA: 0x0000343A File Offset: 0x0000163A
	public void OnEndDrag(PointerEventData eventData)
	{
		if (eventData.button == PointerEventData.InputButton.Left)
		{
			this.List.DropElement(this, eventData.position);
			this.visual.SetParent(base.transform);
			this.visual.localPosition = Vector3.zero;
		}
	}

	// Token: 0x04000032 RID: 50
	public Transform visual;

	// Token: 0x04000033 RID: 51
	public UnityEvent<int, int> onOrderChanged;
}
