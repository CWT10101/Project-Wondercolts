﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200010C RID: 268
public class SaveLoadScreen : MonoBehaviour
{
	// Token: 0x06000836 RID: 2102 RVA: 0x00022A8B File Offset: 0x00020C8B
	private void OnEnable()
	{
		this.Init();
	}

	// Token: 0x06000837 RID: 2103 RVA: 0x00022A93 File Offset: 0x00020C93
	public void Init()
	{
		this.SetMainPanel();
		this.activeSlot.Refresh();
		this.autoSaveToggle.SetIsOnWithoutNotify(SaveData.Info.useAutosave);
	}

	// Token: 0x06000838 RID: 2104 RVA: 0x00022ABC File Offset: 0x00020CBC
	public void SetSlots()
	{
		SaveSlotUI[] array = this.saveSlots;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].Refresh();
		}
	}

	// Token: 0x06000839 RID: 2105 RVA: 0x00022AE8 File Offset: 0x00020CE8
	public void SetPanel(GameObject panel, string headerTitle)
	{
		this.mainPanel.SetActive(false);
		this.slotsPanel.SetActive(false);
		panel.SetActive(true);
		this.headerText.text = headerTitle;
		this.SetSlots();
		this.backButtonObj.SetActive(this.slotsPanel.activeSelf);
	}

	// Token: 0x0600083A RID: 2106 RVA: 0x00022B3C File Offset: 0x00020D3C
	public void SetMainPanel()
	{
		this.SetPanel(this.mainPanel, "SAVE/LOAD");
	}

	// Token: 0x0600083B RID: 2107 RVA: 0x00022B50 File Offset: 0x00020D50
	public void SetSavePanel()
	{
		SaveSlotUI[] array = this.saveSlots;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].context = SaveSlotUI.Context.Save;
		}
		this.SetPanel(this.slotsPanel, "SAVE");
	}

	// Token: 0x0600083C RID: 2108 RVA: 0x00022B8C File Offset: 0x00020D8C
	public void SetLoadPanel()
	{
		SaveSlotUI[] array = this.saveSlots;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].context = SaveSlotUI.Context.Load;
		}
		this.SetPanel(this.slotsPanel, "LOAD");
	}

	// Token: 0x0600083D RID: 2109 RVA: 0x00022BC8 File Offset: 0x00020DC8
	public void SetDeletePanel()
	{
		SaveSlotUI[] array = this.saveSlots;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].context = SaveSlotUI.Context.Delete;
		}
		this.SetPanel(this.slotsPanel, "DELETE");
	}

	// Token: 0x0600083E RID: 2110 RVA: 0x00022C04 File Offset: 0x00020E04
	public void SetAutosave(bool value)
	{
		SaveData.Info.useAutosave = value;
		this.activeSlot.Refresh();
	}

	// Token: 0x040005F8 RID: 1528
	public SaveSlotUI activeSlot;

	// Token: 0x040005F9 RID: 1529
	public SaveSlotUI[] saveSlots;

	// Token: 0x040005FA RID: 1530
	public GameObject backButtonObj;

	// Token: 0x040005FB RID: 1531
	public TMP_Text headerText;

	// Token: 0x040005FC RID: 1532
	public GameObject mainPanel;

	// Token: 0x040005FD RID: 1533
	public GameObject slotsPanel;

	// Token: 0x040005FE RID: 1534
	public UIScreen screen;

	// Token: 0x040005FF RID: 1535
	public Toggle autoSaveToggle;

	// Token: 0x04000600 RID: 1536
	public Button deleteSaveButton;
}
