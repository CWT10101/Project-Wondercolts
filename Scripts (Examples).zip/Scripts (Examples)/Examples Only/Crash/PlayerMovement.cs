﻿using System;
using UnityEngine;

// Token: 0x02000042 RID: 66
public class PlayerMovement : MonoBehaviour
{
	// Token: 0x060001B2 RID: 434 RVA: 0x0000777B File Offset: 0x0000597B
	private void Start()
	{
		this.cc = base.GetComponent<CharacterController>();
		this.psx = Object.FindObjectOfType<PSXEffects>();
		this.dirLight.gameObject.SetActive(false);
		this.museumText.SetActive(false);
	}

	// Token: 0x060001B3 RID: 435 RVA: 0x000077B4 File Offset: 0x000059B4
	private void Update()
	{
		this.cc.Move((base.transform.forward * Input.GetAxisRaw("Vertical") + base.transform.right * Input.GetAxisRaw("Horizontal")).normalized * this.moveSpeed * Time.deltaTime);
		if (!this.cc.isGrounded)
		{
			this.cc.Move(Vector3.up * Time.deltaTime * Physics.gravity.y);
		}
	}

	// Token: 0x060001B4 RID: 436 RVA: 0x0000785A File Offset: 0x00005A5A
	private void OnTriggerEnter(Collider other)
	{
		if (other.transform.tag == "DemoRoom")
		{
			this.ToggleDemoMode(true);
		}
	}

	// Token: 0x060001B5 RID: 437 RVA: 0x0000787A File Offset: 0x00005A7A
	private void OnTriggerExit(Collider other)
	{
		if (other.transform.tag == "DemoRoom")
		{
			this.ToggleDemoMode(false);
		}
	}

	// Token: 0x060001B6 RID: 438 RVA: 0x0000789C File Offset: 0x00005A9C
	public void ToggleDemoMode(bool enabled)
	{
		if (enabled)
		{
			RenderSettings.fog = false;
			this.psx.favorRed = 0f;
			this.psx.maxDarkness = 0;
			this.psx.resolutionFactor = 1;
			this.psx.polygonalDrawDistance = -1f;
			this.psx.dithering = false;
			this.psx.colorDepth = 24;
			this.dirLight.gameObject.SetActive(true);
			this.museumText.SetActive(true);
			this.psx.UpdateProperties();
			return;
		}
		RenderSettings.fog = true;
		this.psx.favorRed = 1f;
		this.psx.maxDarkness = 10;
		this.psx.resolutionFactor = 2;
		this.psx.polygonalDrawDistance = 30.61f;
		this.psx.dithering = false;
		this.psx.colorDepth = 24;
		this.dirLight.gameObject.SetActive(false);
		this.museumText.SetActive(false);
		this.psx.UpdateProperties();
	}

	// Token: 0x040000C8 RID: 200
	public float moveSpeed = 10f;

	// Token: 0x040000C9 RID: 201
	public Light dirLight;

	// Token: 0x040000CA RID: 202
	public GameObject museumText;

	// Token: 0x040000CB RID: 203
	private CharacterController cc;

	// Token: 0x040000CC RID: 204
	private PSXEffects psx;
}
