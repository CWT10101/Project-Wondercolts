﻿using System;
using System.IO;
using UnityEngine;

// Token: 0x0200010A RID: 266
public static class SaveData
{
	// Token: 0x17000105 RID: 261
	// (get) Token: 0x0600081A RID: 2074 RVA: 0x0002230C File Offset: 0x0002050C
	public static string SaveDirectory
	{
		get
		{
			return Application.persistentDataPath;
		}
	}

	// Token: 0x17000106 RID: 262
	// (get) Token: 0x0600081B RID: 2075 RVA: 0x00022313 File Offset: 0x00020513
	public static string LegacySaveFilePath
	{
		get
		{
			return Path.Combine(SaveData.SaveDirectory, "save.dat");
		}
	}

	// Token: 0x17000107 RID: 263
	// (get) Token: 0x0600081C RID: 2076 RVA: 0x00022324 File Offset: 0x00020524
	public static string SaveFilePath
	{
		get
		{
			if (SaveData.ActiveSlot != -1)
			{
				return SaveData.GetSavePath((byte)SaveData.ActiveSlot);
			}
			return null;
		}
	}

	// Token: 0x17000108 RID: 264
	// (get) Token: 0x0600081D RID: 2077 RVA: 0x0002233B File Offset: 0x0002053B
	// (set) Token: 0x0600081E RID: 2078 RVA: 0x00022349 File Offset: 0x00020549
	public static sbyte ActiveSlot
	{
		get
		{
			return (sbyte)PlayerPrefs.GetInt("SaveData_ActiveSlot", -1);
		}
		set
		{
			if (value == SaveData.ActiveSlot)
			{
				return;
			}
			PlayerPrefs.SetInt("SaveData_ActiveSlot", (int)value);
			Debug.Log("Active Slot set to " + value.ToString());
		}
	}

	// Token: 0x17000109 RID: 265
	// (get) Token: 0x0600081F RID: 2079 RVA: 0x00022375 File Offset: 0x00020575
	// (set) Token: 0x06000820 RID: 2080 RVA: 0x00022383 File Offset: 0x00020583
	public static sbyte ContinueSlot
	{
		get
		{
			return (sbyte)PlayerPrefs.GetInt("SaveData_ContinueSlot", -1);
		}
		set
		{
			if (value == SaveData.ContinueSlot)
			{
				return;
			}
			PlayerPrefs.SetInt("SaveData_ContinueSlot", (int)value);
			Debug.Log("Continue Slot set to " + value.ToString());
		}
	}

	// Token: 0x06000821 RID: 2081 RVA: 0x000223AF File Offset: 0x000205AF
	public static string GetSavePath(byte slot)
	{
		return Path.Combine(SaveData.SaveDirectory, string.Format("slot{0}.dat", slot));
	}

	// Token: 0x1700010A RID: 266
	// (get) Token: 0x06000822 RID: 2082 RVA: 0x000223CB File Offset: 0x000205CB
	public static SaveDataInfo Info
	{
		get
		{
			return SaveData._info;
		}
	}

	// Token: 0x06000823 RID: 2083 RVA: 0x000223D4 File Offset: 0x000205D4
	public static bool GetEmptySlot(out byte slot)
	{
		for (byte b = 0; b < 4; b += 1)
		{
			if (!File.Exists(SaveData.GetSavePath(b)))
			{
				slot = b;
				return true;
			}
		}
		slot = 0;
		return false;
	}

	// Token: 0x06000824 RID: 2084 RVA: 0x00022404 File Offset: 0x00020604
	public static bool GetExistingSlot(out byte slot)
	{
		for (byte b = 0; b < 4; b += 1)
		{
			if (File.Exists(SaveData.GetSavePath(b)))
			{
				slot = b;
				return true;
			}
		}
		slot = 0;
		return false;
	}

	// Token: 0x06000825 RID: 2085 RVA: 0x00022434 File Offset: 0x00020634
	public static bool IsLegacySavePresent()
	{
		return File.Exists(SaveData.LegacySaveFilePath);
	}

	// Token: 0x06000826 RID: 2086 RVA: 0x00022440 File Offset: 0x00020640
	public static void Load()
	{
		SaveData.Reset();
		SaveData.Load(SaveData.Info, SaveData.SaveFilePath);
	}

	// Token: 0x06000827 RID: 2087 RVA: 0x00022458 File Offset: 0x00020658
	public static void Load(SaveDataInfo info, string path = null)
	{
		if (path == null)
		{
			path = SaveData.SaveFilePath;
		}
		if (File.Exists(path))
		{
			using (FileStream fileStream = new FileStream(path, FileMode.Open))
			{
				using (BinaryReader binaryReader = new BinaryReader(fileStream))
				{
					info.name = binaryReader.ReadString();
					info.lives = binaryReader.ReadByte();
					info.wumpa = binaryReader.ReadByte();
					if (fileStream.Length - fileStream.Position <= 27L)
					{
						SaveData.ReadPartialV1(binaryReader, info);
					}
					else
					{
						SaveData.ReadPartialV2(binaryReader, info);
					}
				}
			}
		}
	}

	// Token: 0x06000828 RID: 2088 RVA: 0x00022500 File Offset: 0x00020700
	public static bool GetSlotInfo(byte slot, out SaveDataInfo info)
	{
		if (!File.Exists(SaveData.GetSavePath(slot)))
		{
			info = null;
			return false;
		}
		info = new SaveDataInfo();
		SaveData.Load(info, SaveData.GetSavePath(slot));
		return true;
	}

	// Token: 0x06000829 RID: 2089 RVA: 0x00022529 File Offset: 0x00020729
	public static bool PathExists()
	{
		return File.Exists(SaveData.SaveFilePath);
	}

	// Token: 0x0600082A RID: 2090 RVA: 0x00022535 File Offset: 0x00020735
	public static void Autosave()
	{
		if (SaveData.Info.useAutosave && SaveData.ActiveSlot != -1 && SaveData.SlotExists(SaveData.ActiveSlot))
		{
			SaveData.Save();
		}
	}

	// Token: 0x0600082B RID: 2091 RVA: 0x0002255C File Offset: 0x0002075C
	public static void Save()
	{
		SaveData.Save(SaveData.Info);
	}

	// Token: 0x0600082C RID: 2092 RVA: 0x00022568 File Offset: 0x00020768
	public static void Save(SaveDataInfo info)
	{
		using (FileStream fileStream = new FileStream(SaveData.SaveFilePath, FileMode.Create))
		{
			using (BinaryWriter binaryWriter = new BinaryWriter(fileStream))
			{
				binaryWriter.Write(info.name);
				binaryWriter.Write(info.lives);
				binaryWriter.Write(info.wumpa);
				binaryWriter.Write(info.visitedCreator);
				binaryWriter.Write(info.receivedTrialInvite);
				for (int i = 0; i < 10; i++)
				{
					binaryWriter.Write(info.lvlAllCrates[i]);
				}
				for (int i = 0; i < 10; i++)
				{
					binaryWriter.Write(info.lvlTapes[i]);
				}
				for (int i = 0; i < 5; i++)
				{
					binaryWriter.Write(info.lvlTrials[i]);
				}
				for (int i = 0; i < 5; i++)
				{
					binaryWriter.Write(info.lvlSpecialGems[i]);
				}
				for (int i = 0; i < 10; i++)
				{
					binaryWriter.Write(info.tapeMedals[i]);
				}
				for (int i = 0; i < 5; i++)
				{
					binaryWriter.Write(info.trialMedals[i]);
				}
				binaryWriter.Write(info.useAutosave);
			}
		}
	}

	// Token: 0x0600082D RID: 2093 RVA: 0x000226A4 File Offset: 0x000208A4
	public static void Reset()
	{
		SaveData.Info.name = "Crash B.";
		SaveData.Info.lives = 5;
		SaveData.Info.wumpa = 0;
		SaveData.Info.lvlAllCrates.Default<bool>();
		SaveData.Info.lvlTapes.Default<bool>();
		SaveData.Info.lvlTrials.Default<bool>();
		SaveData.Info.lvlSpecialGems.Default<bool>();
		SaveData.Info.tapeMedals.Default<byte>();
		SaveData.Info.trialMedals.Default<byte>();
		SaveData.Info.visitedCreator = false;
		SaveData.Info.receivedTrialInvite = false;
		SaveData.Info.useAutosave = true;
	}

	// Token: 0x0600082E RID: 2094 RVA: 0x00022754 File Offset: 0x00020954
	private static void ReadPartialV1(BinaryReader br, SaveDataInfo info)
	{
		for (int i = 0; i < 5; i++)
		{
			info.lvlAllCrates[i] = br.ReadBoolean();
		}
		for (int j = 0; j < 5; j++)
		{
			info.lvlTapes[j] = br.ReadBoolean();
		}
		for (int k = 0; k < 5; k++)
		{
			info.lvlTrials[k] = br.ReadBoolean();
		}
		for (int l = 0; l < 5; l++)
		{
			info.tapeMedals[l] = br.ReadByte();
		}
		for (int m = 0; m < 5; m++)
		{
			info.trialMedals[m] = br.ReadByte();
		}
		info.visitedCreator = br.ReadBoolean();
		try
		{
			info.receivedTrialInvite = br.ReadBoolean();
		}
		catch (EndOfStreamException)
		{
			info.receivedTrialInvite = false;
		}
	}

	// Token: 0x0600082F RID: 2095 RVA: 0x0002281C File Offset: 0x00020A1C
	private static void ReadPartialV2(BinaryReader br, SaveDataInfo info)
	{
		info.visitedCreator = br.ReadBoolean();
		info.receivedTrialInvite = br.ReadBoolean();
		for (int i = 0; i < 10; i++)
		{
			info.lvlAllCrates[i] = br.ReadBoolean();
		}
		for (int j = 0; j < 10; j++)
		{
			info.lvlTapes[j] = br.ReadBoolean();
		}
		for (int k = 0; k < 5; k++)
		{
			info.lvlTrials[k] = br.ReadBoolean();
		}
		for (int l = 0; l < 5; l++)
		{
			info.lvlSpecialGems[l] = br.ReadBoolean();
		}
		for (int m = 0; m < 10; m++)
		{
			info.tapeMedals[m] = br.ReadByte();
		}
		for (int n = 0; n < 5; n++)
		{
			info.trialMedals[n] = br.ReadByte();
		}
		try
		{
			info.useAutosave = br.ReadBoolean();
		}
		catch (EndOfStreamException)
		{
			info.useAutosave = true;
		}
	}

	// Token: 0x06000830 RID: 2096 RVA: 0x00022914 File Offset: 0x00020B14
	public static void Delete()
	{
		SaveData.Reset();
		File.Delete(SaveData.SaveFilePath);
	}

	// Token: 0x06000831 RID: 2097 RVA: 0x00022925 File Offset: 0x00020B25
	public static void Delete(byte slot)
	{
		if (!SaveData.SlotExists((sbyte)slot))
		{
			return;
		}
		if (slot == (byte)SaveData.ActiveSlot)
		{
			SaveData.Reset();
		}
		File.Delete(SaveData.GetSavePath(slot));
	}

	// Token: 0x06000832 RID: 2098 RVA: 0x00022949 File Offset: 0x00020B49
	public static bool SlotExists(sbyte slot)
	{
		return slot != -1 && File.Exists(SaveData.GetSavePath((byte)slot));
	}

	// Token: 0x040005E9 RID: 1513
	public const string SLOT_PREF = "SaveData_ActiveSlot";

	// Token: 0x040005EA RID: 1514
	public const string CONTINUE_SLOT_PREF = "SaveData_ContinueSlot";

	// Token: 0x040005EB RID: 1515
	private static readonly SaveDataInfo _info = new SaveDataInfo();
}
