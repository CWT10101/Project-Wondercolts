﻿using System;
using UnityEngine;

// Token: 0x0200006A RID: 106
public class CortexCreator : CreatorBoss, IMetadataReceiver<ProjectileMetadata>
{
	// Token: 0x17000076 RID: 118
	// (get) Token: 0x060002A6 RID: 678 RVA: 0x0000B8EC File Offset: 0x00009AEC
	public override IMover Mover
	{
		get
		{
			IMover result;
			if ((result = this._mover) == null)
			{
				result = (this._mover = base.gameObject.AddComponent<CCMover>().Init(this.cc, true));
			}
			return result;
		}
	}

	// Token: 0x17000077 RID: 119
	// (get) Token: 0x060002A7 RID: 679 RVA: 0x0000B924 File Offset: 0x00009B24
	public override BossPhase[] Phases
	{
		get
		{
			BossPhase[] result;
			if ((result = this._phases) == null)
			{
				result = (this._phases = this.CreatePhases(this.maxHPSetting));
			}
			return result;
		}
	}

	// Token: 0x17000078 RID: 120
	// (get) Token: 0x060002A8 RID: 680 RVA: 0x0000B950 File Offset: 0x00009B50
	public override BossPhase FallbackPhase
	{
		get
		{
			BossPhase result;
			if ((result = this._fallbackPhase) == null)
			{
				result = (this._fallbackPhase = this.CreateFallbackPhase());
			}
			return result;
		}
	}

	// Token: 0x060002A9 RID: 681 RVA: 0x0000B978 File Offset: 0x00009B78
	private BossPhase CreatePhase(int phaseIndex)
	{
		return new BossPhase("Phase " + phaseIndex.ToString())
		{
			PhaseEnter = delegate(CreatorBoss self, BossPhase ctx)
			{
				this.projectilesThrown = 0;
				if (phaseIndex == 0)
				{
					this.UpdateFacing();
					this.SetShieldOn();
				}
			},
			PhaseExit = delegate(CreatorBoss self, BossPhase ctx)
			{
				this.isDangerous = false;
				this.animator.Play(this.animHit);
				AudioManager.Play(this.hitSound, AudioManager.MixerTarget.SFX, new Vector3?(this.collider.bounds.center), null);
				AudioManager.Play(this.growlSound, AudioManager.MixerTarget.SFX, new Vector3?(this.collider.bounds.center), null);
				this.SetVelocity((CrashController.instance.transform.position.x < this.transform.position.x) ? this.hitKnockback : (-this.hitKnockback), this.hitKnockback);
				this.wasHit = true;
			},
			Evaluate = delegate(CreatorBoss self, BossPhase ctx)
			{
				if (!this.isDead && this.facing != 0)
				{
					Quaternion quaternion = Quaternion.LookRotation(Vector3.right * Mathf.Sign((float)this.facing));
					this.transform.rotation = Quaternion.RotateTowards(this.transform.rotation, quaternion, 720f * Time.fixedDeltaTime);
					if (this.transform.rotation == quaternion)
					{
						this.facing = 0;
					}
				}
				if (self.MoveResult.Grounded)
				{
					if (this.IsAnimationState(this.animFalling))
					{
						if (this.cc.isGrounded)
						{
							this.ClearVelocity();
							this.animator.Play(this.animLanding);
							AudioManager.Play(this.landSound, AudioManager.MixerTarget.SFX, new Vector3?(this.transform.position), null);
							return;
						}
					}
					else if (this.IsAnimationState(this.animLanding))
					{
						if (this.AnimationJustStarted())
						{
							this.ClearVelocity();
						}
						if (this.IsAnimationFinished())
						{
							this.animator.Play(this.animJumpOnBoard);
							return;
						}
					}
					else if (this.IsAnimationState(this.animJumpOnBoard))
					{
						if (this.AnimationJustStarted())
						{
							self.AddVelocity_Y(this.gravityForce / 6f * Time.fixedDeltaTime);
						}
						if (this.IsAnimationFinished())
						{
							this.UpdateFacing();
							this.animator.Play(this.animIdle);
							this.wasHit = false;
							this.isDangerous = true;
							this.ClearVelocity();
							return;
						}
					}
					else if (this.IsAnimationState(this.animHit))
					{
						if (this.AnimationJustStarted())
						{
							this.Hover(false);
						}
						if (this.IsAnimationFinished())
						{
							this.ClearVelocity();
							this.animator.Play(this.animLanding);
							AudioManager.Play(this.landSound, AudioManager.MixerTarget.SFX, new Vector3?(this.transform.position), null);
							return;
						}
					}
				}
				else if (this.IsAnimationState(this.animHit))
				{
					self.AddVelocity_Y(-this.gravityForce * Time.fixedDeltaTime);
					if (this.AnimationJustStarted())
					{
						this.Hover(false);
					}
					if (this.IsAnimationFinished())
					{
						this.animator.Play(this.animFalling);
						return;
					}
				}
				else if (this.IsAnimationState(this.animIdle))
				{
					this.Hover(true);
					if ((this.tLastFled == 0f || (Clock.SynchronizedTime - this.tLastFled > this.fleeInterval && !CrashController.instance.isDead && !this.isVulnerable)) && MathUtil.InRange(this.transform.position, CrashController.instance.transform.position, this.fleeRadius))
					{
						if (this.FacingCrash())
						{
							this.animator.Play(this.animShoot);
						}
						else
						{
							this.UpdateFacing();
						}
						this.RunFromCrash();
						return;
					}
				}
				else if (this.IsAnimationState(this.animShoot))
				{
					if (this.IsAnimationFinished())
					{
						if (this.tLastFled != 0f && (Clock.SynchronizedTime - this.tLastFled <= this.fleeInterval || CrashController.instance.isDead || this.isVulnerable))
						{
							if (!this.FacingCrash())
							{
								this.UpdateFacing();
							}
							this.animator.Play(this.animIdle);
							this.ClearVelocity();
							return;
						}
						if (MathUtil.InRange(this.transform.position, CrashController.instance.transform.position, this.fleeRadius))
						{
							if (this.FacingCrash())
							{
								this.animator.Play(this.animShoot);
							}
							else
							{
								this.animator.Play(this.animIdle);
								this.UpdateFacing();
							}
							this.RunFromCrash();
							return;
						}
						this.animator.Play(this.animIdle);
						this.UpdateFacing();
						return;
					}
				}
				else if (this.IsAnimationState(this.animJumpOnBoard))
				{
					if (this.AnimationJustStarted())
					{
						self.AddVelocity_Y(this.gravityForce / 6f * Time.fixedDeltaTime);
					}
					if (this.IsAnimationFinished())
					{
						this.UpdateFacing();
						this.animator.Play(this.animIdle);
						this.wasHit = false;
						this.isDangerous = true;
						this.ClearVelocity();
						return;
					}
				}
				else if (this.IsAnimationState(this.animLanding))
				{
					if (this.IsAnimationFinished())
					{
						this.animator.Play(this.animJumpOnBoard);
						return;
					}
				}
				else if (!this.isDead && !this.isDangerous && !this.cc.isGrounded && this.IsAnimationState(this.animFalling))
				{
					self.AddVelocity_Y(-this.gravityForce * Time.fixedDeltaTime);
				}
			}
		};
	}

	// Token: 0x060002AA RID: 682 RVA: 0x0000B9E9 File Offset: 0x00009BE9
	public void ClearVelocity()
	{
		base.SetVelocity(0f, 0f);
	}

	// Token: 0x060002AB RID: 683 RVA: 0x0000B9FC File Offset: 0x00009BFC
	private bool FacingCrash()
	{
		Debug.Log(string.Format("Facing Crash: {0}", Vector3.Dot(base.transform.forward, (CrashController.instance.transform.position + base.transform.position).normalized) < 0f));
		return Vector3.Dot(base.transform.forward, (CrashController.instance.transform.position + base.transform.position).normalized) < 0f;
	}

	// Token: 0x060002AC RID: 684 RVA: 0x0000BA9C File Offset: 0x00009C9C
	private void RunFromCrash()
	{
		float x = CrashController.instance.transform.position.x;
		float x2 = base.transform.position.x;
		base.SetVelocity((x > x2) ? (-this.moveSpeed) : this.moveSpeed, 0f);
		this.tLastFled = Clock.SynchronizedTime;
	}

	// Token: 0x060002AD RID: 685 RVA: 0x0000BAF8 File Offset: 0x00009CF8
	public void SetShieldOn()
	{
		this.SetShieldSphereEnabled(true);
	}

	// Token: 0x060002AE RID: 686 RVA: 0x0000BB01 File Offset: 0x00009D01
	public void SetShieldOff()
	{
		this.SetShieldSphereEnabled(false);
	}

	// Token: 0x060002AF RID: 687 RVA: 0x0000BB0C File Offset: 0x00009D0C
	private void SetShieldSphereEnabled(bool enabled)
	{
		this.shieldSphere.SetActive(enabled);
		AudioManager.Play(this.shieldSound, AudioManager.MixerTarget.SFX, new Vector3?(this.spawnNode.position), new Vector2?(Vector2.one * (enabled ? 1.25f : 1f)));
	}

	// Token: 0x060002B0 RID: 688 RVA: 0x0000BB60 File Offset: 0x00009D60
	private void UpdateFacing()
	{
		float x = CrashController.instance.transform.position.x;
		float x2 = base.transform.position.x;
		if (x > x2)
		{
			this.facing = 1;
			return;
		}
		if (x < x2)
		{
			this.facing = -1;
		}
	}

	// Token: 0x060002B1 RID: 689 RVA: 0x0000BBAC File Offset: 0x00009DAC
	public void Hover(bool enabled)
	{
		if (enabled)
		{
			Vector3 localPosition = Vector3.up * Mathf.Sin(Time.time * this.bobRate) * this.bobHeight;
			this.visual.transform.localPosition = localPosition;
			return;
		}
		this.visual.transform.localPosition = Vector3.zero;
	}

	// Token: 0x060002B2 RID: 690 RVA: 0x0000BC0C File Offset: 0x00009E0C
	private BossPhase[] CreatePhases(int count)
	{
		BossPhase[] array = new BossPhase[count];
		for (int i = 0; i < count; i++)
		{
			array[i] = this.CreatePhase(i);
		}
		return array;
	}

	// Token: 0x060002B3 RID: 691 RVA: 0x0000BC37 File Offset: 0x00009E37
	public void TrySpawnProjectile()
	{
		if (this.isDead)
		{
			return;
		}
		if (this.projectilesThrown <= this.projectileCount + this.phaseIndex)
		{
			this.projectilesThrown++;
			this.ForceSpawnProjectile();
		}
	}

	// Token: 0x060002B4 RID: 692 RVA: 0x0000BC6B File Offset: 0x00009E6B
	public void CheckVulnerability()
	{
		if (this.isDead)
		{
			return;
		}
		if (this.projectilesThrown >= this.projectileCount + this.phaseIndex)
		{
			this.SetShieldOff();
			base.SetVulnerableOn();
		}
	}

	// Token: 0x060002B5 RID: 693 RVA: 0x0000BC98 File Offset: 0x00009E98
	private void ForceSpawnProjectile()
	{
		Projectile p;
		if (Level.instance)
		{
			p = Object.Instantiate<Projectile>(this.projectilePrefab, this.spawnNode.position, this.spawnNode.rotation, Level.instance.transform);
		}
		else if (LevelManager.instance)
		{
			p = Object.Instantiate<Projectile>(this.projectilePrefab, this.spawnNode.position, this.spawnNode.rotation, LevelManager.instance.projectileHolder);
		}
		else
		{
			p = Object.Instantiate<Projectile>(this.projectilePrefab, this.spawnNode.position, this.spawnNode.rotation);
		}
		this.PostProcessProjectile(p);
		Debug.Log(string.Format("Projectiles Thrown: {0} / Projectile Count: {1} / Phase Index: {2}", this.projectilesThrown, this.projectileCount, this.phaseIndex));
		if (!string.IsNullOrEmpty(this.shootSound))
		{
			AudioManager.Play(this.shootSound, AudioManager.MixerTarget.SFX, new Vector3?(this.spawnNode.position), null);
		}
	}

	// Token: 0x060002B6 RID: 694 RVA: 0x0000BDA5 File Offset: 0x00009FA5
	private BossPhase CreateFallbackPhase()
	{
		return new BossPhase("Fallback")
		{
			PhaseEnter = delegate(CreatorBoss self, BossPhase ctx)
			{
				this.animator.Play(this.animDefeated);
			},
			Evaluate = delegate(CreatorBoss self, BossPhase ctx)
			{
				if (self.MoveResult.Grounded)
				{
					self.SetVelocity(0f, 0f);
					return;
				}
				self.AddVelocity_Y(-this.gravityForce * Time.fixedDeltaTime);
			}
		};
	}

	// Token: 0x060002B7 RID: 695 RVA: 0x0000BDD5 File Offset: 0x00009FD5
	public override void ResetEntity()
	{
		this._phases = null;
		this.projectilesThrown = 0;
		this.tLastFled = 0f;
		base.ResetEntity();
	}

	// Token: 0x060002B8 RID: 696 RVA: 0x0000BDF6 File Offset: 0x00009FF6
	protected virtual void PostProcessProjectile(Projectile p)
	{
		p.flightSpeed += 1f;
		p.transform.LookAt(CrashController.instance.transform.position);
	}

	// Token: 0x060002B9 RID: 697 RVA: 0x0000BE24 File Offset: 0x0000A024
	public void ProcessMetadata(ProjectileMetadata meta)
	{
		this.projectilePrefab = this.potentialProjectiles[(int)meta.projectileIndex];
		if (this.projectilePreVisuals.Length != 0)
		{
			this.SetProjectilePrevisuals((int)meta.projectileIndex);
		}
	}

	// Token: 0x060002BA RID: 698 RVA: 0x0000BE50 File Offset: 0x0000A050
	private void SetProjectilePrevisuals(int index)
	{
		GameObject[] array = this.projectilePreVisuals;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(false);
		}
		this.projectilePreVisuals[index].SetActive(true);
	}

	// Token: 0x0400017E RID: 382
	[SerializeField]
	private CharacterController cc;

	// Token: 0x0400017F RID: 383
	public Transform spawnNode;

	// Token: 0x04000180 RID: 384
	public Projectile projectilePrefab;

	// Token: 0x04000181 RID: 385
	public GameObject shieldSphere;

	// Token: 0x04000182 RID: 386
	public Projectile[] potentialProjectiles;

	// Token: 0x04000183 RID: 387
	public GameObject[] projectilePreVisuals;

	// Token: 0x04000184 RID: 388
	[SerializeField]
	private float gravityForce = 25f;

	// Token: 0x04000185 RID: 389
	[SerializeField]
	private float hitKnockback = 7f;

	// Token: 0x04000186 RID: 390
	[SerializeField]
	private int projectileCount = 3;

	// Token: 0x04000187 RID: 391
	private int projectilesThrown;

	// Token: 0x04000188 RID: 392
	[SerializeField]
	private float fleeRadius = 6f;

	// Token: 0x04000189 RID: 393
	[SerializeField]
	private float fleeInterval = 4f;

	// Token: 0x0400018A RID: 394
	public float moveSpeed = 3f;

	// Token: 0x0400018B RID: 395
	public float bobRate = 1.75f;

	// Token: 0x0400018C RID: 396
	public float bobHeight = 0.2f;

	// Token: 0x0400018D RID: 397
	[Header("Animations")]
	[SerializeField]
	private string animShoot = "Shoot";

	// Token: 0x0400018E RID: 398
	[SerializeField]
	private string animIdle = "Idle";

	// Token: 0x0400018F RID: 399
	[SerializeField]
	private string animJumpOnBoard = "JumpOnBoard";

	// Token: 0x04000190 RID: 400
	[SerializeField]
	private string animFalling = "Flailing";

	// Token: 0x04000191 RID: 401
	[SerializeField]
	private string animLanding = "Landing";

	// Token: 0x04000192 RID: 402
	[SerializeField]
	private string animHit = "Flip";

	// Token: 0x04000193 RID: 403
	[SerializeField]
	private string animDefeated = "Defeated";

	// Token: 0x04000194 RID: 404
	[Header("Sounds")]
	[SerializeField]
	private string hitSound = "SFX_BossImpact";

	// Token: 0x04000195 RID: 405
	[SerializeField]
	private string shieldSound = "SFX_CortexShieldTrigger";

	// Token: 0x04000196 RID: 406
	[SerializeField]
	private string growlSound = "SFX_CortexGrowl";

	// Token: 0x04000197 RID: 407
	[SerializeField]
	private string shootSound = "SFX_CortexShoot";

	// Token: 0x04000198 RID: 408
	[SerializeField]
	private string mineSound = "SFX_CortexMine";

	// Token: 0x04000199 RID: 409
	[SerializeField]
	private string landSound = "SFX_TinyFallBack";

	// Token: 0x0400019A RID: 410
	private IMover _mover;

	// Token: 0x0400019B RID: 411
	private BossPhase[] _phases;

	// Token: 0x0400019C RID: 412
	private BossPhase _fallbackPhase;

	// Token: 0x0400019D RID: 413
	private int facing;

	// Token: 0x0400019E RID: 414
	private float tLastFled;
}
