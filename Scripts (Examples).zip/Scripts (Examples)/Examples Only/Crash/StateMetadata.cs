﻿using System;
using System.IO;
using LevelEditor;

// Token: 0x02000035 RID: 53
public class StateMetadata : ObjectMetadata
{
	// Token: 0x17000054 RID: 84
	// (get) Token: 0x0600015B RID: 347 RVA: 0x00006ABC File Offset: 0x00004CBC
	// (set) Token: 0x0600015C RID: 348 RVA: 0x00006AC4 File Offset: 0x00004CC4
	public string StateDisplayText { get; private set; } = "State";

	// Token: 0x17000055 RID: 85
	// (get) Token: 0x0600015D RID: 349 RVA: 0x00006ACD File Offset: 0x00004CCD
	// (set) Token: 0x0600015E RID: 350 RVA: 0x00006AD5 File Offset: 0x00004CD5
	public byte MaxStateValue { get; private set; } = 3;

	// Token: 0x17000056 RID: 86
	// (get) Token: 0x0600015F RID: 351 RVA: 0x00006ADE File Offset: 0x00004CDE
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000057 RID: 87
	// (get) Token: 0x06000160 RID: 352 RVA: 0x00006AE1 File Offset: 0x00004CE1
	public override int Signature
	{
		get
		{
			return string.Format("{0}|{1}|{2}", "StateMetadata", this.StateDisplayText, this.MaxStateValue).GetHashCode();
		}
	}

	// Token: 0x17000058 RID: 88
	// (get) Token: 0x06000161 RID: 353 RVA: 0x00006B08 File Offset: 0x00004D08
	public override int ValueHash
	{
		get
		{
			return (int)this.state;
		}
	}

	// Token: 0x06000162 RID: 354 RVA: 0x00006B10 File Offset: 0x00004D10
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<StateMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<StateMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x06000163 RID: 355 RVA: 0x00006B3C File Offset: 0x00004D3C
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.state = br.ReadByte();
	}

	// Token: 0x06000164 RID: 356 RVA: 0x00006B4A File Offset: 0x00004D4A
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.state);
	}

	// Token: 0x040000A4 RID: 164
	public byte state;
}
