﻿using System;
using System.IO;
using LevelEditor;

// Token: 0x0200002C RID: 44
public class MusicMetadata : ObjectMetadata
{
	// Token: 0x17000031 RID: 49
	// (get) Token: 0x06000109 RID: 265 RVA: 0x000063B0 File Offset: 0x000045B0
	public override bool SupportsMultiEditing
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000032 RID: 50
	// (get) Token: 0x0600010A RID: 266 RVA: 0x000063B3 File Offset: 0x000045B3
	public override int Signature
	{
		get
		{
			return "MusicMetadata".GetHashCode();
		}
	}

	// Token: 0x17000033 RID: 51
	// (get) Token: 0x0600010B RID: 267 RVA: 0x000063BF File Offset: 0x000045BF
	public override int ValueHash
	{
		get
		{
			return (int)this.musicIndex;
		}
	}

	// Token: 0x0600010C RID: 268 RVA: 0x000063C7 File Offset: 0x000045C7
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.musicIndex = br.ReadSByte();
	}

	// Token: 0x0600010D RID: 269 RVA: 0x000063D5 File Offset: 0x000045D5
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.musicIndex);
	}

	// Token: 0x0600010E RID: 270 RVA: 0x000063E4 File Offset: 0x000045E4
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<MusicMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<MusicMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x04000090 RID: 144
	public sbyte musicIndex;
}
