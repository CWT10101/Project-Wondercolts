﻿using System;

// Token: 0x020000CB RID: 203
public interface IPostEnable
{
	// Token: 0x06000617 RID: 1559
	void OnPostEnable();
}
