﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000C1 RID: 193
[DefaultExecutionOrder(10)]
public class GreenCrate : ColourCrate
{
	// Token: 0x170000E3 RID: 227
	// (get) Token: 0x060005E0 RID: 1504 RVA: 0x00019E26 File Offset: 0x00018026
	public override bool AddsToBoxCount
	{
		get
		{
			return false;
		}
	}

	// Token: 0x170000E4 RID: 228
	// (get) Token: 0x060005E1 RID: 1505 RVA: 0x00019E29 File Offset: 0x00018029
	public static HashSet<GreenCrate> Crates { get; } = new HashSet<GreenCrate>();

	// Token: 0x060005E2 RID: 1506 RVA: 0x00019E30 File Offset: 0x00018030
	protected override void OnEnable()
	{
		base.OnEnable();
		GreenCrate.Crates.Add(this);
		this.SetSolid(SwitchCrate.IsSwitchedOn, true);
	}

	// Token: 0x060005E3 RID: 1507 RVA: 0x00019E50 File Offset: 0x00018050
	private void OnDisable()
	{
		GreenCrate.Crates.Remove(this);
	}
}
