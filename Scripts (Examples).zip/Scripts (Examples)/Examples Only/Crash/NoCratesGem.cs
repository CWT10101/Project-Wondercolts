﻿using System;

// Token: 0x02000120 RID: 288
public class NoCratesGem : SpecialGem
{
}
