﻿using System;
using UnityEngine;

// Token: 0x0200007B RID: 123
public class BrokenCrate : MonoBehaviour
{
	// Token: 0x06000379 RID: 889 RVA: 0x0000F067 File Offset: 0x0000D267
	private void Awake()
	{
		this.SetColour(this.crateCol);
		if (this.sfx != null)
		{
			this.audioSource.clip = this.sfx;
		}
	}

	// Token: 0x0600037A RID: 890 RVA: 0x0000F094 File Offset: 0x0000D294
	public void SetColour(Color col)
	{
		this.rend.material.SetColor("_Color", col);
	}

	// Token: 0x0600037B RID: 891 RVA: 0x0000F0AC File Offset: 0x0000D2AC
	private void Start()
	{
		this.RandomizeRotation();
	}

	// Token: 0x0600037C RID: 892 RVA: 0x0000F0B4 File Offset: 0x0000D2B4
	public void RandomizeRotation()
	{
		int num = Random.Range(0, 4) * 90;
		base.transform.rotation = Quaternion.Euler(0f, (float)num, 0f);
	}

	// Token: 0x04000248 RID: 584
	public Color crateCol;

	// Token: 0x04000249 RID: 585
	public Renderer rend;

	// Token: 0x0400024A RID: 586
	public AudioClip sfx;

	// Token: 0x0400024B RID: 587
	public AudioSource audioSource;
}
