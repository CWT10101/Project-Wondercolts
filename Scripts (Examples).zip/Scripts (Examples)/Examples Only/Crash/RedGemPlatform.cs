﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000106 RID: 262
public class RedGemPlatform : EditorBonusPlatform
{
	// Token: 0x17000103 RID: 259
	// (get) Token: 0x06000801 RID: 2049 RVA: 0x00021D39 File Offset: 0x0001FF39
	public static HashSet<RedGemPlatform> Platforms { get; } = new HashSet<RedGemPlatform>();

	// Token: 0x17000104 RID: 260
	// (get) Token: 0x06000802 RID: 2050 RVA: 0x00021D40 File Offset: 0x0001FF40
	// (set) Token: 0x06000803 RID: 2051 RVA: 0x00021D47 File Offset: 0x0001FF47
	public static bool GemCollected { get; private set; }

	// Token: 0x06000804 RID: 2052 RVA: 0x00021D50 File Offset: 0x0001FF50
	public static void RestoreDefault()
	{
		RedGemPlatform.GemCollected = false;
		foreach (RedGemPlatform redGemPlatform in RedGemPlatform.Platforms)
		{
			redGemPlatform.SetTangible(false);
		}
	}

	// Token: 0x06000805 RID: 2053 RVA: 0x00021DA8 File Offset: 0x0001FFA8
	public static void OnGemCollected()
	{
		RedGemPlatform.GemCollected = true;
		foreach (RedGemPlatform redGemPlatform in RedGemPlatform.Platforms)
		{
			redGemPlatform.SetTangible(true);
		}
	}

	// Token: 0x06000806 RID: 2054 RVA: 0x00021E00 File Offset: 0x00020000
	protected override void OnEnable()
	{
		base.OnEnable();
		RedGemPlatform.Platforms.Add(this);
	}

	// Token: 0x06000807 RID: 2055 RVA: 0x00021E14 File Offset: 0x00020014
	public override void PlayModeChanged(bool isPlaying)
	{
		base.PlayModeChanged(isPlaying);
		this.SetTangible(false);
	}

	// Token: 0x06000808 RID: 2056 RVA: 0x00021E24 File Offset: 0x00020024
	private void OnDestroy()
	{
		RedGemPlatform.Platforms.Remove(this);
	}

	// Token: 0x06000809 RID: 2057 RVA: 0x00021E32 File Offset: 0x00020032
	private void SetTangible(bool tangible)
	{
		if (tangible)
		{
			this.rend.sharedMaterial = this.defaultMat;
		}
		else
		{
			this.rend.sharedMaterial = this.intangibleMat;
		}
		this.collider.enabled = tangible;
	}

	// Token: 0x040005DB RID: 1499
	public MeshRenderer rend;

	// Token: 0x040005DC RID: 1500
	public Material defaultMat;

	// Token: 0x040005DD RID: 1501
	public Material intangibleMat;
}
