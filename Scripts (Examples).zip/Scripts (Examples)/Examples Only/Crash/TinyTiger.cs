﻿using System;
using UnityEngine;

// Token: 0x02000074 RID: 116
public class TinyTiger : CreatorBoss, IMetadataReceiver<AggressionMetadata>
{
	// Token: 0x1700008F RID: 143
	// (get) Token: 0x0600033D RID: 829 RVA: 0x0000DFB0 File Offset: 0x0000C1B0
	public override IMover Mover
	{
		get
		{
			IMover result;
			if ((result = this._mover) == null)
			{
				result = (this._mover = base.gameObject.AddComponent<CCMover>().Init(this.cc, true));
			}
			return result;
		}
	}

	// Token: 0x17000090 RID: 144
	// (get) Token: 0x0600033E RID: 830 RVA: 0x0000DFE8 File Offset: 0x0000C1E8
	public override BossPhase[] Phases
	{
		get
		{
			BossPhase[] result;
			if ((result = this._phases) == null)
			{
				result = (this._phases = this.CreatePhases(this.maxHPSetting));
			}
			return result;
		}
	}

	// Token: 0x17000091 RID: 145
	// (get) Token: 0x0600033F RID: 831 RVA: 0x0000E014 File Offset: 0x0000C214
	public override BossPhase FallbackPhase
	{
		get
		{
			BossPhase result;
			if ((result = this._fallbackPhase) == null)
			{
				result = (this._fallbackPhase = this.CreateFallbackPhase());
			}
			return result;
		}
	}

	// Token: 0x06000340 RID: 832 RVA: 0x0000E03C File Offset: 0x0000C23C
	private BossPhase[] CreatePhases(int count)
	{
		BossPhase[] array = new BossPhase[count];
		for (int i = 0; i < count; i++)
		{
			array[i] = this.CreatePhase(i);
		}
		return array;
	}

	// Token: 0x06000341 RID: 833 RVA: 0x0000E067 File Offset: 0x0000C267
	public override void Teleport()
	{
		base.Teleport();
		base.SetVelocity(0f, 0f);
		this.animator.Play(this.animHit, 0, 0f);
	}

	// Token: 0x06000342 RID: 834 RVA: 0x0000E096 File Offset: 0x0000C296
	public override void ResetEntity()
	{
		base.ResetEntity();
		this.skippedAttacks = 0;
		this._phases = null;
	}

	// Token: 0x06000343 RID: 835 RVA: 0x0000E0AC File Offset: 0x0000C2AC
	protected override void OnEnable()
	{
		base.OnEnable();
		if (this.isDead)
		{
			this.animator.Play(this.animDefeated, 0, 1f);
		}
	}

	// Token: 0x06000344 RID: 836 RVA: 0x0000E0D4 File Offset: 0x0000C2D4
	private BossPhase CreatePhase(int phaseIndex)
	{
		BossPhase bossPhase = new BossPhase("Phase " + phaseIndex.ToString());
		bossPhase.PhaseEnter = delegate(CreatorBoss self, BossPhase ctx)
		{
		};
		bossPhase.PhaseExit = delegate(CreatorBoss self, BossPhase ctx)
		{
			this.isDangerous = false;
			if (!self.isDead)
			{
				this.animator.Play(this.animHit);
			}
			base.SetVelocity((CrashController.instance.transform.position.x < base.transform.position.x) ? this.hitKnockback : (-this.hitKnockback), this.hitKnockback);
			AudioManager.Play(this.hitSound, AudioManager.MixerTarget.SFX, new Vector3?(this.collider.bounds.center), null);
			AudioManager.Play(this.hitGrowlSound, AudioManager.MixerTarget.SFX, new Vector3?(this.collider.bounds.center), null);
		};
		bossPhase.Evaluate = delegate(CreatorBoss self, BossPhase ctx)
		{
			if (self.Velocity.x != 0f)
			{
				base.transform.rotation = Quaternion.RotateTowards(base.transform.rotation, Quaternion.LookRotation(Vector3.right * Mathf.Sign(self.Velocity.x)), 720f * Time.fixedDeltaTime);
			}
			if (self.MoveResult.Grounded)
			{
				foreach (IMover.MoveHit moveHit in self.MoveResult.Hits)
				{
					CrashController crashController;
					if (moveHit.Collider.TryGetComponent<CrashController>(out crashController))
					{
						crashController.TakeDamage(1);
						if (crashController.isDead)
						{
							return;
						}
					}
				}
				if (base.IsAnimationState(this.animHit))
				{
					if (base.IsAnimationFinished())
					{
						base.SetVelocity(0f, 0f);
						this.animator.Play(this.animGetUp);
						AudioManager.Play(this.fallSound, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
						return;
					}
				}
				else if (base.IsAnimationState(this.animGetUp))
				{
					if (base.IsAnimationFinished())
					{
						this.wasHit = false;
						this.isDangerous = true;
						this.JumpTowardCrash();
						return;
					}
				}
				else if (base.IsAnimationState(this.animStuck))
				{
					if (base.IsAnimationFinished())
					{
						if (this.fastPullOut)
						{
							this.animator.Play(this.animPullOut);
							return;
						}
						this.animator.Play(this.animPulling);
						return;
					}
				}
				else if (base.IsAnimationState(this.animPullOut))
				{
					if (base.IsAnimationFinished())
					{
						this.JumpTowardCrash();
						return;
					}
				}
				else if (base.IsAnimationState(this.animAttack))
				{
					self.SetVelocity(0f, 0f);
					if (base.IsAnimationFinished())
					{
						if (this.fastPullOut)
						{
							this.animator.Play(this.animStuck);
						}
						else
						{
							this.animator.Play(this.animPullOut);
						}
						AudioManager.Play(this.jumpSound, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
						AudioManager.Play(this.tridentHitSound, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
						return;
					}
				}
				else if (base.IsAnimationState(this.animJump))
				{
					this.JumpTowardCrash();
					AudioManager.Play(this.jumpSound, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
					return;
				}
			}
			else
			{
				if (base.IsAnimationState(this.animAttack))
				{
					if (base.IsAnimationFinished())
					{
						if (this.fastPullOut)
						{
							this.animator.Play(this.animStuck);
						}
						else
						{
							this.animator.Play(this.animPullOut);
						}
						AudioManager.Play(this.jumpSound, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
						AudioManager.Play(this.tridentHitSound, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
					}
				}
				else if (base.IsAnimationState(this.animStuck))
				{
					if (base.IsAnimationFinished())
					{
						if (this.fastPullOut)
						{
							this.animator.Play(this.animPullOut);
						}
						else
						{
							this.animator.Play(this.animPulling);
						}
					}
				}
				else if (base.IsAnimationState(this.animPullOut))
				{
					if (base.IsAnimationFinished())
					{
						this.JumpTowardCrash();
					}
				}
				else
				{
					base.IsAnimationState(this.animJump);
				}
				self.AddVelocity_Y(-this.gravityForce * Time.fixedDeltaTime);
			}
		};
		return bossPhase;
	}

	// Token: 0x06000345 RID: 837 RVA: 0x0000E140 File Offset: 0x0000C340
	private BossPhase CreateFallbackPhase()
	{
		return new BossPhase("Fallback")
		{
			PhaseEnter = delegate(CreatorBoss self, BossPhase ctx)
			{
				this.animator.Play(this.animDefeated);
			},
			Evaluate = delegate(CreatorBoss self, BossPhase ctx)
			{
				if (self.MoveResult.Grounded)
				{
					self.SetVelocity(0f, 0f);
					return;
				}
				self.AddVelocity_Y(-this.gravityForce * Time.fixedDeltaTime);
			}
		};
	}

	// Token: 0x06000346 RID: 838 RVA: 0x0000E170 File Offset: 0x0000C370
	private void JumpTowardCrash()
	{
		float x = CrashController.instance.transform.position.x;
		float x2 = base.transform.position.x;
		float num = Mathf.Abs(x - x2);
		if (num < this.attackRange)
		{
			float num2 = Mathf.Lerp(0f, this.attackMovementSpeed, Mathf.InverseLerp(0f, this.attackRange, num));
			base.SetVelocity_X((x < x2) ? (-num2) : num2);
			if (this.skippedAttacks < this.skipAttackChances)
			{
				this.skippedAttacks += 1;
				this.animator.Play(this.animJump, 0, 0f);
			}
			else
			{
				this.skippedAttacks = 0;
				this.animator.Play(this.animAttack);
			}
		}
		else
		{
			base.SetVelocity_X((x < x2) ? (-this.movementSpeed) : this.movementSpeed);
			this.animator.Play(this.animJump, 0, 0f);
		}
		base.SetVelocity_Y(this.bounceImpulse);
	}

	// Token: 0x06000347 RID: 839 RVA: 0x0000E278 File Offset: 0x0000C478
	public void PlaySoundWoosh()
	{
		AudioManager.Play(this.tridentWooshSound, AudioManager.MixerTarget.SFX, new Vector3?(this.collider.bounds.center), null);
	}

	// Token: 0x06000348 RID: 840 RVA: 0x0000E2B3 File Offset: 0x0000C4B3
	private void OnDrawGizmosSelected()
	{
		Gizmos.color = Color.red;
		Gizmos.DrawWireSphere(base.transform.position, this.attackRange);
	}

	// Token: 0x06000349 RID: 841 RVA: 0x0000E2D5 File Offset: 0x0000C4D5
	public void ProcessMetadata(AggressionMetadata meta)
	{
		this.skipAttackChances = (byte)Mathf.FloorToInt(Mathf.Lerp(25f, 0f, Mathf.InverseLerp(0f, 5f, (float)meta.aggressionLevel)));
	}

	// Token: 0x0400020A RID: 522
	[SerializeField]
	private CharacterController cc;

	// Token: 0x0400020B RID: 523
	[SerializeField]
	private float movementSpeed = 1.5f;

	// Token: 0x0400020C RID: 524
	[SerializeField]
	private float attackMovementSpeed = 1.5f;

	// Token: 0x0400020D RID: 525
	[SerializeField]
	private float bounceImpulse = 6.5f;

	// Token: 0x0400020E RID: 526
	[SerializeField]
	private float gravityForce = 10f;

	// Token: 0x0400020F RID: 527
	[SerializeField]
	private float attackRange = 4f;

	// Token: 0x04000210 RID: 528
	[SerializeField]
	private float hitKnockback = 2f;

	// Token: 0x04000211 RID: 529
	[Header("Animations")]
	[SerializeField]
	private string animJump = "Jump";

	// Token: 0x04000212 RID: 530
	[SerializeField]
	private string animAttack = "Attack";

	// Token: 0x04000213 RID: 531
	[SerializeField]
	private string animStuck = "Stuck";

	// Token: 0x04000214 RID: 532
	[SerializeField]
	private string animPulling = "Pulling";

	// Token: 0x04000215 RID: 533
	[SerializeField]
	private string animPullOut = "Pull Out";

	// Token: 0x04000216 RID: 534
	[SerializeField]
	private string animHit = "Hit";

	// Token: 0x04000217 RID: 535
	[SerializeField]
	private string animGetUp = "Get Up";

	// Token: 0x04000218 RID: 536
	[SerializeField]
	private string animDefeated = "Defeated";

	// Token: 0x04000219 RID: 537
	[Header("Sounds")]
	[SerializeField]
	private string jumpSound = "SFX_TinyBounce";

	// Token: 0x0400021A RID: 538
	[SerializeField]
	private string tridentHitSound = "SFX_TinyTridentStuck";

	// Token: 0x0400021B RID: 539
	[SerializeField]
	private string hitSound = "SFX_BossImpact";

	// Token: 0x0400021C RID: 540
	[SerializeField]
	private string hitGrowlSound = "SFX_TinyHit";

	// Token: 0x0400021D RID: 541
	[SerializeField]
	private string tridentWooshSound = "SFX_TinyTridentAir";

	// Token: 0x0400021E RID: 542
	[SerializeField]
	private string fallSound = "SFX_TinyFallBack";

	// Token: 0x0400021F RID: 543
	[Header("Behavior")]
	[SerializeField]
	private bool fastPullOut;

	// Token: 0x04000220 RID: 544
	[SerializeField]
	private byte skipAttackChances;

	// Token: 0x04000221 RID: 545
	private byte skippedAttacks;

	// Token: 0x04000222 RID: 546
	private IMover _mover;

	// Token: 0x04000223 RID: 547
	private BossPhase[] _phases;

	// Token: 0x04000224 RID: 548
	private BossPhase _fallbackPhase;
}
