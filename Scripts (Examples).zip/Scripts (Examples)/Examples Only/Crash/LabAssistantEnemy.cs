﻿using System;
using UnityEngine;

// Token: 0x020000D4 RID: 212
public class LabAssistantEnemy : EnemyWithProjectile, IMetadataReceiver<RangeMetadata>
{
	// Token: 0x0600062D RID: 1581 RVA: 0x0001B0CA File Offset: 0x000192CA
	public void ProcessMetadata(RangeMetadata meta)
	{
		this.projectileStrength = (int)meta.range;
	}

	// Token: 0x0600062E RID: 1582 RVA: 0x0001B0D8 File Offset: 0x000192D8
	protected override void PostProcessProjectile(Projectile p)
	{
		p.flightSpeed = (float)this.projectileStrength / 5f * (this.projectileStrengthRange.y - this.projectileStrengthRange.x) + this.projectileStrengthRange.x;
	}

	// Token: 0x0400048D RID: 1165
	[Range(0f, 5f)]
	public int projectileStrength = 2;

	// Token: 0x0400048E RID: 1166
	public Vector2 projectileStrengthRange;
}
