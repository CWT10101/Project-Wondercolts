﻿using System;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x0200007F RID: 127
public class CameraTrigger : MonoBehaviour
{
	// Token: 0x06000388 RID: 904 RVA: 0x0000F414 File Offset: 0x0000D614
	public virtual void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			this.onTriggered.Invoke();
		}
	}

	// Token: 0x06000389 RID: 905 RVA: 0x0000F438 File Offset: 0x0000D638
	public virtual void OnTriggerStay(Collider other)
	{
		if (!this.usingStayTrigger)
		{
			return;
		}
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			this.onTriggerStay.Invoke();
		}
	}

	// Token: 0x0600038A RID: 906 RVA: 0x0000F464 File Offset: 0x0000D664
	public virtual void OnTriggerExit(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			this.onLeftTrigger.Invoke();
		}
	}

	// Token: 0x0400025B RID: 603
	public UnityEvent onTriggered;

	// Token: 0x0400025C RID: 604
	public UnityEvent onTriggerStay;

	// Token: 0x0400025D RID: 605
	public UnityEvent onLeftTrigger;

	// Token: 0x0400025E RID: 606
	public bool usingStayTrigger;
}
