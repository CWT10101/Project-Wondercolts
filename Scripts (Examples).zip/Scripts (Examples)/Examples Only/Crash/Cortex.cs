﻿using System;

// Token: 0x02000069 RID: 105
public class Cortex : Boss
{
	// Token: 0x17000075 RID: 117
	// (get) Token: 0x060002A0 RID: 672 RVA: 0x0000B8B9 File Offset: 0x00009AB9
	protected override BossPhase[] Phases
	{
		get
		{
			throw new NotImplementedException();
		}
	}

	// Token: 0x060002A1 RID: 673 RVA: 0x0000B8C0 File Offset: 0x00009AC0
	public override void TouchBottom(CrashController crash)
	{
		base.TouchBottom(crash);
	}

	// Token: 0x060002A2 RID: 674 RVA: 0x0000B8C9 File Offset: 0x00009AC9
	public override void TouchSide(CrashController crash)
	{
		base.TouchSide(crash);
	}

	// Token: 0x060002A3 RID: 675 RVA: 0x0000B8D2 File Offset: 0x00009AD2
	public override void TouchTop(CrashController crash)
	{
		base.TouchTop(crash);
	}

	// Token: 0x060002A4 RID: 676 RVA: 0x0000B8DB File Offset: 0x00009ADB
	protected override void PerformLogic()
	{
		throw new NotImplementedException();
	}
}
