﻿using System;
using UnityEngine;

// Token: 0x020000FE RID: 254
public class POWExplosion : Explosion
{
	// Token: 0x060007D6 RID: 2006 RVA: 0x000214F0 File Offset: 0x0001F6F0
	public override void FixedUpdate()
	{
		float num = (Time.time - this.tStart) / this.duration;
		if (num > 1f)
		{
			num = 1f;
		}
		foreach (Collider collider in Physics.OverlapSphere(base.transform.position, Mathf.Lerp(0.5f, this.size, num)))
		{
			Crate crate;
			if (collider.TryGetComponent<Crate>(out crate))
			{
				crate.Break();
			}
			Pickup pickup;
			if (collider.TryGetComponent<Pickup>(out pickup) && !(pickup is CrystalPickup) && !(pickup is Mask) && !(pickup is TrialClockPickup))
			{
				pickup.Despawn();
				InterfaceManager.instance.hudTrack.DisplayHUD();
			}
			RooTNT rooTNT;
			if (collider.TryGetComponent<RooTNT>(out rooTNT))
			{
				rooTNT.Explode();
			}
		}
		if (num == 1f)
		{
			Object.Destroy(base.gameObject);
		}
	}
}
