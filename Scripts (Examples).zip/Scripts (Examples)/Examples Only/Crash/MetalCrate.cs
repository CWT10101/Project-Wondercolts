﻿using System;
using UnityEngine;

// Token: 0x020000E4 RID: 228
public class MetalCrate : Crate, IFallOn, ISpin, ISlide, ISlam, ITouchBottom
{
	// Token: 0x170000F1 RID: 241
	// (get) Token: 0x060006FB RID: 1787 RVA: 0x0001DDE8 File Offset: 0x0001BFE8
	public override bool AddsToBoxCount
	{
		get
		{
			return false;
		}
	}

	// Token: 0x060006FC RID: 1788 RVA: 0x0001DDEB File Offset: 0x0001BFEB
	public override void Break()
	{
	}

	// Token: 0x060006FD RID: 1789 RVA: 0x0001DDED File Offset: 0x0001BFED
	public override void ForceBreak()
	{
	}

	// Token: 0x060006FE RID: 1790 RVA: 0x0001DDEF File Offset: 0x0001BFEF
	protected override void LandOnCrash()
	{
		CrashController.instance.TakeDamage(0);
		this.Fall(-5f * Time.fixedDeltaTime);
	}

	// Token: 0x060006FF RID: 1791 RVA: 0x0001DE10 File Offset: 0x0001C010
	protected override void Settle()
	{
		RaycastHit raycastHit;
		if (Physics.Raycast(base.transform.position, Vector3.down, out raycastHit, 1f, -1, QueryTriggerInteraction.Ignore))
		{
			ICrateBouncer crateBouncer;
			if (raycastHit.collider.TryGetComponent<ICrateBouncer>(out crateBouncer))
			{
				crateBouncer.BounceCrate(this);
				return;
			}
			TNTCrate tntcrate;
			if (raycastHit.collider.TryGetComponent<TNTCrate>(out tntcrate))
			{
				tntcrate.FallOn(null);
				return;
			}
			DetonatorCrate detonatorCrate;
			if (raycastHit.collider.TryGetComponentInParent(out detonatorCrate))
			{
				detonatorCrate.FallOn(null);
				Debug.Log("Fell on Detonator");
			}
		}
	}

	// Token: 0x06000700 RID: 1792 RVA: 0x0001DE8E File Offset: 0x0001C08E
	public void FallOn(CrashController crash)
	{
	}

	// Token: 0x06000701 RID: 1793 RVA: 0x0001DE90 File Offset: 0x0001C090
	public void Slam(CrashController crash)
	{
		if (base.IsAbove(crash) && crash.animator.TimeSinceStateChanged < Time.fixedDeltaTime / 2f)
		{
			AudioManager.Play("SFX_IronCrate", AudioManager.MixerTarget.SFX, null, null);
		}
	}

	// Token: 0x06000702 RID: 1794 RVA: 0x0001DEDC File Offset: 0x0001C0DC
	public void Slide(CrashController crash)
	{
		if (base.IsAbove(crash) && crash.animator.TimeSinceStateChanged < Time.fixedDeltaTime / 2f)
		{
			AudioManager.Play("SFX_IronCrate", AudioManager.MixerTarget.SFX, null, null);
		}
	}

	// Token: 0x06000703 RID: 1795 RVA: 0x0001DF28 File Offset: 0x0001C128
	public void Spin(CrashController crash)
	{
	}

	// Token: 0x06000704 RID: 1796 RVA: 0x0001DF2A File Offset: 0x0001C12A
	public void TouchBottom(CrashController crash)
	{
	}
}
