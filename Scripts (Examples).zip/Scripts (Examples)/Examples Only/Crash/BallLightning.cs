﻿using System;
using UnityEngine;

// Token: 0x0200005C RID: 92
public class BallLightning : MonoBehaviour
{
	// Token: 0x06000232 RID: 562 RVA: 0x00009B27 File Offset: 0x00007D27
	private void OnEnable()
	{
		this.DoEffect(true);
	}

	// Token: 0x06000233 RID: 563 RVA: 0x00009B30 File Offset: 0x00007D30
	private void FixedUpdate()
	{
		base.transform.localRotation *= this.q;
		float num = this.t;
		this.t += Time.fixedDeltaTime;
		if (num < this.onDuration && this.t >= this.onDuration)
		{
			this.effect.SetActive(false);
			return;
		}
		if (this.t >= this.d)
		{
			this.DoEffect(false);
		}
	}

	// Token: 0x06000234 RID: 564 RVA: 0x00009BAC File Offset: 0x00007DAC
	private void DoEffect(bool first = false)
	{
		if (!first)
		{
			this.effect.SetActive(true);
		}
		base.transform.rotation = Random.rotationUniform;
		this.t = 0f;
		this.d = this.onDuration + Random.Range(this.timeBetweenActivations.x, this.timeBetweenActivations.y);
		this.q = Quaternion.AngleAxis(Random.Range(this.speedRange.x, this.speedRange.y) * Time.fixedDeltaTime, Random.onUnitSphere);
	}

	// Token: 0x04000139 RID: 313
	public GameObject effect;

	// Token: 0x0400013A RID: 314
	public Vector2 speedRange = Vector2.up;

	// Token: 0x0400013B RID: 315
	public float onDuration = 1f;

	// Token: 0x0400013C RID: 316
	public Vector2 timeBetweenActivations = new Vector2(0.5f, 3f);

	// Token: 0x0400013D RID: 317
	private float t;

	// Token: 0x0400013E RID: 318
	private float d;

	// Token: 0x0400013F RID: 319
	private Quaternion q;
}
