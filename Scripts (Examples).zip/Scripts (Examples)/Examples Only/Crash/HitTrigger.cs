﻿using System;
using UnityEngine;

// Token: 0x020000C2 RID: 194
public class HitTrigger : MonoBehaviour
{
	// Token: 0x060005E6 RID: 1510 RVA: 0x00019E72 File Offset: 0x00018072
	private void OnEnable()
	{
		this.myEnemy = base.GetComponentInParent<Enemy>();
	}

	// Token: 0x060005E7 RID: 1511 RVA: 0x00019E80 File Offset: 0x00018080
	private void OnDisable()
	{
		this.myEnemy = null;
	}

	// Token: 0x060005E8 RID: 1512 RVA: 0x00019E8C File Offset: 0x0001808C
	public virtual void OnTriggerEnter(Collider other)
	{
		if (this.myEnemy && this.myEnemy.isDead)
		{
			return;
		}
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			crashController.TakeDamage(this.crashDeathAnimIndex);
		}
	}

	// Token: 0x0400044B RID: 1099
	private Enemy myEnemy;

	// Token: 0x0400044C RID: 1100
	public int crashDeathAnimIndex;
}
