﻿using System;
using UnityEngine;

// Token: 0x0200013C RID: 316
public class TrialPickup : Pickup
{
	// Token: 0x0600095D RID: 2397 RVA: 0x000262C9 File Offset: 0x000244C9
	public override void TryPushToStack()
	{
	}

	// Token: 0x0600095E RID: 2398 RVA: 0x000262CC File Offset: 0x000244CC
	public override void OnTriggerEnter(Collider other)
	{
		PickupHandler pickupHandler;
		if (other.TryGetComponent<PickupHandler>(out pickupHandler))
		{
			this.CollectTrial();
			this.Despawn();
		}
	}

	// Token: 0x0600095F RID: 2399 RVA: 0x000262EF File Offset: 0x000244EF
	protected override void Start()
	{
		if (Level.instance && SaveData.Info.lvlTrials[Level.instance.index])
		{
			Debug.Log("Already collected this scroll");
			base.DisableEntity();
		}
		base.Start();
	}

	// Token: 0x06000960 RID: 2400 RVA: 0x0002632A File Offset: 0x0002452A
	private void CollectTrial()
	{
		if (Level.instance)
		{
			Level.instance.collectedTrial = true;
			InterfaceManager.instance.hudTrack.scrollIconGO.SetActive(true);
			InterfaceManager.instance.hudTrack.ShowGems();
		}
	}

	// Token: 0x06000961 RID: 2401 RVA: 0x00026367 File Offset: 0x00024567
	public override void Spin(CrashController crash)
	{
	}
}
