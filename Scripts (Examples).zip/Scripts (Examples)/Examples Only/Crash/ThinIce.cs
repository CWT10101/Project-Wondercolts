﻿using System;
using UnityEngine;

// Token: 0x02000136 RID: 310
public class ThinIce : Entity
{
	// Token: 0x0600093C RID: 2364 RVA: 0x00025C70 File Offset: 0x00023E70
	public void Interact()
	{
		this.TryPushToStack();
		this.timesInteracted++;
		if (this.timesInteracted > 1)
		{
			this.Break();
			return;
		}
		AudioManager.Play(this.preBreakAudio, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		this.mainVis.SetActive(false);
		this.crackedVis.SetActive(true);
	}

	// Token: 0x0600093D RID: 2365 RVA: 0x00025CE0 File Offset: 0x00023EE0
	public void Break()
	{
		if (this.breakPrefab)
		{
			Object.Instantiate<GameObject>(this.breakPrefab, base.transform.position, Quaternion.identity);
		}
		AudioManager.Play(this.breakAudio, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), new Vector2?(new Vector2(1f, 1.2f)));
		base.DisableEntity();
		this.broken = true;
		base.enabled = false;
	}

	// Token: 0x0600093E RID: 2366 RVA: 0x00025D5B File Offset: 0x00023F5B
	public override void ResetEntity()
	{
		base.enabled = true;
		this.broken = false;
		this.timesInteracted = 0;
		this.mainVis.SetActive(true);
		this.crackedVis.SetActive(false);
		base.ResetEntity();
	}

	// Token: 0x0600093F RID: 2367 RVA: 0x00025D90 File Offset: 0x00023F90
	public virtual void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController))
		{
			if (this.broken || crashController.animator.currentState == crashController.animator.crawlObj)
			{
				return;
			}
			this.Interact();
		}
	}

	// Token: 0x040006BE RID: 1726
	public GameObject breakPrefab;

	// Token: 0x040006BF RID: 1727
	public string preBreakAudio = "SFX_IciclePrefall";

	// Token: 0x040006C0 RID: 1728
	public string breakAudio = "SFX_IcicleBreak";

	// Token: 0x040006C1 RID: 1729
	private int timesInteracted;

	// Token: 0x040006C2 RID: 1730
	private bool broken;

	// Token: 0x040006C3 RID: 1731
	public GameObject mainVis;

	// Token: 0x040006C4 RID: 1732
	public GameObject crackedVis;
}
