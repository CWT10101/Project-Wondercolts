﻿using System;
using UnityEngine;

// Token: 0x0200004E RID: 78
public class DestroyHook : MonoBehaviour
{
	// Token: 0x0600020D RID: 525 RVA: 0x00009472 File Offset: 0x00007672
	public virtual void Destroy()
	{
		Object.Destroy((this.destroyParent && base.transform.parent) ? base.transform.parent.gameObject : base.gameObject);
	}

	// Token: 0x0400011C RID: 284
	public bool destroyParent;
}
