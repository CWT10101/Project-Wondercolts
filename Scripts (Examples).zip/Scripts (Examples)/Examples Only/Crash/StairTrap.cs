﻿using System;
using UnityEngine;

// Token: 0x0200012E RID: 302
public class StairTrap : MonoBehaviour, IMetadataReceiver<PhaseMetadata>
{
	// Token: 0x17000115 RID: 277
	// (get) Token: 0x060008FD RID: 2301 RVA: 0x000253E2 File Offset: 0x000235E2
	public float CycleLength
	{
		get
		{
			return this.timeUp + this.timeDown;
		}
	}

	// Token: 0x060008FE RID: 2302 RVA: 0x000253F4 File Offset: 0x000235F4
	private void FixedUpdate()
	{
		float num = Clock.SynchronizedTime + this.offset * this.CycleLength;
		num %= this.CycleLength;
		this.animator.SetBool("Trapped", num > this.timeUp);
	}

	// Token: 0x060008FF RID: 2303 RVA: 0x00025437 File Offset: 0x00023637
	public void SetTrapOn()
	{
		this.SetTrapCollider(true);
	}

	// Token: 0x06000900 RID: 2304 RVA: 0x00025440 File Offset: 0x00023640
	public void SetTrapOff()
	{
		this.SetTrapCollider(false);
	}

	// Token: 0x06000901 RID: 2305 RVA: 0x0002544C File Offset: 0x0002364C
	private void SetTrapCollider(bool trapped)
	{
		this.stairCollider.enabled = !trapped;
		this.slideCollider.enabled = trapped;
		if (!trapped)
		{
			foreach (Collider collider in Physics.OverlapBox(this.stairCollider.bounds.center, this.stairCollider.bounds.extents * 0.99f, base.transform.rotation, -1, QueryTriggerInteraction.Ignore))
			{
				CrashController component = collider.GetComponent<CrashController>();
				if (component != null)
				{
					component.controller.enabled = false;
					component.transform.position = new Vector3(component.transform.position.x, this.stairCollider.bounds.max.y, collider.transform.position.z);
					component.controller.enabled = true;
					return;
				}
			}
		}
	}

	// Token: 0x06000902 RID: 2306 RVA: 0x00025540 File Offset: 0x00023740
	public void ProcessMetadata(PhaseMetadata meta)
	{
		this.offset = meta.NormalizedValue;
	}

	// Token: 0x0400069C RID: 1692
	public Animator animator;

	// Token: 0x0400069D RID: 1693
	public Collider stairCollider;

	// Token: 0x0400069E RID: 1694
	public Collider slideCollider;

	// Token: 0x0400069F RID: 1695
	public float timeUp = 1f;

	// Token: 0x040006A0 RID: 1696
	public float timeDown = 1f;

	// Token: 0x040006A1 RID: 1697
	public float offset;
}
