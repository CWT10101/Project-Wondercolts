﻿using System;
using UnityEngine;

// Token: 0x020000AB RID: 171
public class EnemyBlocker : MonoBehaviour
{
}
