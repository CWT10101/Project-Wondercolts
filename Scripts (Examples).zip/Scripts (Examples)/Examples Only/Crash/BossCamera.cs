﻿using System;
using Cinemachine;
using UnityEngine;

// Token: 0x02000066 RID: 102
public class BossCamera : MonoBehaviour
{
	// Token: 0x0600028C RID: 652 RVA: 0x0000B4BE File Offset: 0x000096BE
	private void Start()
	{
		CameraManager.instance.SetVCam(this.followCamNorth);
	}

	// Token: 0x04000174 RID: 372
	public CinemachineVirtualCameraBase followCamNorth;

	// Token: 0x04000175 RID: 373
	public CinemachineVirtualCameraBase followCamSouth;
}
