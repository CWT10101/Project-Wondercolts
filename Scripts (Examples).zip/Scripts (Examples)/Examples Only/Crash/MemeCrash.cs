﻿using System;
using UnityEngine;

// Token: 0x020000E1 RID: 225
public class MemeCrash : MonoBehaviour
{
	// Token: 0x060006E6 RID: 1766 RVA: 0x0001D7AC File Offset: 0x0001B9AC
	private void LateUpdate()
	{
		float @float = this.anim.GetFloat("Wokeness");
		Camera main = Camera.main;
		Quaternion quaternion = Quaternion.Inverse(this.finalCameraAlignment.localRotation);
		Vector3 a = quaternion * -this.finalCameraAlignment.localPosition;
		quaternion *= Quaternion.LookRotation(base.transform.position - main.transform.position);
		base.transform.localPosition = a * @float;
		base.transform.localRotation = Quaternion.Lerp(Quaternion.identity, quaternion, @float);
	}

	// Token: 0x0400053E RID: 1342
	[SerializeField]
	private Animator anim;

	// Token: 0x0400053F RID: 1343
	[SerializeField]
	private Transform finalCameraAlignment;
}
