﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

// Token: 0x02000096 RID: 150
public class Database<T>
{
	// Token: 0x06000489 RID: 1161 RVA: 0x0001494B File Offset: 0x00012B4B
	public void Initialize(IEnumerable<IDBDescriptor<T>> descriptors)
	{
		this._descriptors = descriptors;
	}

	// Token: 0x0600048A RID: 1162 RVA: 0x00014954 File Offset: 0x00012B54
	public void Search(string query, HashSet<T> matches, HashSet<T> suggestions)
	{
		if (query == null || query.Length == 0)
		{
			foreach (IDBDescriptor<T> idbdescriptor in this._descriptors)
			{
				if (!idbdescriptor.IsSecret)
				{
					suggestions.Add(idbdescriptor.Value);
				}
			}
			return;
		}
		foreach (IDBDescriptor<T> idbdescriptor2 in this._descriptors)
		{
			if (idbdescriptor2.Name == query)
			{
				matches.Add(idbdescriptor2.Value);
			}
			else if (!idbdescriptor2.IsSecret)
			{
				using (IEnumerator<Match> enumerator2 = Regex.Matches(query, "\\S+").Cast<Match>().GetEnumerator())
				{
					IL_18B:
					while (enumerator2.MoveNext())
					{
						Match match = enumerator2.Current;
						string value = match.Value;
						if (idbdescriptor2.Name == value)
						{
							matches.Add(idbdescriptor2.Value);
						}
						else
						{
							using (HashSet<string>.Enumerator enumerator3 = idbdescriptor2.Tags.GetEnumerator())
							{
								while (enumerator3.MoveNext())
								{
									if (enumerator3.Current == value)
									{
										matches.Add(idbdescriptor2.Value);
										goto IL_18B;
									}
								}
							}
							if (this.FuzzyMatch(idbdescriptor2.Name, value))
							{
								suggestions.Add(idbdescriptor2.Value);
							}
							else
							{
								foreach (string a in idbdescriptor2.Tags)
								{
									if (this.FuzzyMatch(a, value))
									{
										suggestions.Add(idbdescriptor2.Value);
										break;
									}
								}
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x0600048B RID: 1163 RVA: 0x00014B98 File Offset: 0x00012D98
	private bool FuzzyMatch(string a, string b)
	{
		return !string.IsNullOrWhiteSpace(a) && !string.IsNullOrWhiteSpace(b) && (a.StartsWith(b) || a.EndsWith(b) || b.StartsWith(a) || b.EndsWith(a));
	}

	// Token: 0x04000335 RID: 821
	private IEnumerable<IDBDescriptor<T>> _descriptors;
}
