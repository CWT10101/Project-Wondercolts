﻿using System;
using LevelEditor;
using LevelEditor3D;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200001F RID: 31
public class LevelObjButton : MonoBehaviour
{
	// Token: 0x0600008C RID: 140 RVA: 0x0000476A File Offset: 0x0000296A
	public void Init(string obj, Sprite icon, bool flipIcon = false)
	{
		this.objName = obj;
		this.objIcon.sprite = icon;
		if (flipIcon)
		{
			this.objIcon.transform.localScale = new Vector3(-1f, 1f, 1f);
		}
	}

	// Token: 0x0600008D RID: 141 RVA: 0x000047A6 File Offset: 0x000029A6
	public void PassGameObjectToPlaceHook()
	{
		if (!string.IsNullOrEmpty(this.objName))
		{
			if (LevelBuilder.Instance)
			{
				LevelBuilder.Instance.PassGameObjectToPlace(this.objName);
				return;
			}
			LevelCreator.instance.PassGameObjectToPlace(this.objName);
		}
	}

	// Token: 0x04000069 RID: 105
	public string objName;

	// Token: 0x0400006A RID: 106
	public Image objIcon;
}
