﻿using System;
using System.Collections.Generic;
using LevelEditor;
using UnityEngine;

// Token: 0x0200001B RID: 27
public class GridManager : MonoBehaviour
{
	// Token: 0x0600006F RID: 111 RVA: 0x00003D89 File Offset: 0x00001F89
	private void Awake()
	{
		GridManager.instance = this;
	}

	// Token: 0x06000070 RID: 112 RVA: 0x00003D91 File Offset: 0x00001F91
	private void Start()
	{
		this.CreateGrid();
	}

	// Token: 0x06000071 RID: 113 RVA: 0x00003D9C File Offset: 0x00001F9C
	public void CreateGrid()
	{
		this.areaExtents.size = new Vector2((float)(this.sizeX - 16), (float)(this.sizeY - 8));
		this.areaExtents.offset = new Vector2((float)this.sizeX / 2f, (float)this.sizeY / 2f + 3f);
		this.gridHolder.localScale = new Vector3((float)this.sizeX, (float)this.sizeY);
		this.gridHolder.localPosition = new Vector3((float)this.sizeX / 2f - 0.5f, (float)this.sizeY / 2f - 0.5f);
		this.grid = new Tile[this.sizeX, this.sizeY];
		for (int i = 0; i < this.sizeX; i++)
		{
			for (int j = 0; j < this.sizeY; j++)
			{
				Tile tile = new Tile(i, j);
				this.grid[i, j] = tile;
			}
		}
	}

	// Token: 0x06000072 RID: 114 RVA: 0x00003EA0 File Offset: 0x000020A0
	public Tile TileFromWorldPosition(Vector3 worldPosition, out bool isOnGrid)
	{
		float num = worldPosition.x;
		float num2 = worldPosition.y;
		num /= (float)this.offset;
		num2 /= (float)this.offset;
		int num3 = Mathf.RoundToInt(num);
		int num4 = Mathf.RoundToInt(num2);
		isOnGrid = true;
		if (num3 < 0)
		{
			num3 = 0;
			isOnGrid = false;
		}
		else if (num3 >= this.sizeX)
		{
			num3 = this.sizeX - 1;
			isOnGrid = false;
		}
		if (num4 < 0)
		{
			num4 = 0;
			isOnGrid = false;
		}
		else if (num4 >= this.sizeY)
		{
			num4 = this.sizeY - 1;
			isOnGrid = false;
		}
		return this.grid[num3, num4];
	}

	// Token: 0x06000073 RID: 115 RVA: 0x00003F2D File Offset: 0x0000212D
	public IEnumerable<Tile> GetArea(int pos1x, int pos1y, int pos2x, int pos2y)
	{
		int num = Mathf.Clamp(Mathf.RoundToInt((float)(pos1x / this.offset)), 0, this.sizeX);
		int num2 = Mathf.Clamp(Mathf.RoundToInt((float)(pos1y / this.offset)), 0, this.sizeY);
		int num3 = Mathf.Clamp(Mathf.RoundToInt((float)(pos2x / this.offset)), 0, this.sizeX);
		int num4 = Mathf.Clamp(Mathf.RoundToInt((float)(pos2y / this.offset)), 0, this.sizeY);
		int xMin = (num < num3) ? num : num3;
		int xMax = (num > num3) ? num : num3;
		int num5 = (num2 < num4) ? num2 : num4;
		int yMax = (num2 > num4) ? num2 : num4;
		int num6;
		for (int y = num5; y <= yMax; y = num6 + 1)
		{
			for (int x = xMin; x <= xMax; x = num6 + 1)
			{
				yield return this.grid[x, y];
				num6 = x;
			}
			num6 = y;
		}
		yield break;
	}

	// Token: 0x04000057 RID: 87
	public TileObj tilePrefab;

	// Token: 0x04000058 RID: 88
	public Transform gridHolder;

	// Token: 0x04000059 RID: 89
	public BoxCollider2D areaExtents;

	// Token: 0x0400005A RID: 90
	public int sizeX;

	// Token: 0x0400005B RID: 91
	public int sizeY;

	// Token: 0x0400005C RID: 92
	public int offset = 1;

	// Token: 0x0400005D RID: 93
	public Tile[,] grid;

	// Token: 0x0400005E RID: 94
	public static GridManager instance;
}
