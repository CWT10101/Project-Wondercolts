﻿using System;
using UnityEngine;

// Token: 0x02000115 RID: 277
public class Shrinker : MonoBehaviour
{
	// Token: 0x06000880 RID: 2176 RVA: 0x00023C4C File Offset: 0x00021E4C
	public void ToggleShrink()
	{
		if (CrashController.instance.transform.localScale == this.normalScale)
		{
			this.Shrink();
		}
		else
		{
			this.ResetScale();
		}
		AudioManager.Play("SFX_ValidLevel", AudioManager.MixerTarget.UI, null, null);
	}

	// Token: 0x06000881 RID: 2177 RVA: 0x00023CA1 File Offset: 0x00021EA1
	public void Shrink()
	{
		CrashController.instance.transform.localScale = this.shrunkScale;
	}

	// Token: 0x06000882 RID: 2178 RVA: 0x00023CB8 File Offset: 0x00021EB8
	public void ResetScale()
	{
		CrashController.instance.transform.localScale = this.normalScale;
	}

	// Token: 0x04000646 RID: 1606
	public Vector3 normalScale;

	// Token: 0x04000647 RID: 1607
	public Vector3 shrunkScale;
}
