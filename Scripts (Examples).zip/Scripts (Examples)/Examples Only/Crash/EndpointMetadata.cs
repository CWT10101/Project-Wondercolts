﻿using System;
using System.IO;
using LevelEditor;
using UnityEngine;

// Token: 0x02000028 RID: 40
public class EndpointMetadata : ObjectMetadata
{
	// Token: 0x17000023 RID: 35
	// (get) Token: 0x060000E7 RID: 231 RVA: 0x000060BC File Offset: 0x000042BC
	// (set) Token: 0x060000E8 RID: 232 RVA: 0x000060C4 File Offset: 0x000042C4
	public bool HasData { get; private set; }

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x060000E9 RID: 233 RVA: 0x000060CD File Offset: 0x000042CD
	// (set) Token: 0x060000EA RID: 234 RVA: 0x000060D5 File Offset: 0x000042D5
	public Vector2Int Position { get; private set; }

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x060000EB RID: 235 RVA: 0x000060DE File Offset: 0x000042DE
	public override bool SupportsMultiEditing
	{
		get
		{
			return false;
		}
	}

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x060000EC RID: 236 RVA: 0x000060E1 File Offset: 0x000042E1
	public override int Signature
	{
		get
		{
			return "EndpointMetadata".GetHashCode();
		}
	}

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x060000ED RID: 237 RVA: 0x000060ED File Offset: 0x000042ED
	public override int ValueHash
	{
		get
		{
			return this.valueHash;
		}
	}

	// Token: 0x060000EE RID: 238 RVA: 0x000060F8 File Offset: 0x000042F8
	public override void Serialize(BinaryWriter bw)
	{
		bw.Write(this.HasData);
		if (this.HasData)
		{
			bw.Write((short)this.Position.x);
			bw.Write((short)this.Position.y);
		}
	}

	// Token: 0x060000EF RID: 239 RVA: 0x00006144 File Offset: 0x00004344
	public override void Deserialize(BinaryReader br, Tile[,] grid)
	{
		this.HasData = br.ReadBoolean();
		if (this.HasData)
		{
			this.Position = new Vector2Int((int)br.ReadInt16(), (int)br.ReadInt16());
			return;
		}
		this.Position = default(Vector2Int);
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x0000618C File Offset: 0x0000438C
	public override void Apply(LevelObj obj)
	{
		IMetadataReceiver<EndpointMetadata>[] componentsInChildren = obj.GetComponentsInChildren<IMetadataReceiver<EndpointMetadata>>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].ProcessMetadata(this);
		}
	}

	// Token: 0x060000F1 RID: 241 RVA: 0x000061B8 File Offset: 0x000043B8
	public void SetPosition(int x, int y)
	{
		this.HasData = true;
		this.Position = new Vector2Int(x, y);
		this.valueHash = this.Position.GetHashCode();
	}

	// Token: 0x060000F2 RID: 242 RVA: 0x000061F4 File Offset: 0x000043F4
	public void ClearPosition()
	{
		this.HasData = false;
		this.Position = default(Vector2Int);
		this.valueHash = 0;
	}

	// Token: 0x0400008C RID: 140
	private int valueHash;
}
