﻿using System;
using UnityEngine;

// Token: 0x0200007A RID: 122
public class BreakCratesOnImpact : MonoBehaviour
{
	// Token: 0x06000376 RID: 886 RVA: 0x0000F05B File Offset: 0x0000D25B
	private void Start()
	{
	}

	// Token: 0x06000377 RID: 887 RVA: 0x0000F05D File Offset: 0x0000D25D
	private void Update()
	{
	}
}
