﻿using System;
using UnityEngine;

// Token: 0x02000056 RID: 86
public class SignalSMB : StateMachineBehaviour
{
	// Token: 0x06000223 RID: 547 RVA: 0x00009861 File Offset: 0x00007A61
	public override void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
	{
		if (!string.IsNullOrWhiteSpace(this.signalOnEnter))
		{
			animator.gameObject.SendMessage(this.signalOnEnter);
		}
	}

	// Token: 0x06000224 RID: 548 RVA: 0x00009881 File Offset: 0x00007A81
	public override void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
	{
		if (!string.IsNullOrWhiteSpace(this.signalOnExit))
		{
			animator.gameObject.SendMessage(this.signalOnExit);
		}
	}

	// Token: 0x04000130 RID: 304
	public string signalOnEnter = "";

	// Token: 0x04000131 RID: 305
	public string signalOnExit = "";
}
