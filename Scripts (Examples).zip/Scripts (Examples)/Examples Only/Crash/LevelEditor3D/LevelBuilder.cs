﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cinemachine;
using LevelEditor;
using Rewired;
using UnityEngine;

namespace LevelEditor3D
{
	// Token: 0x020001C2 RID: 450
	public class LevelBuilder : MonoBehaviour
	{
		// Token: 0x1700044C RID: 1100
		// (get) Token: 0x0600117F RID: 4479 RVA: 0x0003E9CB File Offset: 0x0003CBCB
		// (set) Token: 0x06001180 RID: 4480 RVA: 0x0003E9D3 File Offset: 0x0003CBD3
		public Transform RoomHolder { get; private set; }

		// Token: 0x1700044D RID: 1101
		// (get) Token: 0x06001181 RID: 4481 RVA: 0x0003E9DC File Offset: 0x0003CBDC
		// (set) Token: 0x06001182 RID: 4482 RVA: 0x0003E9E4 File Offset: 0x0003CBE4
		public List<Room> Rooms { get; private set; }

		// Token: 0x1700044E RID: 1102
		// (get) Token: 0x06001183 RID: 4483 RVA: 0x0003E9ED File Offset: 0x0003CBED
		// (set) Token: 0x06001184 RID: 4484 RVA: 0x0003E9F5 File Offset: 0x0003CBF5
		public Room[] LevelBlueprint { get; private set; }

		// Token: 0x1700044F RID: 1103
		// (get) Token: 0x06001185 RID: 4485 RVA: 0x0003E9FE File Offset: 0x0003CBFE
		// (set) Token: 0x06001186 RID: 4486 RVA: 0x0003EA06 File Offset: 0x0003CC06
		public EditorTool ActiveTool { get; private set; }

		// Token: 0x17000450 RID: 1104
		// (get) Token: 0x06001187 RID: 4487 RVA: 0x0003EA0F File Offset: 0x0003CC0F
		// (set) Token: 0x06001188 RID: 4488 RVA: 0x0003EA17 File Offset: 0x0003CC17
		public bool EditMode { get; private set; }

		// Token: 0x17000451 RID: 1105
		// (get) Token: 0x06001189 RID: 4489 RVA: 0x0003EA20 File Offset: 0x0003CC20
		// (set) Token: 0x0600118A RID: 4490 RVA: 0x0003EA27 File Offset: 0x0003CC27
		public static LevelBuilder Instance { get; private set; }

		// Token: 0x0600118B RID: 4491 RVA: 0x0003EA2F File Offset: 0x0003CC2F
		private void Awake()
		{
			LevelBuilder.Instance = this;
			this.rwInput = ReInput.players.GetPlayer(0);
		}

		// Token: 0x0600118C RID: 4492 RVA: 0x0003EA48 File Offset: 0x0003CC48
		private void OnDestroy()
		{
			LevelBuilder.Instance = null;
		}

		// Token: 0x0600118D RID: 4493 RVA: 0x0003EA50 File Offset: 0x0003CC50
		private void Start()
		{
			for (int i = 0; i < this.LevelBlueprint.Length; i++)
			{
				this.AppendRoom(this.LevelBlueprint[i], true);
			}
		}

		// Token: 0x0600118E RID: 4494 RVA: 0x0003EA80 File Offset: 0x0003CC80
		private void Update()
		{
			if (this.EditMode)
			{
				float axis = Input.GetAxis("Vertical");
				this.editorDollyCart.m_Speed = axis * this._editorCameraSpeed;
				this.RunTool();
			}
		}

		// Token: 0x0600118F RID: 4495 RVA: 0x0003EAB9 File Offset: 0x0003CCB9
		public void SetTool(EditorTool tool)
		{
			if (this.ActiveTool == tool)
			{
				return;
			}
			this.ActiveTool.OnToolDisabled();
			this.ActiveTool = tool;
			this.ActiveTool.OnToolEnabled();
			this.ActiveToolState = EditorTool.ToolState.Idle;
		}

		// Token: 0x06001190 RID: 4496 RVA: 0x0003EAF0 File Offset: 0x0003CCF0
		private void RunTool()
		{
			if (!this.ActiveTool)
			{
				return;
			}
			if (this.ActiveToolState != EditorTool.ToolState.Primary && this.rwInput.GetButtonDown("ToolPrimary") && !LevelInterfaceManager3D.Instance.mouseOverUI)
			{
				this.ActiveToolState = EditorTool.ToolState.Primary;
				this.ActiveToolPhase = EditorTool.ToolPhase.Begin;
				this.tUsedTool = Time.timeSinceLevelLoad;
			}
			else if (this.ActiveToolState != EditorTool.ToolState.Secondary && this.rwInput.GetButtonDown("ToolSecondary") && !LevelInterfaceManager3D.Instance.mouseOverUI)
			{
				this.ActiveToolState = EditorTool.ToolState.Secondary;
				this.ActiveToolPhase = EditorTool.ToolPhase.Begin;
				this.tUsedTool = Time.timeSinceLevelLoad;
			}
			else if (this.ActiveToolState == EditorTool.ToolState.Primary && (!this.ActiveTool.PrimaryIsContinuous || this.rwInput.GetButtonUp("ToolPrimary") || LevelInterfaceManager3D.Instance.mouseOverUI))
			{
				this.ActiveToolPhase = EditorTool.ToolPhase.End;
			}
			else if (this.ActiveToolState == EditorTool.ToolState.Secondary && (!this.ActiveTool.SecondaryIsContinuous || this.rwInput.GetButtonUp("ToolSecondary") || LevelInterfaceManager3D.Instance.mouseOverUI))
			{
				this.ActiveToolPhase = EditorTool.ToolPhase.End;
			}
			if (this.ActiveToolState == EditorTool.ToolState.Primary)
			{
				this.ActiveTool.PrimaryAction(this.ActiveToolPhase, Time.timeSinceLevelLoad - this.tUsedTool);
			}
			else if (this.ActiveToolState == EditorTool.ToolState.Secondary)
			{
				this.ActiveTool.SecondaryAction(this.ActiveToolPhase, Time.timeSinceLevelLoad - this.tUsedTool);
			}
			if (this.ActiveToolPhase == EditorTool.ToolPhase.Begin)
			{
				this.ActiveToolPhase = EditorTool.ToolPhase.Hold;
				return;
			}
			if (this.ActiveToolPhase == EditorTool.ToolPhase.End)
			{
				this.ActiveToolState = EditorTool.ToolState.Idle;
				this.ActiveToolPhase = EditorTool.ToolPhase.Idle;
				this.tUsedTool = 0f;
			}
		}

		// Token: 0x06001191 RID: 4497 RVA: 0x0003EC8B File Offset: 0x0003CE8B
		public void PassGameObjectToPlace(string objID)
		{
			this.objToPlace = LevelResourcesManager.instance.GetObjBase(objID).objPrefab;
			LevelInterfaceManager3D.Instance.drawToggle.isOn = true;
		}

		// Token: 0x06001192 RID: 4498 RVA: 0x0003ECB4 File Offset: 0x0003CEB4
		public void PlaceObject()
		{
			Room roomAtPosition = this.GetRoomAtPosition(this.gridCon.Position);
			if (roomAtPosition)
			{
				Bounds objBounds = this.objToPlace.GetComponent<LevelObj>().objBounds;
				Collider[] array = Physics.OverlapBox(this.gridCon.Position + objBounds.center + Vector3.up * 0.5f, objBounds.extents * 0.99f, Quaternion.identity, 1);
				for (int i = 0; i < array.Length; i++)
				{
					LevelObj componentInParent = array[i].GetComponentInParent<LevelObj>();
					if (componentInParent != null)
					{
						this.DeleteObject(componentInParent);
					}
				}
				this.PlaceObject(roomAtPosition);
			}
		}

		// Token: 0x06001193 RID: 4499 RVA: 0x0003ED64 File Offset: 0x0003CF64
		public void PlaceObject(Room room)
		{
			if (LevelBuilder.Instance.objToPlace == null)
			{
				return;
			}
			GameObject gameObject = Object.Instantiate<GameObject>(this.objToPlace, this.gridCon.visual.transform.position + new Vector3(0f, 0.5f, 0f), this.objToPlace.transform.rotation);
			gameObject.transform.parent = room.EntitiesHolder;
			LevelObj component = gameObject.GetComponent<LevelObj>();
			BoxCollider boxCollider = component.editorVis.AddComponent<BoxCollider>();
			boxCollider.center = component.objBounds.center;
			boxCollider.size = component.objBounds.size;
		}

		// Token: 0x06001194 RID: 4500 RVA: 0x0003EE10 File Offset: 0x0003D010
		public void DeleteObject()
		{
			if (this.GetRoomAtPosition(this.gridCon.Position))
			{
				Collider[] array = Physics.OverlapBox(this.gridCon.Position + Vector3.up * 0.5f, Vector3.one * 0.25f, Quaternion.identity, 1);
				for (int i = 0; i < array.Length; i++)
				{
					LevelObj componentInParent = array[i].GetComponentInParent<LevelObj>();
					if (componentInParent != null)
					{
						this.DeleteObject(componentInParent);
					}
				}
			}
		}

		// Token: 0x06001195 RID: 4501 RVA: 0x0003EE90 File Offset: 0x0003D090
		public void DeleteObject(LevelObj obj)
		{
			AudioManager.Play("SFX_Scrap", null, null);
			Object.Instantiate<BrokenCrate>(ResourceManager.instance.brokenCrate, this.gridCon.visual.transform.position, this.gridCon.visual.transform.rotation);
			Object.Destroy(obj.gameObject);
		}

		// Token: 0x06001196 RID: 4502 RVA: 0x0003EEFF File Offset: 0x0003D0FF
		public void ToggleEditMode()
		{
			this.EditMode = !this.EditMode;
			if (this.EditMode)
			{
				this.SetEditorMode();
				return;
			}
			this.SetPlaymode();
		}

		// Token: 0x06001197 RID: 4503 RVA: 0x0003EF28 File Offset: 0x0003D128
		public void SetEditorMode()
		{
			this.gridCon.Show();
			float position = this.editorDollyCart.m_Path.FromPathNativeUnits(this.editorDollyCart.m_Path.FindClosestPoint(this.playmodeCameraTarget.position, 0, -1, 1), CinemachinePathBase.PositionUnits.Distance);
			this.editorDollyCart.m_Position = position;
			CameraManager.instance.SetVCam(this.editorCamera);
			UnityUtil.GetAllComponentsInScene<IPlayModeCallback>(false).ForEach(delegate(IPlayModeCallback i)
			{
				i.PlayModeChanged(false);
			});
			LevelInterfaceManager3D.Instance.editorHud.SetActive(true);
			CrashController.instance.enabled = false;
			CrashController.instance.controller.enabled = false;
			CrashController.instance.animator.SetState(CrashController.instance.animator.warpOutObj, false);
			foreach (Room room in this.Rooms)
			{
				LevelObj[] componentsInChildren = room.EntitiesHolder.GetComponentsInChildren<LevelObj>();
				for (int j = 0; j < componentsInChildren.Length; j++)
				{
					componentsInChildren[j].SetPlayMode(false);
				}
			}
		}

		// Token: 0x06001198 RID: 4504 RVA: 0x0003F060 File Offset: 0x0003D260
		public void SetPlaymode()
		{
			Clock.SetCrashSpawnTime();
			SwitchCrate.DefaultSwitchState();
			DeathRoutePlatform.RestoreDefault();
			UnityUtil.GetAllComponentsInScene<IPlayModeCallback>(false).ForEach(delegate(IPlayModeCallback i)
			{
				i.PlayModeChanged(true);
			});
			this.gridCon.Hide();
			EntityTracker.Dump();
			this.SetCameraTrigger(this.GetCurrentRoom().camIndex);
			LevelInterfaceManager3D.Instance.editorHud.SetActive(false);
			CrashController.instance.transform.position = this.editorDollyCart.transform.position + Vector3.up;
			CrashController.instance.enabled = true;
			CrashController.instance.controller.enabled = true;
			CrashController.instance.animator.SetState(CrashController.instance.animator.warpInObj, false);
			foreach (Room room in this.Rooms)
			{
				LevelObj[] componentsInChildren = room.EntitiesHolder.GetComponentsInChildren<LevelObj>();
				for (int j = 0; j < componentsInChildren.Length; j++)
				{
					componentsInChildren[j].SetPlayMode(true);
				}
			}
		}

		// Token: 0x06001199 RID: 4505 RVA: 0x0003F19C File Offset: 0x0003D39C
		public void MoveCameraToRoom(Room room)
		{
			float num = this.editorDollyCart.m_Path.FromPathNativeUnits(this.editorDollyCart.m_Path.FindClosestPoint(room.CamStartPoint.position, 0, -1, 1), CinemachinePathBase.PositionUnits.Distance);
			this.editorDollyCart.m_Position = num + room.LocalBounds.size.z / 2f;
		}

		// Token: 0x0600119A RID: 4506 RVA: 0x0003F1FF File Offset: 0x0003D3FF
		public Room GetCurrentRoom()
		{
			return this.GetRoomAtPosition(this.editorDollyCart.transform.position);
		}

		// Token: 0x0600119B RID: 4507 RVA: 0x0003F218 File Offset: 0x0003D418
		public Room GetRoomAtPosition(Vector3 worldPos)
		{
			foreach (Room room in this.Rooms)
			{
				if (room.WithinBounds(worldPos))
				{
					return room;
				}
			}
			return null;
		}

		// Token: 0x0600119C RID: 4508 RVA: 0x0003F274 File Offset: 0x0003D474
		private Room CreateRoom(Room source)
		{
			Room room = Object.Instantiate<Room>(source, this.RoomHolder);
			Object.Instantiate<RoomItemUI>(LevelResourcesManager3D.Instance.RoomItemUIPrefab, LevelInterfaceManager3D.Instance.roomItemUIHolder).Init(room);
			return room;
		}

		// Token: 0x0600119D RID: 4509 RVA: 0x0003F2AE File Offset: 0x0003D4AE
		public void AppendRoomIndex(int resourceIndex)
		{
			this.AppendRoom(LevelResourcesManager3D.Instance.RoomPrefabs[resourceIndex], true);
		}

		// Token: 0x0600119E RID: 4510 RVA: 0x0003F2C3 File Offset: 0x0003D4C3
		public void AppendRoom(Room room, bool instantiate = false)
		{
			if (instantiate)
			{
				room = this.CreateRoom(room);
			}
			this.Rooms.Add(room);
			this.SnapRooms(this.Rooms.Count - 2);
		}

		// Token: 0x0600119F RID: 4511 RVA: 0x0003F2F0 File Offset: 0x0003D4F0
		public void ShiftRoom(Room room, int newIndex)
		{
			int num = this.Rooms.IndexOf(room);
			int startingIndex = Math.Min(num, newIndex);
			if (newIndex > num)
			{
				newIndex--;
			}
			this.Rooms.Remove(room);
			this.Rooms.Insert(newIndex, room);
			this.SnapRooms(startingIndex);
		}

		// Token: 0x060011A0 RID: 4512 RVA: 0x0003F33C File Offset: 0x0003D53C
		public void SwapRooms(Room room1, Room room2)
		{
			room1 == room2;
		}

		// Token: 0x060011A1 RID: 4513 RVA: 0x0003F348 File Offset: 0x0003D548
		public void RemoveRoom(Room room)
		{
			int startingIndex = this.Rooms.IndexOf(room);
			this.Rooms.Remove(room);
			this.SnapRooms(startingIndex);
			Object.Destroy(room.gameObject);
		}

		// Token: 0x060011A2 RID: 4514 RVA: 0x0003F384 File Offset: 0x0003D584
		public void RemoveAll()
		{
			foreach (Room room in this.Rooms)
			{
				Object.Destroy(room.gameObject);
			}
			this.Rooms.Clear();
		}

		// Token: 0x060011A3 RID: 4515 RVA: 0x0003F3E4 File Offset: 0x0003D5E4
		public void SnapRooms(int startingIndex = 1)
		{
			if (this.Rooms == null || this.Rooms.Count == 0)
			{
				return;
			}
			if (startingIndex < 1)
			{
				startingIndex = 1;
			}
			Room room = this.Rooms[0];
			room.transform.SetPositionAndRotation(Vector3.zero - (room.StartPoint.position - room.transform.position), Quaternion.identity);
			for (int i = startingIndex; i < this.Rooms.Count; i++)
			{
				Room room2 = this.Rooms[i];
				Room room3 = this.Rooms[i - 1];
				room2.transform.SetPositionAndRotation(room3.EndPoint.position - (room2.StartPoint.position - room2.transform.position), room3.EndPoint.rotation);
			}
			this.endRoom.transform.position = this.Rooms[this.Rooms.Count - 1].EndPoint.position;
			this.SetDollyTrack();
			this.CountCrates();
			this.CountEnemies();
			LevelInterfaceManager3D.Instance.addRoomButton.transform.SetAsLastSibling();
			Debug.Log("Add Room Button set last");
		}

		// Token: 0x060011A4 RID: 4516 RVA: 0x0003F528 File Offset: 0x0003D728
		public void SetDollyTrack()
		{
			List<Transform> list = new List<Transform>();
			for (int i = 0; i < this.Rooms.Count; i++)
			{
				list.Add(this.Rooms[i].CamStartPoint);
				list.Add(this.Rooms[i].Midpoint);
			}
			list.Add(this.endRoom.transform);
			this.dollyTrack.m_Waypoints = (from t in list
			select new CinemachineSmoothPath.Waypoint
			{
				position = this.dollyTrack.transform.InverseTransformPoint(t.position)
			}).ToArray<CinemachineSmoothPath.Waypoint>();
			this.dollyTrack.InvalidateDistanceCache();
		}

		// Token: 0x060011A5 RID: 4517 RVA: 0x0003F5BD File Offset: 0x0003D7BD
		public void SetCameraTrigger(int index)
		{
			CameraManager.instance.SetVCam(this.cameras[index]);
		}

		// Token: 0x060011A6 RID: 4518 RVA: 0x0003F5D4 File Offset: 0x0003D7D4
		public void CountCrates()
		{
			this.crateCount = 0;
			for (int i = 0; i < this.Rooms.Count; i++)
			{
				this.crateCount += this.Rooms[i].Crates.Count;
			}
			Debug.Log(string.Format("There are {0} crates in the level", this.crateCount));
		}

		// Token: 0x060011A7 RID: 4519 RVA: 0x0003F63C File Offset: 0x0003D83C
		public void CountEnemies()
		{
			this.enemyCount = 0;
			for (int i = 0; i < this.Rooms.Count; i++)
			{
				this.enemyCount += this.Rooms[i].Enemies.Count;
			}
			Debug.Log(string.Format("There are {0} enemies in the level", this.enemyCount));
		}

		// Token: 0x04000B97 RID: 2967
		[ReadOnly]
		public int crateCount;

		// Token: 0x04000B98 RID: 2968
		[ReadOnly]
		public int enemyCount;

		// Token: 0x04000B99 RID: 2969
		public CinemachineSmoothPath dollyTrack;

		// Token: 0x04000B9A RID: 2970
		public CinemachineVirtualCameraBase[] cameras;

		// Token: 0x04000B9B RID: 2971
		public CinemachineVirtualCameraBase editorCamera;

		// Token: 0x04000B9C RID: 2972
		public CinemachineDollyCart editorDollyCart;

		// Token: 0x04000B9D RID: 2973
		public Transform playmodeCameraTarget;

		// Token: 0x04000B9E RID: 2974
		public GridControl gridCon;

		// Token: 0x04000B9F RID: 2975
		public GameObject endRoom;

		// Token: 0x04000BA0 RID: 2976
		[SerializeField]
		private float _editorCameraSpeed = 5f;

		// Token: 0x04000BA1 RID: 2977
		public GameObject objToPlace;

		// Token: 0x04000BA2 RID: 2978
		public int selectedObjIndex;

		// Token: 0x04000BA4 RID: 2980
		public EditorTool.ToolState ActiveToolState;

		// Token: 0x04000BA5 RID: 2981
		public EditorTool.ToolPhase ActiveToolPhase;

		// Token: 0x04000BA6 RID: 2982
		private float tUsedTool;

		// Token: 0x04000BA7 RID: 2983
		private Player rwInput;
	}
}
