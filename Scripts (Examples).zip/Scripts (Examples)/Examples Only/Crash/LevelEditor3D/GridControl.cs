﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace LevelEditor3D
{
	// Token: 0x020001C1 RID: 449
	public class GridControl : MonoBehaviour
	{
		// Token: 0x1700044A RID: 1098
		// (get) Token: 0x06001172 RID: 4466 RVA: 0x0003E528 File Offset: 0x0003C728
		private float TimeSinceHeightChanged
		{
			get
			{
				if (this._timeHeightChanged != -1f)
				{
					return Time.time - this._timeHeightChanged;
				}
				return float.PositiveInfinity;
			}
		}

		// Token: 0x1700044B RID: 1099
		// (get) Token: 0x06001173 RID: 4467 RVA: 0x0003E549 File Offset: 0x0003C749
		public Vector3 Position
		{
			get
			{
				return this.visual.transform.position;
			}
		}

		// Token: 0x06001174 RID: 4468 RVA: 0x0003E55C File Offset: 0x0003C75C
		private void Awake()
		{
			this._gridColorFaded = new Color(this.gridColor.r, this.gridColor.g, this.gridColor.b, 0f);
			this.gridViewProps = new MaterialPropertyBlock();
			this.gridViewProps.SetColor("_Color", this._gridColorFaded);
			this.SetupViewGrid();
		}

		// Token: 0x06001175 RID: 4469 RVA: 0x0003E5C4 File Offset: 0x0003C7C4
		private void SetupViewGrid()
		{
			this.gridViewMatrices.Clear();
			Room roomAtPosition = LevelBuilder.Instance.GetRoomAtPosition(this.visual.transform.position);
			RoomGrid.Floor floor;
			if (roomAtPosition && roomAtPosition.Grid.GetFloor(this.height, out floor))
			{
				for (int i = 0; i < floor.spaces.Length; i++)
				{
					Vector2[] spaces = floor.spaces;
					Vector3 a;
					if (roomAtPosition.Grid.GetPosition(this.height, i, out a))
					{
						this.gridViewMatrices.Add(Matrix4x4.TRS(a + Vector3.up * 0.5f, Quaternion.identity, Vector3.one));
					}
				}
			}
		}

		// Token: 0x06001176 RID: 4470 RVA: 0x0003E679 File Offset: 0x0003C879
		private void DrawViewGrid()
		{
			Graphics.DrawMeshInstanced(this.gridViewMesh, 0, this.gridViewMat, this.gridViewMatrices, this.gridViewProps);
		}

		// Token: 0x06001177 RID: 4471 RVA: 0x0003E69C File Offset: 0x0003C89C
		private void Update()
		{
			if (!LevelInterfaceManager3D.Instance.mouseOverUI)
			{
				this.SetPosition();
				if (!this.visual.gameObject.activeInHierarchy)
				{
					this.visual.gameObject.SetActive(true);
				}
			}
			else if (this.visual.gameObject.activeInHierarchy)
			{
				this.visual.gameObject.SetActive(false);
			}
			if (!LevelInterfaceManager3D.Instance.mouseOverUI)
			{
				this.SetHeight(Input.mouseScrollDelta.y);
			}
			this.GridFade();
			this.DrawViewGrid();
		}

		// Token: 0x06001178 RID: 4472 RVA: 0x0003E72C File Offset: 0x0003C92C
		private void SetPosition()
		{
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			Room currentRoom = LevelBuilder.Instance.GetCurrentRoom();
			if (currentRoom == null)
			{
				return;
			}
			Plane plane = new Plane(Vector3.up, Vector3.up * currentRoom.Grid.GetHeight(this.height));
			float distance;
			if (plane.Raycast(ray, out distance))
			{
				Vector3 point = ray.GetPoint(distance);
				Vector3 position;
				int num;
				if (currentRoom.Grid.GetPosition(this.height, currentRoom.transform.InverseTransformPoint(point).XZ(), out position, out num))
				{
					this.visual.transform.position = position;
					return;
				}
				string str = "Couldn't get space from position ";
				Vector3 vector = point;
				Debug.LogError(str + vector.ToString());
			}
		}

		// Token: 0x06001179 RID: 4473 RVA: 0x0003E7F8 File Offset: 0x0003C9F8
		private void GridFade()
		{
			if (this.TimeSinceHeightChanged <= this.gridFadeDuration)
			{
				this.gridViewProps.SetColor("_Color", Color.Lerp(this.gridColor, this._gridColorFaded, this.TimeSinceHeightChanged / this.gridFadeDuration));
				return;
			}
			if (this._timeHeightChanged != -1f)
			{
				this._timeHeightChanged = -1f;
				this.gridViewProps.SetColor("_Color", this._gridColorFaded);
			}
		}

		// Token: 0x0600117A RID: 4474 RVA: 0x0003E870 File Offset: 0x0003CA70
		public void Show()
		{
			this._timeHeightChanged = -1f;
			this.visual.gameObject.SetActive(true);
			base.enabled = true;
		}

		// Token: 0x0600117B RID: 4475 RVA: 0x0003E895 File Offset: 0x0003CA95
		public void Hide()
		{
			this.visual.gameObject.SetActive(false);
			base.enabled = false;
		}

		// Token: 0x0600117C RID: 4476 RVA: 0x0003E8B0 File Offset: 0x0003CAB0
		private void SetHeight(float delta)
		{
			if (delta == 0f)
			{
				return;
			}
			if (delta < 0f && this.height == 0)
			{
				return;
			}
			if (delta > 0f && this.height == LevelBuilder.Instance.GetCurrentRoom().Grid.floors.Length - 1)
			{
				return;
			}
			this._timeHeightChanged = Time.time;
			if (delta > 0f)
			{
				this.height++;
			}
			else if (delta < 0f)
			{
				this.height--;
			}
			if (this.height > 0)
			{
				this.heightLine.SetPosition(1, Vector3.down * (float)this.height);
			}
			this.heightLine.enabled = (this.height > 0);
			this.SetupViewGrid();
			this.cameraHoist.localPosition = Vector3.up * (float)this.height;
		}

		// Token: 0x0600117D RID: 4477 RVA: 0x0003E995 File Offset: 0x0003CB95
		private void CycleSelection(float delta)
		{
		}

		// Token: 0x04000B87 RID: 2951
		public Transform cameraHoist;

		// Token: 0x04000B88 RID: 2952
		public Transform grid;

		// Token: 0x04000B89 RID: 2953
		public Transform visual;

		// Token: 0x04000B8A RID: 2954
		public LineRenderer heightLine;

		// Token: 0x04000B8B RID: 2955
		public Mesh gridViewMesh;

		// Token: 0x04000B8C RID: 2956
		public Material gridViewMat;

		// Token: 0x04000B8D RID: 2957
		private readonly List<Matrix4x4> gridViewMatrices = new List<Matrix4x4>();

		// Token: 0x04000B8E RID: 2958
		private MaterialPropertyBlock gridViewProps;

		// Token: 0x04000B8F RID: 2959
		public Color gridColor = Color.white;

		// Token: 0x04000B90 RID: 2960
		public float gridFadeDuration = 3f;

		// Token: 0x04000B91 RID: 2961
		private Color _gridColorFaded;

		// Token: 0x04000B92 RID: 2962
		private int height;

		// Token: 0x04000B93 RID: 2963
		private float _timeHeightChanged = -1f;
	}
}
