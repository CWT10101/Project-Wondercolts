﻿using System;
using System.Collections.Generic;
using LevelEditor;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace LevelEditor3D
{
	// Token: 0x020001CA RID: 458
	public class LevelInterfaceManager3D : MonoBehaviour
	{
		// Token: 0x17000468 RID: 1128
		// (get) Token: 0x060011F1 RID: 4593 RVA: 0x000403AA File Offset: 0x0003E5AA
		// (set) Token: 0x060011F2 RID: 4594 RVA: 0x000403B1 File Offset: 0x0003E5B1
		public static LevelInterfaceManager3D Instance { get; private set; }

		// Token: 0x060011F3 RID: 4595 RVA: 0x000403B9 File Offset: 0x0003E5B9
		private void Awake()
		{
			LevelInterfaceManager3D.Instance = this;
		}

		// Token: 0x060011F4 RID: 4596 RVA: 0x000403C1 File Offset: 0x0003E5C1
		private void OnDestroy()
		{
			LevelInterfaceManager3D.Instance = null;
		}

		// Token: 0x060011F5 RID: 4597 RVA: 0x000403CC File Offset: 0x0003E5CC
		private void Start()
		{
			this.roomWindowItems = new RoomWindowItemUI[LevelResourcesManager3D.Instance.RoomPrefabs.Length];
			int num = 0;
			foreach (Room room in LevelResourcesManager3D.Instance.RoomPrefabs)
			{
				this.roomWindowItems[num] = Object.Instantiate<RoomWindowItemUI>(LevelResourcesManager3D.Instance.RoomWindowItemUIPrefab, this.roomItemHolder).Init(room, this.roomScreenToggleGroup);
				num++;
			}
			foreach (string text in LevelSerializer3D.Instance.levels)
			{
				LoadLevel3DButton loadLevel3DButton = Object.Instantiate<LoadLevel3DButton>(LevelResourcesManager3D.Instance.loadLevelButton);
				loadLevel3DButton.transform.SetParent(this.loadButtonHolder);
				loadLevel3DButton.text.text = text;
				loadLevel3DButton.levelName = text;
			}
			this.InitObjButtons();
		}

		// Token: 0x060011F6 RID: 4598 RVA: 0x000404BC File Offset: 0x0003E6BC
		private void Update()
		{
			bool flag = this.mouseOverUI;
			this.mouseOverUI = EventSystem.current.IsPointerOverGameObject();
			if (flag && !this.mouseOverUI)
			{
				EventSystem.current.SetSelectedGameObject(null);
			}
			bool flag2 = this.mouseOverUI;
		}

		// Token: 0x060011F7 RID: 4599 RVA: 0x000404F0 File Offset: 0x0003E6F0
		public void CycleWeather()
		{
			if (this.currentWeatherIndex < this.weathers.Length - 1)
			{
				this.currentWeatherIndex++;
			}
			else
			{
				this.currentWeatherIndex = 0;
			}
			this.SetWeather(this.currentWeatherIndex);
		}

		// Token: 0x060011F8 RID: 4600 RVA: 0x00040528 File Offset: 0x0003E728
		public void SetWeather(int index)
		{
			for (int i = 0; i < this.weathers.Length; i++)
			{
				this.weathers[i].SetActive(false);
			}
			this.currentWeatherIndex = index;
			this.weathers[this.currentWeatherIndex].SetActive(true);
		}

		// Token: 0x060011F9 RID: 4601 RVA: 0x00040570 File Offset: 0x0003E770
		public void SetSkybox(int index)
		{
			this.currentSkyboxIndex = index;
			RenderSettings.skybox = this.skyboxMaterials[this.currentSkyboxIndex];
		}

		// Token: 0x060011FA RID: 4602 RVA: 0x00040590 File Offset: 0x0003E790
		public void CycleSkybox()
		{
			if (this.currentSkyboxIndex < this.skyboxMaterials.Count - 1)
			{
				this.currentSkyboxIndex++;
			}
			else
			{
				this.currentSkyboxIndex = 0;
			}
			RenderSettings.skybox = this.skyboxMaterials[this.currentSkyboxIndex];
		}

		// Token: 0x060011FB RID: 4603 RVA: 0x000405DF File Offset: 0x0003E7DF
		public void AddRoomHook()
		{
			LevelBuilder.Instance.AppendRoomIndex(this.roomScreenToggleGroup.GetFirstActiveToggle().transform.GetSiblingIndex());
		}

		// Token: 0x060011FC RID: 4604 RVA: 0x00040600 File Offset: 0x0003E800
		public void ToggleEditMode()
		{
			LevelBuilder.Instance.ToggleEditMode();
			this.playmodeButtonEditIcon.SetActive(!LevelBuilder.Instance.EditMode);
			this.playmodeButtonPlayIcon.SetActive(LevelBuilder.Instance.EditMode);
			EventSystem.current.SetSelectedGameObject(null);
		}

		// Token: 0x060011FD RID: 4605 RVA: 0x00040650 File Offset: 0x0003E850
		public void MainContentNavigateBack()
		{
			GameObject[] array = this.contentWindowArray;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].SetActive(false);
			}
			this.contentWindowHeader.SetActive(false);
			this.contentWindowMainContent.SetActive(true);
		}

		// Token: 0x060011FE RID: 4606 RVA: 0x00040694 File Offset: 0x0003E894
		public void NavigateToContentWindow(GameObject contentWindow)
		{
			GameObject[] array = this.contentWindowArray;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].SetActive(false);
			}
			this.contentWindowMainContent.SetActive(false);
			contentWindow.SetActive(true);
			this.contentWindowHeaderText.text = contentWindow.name;
			this.contentWindowHeader.SetActive(true);
		}

		// Token: 0x060011FF RID: 4607 RVA: 0x000406EF File Offset: 0x0003E8EF
		public void SaveButtonHook()
		{
			LevelSerializer3D.SaveLevel(this.levelNameField.text, LevelBuilder.Instance.Rooms);
		}

		// Token: 0x06001200 RID: 4608 RVA: 0x0004070B File Offset: 0x0003E90B
		public void ExportButtonHook()
		{
		}

		// Token: 0x06001201 RID: 4609 RVA: 0x0004070D File Offset: 0x0003E90D
		public void NewLevelButtonHook()
		{
		}

		// Token: 0x06001202 RID: 4610 RVA: 0x00040710 File Offset: 0x0003E910
		private void InitObjButtons()
		{
			LevelObjButton levelObjButton = LevelResourcesManager.instance.levelObjButton;
			List<LevelGameObjectBase> levelGameObjects = LevelResourcesManager.instance.levelGameObjects;
			for (int i = 0; i < levelGameObjects.Count; i++)
			{
				LevelObj levelObj;
				if (levelGameObjects[i].objPrefab.TryGetComponent<LevelObj>(out levelObj) && !levelObj.excludeFromEditor3D)
				{
					Transform transform = null;
					if (levelObj.obj_category == "Crate")
					{
						transform = this.cratesHolder;
					}
					else if (levelObj.obj_category == "Block")
					{
						transform = this.pickupsHolder;
					}
					else if (levelObj.obj_category == "Hazards")
					{
						transform = this.hazardsHolder;
					}
					else if (levelObj.obj_category == "Enemies")
					{
						transform = this.enemiesHolder;
					}
					else if (levelObj.obj_category == "Gameplay")
					{
						transform = this.gameplayHolder;
					}
					if (transform != null)
					{
						LevelObjButton levelObjButton2 = Object.Instantiate<LevelObjButton>(levelObjButton, transform);
						Sprite icon;
						if (CrashAnimator.Skin != 0 && levelObj.Obj_IconCocoVariant != null)
						{
							icon = levelObj.Obj_IconCocoVariant;
						}
						else
						{
							icon = levelObj.obj_Icon;
						}
						levelObjButton2.Init(levelObj.obj_ID, icon, levelObj.flipIcon);
					}
				}
			}
		}

		// Token: 0x04000BD3 RID: 3027
		public Transform roomItemUIHolder;

		// Token: 0x04000BD4 RID: 3028
		public GameObject editorHud;

		// Token: 0x04000BD5 RID: 3029
		public GameObject playmodeButtonPlayIcon;

		// Token: 0x04000BD6 RID: 3030
		public GameObject playmodeButtonEditIcon;

		// Token: 0x04000BD7 RID: 3031
		public Button addRoomButton;

		// Token: 0x04000BD8 RID: 3032
		public bool mouseOverUI;

		// Token: 0x04000BD9 RID: 3033
		[Header("---Screens---")]
		public UIScreen editorHUD;

		// Token: 0x04000BDA RID: 3034
		[Header("---Content Window---")]
		public GameObject contentWindowHeader;

		// Token: 0x04000BDB RID: 3035
		public TMP_Text contentWindowHeaderText;

		// Token: 0x04000BDC RID: 3036
		public GameObject contentWindowHeaderBackButtonHolder;

		// Token: 0x04000BDD RID: 3037
		public GameObject contentWindowMainContent;

		// Token: 0x04000BDE RID: 3038
		public GameObject[] contentWindowArray;

		// Token: 0x04000BDF RID: 3039
		public Transform cratesHolder;

		// Token: 0x04000BE0 RID: 3040
		public Transform pickupsHolder;

		// Token: 0x04000BE1 RID: 3041
		public Transform enemiesHolder;

		// Token: 0x04000BE2 RID: 3042
		public Transform hazardsHolder;

		// Token: 0x04000BE3 RID: 3043
		public Transform gameplayHolder;

		// Token: 0x04000BE4 RID: 3044
		[Header("---Room Screen---")]
		public UIScreen roomScreen;

		// Token: 0x04000BE5 RID: 3045
		public Transform roomItemHolder;

		// Token: 0x04000BE6 RID: 3046
		public ToggleGroup roomScreenToggleGroup;

		// Token: 0x04000BE7 RID: 3047
		private RoomWindowItemUI[] roomWindowItems;

		// Token: 0x04000BE8 RID: 3048
		[Header("---Toolbar---")]
		public Toggle selectToggle;

		// Token: 0x04000BE9 RID: 3049
		public Toggle drawToggle;

		// Token: 0x04000BEA RID: 3050
		public Toggle deleteToggle;

		// Token: 0x04000BEB RID: 3051
		[Header("---Weather---")]
		public int currentWeatherIndex;

		// Token: 0x04000BEC RID: 3052
		public GameObject[] weathers;

		// Token: 0x04000BED RID: 3053
		[Header("---Skybox---")]
		public int currentSkyboxIndex;

		// Token: 0x04000BEE RID: 3054
		public List<Material> skyboxMaterials = new List<Material>();

		// Token: 0x04000BEF RID: 3055
		[Header("---Save Screen---")]
		public TMP_InputField levelNameField;

		// Token: 0x04000BF0 RID: 3056
		public TMP_InputField levelAuthorField;

		// Token: 0x04000BF1 RID: 3057
		public Button saveButton;

		// Token: 0x04000BF2 RID: 3058
		public Button exportButton;

		// Token: 0x04000BF3 RID: 3059
		[Header("---Load Screen---")]
		public Transform loadButtonHolder;
	}
}
