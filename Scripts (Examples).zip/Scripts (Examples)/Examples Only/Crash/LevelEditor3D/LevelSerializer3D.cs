﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace LevelEditor3D
{
	// Token: 0x020001C6 RID: 454
	public class LevelSerializer3D : MonoBehaviour
	{
		// Token: 0x17000458 RID: 1112
		// (get) Token: 0x060011BC RID: 4540 RVA: 0x0003F855 File Offset: 0x0003DA55
		// (set) Token: 0x060011BD RID: 4541 RVA: 0x0003F85C File Offset: 0x0003DA5C
		public static LevelSerializer3D Instance { get; private set; }

		// Token: 0x17000459 RID: 1113
		// (get) Token: 0x060011BE RID: 4542 RVA: 0x0003F864 File Offset: 0x0003DA64
		public static string InternalPath
		{
			[MethodImpl(MethodImplOptions.AggressiveInlining)]
			get
			{
				return Path.Combine(Application.streamingAssetsPath, "Crash-Creator-Content", "internal");
			}
		}

		// Token: 0x060011BF RID: 4543 RVA: 0x0003F87A File Offset: 0x0003DA7A
		private void Awake()
		{
			LevelSerializer3D.Instance = this;
			this.LoadLevels();
		}

		// Token: 0x060011C0 RID: 4544 RVA: 0x0003F888 File Offset: 0x0003DA88
		public static void SaveLevel(string fileName, List<Room> rooms)
		{
			using (FileStream fileStream = new FileStream(Path.Combine(LevelSerializer3D.InternalPath, fileName), FileMode.Create, FileAccess.Write, FileShare.None))
			{
				using (BinaryWriter binaryWriter = new BinaryWriter(fileStream))
				{
					binaryWriter.Write(LevelInterfaceManager3D.Instance.levelNameField.text);
					binaryWriter.Write(LevelInterfaceManager3D.Instance.levelAuthorField.text);
					binaryWriter.Write((byte)rooms.Count);
					foreach (Room room in rooms)
					{
						room.Serialize(binaryWriter);
					}
				}
			}
		}

		// Token: 0x060011C1 RID: 4545 RVA: 0x0003F954 File Offset: 0x0003DB54
		public static void LoadLevel(string filePath)
		{
			string message;
			string message2;
			RoomData[] array;
			using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				using (BinaryReader binaryReader = new BinaryReader(fileStream))
				{
					message = binaryReader.ReadString();
					message2 = binaryReader.ReadString();
					byte b = binaryReader.ReadByte();
					array = new RoomData[(int)b];
					for (int i = 0; i < (int)b; i++)
					{
					}
				}
			}
			LevelBuilder.Instance.RemoveAll();
			Debug.Log(message);
			Debug.Log(message2);
			foreach (RoomData roomData in array)
			{
				Room room = Object.Instantiate<Room>(LevelResourcesManager3D.Instance.RoomDictionary[roomData.id]);
				LevelBuilder.Instance.AppendRoom(room, false);
			}
		}

		// Token: 0x060011C2 RID: 4546 RVA: 0x0003FA38 File Offset: 0x0003DC38
		public void LoadLevels()
		{
			try
			{
				DirectoryInfo directoryInfo = new DirectoryInfo(LevelSerializer3D.InternalPath);
				if (!directoryInfo.Exists)
				{
					Debug.LogWarning("Directory doesn't exist");
				}
				else
				{
					foreach (FileInfo fileInfo in directoryInfo.GetFiles())
					{
						this.levels.Add(fileInfo.Name);
					}
				}
			}
			catch (Exception message)
			{
				Debug.LogError(message);
			}
		}

		// Token: 0x04000BB9 RID: 3001
		public const string internalFolder = "internal";

		// Token: 0x04000BBA RID: 3002
		public List<string> levels = new List<string>();
	}
}
