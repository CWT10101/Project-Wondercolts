﻿using System;
using System.Collections.Generic;
using System.Linq;
using LevelEditor;
using UnityEngine;

namespace LevelEditor3D
{
	// Token: 0x020001C9 RID: 457
	public class RoomGrid : MonoBehaviour
	{
		// Token: 0x060011E8 RID: 4584 RVA: 0x0003FE04 File Offset: 0x0003E004
		public void BakeBounds()
		{
			Bounds localBounds = this.room.LocalBounds;
			List<Vector3> list = new List<Vector3>();
			for (float num = localBounds.min.z + this.offset.z; num < localBounds.max.z + this.offset.z; num += 1f)
			{
				for (float num2 = localBounds.min.y + this.offset.y; num2 < localBounds.max.y + this.offset.y; num2 += 1f)
				{
					for (float num3 = localBounds.min.x + this.offset.x; num3 < localBounds.max.x + this.offset.x; num3 += 1f)
					{
						list.Add(new Vector3(num3, num2, num));
					}
				}
			}
			float n = 0.499f;
			float n2 = n * 2f;
			list.RemoveAll(delegate(Vector3 c)
			{
				foreach (Bounds bounds in this.bounds)
				{
					if (bounds.Contains(c + new Vector3(n, n2, n)) && bounds.Contains(c + new Vector3(n, n2, -n)) && bounds.Contains(c + new Vector3(n, 0f, n)) && bounds.Contains(c + new Vector3(n, 0f, -n)) && bounds.Contains(c + new Vector3(-n, n2, n)) && bounds.Contains(c + new Vector3(-n, n2, -n)) && bounds.Contains(c + new Vector3(-n, 0f, n)) && bounds.Contains(c + new Vector3(-n, 0f, -n)))
					{
						return false;
					}
				}
				return true;
			});
			List<RoomGrid.Floor> list2 = new List<RoomGrid.Floor>();
			foreach (IGrouping<float, Vector3> grouping in from v in list
			group v by v.y)
			{
				RoomGrid.Floor item = default(RoomGrid.Floor);
				item.height = grouping.Key;
				List<Vector2> list3 = new List<Vector2>();
				foreach (Vector3 v2 in grouping)
				{
					list3.Add(v2.XZ());
				}
				item.spaces = list3.ToArray();
				list2.Add(item);
			}
			this.floors = list2.ToArray();
		}

		// Token: 0x060011E9 RID: 4585 RVA: 0x00040044 File Offset: 0x0003E244
		public float GetHeight(int floorIndex = 0)
		{
			RoomGrid.Floor floor;
			if (this.GetFloor(floorIndex, out floor))
			{
				return base.transform.TransformPoint(0f, floor.height, 0f).y;
			}
			return base.transform.position.y;
		}

		// Token: 0x060011EA RID: 4586 RVA: 0x0004008D File Offset: 0x0003E28D
		public bool GetFloor(int floorIndex, out RoomGrid.Floor f)
		{
			if (floorIndex < 0)
			{
				f = default(RoomGrid.Floor);
				return false;
			}
			if (floorIndex >= this.floors.Length)
			{
				f = default(RoomGrid.Floor);
				return false;
			}
			f = this.floors[floorIndex];
			return true;
		}

		// Token: 0x060011EB RID: 4587 RVA: 0x000400C4 File Offset: 0x0003E2C4
		public bool GetPosition(int floorIndex, int spaceIndex, out Vector3 worldPos)
		{
			RoomGrid.Floor floor;
			if (this.GetFloor(floorIndex, out floor) && spaceIndex >= 0 && spaceIndex < floor.spaces.Length)
			{
				Vector2 vector = floor.spaces[spaceIndex];
				worldPos = base.transform.TransformPoint(vector.x, 0f, vector.y) + Vector3.up * this.GetHeight(floorIndex);
				return true;
			}
			worldPos = default(Vector3);
			return false;
		}

		// Token: 0x060011EC RID: 4588 RVA: 0x0004013C File Offset: 0x0003E33C
		public bool GetPosition(int floorIndex, Vector2 xz, out Vector3 worldPosition, out int index)
		{
			RoomGrid.Floor floor;
			if (this.GetFloor(floorIndex, out floor))
			{
				Vector2 vector = default(Vector2);
				int num = 0;
				float num2 = float.PositiveInfinity;
				for (int i = 0; i < floor.spaces.Length; i++)
				{
					Vector2 vector2 = floor.spaces[i];
					float num3 = Vector2.SqrMagnitude(vector2 - xz);
					if (vector == default(Vector2) || num2 > num3)
					{
						vector = vector2;
						num = i;
						num2 = num3;
					}
				}
				worldPosition = base.transform.TransformPoint(vector.x, 0f, vector.y) + Vector3.up * this.GetHeight(floorIndex);
				index = num;
				return true;
			}
			worldPosition = default(Vector3);
			index = 0;
			return false;
		}

		// Token: 0x060011ED RID: 4589 RVA: 0x00040206 File Offset: 0x0003E406
		public IEnumerable<Vector3> GetPositions()
		{
			int num;
			for (int f = 0; f < this.floors.Length; f = num + 1)
			{
				RoomGrid.Floor floor = this.floors[f];
				for (int s = 0; s < floor.spaces.Length; s = num + 1)
				{
					Vector2 vector = floor.spaces[s];
					yield return base.transform.TransformPoint(vector.x, 0f, vector.y) + Vector3.up * floor.height;
					num = s;
				}
				floor = default(RoomGrid.Floor);
				num = f;
			}
			yield break;
		}

		// Token: 0x060011EE RID: 4590 RVA: 0x00040218 File Offset: 0x0003E418
		public bool GetObj(Vector3 position, out LevelObj obj)
		{
			Collider[] array = Physics.OverlapBox(position, new Vector3(0.5f, 0.5f, 0.5f), base.transform.rotation);
			for (int i = 0; i < array.Length; i++)
			{
				if (array[i].TryGetComponentInParent(out obj))
				{
					return true;
				}
			}
			obj = null;
			return false;
		}

		// Token: 0x060011EF RID: 4591 RVA: 0x0004026C File Offset: 0x0003E46C
		private void OnDrawGizmos()
		{
			if (this.bounds != null)
			{
				Gizmos.matrix = base.transform.localToWorldMatrix;
				Gizmos.color = Color.white;
				foreach (Bounds bounds in this.bounds)
				{
					Gizmos.DrawWireCube(bounds.center, bounds.size);
				}
			}
			if (this.floors != null)
			{
				Gizmos.matrix = base.transform.localToWorldMatrix;
				int num = 0;
				foreach (RoomGrid.Floor floor in this.floors)
				{
					Gizmos.color = Color.HSVToRGB((float)num / (float)this.floors.Length, 0.5f, 1f) * new Color(1f, 1f, 1f, 0.25f);
					foreach (Vector2 vector in floor.spaces)
					{
						Gizmos.DrawWireCube(new Vector3(vector.x, floor.height + 0.5f, vector.y), Vector3.one);
					}
					num++;
				}
			}
		}

		// Token: 0x04000BCE RID: 3022
		[SerializeField]
		private Room room;

		// Token: 0x04000BCF RID: 3023
		public GameObject[] groundPieces;

		// Token: 0x04000BD0 RID: 3024
		public Bounds[] bounds;

		// Token: 0x04000BD1 RID: 3025
		public Vector3 offset;

		// Token: 0x04000BD2 RID: 3026
		public RoomGrid.Floor[] floors;

		// Token: 0x0200028E RID: 654
		[Serializable]
		public struct Floor
		{
			// Token: 0x04000EDB RID: 3803
			public float height;

			// Token: 0x04000EDC RID: 3804
			public Vector2[] spaces;
		}
	}
}
