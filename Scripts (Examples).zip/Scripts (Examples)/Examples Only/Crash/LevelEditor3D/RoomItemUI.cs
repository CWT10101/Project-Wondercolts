﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace LevelEditor3D
{
	// Token: 0x020001CB RID: 459
	public class RoomItemUI : MonoBehaviour, IPointerClickHandler, IEventSystemHandler
	{
		// Token: 0x17000469 RID: 1129
		// (get) Token: 0x06001204 RID: 4612 RVA: 0x00040859 File Offset: 0x0003EA59
		// (set) Token: 0x06001205 RID: 4613 RVA: 0x00040861 File Offset: 0x0003EA61
		public Room Room { get; private set; }

		// Token: 0x06001206 RID: 4614 RVA: 0x0004086A File Offset: 0x0003EA6A
		public void Init(Room room)
		{
			this.Room = room;
			this.label.text = room.DisplayName;
			this.graphic.sprite = room.DisplayIcon;
			LayoutRebuilder.ForceRebuildLayoutImmediate(base.transform.parent.GetComponent<RectTransform>());
		}

		// Token: 0x06001207 RID: 4615 RVA: 0x000408AA File Offset: 0x0003EAAA
		public void OnOrderChanged(int oldIndex, int newIndex)
		{
			LevelBuilder.Instance.ShiftRoom(this.Room, newIndex);
		}

		// Token: 0x06001208 RID: 4616 RVA: 0x000408BD File Offset: 0x0003EABD
		public void DestroyItemHook()
		{
			LevelBuilder.Instance.RemoveRoom(this.Room);
			Object.Destroy(base.gameObject);
		}

		// Token: 0x06001209 RID: 4617 RVA: 0x000408DA File Offset: 0x0003EADA
		public void OnPointerClick(PointerEventData eventData)
		{
			LevelBuilder.Instance.MoveCameraToRoom(this.Room);
		}

		// Token: 0x04000BF6 RID: 3062
		public TMP_Text label;

		// Token: 0x04000BF7 RID: 3063
		public Image graphic;

		// Token: 0x04000BF8 RID: 3064
		public Image border;
	}
}
