﻿using System;
using UnityEngine;

namespace LevelEditor3D
{
	// Token: 0x020001C5 RID: 453
	[Serializable]
	public class LevelGameObjectBase3D
	{
		// Token: 0x04000BB6 RID: 2998
		public string obj_ID;

		// Token: 0x04000BB7 RID: 2999
		public GameObject objPrefab;
	}
}
