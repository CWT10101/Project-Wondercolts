﻿using System;
using UnityEngine;

namespace LevelEditor3D
{
	// Token: 0x020001C3 RID: 451
	public class LevelObj3D : MonoBehaviour
	{
		// Token: 0x17000452 RID: 1106
		// (get) Token: 0x060011AA RID: 4522 RVA: 0x0003F6EB File Offset: 0x0003D8EB
		// (set) Token: 0x060011AB RID: 4523 RVA: 0x0003F6F3 File Offset: 0x0003D8F3
		public bool IsSingularInstance { get; private set; }

		// Token: 0x060011AC RID: 4524 RVA: 0x0003F6FC File Offset: 0x0003D8FC
		public void SetEditor()
		{
			this.editorVisual.SetActive(true);
			this.gameplayVisual.SetActive(false);
			IPlayModeCallback[] componentsInChildren = base.GetComponentsInChildren<IPlayModeCallback>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].PlayModeChanged(false);
			}
		}

		// Token: 0x060011AD RID: 4525 RVA: 0x0003F740 File Offset: 0x0003D940
		public void SetPlaymode()
		{
			this.editorVisual.SetActive(false);
			this.gameplayVisual.SetActive(true);
			Entity componentInChildren = this.gameplayVisual.GetComponentInChildren<Entity>(true);
			if (componentInChildren != null)
			{
				componentInChildren.ResetEntity();
			}
			IPlayModeCallback[] componentsInChildren = base.GetComponentsInChildren<IPlayModeCallback>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].PlayModeChanged(true);
			}
		}

		// Token: 0x04000BAB RID: 2987
		public string obj_ID;

		// Token: 0x04000BAC RID: 2988
		public string obj_class;

		// Token: 0x04000BAD RID: 2989
		public GameObject editorVisual;

		// Token: 0x04000BAE RID: 2990
		public GameObject gameplayVisual;

		// Token: 0x04000BAF RID: 2991
		public GameObject editorOutlineVis;
	}
}
