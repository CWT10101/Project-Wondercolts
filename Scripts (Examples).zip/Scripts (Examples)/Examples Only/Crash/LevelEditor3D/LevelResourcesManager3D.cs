﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace LevelEditor3D
{
	// Token: 0x020001C4 RID: 452
	public class LevelResourcesManager3D : MonoBehaviour
	{
		// Token: 0x17000453 RID: 1107
		// (get) Token: 0x060011AF RID: 4527 RVA: 0x0003F7A2 File Offset: 0x0003D9A2
		// (set) Token: 0x060011B0 RID: 4528 RVA: 0x0003F7AA File Offset: 0x0003D9AA
		public Room[] RoomPrefabs { get; private set; }

		// Token: 0x17000454 RID: 1108
		// (get) Token: 0x060011B1 RID: 4529 RVA: 0x0003F7B3 File Offset: 0x0003D9B3
		public Dictionary<string, Room> RoomDictionary { get; } = new Dictionary<string, Room>();

		// Token: 0x17000455 RID: 1109
		// (get) Token: 0x060011B2 RID: 4530 RVA: 0x0003F7BB File Offset: 0x0003D9BB
		// (set) Token: 0x060011B3 RID: 4531 RVA: 0x0003F7C3 File Offset: 0x0003D9C3
		public RoomItemUI RoomItemUIPrefab { get; private set; }

		// Token: 0x17000456 RID: 1110
		// (get) Token: 0x060011B4 RID: 4532 RVA: 0x0003F7CC File Offset: 0x0003D9CC
		// (set) Token: 0x060011B5 RID: 4533 RVA: 0x0003F7D4 File Offset: 0x0003D9D4
		public RoomWindowItemUI RoomWindowItemUIPrefab { get; private set; }

		// Token: 0x17000457 RID: 1111
		// (get) Token: 0x060011B6 RID: 4534 RVA: 0x0003F7DD File Offset: 0x0003D9DD
		// (set) Token: 0x060011B7 RID: 4535 RVA: 0x0003F7E4 File Offset: 0x0003D9E4
		public static LevelResourcesManager3D Instance { get; private set; }

		// Token: 0x060011B8 RID: 4536 RVA: 0x0003F7EC File Offset: 0x0003D9EC
		private void Awake()
		{
			LevelResourcesManager3D.Instance = this;
			for (int i = 0; i < this.RoomPrefabs.Length; i++)
			{
				this.RoomDictionary.Add(this.RoomPrefabs[i].ID, this.RoomPrefabs[i]);
			}
		}

		// Token: 0x060011B9 RID: 4537 RVA: 0x0003F832 File Offset: 0x0003DA32
		private void OnDestroy()
		{
			LevelResourcesManager3D.Instance = null;
		}

		// Token: 0x04000BB4 RID: 2996
		[SerializeField]
		public LoadLevel3DButton loadLevelButton;
	}
}
