﻿using System;
using System.Collections.Generic;
using System.IO;
using LevelEditor;
using UnityEngine;
using UnityEngine.Events;

namespace LevelEditor3D
{
	// Token: 0x020001C7 RID: 455
	public class Room : MonoBehaviour
	{
		// Token: 0x1700045A RID: 1114
		// (get) Token: 0x060011C4 RID: 4548 RVA: 0x0003FABB File Offset: 0x0003DCBB
		// (set) Token: 0x060011C5 RID: 4549 RVA: 0x0003FAC3 File Offset: 0x0003DCC3
		public RoomGrid Grid { get; private set; }

		// Token: 0x1700045B RID: 1115
		// (get) Token: 0x060011C6 RID: 4550 RVA: 0x0003FACC File Offset: 0x0003DCCC
		// (set) Token: 0x060011C7 RID: 4551 RVA: 0x0003FAD4 File Offset: 0x0003DCD4
		public string DisplayName { get; private set; }

		// Token: 0x1700045C RID: 1116
		// (get) Token: 0x060011C8 RID: 4552 RVA: 0x0003FADD File Offset: 0x0003DCDD
		// (set) Token: 0x060011C9 RID: 4553 RVA: 0x0003FAE5 File Offset: 0x0003DCE5
		public string ID { get; private set; }

		// Token: 0x1700045D RID: 1117
		// (get) Token: 0x060011CA RID: 4554 RVA: 0x0003FAEE File Offset: 0x0003DCEE
		// (set) Token: 0x060011CB RID: 4555 RVA: 0x0003FAF6 File Offset: 0x0003DCF6
		public Sprite DisplayIcon { get; private set; }

		// Token: 0x1700045E RID: 1118
		// (get) Token: 0x060011CC RID: 4556 RVA: 0x0003FAFF File Offset: 0x0003DCFF
		public Bounds LocalBounds
		{
			get
			{
				return this._bounds;
			}
		}

		// Token: 0x060011CD RID: 4557 RVA: 0x0003FB07 File Offset: 0x0003DD07
		public bool WithinBounds(Vector3 worldPos)
		{
			return this._bounds.Contains(base.transform.InverseTransformPoint(worldPos));
		}

		// Token: 0x1700045F RID: 1119
		// (get) Token: 0x060011CE RID: 4558 RVA: 0x0003FB20 File Offset: 0x0003DD20
		// (set) Token: 0x060011CF RID: 4559 RVA: 0x0003FB28 File Offset: 0x0003DD28
		public Transform EntitiesHolder { get; private set; }

		// Token: 0x17000460 RID: 1120
		// (get) Token: 0x060011D0 RID: 4560 RVA: 0x0003FB31 File Offset: 0x0003DD31
		// (set) Token: 0x060011D1 RID: 4561 RVA: 0x0003FB39 File Offset: 0x0003DD39
		public GameObject Ceiling { get; private set; }

		// Token: 0x17000461 RID: 1121
		// (get) Token: 0x060011D2 RID: 4562 RVA: 0x0003FB42 File Offset: 0x0003DD42
		// (set) Token: 0x060011D3 RID: 4563 RVA: 0x0003FB4A File Offset: 0x0003DD4A
		public GameObject DoorHolder { get; private set; }

		// Token: 0x17000462 RID: 1122
		// (get) Token: 0x060011D4 RID: 4564 RVA: 0x0003FB53 File Offset: 0x0003DD53
		// (set) Token: 0x060011D5 RID: 4565 RVA: 0x0003FB5B File Offset: 0x0003DD5B
		public Transform StartPoint { get; private set; }

		// Token: 0x17000463 RID: 1123
		// (get) Token: 0x060011D6 RID: 4566 RVA: 0x0003FB64 File Offset: 0x0003DD64
		// (set) Token: 0x060011D7 RID: 4567 RVA: 0x0003FB6C File Offset: 0x0003DD6C
		public Transform EndPoint { get; private set; }

		// Token: 0x17000464 RID: 1124
		// (get) Token: 0x060011D8 RID: 4568 RVA: 0x0003FB75 File Offset: 0x0003DD75
		// (set) Token: 0x060011D9 RID: 4569 RVA: 0x0003FB7D File Offset: 0x0003DD7D
		public Transform CamStartPoint { get; private set; }

		// Token: 0x17000465 RID: 1125
		// (get) Token: 0x060011DA RID: 4570 RVA: 0x0003FB86 File Offset: 0x0003DD86
		// (set) Token: 0x060011DB RID: 4571 RVA: 0x0003FB8E File Offset: 0x0003DD8E
		public Transform Midpoint { get; private set; }

		// Token: 0x17000466 RID: 1126
		// (get) Token: 0x060011DC RID: 4572 RVA: 0x0003FB97 File Offset: 0x0003DD97
		// (set) Token: 0x060011DD RID: 4573 RVA: 0x0003FB9F File Offset: 0x0003DD9F
		public List<LevelObj> Crates { get; private set; }

		// Token: 0x17000467 RID: 1127
		// (get) Token: 0x060011DE RID: 4574 RVA: 0x0003FBA8 File Offset: 0x0003DDA8
		// (set) Token: 0x060011DF RID: 4575 RVA: 0x0003FBB0 File Offset: 0x0003DDB0
		public List<LevelObj> Enemies { get; private set; }

		// Token: 0x060011E0 RID: 4576 RVA: 0x0003FBB9 File Offset: 0x0003DDB9
		private void Start()
		{
			this.EntitiesHolder.gameObject.SetActive(true);
			this.AssignCamTriggers();
		}

		// Token: 0x060011E1 RID: 4577 RVA: 0x0003FBD4 File Offset: 0x0003DDD4
		public void AssignCamTriggers()
		{
			if (this.entryCamTrigger == null || this.exitCamTrigger == null)
			{
				return;
			}
			this.entryCamTrigger.onTriggered.RemoveAllListeners();
			this.entryCamTrigger.onTriggered.AddListener(new UnityAction(this.SetCamTrigger));
		}

		// Token: 0x060011E2 RID: 4578 RVA: 0x0003FC2A File Offset: 0x0003DE2A
		public void SetCamTrigger()
		{
			LevelBuilder.Instance.SetCameraTrigger(this.camIndex);
		}

		// Token: 0x060011E3 RID: 4579 RVA: 0x0003FC3C File Offset: 0x0003DE3C
		public void Serialize(BinaryWriter bw)
		{
			bw.Write(this.ID);
			Debug.Log("Room " + this.ID + " :");
			ushort num = 0;
			int num2 = 0;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				using (BinaryWriter binaryWriter = new BinaryWriter(memoryStream))
				{
					foreach (Vector3 position in this.Grid.GetPositions())
					{
						LevelObj levelObj;
						if (this.Grid.GetObj(position, out levelObj))
						{
							binaryWriter.Write(true);
							levelObj.Serialize(binaryWriter);
							num2++;
						}
						else
						{
							binaryWriter.Write(false);
						}
						num += 1;
					}
				}
				bw.Write(num);
				bw.Write(memoryStream.ToArray());
				Debug.Log(string.Format("Wrote {0}/{1} Objects", num2, num));
			}
		}

		// Token: 0x060011E4 RID: 4580 RVA: 0x0003FD54 File Offset: 0x0003DF54
		public static RoomData Deserialize(byte version, BinaryReader br)
		{
			RoomData roomData = new RoomData
			{
				id = br.ReadString(),
				objects = new SaveableLevelObject[(int)br.ReadUInt16()]
			};
			for (int i = 0; i < roomData.objects.Length; i++)
			{
				LevelObj.Deserialize(version, br);
			}
			return roomData;
		}

		// Token: 0x060011E5 RID: 4581 RVA: 0x0003FDA0 File Offset: 0x0003DFA0
		private void OnDrawGizmos()
		{
			Gizmos.color = new Color(1f, 1f, 0f);
			Gizmos.matrix = base.transform.localToWorldMatrix;
			Gizmos.DrawWireCube(this._bounds.center, this._bounds.size);
		}

		// Token: 0x04000BBF RID: 3007
		[SerializeField]
		private Bounds _bounds;

		// Token: 0x04000BC9 RID: 3017
		public int camIndex;

		// Token: 0x04000BCA RID: 3018
		public CameraTrigger entryCamTrigger;

		// Token: 0x04000BCB RID: 3019
		public CameraTrigger exitCamTrigger;
	}
}
