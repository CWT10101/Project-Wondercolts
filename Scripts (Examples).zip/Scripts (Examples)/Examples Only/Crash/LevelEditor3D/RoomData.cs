﻿using System;
using LevelEditor;

namespace LevelEditor3D
{
	// Token: 0x020001C8 RID: 456
	public class RoomData
	{
		// Token: 0x04000BCC RID: 3020
		public string id;

		// Token: 0x04000BCD RID: 3021
		public SaveableLevelObject[] objects;
	}
}
