﻿using System;
using UnityEngine;

// Token: 0x020000F3 RID: 243
public class OrientationOverride : MonoBehaviour, IPostEnable
{
	// Token: 0x06000786 RID: 1926 RVA: 0x0001FF1F File Offset: 0x0001E11F
	public void OnPostEnable()
	{
		Debug.LogWarning("SET ORIENTATION");
		base.transform.rotation = Quaternion.LookRotation(this.forward);
	}

	// Token: 0x0400059C RID: 1436
	public Vector3 forward = Vector3.forward;
}
