﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x02000153 RID: 339
public class QualityDropdown : MonoBehaviour
{
	// Token: 0x14000004 RID: 4
	// (add) Token: 0x060009E7 RID: 2535 RVA: 0x00027C8C File Offset: 0x00025E8C
	// (remove) Token: 0x060009E8 RID: 2536 RVA: 0x00027CC0 File Offset: 0x00025EC0
	public static event Action<int> OnQualityChanged;

	// Token: 0x060009E9 RID: 2537 RVA: 0x00027CF4 File Offset: 0x00025EF4
	private void Start()
	{
		this.dropdown.ClearOptions();
		string[] names = QualitySettings.names;
		this.dropdown.AddOptions(new List<string>(names));
		int qualityLevel = QualitySettings.GetQualityLevel();
		this.dropdown.value = qualityLevel;
	}

	// Token: 0x060009EA RID: 2538 RVA: 0x00027D35 File Offset: 0x00025F35
	public void SetQuality(int qualityIndex)
	{
		PlayerPrefs.SetInt("Quality", qualityIndex);
		QualitySettings.SetQualityLevel(qualityIndex);
		Action<int> onQualityChanged = QualityDropdown.OnQualityChanged;
		if (onQualityChanged == null)
		{
			return;
		}
		onQualityChanged(qualityIndex);
	}

	// Token: 0x0400071C RID: 1820
	public TMP_Dropdown dropdown;
}
