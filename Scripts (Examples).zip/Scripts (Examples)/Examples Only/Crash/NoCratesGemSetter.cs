﻿using System;
using UnityEngine;

// Token: 0x020000F0 RID: 240
public class NoCratesGemSetter : PickupSetter
{
	// Token: 0x170000F6 RID: 246
	// (get) Token: 0x06000763 RID: 1891 RVA: 0x0001EF62 File Offset: 0x0001D162
	public override Pickup Pickup
	{
		get
		{
			return this.nocratesGem;
		}
	}

	// Token: 0x170000F7 RID: 247
	// (get) Token: 0x06000764 RID: 1892 RVA: 0x0001EF6A File Offset: 0x0001D16A
	// (set) Token: 0x06000765 RID: 1893 RVA: 0x0001EF72 File Offset: 0x0001D172
	public override bool Collected
	{
		get
		{
			return this.collected;
		}
		set
		{
			this.collected = value;
		}
	}

	// Token: 0x0400056A RID: 1386
	[SerializeField]
	private CrystalPickup nocratesGem;

	// Token: 0x0400056B RID: 1387
	[SerializeField]
	private bool collected;
}
