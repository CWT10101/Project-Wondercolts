﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000068 RID: 104
public class CCMover : MonoBehaviour, IMover
{
	// Token: 0x17000072 RID: 114
	// (get) Token: 0x06000297 RID: 663 RVA: 0x0000B534 File Offset: 0x00009734
	// (set) Token: 0x06000298 RID: 664 RVA: 0x0000B53C File Offset: 0x0000973C
	public CharacterController Controller { get; private set; }

	// Token: 0x17000073 RID: 115
	// (get) Token: 0x06000299 RID: 665 RVA: 0x0000B545 File Offset: 0x00009745
	public bool Is2D
	{
		get
		{
			return this._is2D;
		}
	}

	// Token: 0x17000074 RID: 116
	// (get) Token: 0x0600029A RID: 666 RVA: 0x0000B54D File Offset: 0x0000974D
	public bool CanUpdate
	{
		get
		{
			return this.Controller.enabled;
		}
	}

	// Token: 0x0600029B RID: 667 RVA: 0x0000B55A File Offset: 0x0000975A
	public CCMover Init(CharacterController cc, bool is2D)
	{
		this.Controller = cc;
		this._is2D = is2D;
		return this;
	}

	// Token: 0x0600029C RID: 668 RVA: 0x0000B56C File Offset: 0x0000976C
	public void OnControllerColliderHit(ControllerColliderHit hit)
	{
		this.hits.Add(new IMover.MoveHit
		{
			Normal = hit.normal,
			Position = hit.point,
			Collider = hit.collider
		});
	}

	// Token: 0x0600029D RID: 669 RVA: 0x0000B5B4 File Offset: 0x000097B4
	IMover.MoveResult IMover.Move(Vector3 velocity, float dt)
	{
		this.hits.Clear();
		if (this.Is2D)
		{
			velocity = velocity.XY();
		}
		Vector3 position = this.Controller.transform.position;
		this.Controller.Move(velocity * dt + this.deflection);
		Vector3 moveDelta = this.Controller.transform.position - position;
		this.deflection = default(Vector3);
		bool flag = false;
		foreach (IMover.MoveHit moveHit in this.hits)
		{
			if (Vector3.Angle(Vector3.up, moveHit.Normal) <= 60f)
			{
				flag = true;
				break;
			}
		}
		Vector3 vector = default(Vector3);
		foreach (IMover.MoveHit moveHit2 in this.hits)
		{
			float num = Vector3.Angle(Vector3.up, moveHit2.Normal);
			if (num > 60f && num < 120f)
			{
				vector += moveHit2.Normal;
			}
		}
		if (!flag && vector != default(Vector3) && vector.y != 0f)
		{
			vector.Normalize();
			Vector3 vector2 = this.Controller.transform.TransformPoint(this.Controller.center);
			Vector3 a;
			if (vector.y > 0f)
			{
				a = vector2 - Vector3.up * (this.Controller.height / 2f);
			}
			else
			{
				a = vector2 + Vector3.up * (this.Controller.height / 2f);
			}
			Vector3 vector3 = a - vector;
			float d;
			if (vector3.x > vector2.x)
			{
				d = vector2.x + this.Controller.radius - vector3.x;
			}
			else
			{
				d = vector2.x - this.Controller.radius - vector3.x;
			}
			this.deflection = Vector3.right * d * Mathf.Abs(velocity.y * dt);
		}
		return new IMover.MoveResult
		{
			Hits = this.hits.ToArray(),
			MoveDelta = moveDelta,
			Grounded = flag,
			Wall = (vector != default(Vector3))
		};
	}

	// Token: 0x0600029E RID: 670 RVA: 0x0000B870 File Offset: 0x00009A70
	public void Teleport(Vector3 position)
	{
		this.Controller.enabled = false;
		this.Controller.transform.position = position;
		this.Controller.enabled = true;
	}

	// Token: 0x0400017B RID: 379
	private bool _is2D;

	// Token: 0x0400017C RID: 380
	private readonly List<IMover.MoveHit> hits = new List<IMover.MoveHit>();

	// Token: 0x0400017D RID: 381
	private Vector3 deflection = Vector3.zero;
}
