﻿using System;
using LevelEditor;
using LevelEditor3D;
using UnityEngine;

// Token: 0x0200005F RID: 95
public class BasicEnemy : Enemy, IMetadataReceiver<FlipMetadata>, IMetadataReceiver<SpeedMetadata>, IMetadataReceiver<RotationMetadata>
{
	// Token: 0x1700006B RID: 107
	// (get) Token: 0x06000244 RID: 580 RVA: 0x00009F1C File Offset: 0x0000811C
	// (set) Token: 0x06000245 RID: 581 RVA: 0x00009F24 File Offset: 0x00008124
	public Vector3 Direction { get; private set; }

	// Token: 0x06000246 RID: 582 RVA: 0x00009F30 File Offset: 0x00008130
	protected override void OnEnable()
	{
		base.OnEnable();
		this._dir = this.Direction;
		if (this.doRotation || LevelInterfaceManager3D.Instance)
		{
			base.transform.rotation = Quaternion.LookRotation(this._dir);
		}
		this.inEditor = (base.GetComponentInParent<LevelObj>() != null);
	}

	// Token: 0x06000247 RID: 583 RVA: 0x00009F8B File Offset: 0x0000818B
	protected override void FixedUpdate()
	{
		base.FixedUpdate();
		this.DoMovement();
	}

	// Token: 0x06000248 RID: 584 RVA: 0x00009F9C File Offset: 0x0000819C
	public override void Bump(Enemy other)
	{
		if (this.shouldReverse)
		{
			return;
		}
		if (Vector2.Dot((other.transform.position - base.transform.position).XZ().normalized, this._dir.XZ()) > 0f)
		{
			this.shouldReverse = true;
		}
	}

	// Token: 0x06000249 RID: 585 RVA: 0x00009FF8 File Offset: 0x000081F8
	protected void DoMovement()
	{
		if (!this.isDead && this.controller.enabled)
		{
			if (this.shouldReverse)
			{
				this._dir *= -1f;
				this.shouldReverse = false;
			}
			if (this.controller.isGrounded && this.IsGapOrBlocker())
			{
				this._dir *= -1f;
			}
			Vector3 a = new Vector3(this.externalForce.x * this.externalForceMultiplier + this._dir.x * this.speed, this.externalForce.y * this.externalForceMultiplier + this.fallMomentum, this.externalForce.z * this.externalForceMultiplier + this._dir.z * this.speed);
			if (this.inEditor)
			{
				a = Vector3.Scale(a, new Vector3(1f, 1f, 0f));
			}
			this.controller.Move(a * Time.deltaTime);
			if (this.gravity != 0f)
			{
				if (this.controller.isGrounded)
				{
					this.fallMomentum = -1f;
				}
				else
				{
					this.fallMomentum += this.gravity * Time.deltaTime;
				}
			}
			if (this.doRotation && this.rotationSpeed != 0f && this._dir.sqrMagnitude > 0f)
			{
				base.transform.rotation = Quaternion.RotateTowards(base.transform.rotation, Quaternion.LookRotation(this._dir), this.rotationSpeed * 360f * Time.deltaTime);
			}
		}
	}

	// Token: 0x0600024A RID: 586 RVA: 0x0000A1B4 File Offset: 0x000083B4
	private void OnControllerColliderHit(ControllerColliderHit hit)
	{
		CrashController crashController;
		if (hit.collider.TryGetComponent<CrashController>(out crashController))
		{
			if (!crashController.isDead && crashController.LastMoveDelta == Vector3.zero)
			{
				Vector3 normal = hit.normal;
				Vector3 point = hit.point;
				Vector3 direction = -hit.moveDirection;
				base.GenerateCollision(crashController.controller, this.controller, normal, point, direction, hit.moveLength);
			}
			Debug.DrawRay(hit.point, hit.normal, new Color(1f, 0.5f, 0f), Time.fixedDeltaTime * 20f, false);
			return;
		}
		Debug.DrawRay(hit.point, hit.normal, new Color(1f, 0.5f, 1f), Time.fixedDeltaTime * 5f, false);
		if (Vector2.Dot((hit.point - base.transform.position).XZ().normalized, this._dir.XZ()) > 0f && Vector3.Angle(Vector3.up, hit.normal) > this.controller.slopeLimit)
		{
			Enemy componentInParent = hit.gameObject.GetComponentInParent<Enemy>();
			if (componentInParent != null)
			{
				componentInParent.Bump(this);
			}
			this.shouldReverse = true;
		}
	}

	// Token: 0x0600024B RID: 587 RVA: 0x0000A2FD File Offset: 0x000084FD
	public override void ResetEntity()
	{
		this.fallMomentum = 0f;
		this._dir = this.Direction;
		if (this.doRotation)
		{
			base.transform.rotation = Quaternion.LookRotation(this._dir);
		}
		base.ResetEntity();
	}

	// Token: 0x0600024C RID: 588 RVA: 0x0000A33C File Offset: 0x0000853C
	protected bool IsGapOrBlocker()
	{
		if (this._dir.sqrMagnitude == 0f)
		{
			return false;
		}
		Bounds bounds = new Bounds(this.controller.bounds.center + this._dir.normalized * this.controller.radius * 2f, new Vector3(this.controller.radius * 2f, this.controller.height, this.controller.radius * 2f));
		bounds.Encapsulate(bounds.min - Vector3.up * (this.controller.radius * 1.71f));
		Collider[] array = Physics.OverlapBox(bounds.center, bounds.extents, Quaternion.identity, Enemy.HitMask, QueryTriggerInteraction.Collide);
		Collider[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			EnemyBlocker enemyBlocker;
			if (array2[i].TryGetComponent<EnemyBlocker>(out enemyBlocker))
			{
				return true;
			}
		}
		if (!this.avoidFalling)
		{
			return false;
		}
		array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			if (array2[i].gameObject != base.gameObject)
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x0600024D RID: 589 RVA: 0x0000A47A File Offset: 0x0000867A
	public virtual void ProcessMetadata(FlipMetadata meta)
	{
		this.Direction = (meta.isFlipped ? Vector3.right : Vector3.left);
	}

	// Token: 0x0600024E RID: 590 RVA: 0x0000A498 File Offset: 0x00008698
	public virtual void ProcessMetadata(SpeedMetadata meta)
	{
		if (this.processSpeedMetadata)
		{
			float num = 0.5f;
			float num2 = 3f;
			this.animator.speed = (float)meta.speed / 5f * (num2 - num) + num;
		}
	}

	// Token: 0x0600024F RID: 591 RVA: 0x0000A4D8 File Offset: 0x000086D8
	private void DrawBounds(Bounds b, float delay = 0f)
	{
		Vector3 vector = new Vector3(b.min.x, b.min.y, b.min.z);
		Vector3 vector2 = new Vector3(b.max.x, b.min.y, b.min.z);
		Vector3 vector3 = new Vector3(b.max.x, b.min.y, b.max.z);
		Vector3 vector4 = new Vector3(b.min.x, b.min.y, b.max.z);
		Debug.DrawLine(vector, vector2, Color.blue, delay);
		Debug.DrawLine(vector2, vector3, Color.red, delay);
		Debug.DrawLine(vector3, vector4, Color.yellow, delay);
		Debug.DrawLine(vector4, vector, Color.magenta, delay);
		Vector3 vector5 = new Vector3(b.min.x, b.max.y, b.min.z);
		Vector3 vector6 = new Vector3(b.max.x, b.max.y, b.min.z);
		Vector3 vector7 = new Vector3(b.max.x, b.max.y, b.max.z);
		Vector3 vector8 = new Vector3(b.min.x, b.max.y, b.max.z);
		Debug.DrawLine(vector5, vector6, Color.blue, delay);
		Debug.DrawLine(vector6, vector7, Color.red, delay);
		Debug.DrawLine(vector7, vector8, Color.yellow, delay);
		Debug.DrawLine(vector8, vector5, Color.magenta, delay);
		Debug.DrawLine(vector, vector5, Color.white, delay);
		Debug.DrawLine(vector2, vector6, Color.gray, delay);
		Debug.DrawLine(vector3, vector7, Color.green, delay);
		Debug.DrawLine(vector4, vector8, Color.cyan, delay);
	}

	// Token: 0x06000250 RID: 592 RVA: 0x0000A6E5 File Offset: 0x000088E5
	public void ProcessMetadata(RotationMetadata meta)
	{
		this.Direction = meta.Rotation;
	}

	// Token: 0x04000146 RID: 326
	public bool avoidFalling;

	// Token: 0x04000147 RID: 327
	public float speed;

	// Token: 0x04000148 RID: 328
	[SerializeField]
	protected float gravity = -10f;

	// Token: 0x04000149 RID: 329
	public CharacterController controller;

	// Token: 0x0400014B RID: 331
	public float rotationSpeed = 2.5f;

	// Token: 0x0400014C RID: 332
	public bool doRotation = true;

	// Token: 0x0400014D RID: 333
	public float externalForceMultiplier = 1f;

	// Token: 0x0400014E RID: 334
	public float fallMomentum;

	// Token: 0x0400014F RID: 335
	protected Vector3 _dir;

	// Token: 0x04000150 RID: 336
	protected Vector3 externalForce = Vector3.zero;

	// Token: 0x04000151 RID: 337
	protected bool shouldReverse;

	// Token: 0x04000152 RID: 338
	protected bool inEditor;

	// Token: 0x04000153 RID: 339
	public bool processSpeedMetadata = true;
}
