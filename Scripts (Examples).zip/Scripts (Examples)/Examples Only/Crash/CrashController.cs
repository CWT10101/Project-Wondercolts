﻿using System;
using System.Collections.Generic;
using System.Reflection;
using LevelEditor;
using Rewired;
using UnityEngine;

// Token: 0x0200008C RID: 140
[RequireComponent(typeof(CharacterController))]
public class CrashController : MonoBehaviour
{
	// Token: 0x170000A4 RID: 164
	// (get) Token: 0x060003E7 RID: 999 RVA: 0x000100A3 File Offset: 0x0000E2A3
	public static bool isTriple
	{
		get
		{
			return CrashController.instance.pickupHandler.invincibilityMask.activeSelf;
		}
	}

	// Token: 0x170000A5 RID: 165
	// (get) Token: 0x060003E8 RID: 1000 RVA: 0x000100B9 File Offset: 0x0000E2B9
	// (set) Token: 0x060003E9 RID: 1001 RVA: 0x000100C1 File Offset: 0x0000E2C1
	public Vector3 LastMoveDelta { get; private set; } = Vector3.zero;

	// Token: 0x170000A6 RID: 166
	// (get) Token: 0x060003EA RID: 1002 RVA: 0x000100CA File Offset: 0x0000E2CA
	// (set) Token: 0x060003EB RID: 1003 RVA: 0x000100D2 File Offset: 0x0000E2D2
	public float velocity { get; private set; }

	// Token: 0x170000A7 RID: 167
	// (get) Token: 0x060003EC RID: 1004 RVA: 0x000100DB File Offset: 0x0000E2DB
	public float SqrDeadzone
	{
		get
		{
			return this.deadzone * this.deadzone;
		}
	}

	// Token: 0x170000A8 RID: 168
	// (get) Token: 0x060003ED RID: 1005 RVA: 0x000100EC File Offset: 0x0000E2EC
	public float EffectiveSpeed
	{
		get
		{
			if (this.doubleJumped)
			{
				return this.speed * 0.5f;
			}
			if (this.slipSurface)
			{
				return this.slipSpeed;
			}
			if (this.animator.currentState == this.animator.slideObj)
			{
				return this.speed * 2f;
			}
			if (!(this.animator.currentState == this.animator.crawlObj))
			{
				return this.speed;
			}
			return this.speed * 0.25f;
		}
	}

	// Token: 0x170000A9 RID: 169
	// (get) Token: 0x060003EE RID: 1006 RVA: 0x00010177 File Offset: 0x0000E377
	private bool canSpin
	{
		get
		{
			return this.spinTimer == 0f;
		}
	}

	// Token: 0x170000AA RID: 170
	// (get) Token: 0x060003EF RID: 1007 RVA: 0x00010186 File Offset: 0x0000E386
	// (set) Token: 0x060003F0 RID: 1008 RVA: 0x0001018E File Offset: 0x0000E38E
	public bool IsGrounded
	{
		get
		{
			return this._isGrounded;
		}
		set
		{
			if (value != this._isGrounded)
			{
				this._isGrounded = value;
			}
		}
	}

	// Token: 0x170000AB RID: 171
	// (get) Token: 0x060003F1 RID: 1009 RVA: 0x000101A0 File Offset: 0x0000E3A0
	// (set) Token: 0x060003F2 RID: 1010 RVA: 0x000101A8 File Offset: 0x0000E3A8
	public bool WasGrounded { get; private set; } = true;

	// Token: 0x170000AC RID: 172
	// (get) Token: 0x060003F3 RID: 1011 RVA: 0x000101B1 File Offset: 0x0000E3B1
	private float TimeSinceGrounded
	{
		get
		{
			if (this.timeLastGrounded != -1f)
			{
				return Time.timeSinceLevelLoad - this.timeLastGrounded;
			}
			return float.PositiveInfinity;
		}
	}

	// Token: 0x170000AD RID: 173
	// (get) Token: 0x060003F4 RID: 1012 RVA: 0x000101D2 File Offset: 0x0000E3D2
	// (set) Token: 0x060003F5 RID: 1013 RVA: 0x000101DA File Offset: 0x0000E3DA
	public Surface.Material SurfaceType { get; private set; }

	// Token: 0x170000AE RID: 174
	// (get) Token: 0x060003F6 RID: 1014 RVA: 0x000101E3 File Offset: 0x0000E3E3
	public bool DoubleJumpEnabled
	{
		get
		{
			return this.pickupHandler.currentMask is Uka;
		}
	}

	// Token: 0x170000AF RID: 175
	// (get) Token: 0x060003F7 RID: 1015 RVA: 0x000101F8 File Offset: 0x0000E3F8
	public bool CanDoubleJump
	{
		get
		{
			return this.DoubleJumpEnabled && this.doubleJumpReady;
		}
	}

	// Token: 0x170000B0 RID: 176
	// (get) Token: 0x060003F8 RID: 1016 RVA: 0x0001020A File Offset: 0x0000E40A
	public static int HitMask
	{
		get
		{
			return CollisionMask.Get("Player");
		}
	}

	// Token: 0x060003F9 RID: 1017 RVA: 0x00010218 File Offset: 0x0000E418
	public void ResetInternalState()
	{
		this.animator.SetState(this.animator.idleObj, false);
		this.timeLastGrounded = -1f;
		this.IsGrounded = false;
		this.WasGrounded = false;
		this.doubleJumped = false;
		this.slamming = false;
		this.spinTimer = 0f;
		this.bounceChain = 0;
		this.slipSurface = false;
		this.wasSlipping = false;
		this.surfaceNormal = Vector3.zero;
		this.direction = Vector3.zero;
		this.velocity = 0f;
		this.platformMomentum = Vector3.zero;
	}

	// Token: 0x060003FA RID: 1018 RVA: 0x000102AF File Offset: 0x0000E4AF
	private float GetAxis(int id)
	{
		if (this.isInputLocked || this.isPaused)
		{
			return 0f;
		}
		return this.rwInput.GetAxisRaw(id);
	}

	// Token: 0x060003FB RID: 1019 RVA: 0x000102D4 File Offset: 0x0000E4D4
	private Vector2 GetAxis2D(int idX, int idY, float sqDeadzone = 0f)
	{
		Vector2 vector = new Vector2(this.GetAxis(idX), this.GetAxis(idY));
		if (sqDeadzone > 0f && vector.sqrMagnitude <= sqDeadzone)
		{
			return Vector2.zero;
		}
		return Vector2.ClampMagnitude(vector, 1f);
	}

	// Token: 0x060003FC RID: 1020 RVA: 0x00010319 File Offset: 0x0000E519
	private bool GetButton(int id)
	{
		return !this.locomotionOnly && !this.isInputLocked && !this.isPaused && this.rwInput.GetButton(id);
	}

	// Token: 0x060003FD RID: 1021 RVA: 0x00010343 File Offset: 0x0000E543
	private bool GetButton(int id, float graceTime)
	{
		return !this.locomotionOnly && !this.isInputLocked && !this.isPaused && this.rwInput.GetButtonTimeUnpressed(id) <= (double)graceTime;
	}

	// Token: 0x060003FE RID: 1022 RVA: 0x00010374 File Offset: 0x0000E574
	private bool GetButtonDown(int id)
	{
		return !this.locomotionOnly && !this.isInputLocked && !this.isPaused && this.rwInput.GetButtonDown(id);
	}

	// Token: 0x060003FF RID: 1023 RVA: 0x000103A0 File Offset: 0x0000E5A0
	private bool GetButtonDown(int id, float graceTime)
	{
		return !this.locomotionOnly && !this.isInputLocked && !this.isPaused && this.rwInput.GetButton(id) && this.rwInput.GetButtonTimePressed(id) <= (double)graceTime;
	}

	// Token: 0x06000400 RID: 1024 RVA: 0x000103EC File Offset: 0x0000E5EC
	private bool GetButtonUp(int id)
	{
		return !this.locomotionOnly && !this.isInputLocked && !this.isPaused && this.rwInput.GetButtonUp(id);
	}

	// Token: 0x06000401 RID: 1025 RVA: 0x00010416 File Offset: 0x0000E616
	private void OnDisable()
	{
		this.currentIFrames = 0f;
		Shader.DisableKeyword("CRASH_STATE_IFRAMES");
		Shader.DisableKeyword("CRASH_STATE_INVINCIBLE");
	}

	// Token: 0x06000402 RID: 1026 RVA: 0x00010438 File Offset: 0x0000E638
	private void Awake()
	{
		CrashController.instance = this;
		this.rwInput = ReInput.players.GetPlayer(0);
		CrashController.Horizontal = ReInput.mapping.GetActionId("Horizontal");
		CrashController.Vertical = ReInput.mapping.GetActionId("Vertical");
		CrashController.JumpInput = ReInput.mapping.GetActionId("Jump");
		CrashController.CrouchInput = ReInput.mapping.GetActionId("Crouch");
		CrashController.SpinInput = ReInput.mapping.GetActionId("Spin");
		CrashController.PauseInput = ReInput.mapping.GetActionId("Pause");
		CrashController.HUDInput = ReInput.mapping.GetActionId("ShowHUD");
		this.standingColliderHeight = this.controller.height;
	}

	// Token: 0x06000403 RID: 1027 RVA: 0x000104FC File Offset: 0x0000E6FC
	private void Start()
	{
		if ((Level.instance || WarpRoom.instance) && LevelSerializer.instance.akuHitCounter > 0)
		{
			CrashSpawner.instance.SpawnAkuAku(this, base.transform, false, LevelSerializer.instance.akuHitCounter);
		}
	}

	// Token: 0x06000404 RID: 1028 RVA: 0x0001054A File Offset: 0x0000E74A
	private void Update()
	{
		if (this.animator.currentState == this.animator.warpInObj)
		{
			return;
		}
		if (this.isDead)
		{
			return;
		}
		this.PollForPause();
	}

	// Token: 0x06000405 RID: 1029 RVA: 0x0001057C File Offset: 0x0000E77C
	private void FixedUpdate()
	{
		if (this.animator.currentState == this.animator.warpInObj)
		{
			return;
		}
		if (this.animator.currentState == this.animator.asleepObj)
		{
			return;
		}
		if (this.animator.currentState == this.animator.wakeUpObj)
		{
			return;
		}
		if (this.animator.currentState == this.animator.wearAkuObj)
		{
			return;
		}
		if (this.isDead)
		{
			return;
		}
		Physics.SyncTransforms();
		this._standingObstructedCached = null;
		if (this.currentIFrames > 0f)
		{
			this.currentIFrames -= Time.deltaTime;
			if (this.currentIFrames <= 0f)
			{
				this.currentIFrames = 0f;
				Shader.DisableKeyword("CRASH_STATE_IFRAMES");
			}
		}
		this.GroundCheck();
		this.ValidateSlipCondition();
		this.UpdateRotation();
		this.UpdateMovement();
		this.ApplyGravity();
		if (this.animator.currentState == this.animator.slideObj)
		{
			Physics.SyncTransforms();
			RaycastHit raycastHit;
			ISlide slide;
			if (Physics.Raycast(base.transform.position, Vector3.up, out raycastHit, 1.5f, CrashController.HitMask, QueryTriggerInteraction.Ignore) && raycastHit.collider.TryGetComponentInParent(out slide))
			{
				slide.Slide(this);
			}
		}
		if (this.isDead)
		{
			return;
		}
		if (!this.locomotionOnly)
		{
			this.Jump();
			this.Slam();
		}
		this.Spin();
		this.Animate();
		this.DisplayHUD();
		this.SetControllerHeight((this.animator.currentState == this.animator.crouchObj || this.animator.currentState == this.animator.slamStartObj || this.animator.currentState == this.animator.crawlObj || this.animator.currentState == this.animator.slideObj) ? this.crouchingColliderHeight : ((this.animator.currentState == this.animator.jumpObj || this.animator.currentState == this.animator.jumpFlipObj || this.animator.currentState == this.animator.jumpHighObj || this.animator.currentState == this.animator.jumpPeakObj || this.animator.currentState == this.animator.ukaJumpObj) ? this.jumpingColliderHeight : this.standingColliderHeight));
		this.WasGrounded = this.IsGrounded;
		this.wasSlipping = this.slipSurface;
		this.prevDirection = this.direction;
	}

	// Token: 0x06000406 RID: 1030 RVA: 0x00010858 File Offset: 0x0000EA58
	public void OnControllerColliderHit(ControllerColliderHit hit)
	{
		if (this.isDead)
		{
			return;
		}
		if (this.animator.currentState == this.animator.elevatorObj)
		{
			return;
		}
		if (!this.contactedColliders.Add(hit.collider))
		{
			return;
		}
		Vector3 normal = hit.normal;
		float num = Vector3.Angle(Vector3.up, normal);
		RaycastHit raycastHit;
		if ((num >= 91f || num <= 89f) && hit.collider.Raycast(new Ray(hit.point - hit.moveDirection * hit.moveLength, hit.moveDirection), out raycastHit, hit.moveLength + 0.1f))
		{
			normal = raycastHit.normal;
			num = Vector3.Angle(Vector3.up, normal);
		}
		CharacterController characterController;
		if (!this.IsGrounded && this.animator.currentState != this.animator.slideObj && hit.collider.TryGetComponentInParent(out characterController))
		{
			num = (float)((num < 90f) ? 0 : 180);
		}
		if (num < 90f && hit.collider.gameObject.layer != LayerMask.NameToLayer("InvisibleWall"))
		{
			this.surfaceNormal = normal;
			if (hit.collider.sharedMaterial && hit.collider.sharedMaterial.dynamicFriction == 0f)
			{
				float a = Vector3.Angle(this.surfaceNormal, Vector3.up);
				Vector3 axis = Vector3.Cross(Vector3.up, this.surfaceNormal);
				Quaternion rotation = Quaternion.AngleAxis(Mathf.Lerp(a, 90f, 0.5f), axis);
				this.surfaceNormal = rotation * Vector3.up;
			}
		}
		if (this.slamming)
		{
			ISlam slam;
			if (hit.collider.TryGetComponentInParent(out slam))
			{
				slam.Slam(this);
				return;
			}
		}
		else if (num < 70f)
		{
			ISpin spin;
			ITouchTop touchTop;
			if (this.animator.currentState == this.animator.spinObj && hit.collider.TryGetComponentInParent(out spin))
			{
				spin.Spin(this);
			}
			else if (this.animator.currentState != this.animator.slideObj && this.WasGrounded && this.IsGrounded && hit.collider.TryGetComponentInParent(out touchTop))
			{
				touchTop.TouchTop(this);
			}
			if (this.isDead)
			{
				return;
			}
			IPlatform platform;
			if (hit.collider.TryGetComponentInParent(out platform) && this.platform != platform)
			{
				IPlatform platform2 = this.platform;
				if (platform2 != null)
				{
					platform2.OnExit(base.transform);
				}
				this.platform = platform;
				this.platform.OnEnter(base.transform);
			}
			SlipCollider slipCollider;
			if (hit.collider.TryGetComponent<SlipCollider>(out slipCollider) && slipCollider.enabled)
			{
				if (!this.slipSurface)
				{
					this.slipSurface = true;
					Vector2 vector = new Vector2(this.prevDirection.x, this.prevDirection.z);
					vector *= this.speed / this.slipSpeed;
					this.direction = new Vector3(vector.x, this.velocity, vector.y);
				}
			}
			else if (!this.WasGrounded)
			{
				this.slipSurface = false;
			}
			if (!this.WasGrounded && this.velocity <= 0f)
			{
				this.surfacePoint = hit.point;
				ISpin spin2;
				IFallOn fallOn;
				if ((!(this.animator.currentState == this.animator.spinObj) || !hit.collider.TryGetComponentInParent(out spin2)) && hit.collider.TryGetComponentInParent(out fallOn))
				{
					fallOn.FallOn(this);
				}
			}
			if (!this.IsGrounded && hit.collider.gameObject.layer != LayerMask.NameToLayer("Entity") && this.velocity <= 0f)
			{
				this.IsGrounded = true;
				Surface surface;
				if (hit.gameObject.TryGetComponent<Surface>(out surface))
				{
					this.SurfaceType = surface.Type;
					return;
				}
				this.SurfaceType = Surface.Material.Generic;
				return;
			}
		}
		else if (num >= 91f)
		{
			ISpin spin3;
			if (this.animator.currentState == this.animator.spinObj && hit.collider.TryGetComponentInParent(out spin3))
			{
				spin3.Spin(this);
				return;
			}
			ISlide slide;
			if (this.animator.currentState == this.animator.slideObj && hit.collider.TryGetComponentInParent(out slide))
			{
				slide.Slide(this);
				return;
			}
			if (this.velocity > 0f || (hit.moveDirection.y > 0.01f && hit.moveLength != this.controller.stepOffset) || hit.gameObject.layer == LayerMask.NameToLayer("Entity"))
			{
				this.StopAscent();
				ISlam slam2;
				if (this.slamming && hit.collider.TryGetComponentInParent(out slam2))
				{
					slam2.Slam(this);
					return;
				}
				ITouchBottom touchBottom;
				if (hit.collider.TryGetComponentInParent(out touchBottom) && this.velocity >= 0f)
				{
					touchBottom.TouchBottom(this);
					return;
				}
			}
		}
		else
		{
			ISpin spin4;
			if (this.animator.currentState == this.animator.spinObj && hit.collider.TryGetComponentInParent(out spin4))
			{
				spin4.Spin(this);
				return;
			}
			ISlide slide2;
			if (this.animator.currentState == this.animator.slideObj && hit.collider.TryGetComponentInParent(out slide2))
			{
				slide2.Slide(this);
				return;
			}
			ITouchSide touchSide;
			if (hit.collider.TryGetComponentInParent(out touchSide))
			{
				touchSide.TouchSide(this);
			}
		}
	}

	// Token: 0x06000407 RID: 1031 RVA: 0x00010DE3 File Offset: 0x0000EFE3
	private void SetControllerHeight(float height)
	{
		this.controller.height = height;
		this.controller.center = Vector3.up * height / 2f;
	}

	// Token: 0x06000408 RID: 1032 RVA: 0x00010E14 File Offset: 0x0000F014
	public void Bounce()
	{
		this.animator.SetState(this.animator.landObj, false);
		this.doubleJumped = false;
		this.doubleJumpReady = true;
		this.slamming = false;
		this.cachedDirection = null;
		this.direction = new Vector3(this.input.x, this.velocity, this.input.y);
		AudioManager.Play("SFX_CrateBounce", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), new Vector2?(Vector2.one * (0.8f + Mathf.Min(0.5f, (float)this.bounceChain / 10f))));
		this.bounceChain++;
		this.velocity = (this.GetButton(CrashController.JumpInput) ? this.highJumpStrength : this.jumpStrength);
	}

	// Token: 0x06000409 RID: 1033 RVA: 0x00010EF8 File Offset: 0x0000F0F8
	public void BounceDown()
	{
		this.cachedDirection = null;
		this.direction = new Vector3(this.input.x, this.velocity, this.input.y);
		AudioManager.Play("SFX_CrateBounce", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), new Vector2?(Vector2.one * (0.8f + Mathf.Min(0.5f, (float)this.bounceChain / 10f))));
		this.bounceChain++;
		this.velocity = -this.jumpStrength / 4f;
	}

	// Token: 0x0600040A RID: 1034 RVA: 0x00010FA4 File Offset: 0x0000F1A4
	public void ArrowBounce(bool playSound = true)
	{
		if (this.IsStandingObstructed())
		{
			return;
		}
		this.doubleJumped = false;
		this.doubleJumpReady = true;
		this.slamming = false;
		if (playSound)
		{
			AudioManager.Play("SFX_CrateBounce", new Vector3?(base.transform.position), null);
		}
		this.velocity = (this.GetButton(CrashController.JumpInput) ? this.arrowHighBounceStrength : this.arrowBounceStrength);
		this.cachedDirection = null;
		this.direction = new Vector3(this.input.x, this.velocity, this.input.y);
		if (this.input.sqrMagnitude > this.SqrDeadzone)
		{
			this.animator.SetState(this.animator.jumpFlipObj, true);
			return;
		}
		this.animator.SetState(this.animator.jumpObj, false);
	}

	// Token: 0x0600040B RID: 1035 RVA: 0x0001108C File Offset: 0x0000F28C
	public void StopAscent()
	{
		if (this.velocity > 0f)
		{
			this.velocity = 0f;
		}
	}

	// Token: 0x0600040C RID: 1036 RVA: 0x000110A6 File Offset: 0x0000F2A6
	public void PseudoLand()
	{
		this.jumped = false;
		this.timeLastGrounded = Time.timeSinceLevelLoad;
		if (this.velocity < 0f)
		{
			this.velocity *= 0.5f;
		}
	}

	// Token: 0x0600040D RID: 1037 RVA: 0x000110D9 File Offset: 0x0000F2D9
	public void Deflect(Transform other)
	{
		if (this.animator.currentState == this.animator.slideObj)
		{
			this.desiredBearing *= -1f;
			return;
		}
		bool flag = this.slamming;
	}

	// Token: 0x0600040E RID: 1038 RVA: 0x00011118 File Offset: 0x0000F318
	private void Depenetrate()
	{
		Collider[] array = Physics.OverlapBox(this.controller.bounds.center, this.controller.bounds.extents, base.transform.rotation, 1, QueryTriggerInteraction.Ignore);
		if (array.Length != 0)
		{
			Debug.Log(string.Format("{0} overlaps", array.Length));
			this.controller.enabled = false;
			foreach (Collider collider in array)
			{
				Debug.Log("Possible overlap with " + collider.gameObject.name, collider.gameObject);
				Vector3 a;
				float d;
				if (Physics.ComputePenetration(this.controller, base.transform.position, base.transform.rotation, collider, collider.transform.position, collider.transform.rotation, out a, out d))
				{
					Debug.Log("Depenetrate from " + collider.gameObject.name, collider.gameObject);
					Random random = new Random(collider.GetInstanceID());
					Vector3 vector = new Vector3((float)(random.Next() / int.MaxValue), (float)(random.Next() / int.MaxValue), (float)(random.Next() / int.MaxValue));
					vector.Normalize();
					Debug.DrawRay(base.transform.position, a * d, new Color(vector.x, vector.y, vector.z), 3f, false);
					base.transform.Translate(a * d, Space.World);
				}
			}
			this.controller.enabled = true;
			Physics.SyncTransforms();
		}
	}

	// Token: 0x0600040F RID: 1039 RVA: 0x000112D0 File Offset: 0x0000F4D0
	private void GroundCheck()
	{
		bool isGrounded = false;
		RaycastHit raycastHit;
		if (this.velocity <= 0f && Physics.SphereCast(base.transform.position + 2f * this.controller.radius * Vector3.up, this.controller.radius, Vector3.down, out raycastHit, this.slamming ? (this.controller.radius + this.controller.skinWidth + 0.05f + Mathf.Max(0f, -this.velocity * Time.fixedDeltaTime)) : (this.controller.radius + this.controller.skinWidth + 0.05f), CrashController.HitMask, QueryTriggerInteraction.Ignore))
		{
			float num = Vector3.Angle(raycastHit.normal, Vector3.up);
			if (this.animator.currentState == this.animator.slideObj)
			{
				ISlide slide;
				ITouchTop touchTop;
				if (raycastHit.collider.TryGetComponentInParent(out slide))
				{
					slide.Slide(this);
				}
				else if (num < 70f && raycastHit.collider.TryGetComponentInParent(out touchTop))
				{
					touchTop.TouchTop(this);
				}
			}
			if (num < 90f && raycastHit.collider.gameObject.layer != LayerMask.NameToLayer("Entity"))
			{
				Surface surface;
				if (raycastHit.collider.TryGetComponentInParent(out surface))
				{
					this.SurfaceType = surface.Type;
				}
				else
				{
					this.SurfaceType = Surface.Material.Generic;
				}
				this.surfacePoint = raycastHit.point;
				ISpin spin;
				if (!this.slamming && !this.WasGrounded && (!(this.animator.currentState == this.animator.spinObj) || !raycastHit.collider.TryGetComponentInParent(out spin)))
				{
					IFallOn componentInParent = raycastHit.collider.GetComponentInParent<IFallOn>();
					if (componentInParent != null)
					{
						componentInParent.FallOn(this);
					}
				}
				if (this.velocity <= 0f)
				{
					isGrounded = true;
				}
				else
				{
					this.skipVelocity = true;
				}
				IPlatform componentInParent2 = raycastHit.collider.GetComponentInParent<IPlatform>();
				if (componentInParent2 != null)
				{
					if (this.platform != componentInParent2)
					{
						if (this.platform != null)
						{
							float num2 = -Vector3.Distance(base.transform.position, ((Component)this.platform).transform.position);
							if (-Vector3.Distance(base.transform.position, ((Component)componentInParent2).transform.position) > num2)
							{
								this.platform.OnExit(base.transform);
								this.platform = componentInParent2;
								this.platform.OnEnter(base.transform);
							}
						}
						else
						{
							this.platform = componentInParent2;
							this.platform.OnEnter(base.transform);
						}
					}
				}
				else if (this.platform != null)
				{
					this.platform.OnExit(base.transform);
					this.platform = null;
				}
			}
		}
		this.IsGrounded = isGrounded;
	}

	// Token: 0x06000410 RID: 1040 RVA: 0x000115B4 File Offset: 0x0000F7B4
	private void SnapToGround()
	{
		if (Vector3.Distance(base.transform.position, this.surfacePoint) <= this.controller.stepOffset + this.controller.skinWidth)
		{
			this.controller.enabled = false;
			base.transform.position = new Vector3(base.transform.position.x, this.surfacePoint.y + this.controller.skinWidth, base.transform.position.z);
			this.controller.enabled = true;
		}
	}

	// Token: 0x06000411 RID: 1041 RVA: 0x00011650 File Offset: 0x0000F850
	private void ValidateSlipCondition()
	{
		RaycastHit raycastHit;
		if (this.IsGrounded && this.WasGrounded && Physics.SphereCast(base.transform.position + Vector3.up * this.controller.radius, this.controller.radius, Vector3.down, out raycastHit, this.controller.radius, CrashController.HitMask, QueryTriggerInteraction.Ignore))
		{
			SlipCollider slipCollider;
			this.slipSurface = raycastHit.transform.TryGetComponent<SlipCollider>(out slipCollider);
		}
	}

	// Token: 0x06000412 RID: 1042 RVA: 0x000116D0 File Offset: 0x0000F8D0
	private void UpdateMovement()
	{
		float y = this.skipVelocity ? 0f : this.velocity;
		this.contactedColliders.Clear();
		if (this.animator.currentState == this.animator.slideObj)
		{
			this.direction = new Vector3(this.desiredBearing.x, y, this.desiredBearing.y);
		}
		else if (this.slipSurface)
		{
			this.input = this.GetAxis2D(CrashController.Horizontal, CrashController.Vertical, this.SqrDeadzone);
			Vector2 vector = this.direction.XZ();
			float num = (this.input.sqrMagnitude > this.SqrDeadzone) ? this.slipAcceleration : this.slipDeceleration;
			if (this.surfaceNormal == Vector3.zero)
			{
				vector = Vector2.MoveTowards(vector, this.input, Time.deltaTime * num);
			}
			else
			{
				float d = Mathf.InverseLerp(0f, 45f, Vector3.Angle(Vector3.up, this.surfaceNormal));
				Vector3 vector2 = Vector3.Cross(this.surfaceNormal, Vector3.Cross(this.surfaceNormal, Vector3.up));
				vector = Vector2.MoveTowards(vector, this.input, Time.deltaTime * num * Mathf.Lerp(0.5f, 1f, Vector2.Dot(this.input.normalized, vector2.XZ().normalized)));
				float d2 = (float)((this.animator.currentState == this.animator.slideObj) ? 4 : ((this.animator.currentState == this.animator.slamImpactObj) ? 2 : ((this.animator.currentState == this.animator.crouchObj) ? 2 : 1)));
				Vector3 v = vector2 * d * d2 * this.slopeSlipFactor * Time.deltaTime;
				vector += v.XZ();
			}
			this.direction = new Vector3(vector.x, y, vector.y);
			if (this.input.sqrMagnitude > 0f)
			{
				this.desiredBearing = this.input.normalized;
			}
		}
		else
		{
			this.input = this.GetAxis2D(CrashController.Horizontal, CrashController.Vertical, this.SqrDeadzone);
			if (this.IsGrounded)
			{
				this.direction = new Vector3(this.input.x, y, this.input.y);
				if (this.input.sqrMagnitude > 0f)
				{
					this.desiredBearing = this.input.normalized;
				}
			}
			else if (this.input.sqrMagnitude == 0f)
			{
				if (this.cachedDirection == null)
				{
					this.cachedDirection = new Vector2?(this.direction.XZ());
				}
				this.direction = new Vector3(0f, y, 0f);
			}
			else
			{
				if (this.cachedDirection != null)
				{
					if (this.cachedDirection.Value.sqrMagnitude > 0f)
					{
						float num2 = Mathf.Max(0f, Vector2.Dot(this.cachedDirection.Value.normalized, this.input.normalized));
						this.direction = new Vector3(this.cachedDirection.Value.x * num2, y, this.cachedDirection.Value.y * num2);
					}
					this.cachedDirection = null;
				}
				Vector2 vector3 = this.direction.XZ();
				vector3 = Vector2.MoveTowards(vector3, this.input, Time.deltaTime * this.airAcceleration);
				this.direction = new Vector3(vector3.x, y, vector3.y);
				if (vector3.sqrMagnitude > 0f)
				{
					this.desiredBearing = vector3.normalized;
				}
			}
		}
		Quaternion rotation = Quaternion.LookRotation(Vector3.Cross(Camera.main.transform.right, Vector3.up));
		Vector3 vector4 = Vector3.Scale(rotation * this.direction, new Vector3(this.EffectiveSpeed, 1f, this.EffectiveSpeed)) * Time.fixedDeltaTime;
		if (this.platformMomentum != Vector3.zero)
		{
			vector4 += this.platformMomentum;
		}
		if (this.IsGrounded && this.surfaceNormal != Vector3.zero)
		{
			float time = Vector3.Angle(this.surfaceNormal, Vector3.up);
			float num3 = this.slopeFallForce.Evaluate(time);
			if (num3 > 0f)
			{
				Vector3 vector5 = Vector3.Cross(this.surfaceNormal, Vector3.Cross(this.surfaceNormal, Vector3.up));
				vector4 += vector5 * (1f - Vector3.ProjectOnPlane(vector5, Vector3.up).magnitude) * num3 * -this.gravity * Time.fixedDeltaTime;
			}
		}
		if (this.slamming)
		{
			RaycastHit[] array = Physics.CapsuleCastAll(base.transform.TransformPoint(this.controller.center - Vector3.up * (this.controller.height / 2f - this.controller.radius)), base.transform.TransformPoint(this.controller.center + Vector3.up * (this.controller.height / 2f - this.controller.radius)), this.controller.radius, vector4, vector4.magnitude);
			if (array != null && array.Length != 0)
			{
				foreach (RaycastHit raycastHit in array)
				{
					ISlam slam;
					if (raycastHit.collider.TryGetComponentInParent(out slam) && ((Component)slam).transform.position.y < base.transform.position.y)
					{
						slam.Slam(this);
					}
				}
			}
			if (this.velocity > 0f && this.IsStandingObstructed())
			{
				this.velocity = 0f;
			}
		}
		Vector3 position = base.transform.position;
		if (this.platform != null)
		{
			Vector3 vector6;
			this.platform.GetDelta(base.transform, out vector6);
			if (this.IsGrounded || this.WasGrounded)
			{
				this.platformMomentum = Vector3.zero;
				if (vector6 != Vector3.zero)
				{
					RaycastHit raycastHit2;
					if (Physics.CapsuleCast(base.transform.TransformPoint(this.controller.center - Vector3.up * (this.controller.height / 2f - this.controller.radius)), base.transform.TransformPoint(this.controller.center + Vector3.up * (this.controller.height / 2f - this.controller.radius)), this.controller.radius, vector6, out raycastHit2, vector6.magnitude, this.movingPlatformCastMask, QueryTriggerInteraction.Ignore))
					{
						vector6 *= raycastHit2.distance / vector6.magnitude;
						ControllerColliderHit controllerColliderHit = new ControllerColliderHit();
						Type typeFromHandle = typeof(ControllerColliderHit);
						typeFromHandle.GetField("m_Controller", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controllerColliderHit, this.controller);
						typeFromHandle.GetField("m_Collider", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controllerColliderHit, raycastHit2.collider);
						typeFromHandle.GetField("m_Normal", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controllerColliderHit, raycastHit2.normal);
						typeFromHandle.GetField("m_Point", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controllerColliderHit, raycastHit2.point);
						typeFromHandle.GetField("m_MoveDirection", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controllerColliderHit, vector6.normalized);
						typeFromHandle.GetField("m_MoveLength", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controllerColliderHit, raycastHit2.distance);
						this.OnControllerColliderHit(controllerColliderHit);
					}
					this.controller.enabled = false;
					base.transform.Translate(vector6, Space.World);
					this.controller.enabled = true;
					Physics.SyncTransforms();
					this.GroundCheck();
				}
			}
			else
			{
				this.platformMomentum = vector6;
				this.platformMomentum.y = ((this.platformMomentum.y < 0f) ? 0f : this.platformMomentum.y);
				if (this.platform != null)
				{
					this.platform.OnExit(base.transform);
					this.platform = null;
				}
			}
		}
		if (this.inEditor)
		{
			vector4 = Vector3.Scale(vector4, new Vector3(1f, 1f, 0f));
		}
		Physics.SyncTransforms();
		if (this.controller.enabled)
		{
			this.controller.Move(vector4);
		}
		this.LastMoveDelta = base.transform.position - position;
		Debug.DrawRay(base.transform.position, vector4, Color.yellow);
		this.platformMomentum.Set(Mathf.MoveTowards(this.platformMomentum.x, 0f, Time.fixedDeltaTime * 0.125f), Mathf.MoveTowards(this.platformMomentum.y, 0f, Time.fixedDeltaTime * 0.5f), Mathf.MoveTowards(this.platformMomentum.z, 0f, Time.fixedDeltaTime * 0.125f));
		if (this.slipSurface && this.wasSlipping)
		{
			Vector3 vector7 = Quaternion.Inverse(rotation) * this.LastMoveDelta * (1f / this.EffectiveSpeed) / Time.fixedDeltaTime;
			vector7.Set((Mathf.Abs(vector7.x) > Mathf.Abs(this.direction.x)) ? this.direction.x : vector7.x, vector7.y, (Mathf.Abs(vector7.z) > Mathf.Abs(this.direction.z)) ? this.direction.z : vector7.z);
			this.direction.Set(vector7.x, this.direction.y, vector7.z);
		}
		if (this.IsGrounded)
		{
			this.timeLastGrounded = Time.timeSinceLevelLoad;
		}
		if (this.WasGrounded && this.IsGrounded)
		{
			this.jumped = false;
			this.doubleJumped = false;
			this.doubleJumpReady = true;
			this.cachedDirection = null;
			this.platformMomentum = Vector3.zero;
			this.bounceChain = 0;
		}
		else if (this.TimeSinceGrounded >= this.coyoteTime)
		{
			this.surfaceNormal = Vector3.zero;
		}
		this.skipVelocity = false;
	}

	// Token: 0x06000413 RID: 1043 RVA: 0x000121D8 File Offset: 0x000103D8
	private void UpdateRotation()
	{
		if (this.desiredBearing == Vector2.zero)
		{
			return;
		}
		float target;
		if (this.cameraRelativeInput)
		{
			target = Mathf.Atan2(this.desiredBearing.x, this.desiredBearing.y) * 57.29578f + Camera.main.transform.eulerAngles.y;
		}
		else
		{
			target = Mathf.Atan2(this.desiredBearing.x, this.desiredBearing.y) * 57.29578f;
		}
		float y = Mathf.SmoothDampAngle(base.transform.eulerAngles.y, target, ref this.rotationVelocity, this.smoothTime);
		base.transform.rotation = Quaternion.Euler(0f, y, 0f);
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x0001229C File Offset: 0x0001049C
	private void ApplyGravity()
	{
		if (this.animator.currentState == this.animator.slideObj && this.TimeSinceGrounded < 0.1f)
		{
			return;
		}
		if (this.IsGrounded && this.velocity < 0f)
		{
			this.velocity = -this.controller.skinWidth * 2f / Time.fixedDeltaTime;
		}
		else if (!this.IsGrounded && this.WasGrounded && this.velocity < 0f)
		{
			this.velocity = this.LastMoveDelta.y / Time.fixedUnscaledDeltaTime;
		}
		else if (this.slamming && this.velocity < 0f)
		{
			this.velocity += this.gravity * this.gravityMultiplier * 2f * Time.fixedDeltaTime;
		}
		else if (this.animator.currentState == this.animator.slideObj)
		{
			this.velocity += this.gravity * this.gravityMultiplier * 0.25f * Time.fixedDeltaTime;
		}
		else
		{
			this.velocity += this.gravity * this.gravityMultiplier * Time.fixedDeltaTime;
		}
		this.velocity = Mathf.Max(this.velocity, -1f / Time.fixedDeltaTime);
		this.direction.y = this.velocity;
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x00012414 File Offset: 0x00010614
	private void Jump()
	{
		if (this.GetButtonDown(CrashController.JumpInput) && !this.IsStandingObstructed())
		{
			if (this.CanDoubleJump && this.TimeSinceGrounded >= this.coyoteTime && this.animator.currentState != this.animator.slideObj)
			{
				this.velocity = this.ukaJumpStrength;
				(this.pickupHandler.currentMask as Uka).Zap();
				this.doubleJumped = true;
				this.doubleJumpReady = false;
				return;
			}
			if (!this.jumped && (this.TimeSinceGrounded < this.coyoteTime || this.animator.currentState == this.animator.slideObj))
			{
				AudioManager.Play("SFX_CrashJump", new Vector3?(base.transform.position), null);
				this.jumped = true;
				this.velocity = ((this.animator.currentState == this.animator.slideObj) ? this.highJumpStrength : (this.GetButton(CrashController.CrouchInput, 0.1f) ? this.highJumpStrength : this.jumpStrength));
			}
		}
	}

	// Token: 0x06000416 RID: 1046 RVA: 0x0001254C File Offset: 0x0001074C
	private void Spin()
	{
		if (this.slamming)
		{
			return;
		}
		if (this.spinTimer > 0f)
		{
			this.spinTimer -= Time.deltaTime;
			if (this.spinTimer <= 0f)
			{
				this.spinTimer = 0f;
				return;
			}
		}
		else if (!this.locomotionOnly && this.GetButtonDown(CrashController.SpinInput) && this.canSpin && !this.IsStandingObstructed())
		{
			AudioManager.Play(CrashAudio.Spin, new Vector3?(base.transform.position), null);
			this.spinTimer = this.spinDuration;
		}
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x000125F0 File Offset: 0x000107F0
	private void Slam()
	{
		if (!this.slamming && !this.IsGrounded && this.LastMoveDelta.y > 0f && this.spinTimer == 0f && this.GetButtonDown(CrashController.CrouchInput))
		{
			AudioManager.Play("SFX_CrashJump", new Vector3?(base.transform.position), null);
			this.slamming = true;
			this.slipSurface = false;
			this.velocity = this.jumpStrength / 2f;
		}
	}

	// Token: 0x06000418 RID: 1048 RVA: 0x00012680 File Offset: 0x00010880
	public void Die(int index = 0)
	{
		if (this.animator.currentState == this.animator.warpOutObj)
		{
			return;
		}
		Debug.Log("Crash died");
		if (!this.isDead)
		{
			Shader.DisableKeyword("CRASH_STATE_IFRAMES");
			Shader.DisableKeyword("CRASH_STATE_INVINCIBLE");
			this.currentIFrames = 0f;
			if (Time.timeScale > 0f)
			{
				ResourceManager.InstantiateDeathEffect(base.transform, index);
			}
			if (this.inBonus)
			{
				BonusManager.instance.BonusDeath(1f);
				if (CrashSpawner.instance)
				{
					CrashSpawner.instance.RespawnCrash(this, 2f, BonusManager.instance.bonusRespawnPoint);
				}
				this.inBonus = false;
			}
			else if (this.inEditor)
			{
				if (LevelInterfaceManager.instance)
				{
					LevelInterfaceManager.instance.ResetTimeTrial();
				}
				if (!string.IsNullOrEmpty(LevelSerializer.instance.loadOnPlayString))
				{
					if (LevelInterfaceManager.instance.currentLevelType != 0 && LevelInterfaceManager.instance.currentLevelType != 2)
					{
						this.pickupHandler.LoseLife();
					}
					else if (CrashSpawner.instance)
					{
						CrashSpawner.instance.RespawnCrash(this, (float)((Time.timeScale > 0f) ? 2 : 0), null);
					}
				}
				else if (CrashSpawner.instance)
				{
					CrashSpawner.instance.RespawnCrash(this, 1f, null);
				}
				DeathRoutePlatform.CrashDied();
			}
			else
			{
				this.pickupHandler.LoseLife();
				if (Level.instance)
				{
					if (CrashSpawner.instance.crashSpawnPoint.position != CrashSpawner.instance.startingPosition)
					{
						Level.instance.tape.SetTangible(false);
					}
					NoDeathGem noDeathGem = Level.instance.specialGem as NoDeathGem;
					if (noDeathGem != null)
					{
						noDeathGem.gameObject.SetActive(false);
					}
				}
			}
			this.rotationVelocity = 0f;
			this.velocity = 0f;
			this.slipSurface = false;
			this.slamming = false;
			this.doubleJumped = false;
			this.WasGrounded = false;
			this.platform = null;
			this.isDead = true;
			this.isInputLocked = true;
			this.controller.enabled = false;
			if (Time.timeScale > 0f)
			{
				AudioManager.Play(CrashAudio.Death, new Vector3?(base.transform.position), null);
				this.animator.SetState(this.animator.deadState, false);
			}
			if (this.pickupHandler.currentMask != null)
			{
				this.pickupHandler.LoseMask(true);
			}
		}
	}

	// Token: 0x06000419 RID: 1049 RVA: 0x00012908 File Offset: 0x00010B08
	public bool TakeDamage(int crashDeathEffectIndex = 0)
	{
		if (this.animator.currentState == this.animator.warpOutObj || this.animator.currentState == this.animator.warpInObj)
		{
			return false;
		}
		Aku aku = this.pickupHandler.currentMask as Aku;
		if (aku != null)
		{
			if (aku.invincibileMode)
			{
				return false;
			}
			if (this.currentIFrames > 0f)
			{
				return false;
			}
			Shader.EnableKeyword("CRASH_STATE_IFRAMES");
			this.currentIFrames = this.invincibilityFramesLength;
			return this.pickupHandler.HurtMask();
		}
		else
		{
			if (this.currentIFrames > 0f)
			{
				return false;
			}
			this.Die(crashDeathEffectIndex);
			return true;
		}
	}

	// Token: 0x0600041A RID: 1050 RVA: 0x000129B7 File Offset: 0x00010BB7
	private void DisplayHUD()
	{
		if (this.GetButtonDown(CrashController.HUDInput))
		{
			InterfaceManager.instance.hudTrack.DisplayHUD();
		}
	}

	// Token: 0x0600041B RID: 1051 RVA: 0x000129D8 File Offset: 0x00010BD8
	public bool IsStandingObstructed()
	{
		if (this._standingObstructedCached != null)
		{
			return this._standingObstructedCached.Value;
		}
		Collider[] array = Physics.OverlapCapsule(base.transform.TransformPoint(Vector3.up * (this.standingColliderHeight / 2f)), base.transform.TransformPoint(Vector3.up * (this.standingColliderHeight - this.controller.radius)), this.controller.radius, 1, QueryTriggerInteraction.Ignore);
		for (int i = 0; i < array.Length; i++)
		{
			if (!array[i].CompareTag("Player"))
			{
				this._standingObstructedCached = new bool?(true);
				return this._standingObstructedCached.Value;
			}
		}
		this._standingObstructedCached = new bool?(false);
		return this._standingObstructedCached.Value;
	}

	// Token: 0x0600041C RID: 1052 RVA: 0x00012AA5 File Offset: 0x00010CA5
	public void Mount(Transform newParent)
	{
		base.gameObject.SetActive(false);
		base.transform.SetParent(newParent);
	}

	// Token: 0x0600041D RID: 1053 RVA: 0x00012ABF File Offset: 0x00010CBF
	public void Dismount()
	{
		base.transform.SetParent(base.transform.parent.parent);
		base.gameObject.SetActive(true);
	}

	// Token: 0x0600041E RID: 1054 RVA: 0x00012AE8 File Offset: 0x00010CE8
	private void PollForPause()
	{
		if (this.rwInput.GetButtonDown(CrashController.PauseInput))
		{
			this.TogglePause();
		}
	}

	// Token: 0x0600041F RID: 1055 RVA: 0x00012B02 File Offset: 0x00010D02
	public void TogglePause()
	{
		this.isPaused = !this.isPaused;
		InterfaceManager.Pause(this.isPaused);
		Time.timeScale = (this.isPaused ? 0f : Clock.TimeScale);
	}

	// Token: 0x06000420 RID: 1056 RVA: 0x00012B37 File Offset: 0x00010D37
	public void Pause(bool pause)
	{
		this.isPaused = true;
		InterfaceManager.Pause(true);
		Time.timeScale = (this.isPaused ? 0f : Clock.TimeScale);
	}

	// Token: 0x06000421 RID: 1057 RVA: 0x00012B5F File Offset: 0x00010D5F
	public void Resume()
	{
		this.isPaused = false;
		InterfaceManager.Pause(false);
		Time.timeScale = Clock.TimeScale;
	}

	// Token: 0x06000422 RID: 1058 RVA: 0x00012B78 File Offset: 0x00010D78
	private void Animate()
	{
		if (this.animator.currentState == this.animator.elevatorObj)
		{
			return;
		}
		if (this.spinTimer > 0f)
		{
			this.animator.SetState(this.animator.spinObj, false);
			return;
		}
		if (this.slamming)
		{
			if (!this.IsGrounded)
			{
				this.animator.SetState(this.animator.slamStartObj, false);
				return;
			}
			if (this.IsGrounded && this.WasGrounded)
			{
				AudioManager.Play("SFX_CrashLand", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
				this.animator.SetState(this.animator.slamImpactObj, false);
				this.slamming = false;
				return;
			}
		}
		else
		{
			if (!this.WasGrounded && this.IsGrounded && this.animator.currentState != this.animator.slideObj && (this.animator.previousState != this.animator.slideObj || this.animator.currentState == this.animator.jumpHighObj))
			{
				AudioManager.Play("SFX_CrashLand", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
				this.animator.SetState(this.animator.landObj, false);
				return;
			}
			if (this.doubleJumped)
			{
				if (this.animator.currentState != this.animator.ukaJumpObj)
				{
					this.animator.SetState(this.animator.ukaJumpObj, false);
					return;
				}
			}
			else if (!this.IsGrounded && this.velocity > 0f && this.animator.currentState == this.animator.jumpObj)
			{
				if (this.input.sqrMagnitude > this.SqrDeadzone)
				{
					this.animator.SetState(this.animator.jumpFlipObj, false);
					return;
				}
			}
			else if (!this.IsGrounded && this.velocity > 0f && !(this.animator.currentState == this.animator.jumpHighObj) && !(this.animator.currentState == this.animator.jumpFlipObj) && !(this.animator.currentState == this.animator.jumpObj))
			{
				if (this.GetButton(CrashController.CrouchInput, 0.2f))
				{
					this.animator.SetState(this.animator.jumpHighObj, false);
					return;
				}
				if (this.animator.currentState != this.animator.jumpHighObj)
				{
					if (this.input.sqrMagnitude > this.SqrDeadzone)
					{
						this.animator.SetState(this.animator.jumpFlipObj, false);
						return;
					}
					this.animator.SetState(this.animator.jumpObj, false);
					return;
				}
			}
			else
			{
				if (!this.IsGrounded && this.velocity < 0f && (this.animator.currentState == this.animator.jumpObj || this.animator.currentState == this.animator.idleObj || this.animator.currentState == this.animator.walkObj || this.animator.currentState == this.animator.RunObj || this.animator.currentState == this.animator.crawlObj || this.animator.currentState == this.animator.slamImpactObj || this.animator.previousState == this.animator.slideObj) && this.animator.currentState != this.animator.jumpHighObj)
				{
					this.animator.SetState(this.animator.jumpPeakObj, false);
					return;
				}
				if (this.IsGrounded)
				{
					if (this.input.sqrMagnitude > this.SqrDeadzone && ((this.animator.currentState == this.animator.landObj && this.animator.TimeSinceStateChanged <= 0.1f && this.GetButtonDown(CrashController.CrouchInput, 0.1f)) || this.GetButtonDown(CrashController.CrouchInput)))
					{
						this.SnapToGround();
						this.velocity = 0f;
						this.animator.SetState(this.animator.slideObj, false);
						if (this.animator.TimeSinceStateChanged == 0f)
						{
							AudioManager.Play("SFX_CrashSlide", new Vector3?(base.transform.position), null);
							return;
						}
					}
					else if (this.GetButton(CrashController.CrouchInput) || this.IsStandingObstructed())
					{
						if (this.input.sqrMagnitude <= this.SqrDeadzone || this.animator.previousState == this.animator.slideObj)
						{
							if (this.animator.currentState != this.animator.crouchObj)
							{
								this.animator.SetState(this.animator.crouchObj, false);
								return;
							}
						}
						else if (this.animator.currentState != this.animator.slideObj)
						{
							this.animator.SetState(this.animator.crawlObj, false);
							return;
						}
					}
					else
					{
						if (!this.GetButton(CrashController.CrouchInput) && (this.animator.currentState == this.animator.crouchObj || this.animator.currentState == this.animator.crawlObj) && !this.IsStandingObstructed())
						{
							this.animator.SetState(this.animator.idleObj, false);
							return;
						}
						if (this.input.sqrMagnitude > this.SqrDeadzone)
						{
							if (this.slipSurface)
							{
								if (this.animator.currentState == this.animator.idleObj || this.animator.currentState == this.animator.landObj || this.animator.currentState == this.animator.slipObj)
								{
									this.animator.SetState(this.animator.slipWalkObj, false);
									return;
								}
							}
							else if (this.animator.currentState == this.animator.idleObj || this.animator.currentState == this.animator.landObj || this.animator.currentState == this.animator.slipWalkObj)
							{
								if (this.input.magnitude > 0.5f)
								{
									this.animator.SetState(this.animator.RunObj, false);
									return;
								}
								this.animator.SetState(this.animator.walkObj, false);
								return;
							}
						}
						else
						{
							if (this.slipSurface && this.direction.XZ().sqrMagnitude > this.SqrDeadzone && (this.animator.currentState == this.animator.slipWalkObj || this.animator.currentState == this.animator.idleObj || this.animator.currentState == this.animator.slipObj))
							{
								this.animator.SetState(this.animator.slipObj, false);
								return;
							}
							if (this.animator.currentState == this.animator.slipObj)
							{
								this.animator.SetState(this.animator.idleObj, false);
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x040002A9 RID: 681
	public static CrashController instance;

	// Token: 0x040002AA RID: 682
	public bool cameraRelativeInput;

	// Token: 0x040002AB RID: 683
	public Player rwInput;

	// Token: 0x040002AC RID: 684
	public CrashAnimator animator;

	// Token: 0x040002AD RID: 685
	public CrashAudio audio;

	// Token: 0x040002AE RID: 686
	public CharacterController controller;

	// Token: 0x040002AF RID: 687
	public PickupHandler pickupHandler;

	// Token: 0x040002B0 RID: 688
	public LayerMask movingPlatformCastMask;

	// Token: 0x040002B1 RID: 689
	public float speed = 1f;

	// Token: 0x040002B2 RID: 690
	public float airAcceleration = 3f;

	// Token: 0x040002B3 RID: 691
	public float slipSpeed = 2f;

	// Token: 0x040002B4 RID: 692
	public float slipAcceleration = 0.5f;

	// Token: 0x040002B5 RID: 693
	public float slipDeceleration = 0.1f;

	// Token: 0x040002B6 RID: 694
	public float slopeSlipFactor = 2f;

	// Token: 0x040002B7 RID: 695
	public float jumpStrength = 15f;

	// Token: 0x040002B8 RID: 696
	public float highJumpStrength = 20f;

	// Token: 0x040002B9 RID: 697
	public float ukaJumpStrength = 20f;

	// Token: 0x040002BA RID: 698
	public float arrowBounceStrength = 22.5f;

	// Token: 0x040002BB RID: 699
	public float arrowHighBounceStrength = 25f;

	// Token: 0x040002BC RID: 700
	public float coyoteTime = 0.1f;

	// Token: 0x040002BD RID: 701
	public bool isInputLocked;

	// Token: 0x040002BE RID: 702
	public bool isDead;

	// Token: 0x040002BF RID: 703
	public bool inBonus;

	// Token: 0x040002C0 RID: 704
	public bool inEditor;

	// Token: 0x040002C1 RID: 705
	public bool isPaused;

	// Token: 0x040002C2 RID: 706
	public bool locomotionOnly;

	// Token: 0x040002C3 RID: 707
	public Transform camTarget;

	// Token: 0x040002C4 RID: 708
	public float invincibilityFramesLength = 2f;

	// Token: 0x040002C5 RID: 709
	private float currentIFrames;

	// Token: 0x040002C7 RID: 711
	[SerializeField]
	private float smoothTime = 0.05f;

	// Token: 0x040002C8 RID: 712
	[SerializeField]
	private float gravity = -10f;

	// Token: 0x040002C9 RID: 713
	[SerializeField]
	private float gravityMultiplier = 3f;

	// Token: 0x040002CA RID: 714
	[SerializeField]
	private AnimationCurve slopeFallForce;

	// Token: 0x040002CB RID: 715
	private float rotationVelocity;

	// Token: 0x040002CD RID: 717
	public Vector2 input;

	// Token: 0x040002CE RID: 718
	private Vector3 direction;

	// Token: 0x040002CF RID: 719
	private Vector3 prevDirection;

	// Token: 0x040002D0 RID: 720
	private Vector2? cachedDirection;

	// Token: 0x040002D1 RID: 721
	private Vector2 desiredBearing = Vector2.zero;

	// Token: 0x040002D2 RID: 722
	private float deadzone = 0.1f;

	// Token: 0x040002D3 RID: 723
	private bool skipVelocity;

	// Token: 0x040002D4 RID: 724
	public bool slipSurface;

	// Token: 0x040002D5 RID: 725
	private bool wasSlipping;

	// Token: 0x040002D6 RID: 726
	private Vector3 surfaceNormal = Vector3.zero;

	// Token: 0x040002D7 RID: 727
	private Vector3 surfacePoint;

	// Token: 0x040002D8 RID: 728
	public float spinDuration = 0.45f;

	// Token: 0x040002D9 RID: 729
	private float spinTimer;

	// Token: 0x040002DA RID: 730
	private bool jumped;

	// Token: 0x040002DB RID: 731
	private bool doubleJumped;

	// Token: 0x040002DC RID: 732
	private bool slamming;

	// Token: 0x040002DD RID: 733
	private bool _isGrounded;

	// Token: 0x040002DF RID: 735
	private float timeLastGrounded = -1f;

	// Token: 0x040002E1 RID: 737
	private bool doubleJumpReady;

	// Token: 0x040002E2 RID: 738
	[ReadOnly]
	public int bounceChain;

	// Token: 0x040002E3 RID: 739
	private float standingColliderHeight;

	// Token: 0x040002E4 RID: 740
	[SerializeField]
	private float crouchingColliderHeight;

	// Token: 0x040002E5 RID: 741
	[SerializeField]
	private float jumpingColliderHeight;

	// Token: 0x040002E6 RID: 742
	private IPlatform platform;

	// Token: 0x040002E7 RID: 743
	private Vector3 platformMomentum = Vector3.zero;

	// Token: 0x040002E8 RID: 744
	public static int Horizontal;

	// Token: 0x040002E9 RID: 745
	public static int Vertical;

	// Token: 0x040002EA RID: 746
	public static int JumpInput;

	// Token: 0x040002EB RID: 747
	public static int CrouchInput;

	// Token: 0x040002EC RID: 748
	public static int SpinInput;

	// Token: 0x040002ED RID: 749
	public static int PauseInput;

	// Token: 0x040002EE RID: 750
	public static int HUDInput;

	// Token: 0x040002EF RID: 751
	private readonly HashSet<Collider> contactedColliders = new HashSet<Collider>();

	// Token: 0x040002F0 RID: 752
	private bool? _standingObstructedCached;
}
