﻿using System;
using Cinemachine;
using UnityEngine;

// Token: 0x020000B0 RID: 176
public class ExampleCameraFollowTarget : MonoBehaviour
{
	// Token: 0x0600057E RID: 1406 RVA: 0x0001865B File Offset: 0x0001685B
	private void Start()
	{
		this._dampVelocity = Vector3.zero;
		this._targetHeight = this.PlayerTransform.position.y;
		this._currentTrackYRotation = 0f;
	}

	// Token: 0x0600057F RID: 1407 RVA: 0x00018689 File Offset: 0x00016889
	private void LateUpdate()
	{
		if (!this.CameraTrack)
		{
			return;
		}
		this.GetCameraParameters();
		this.MoveCameraTarget();
		this.RotateCameraTarget();
	}

	// Token: 0x06000580 RID: 1408 RVA: 0x000186AB File Offset: 0x000168AB
	public void SetCameraTrack(CinemachinePathBase newTrack)
	{
		this.CameraTrack = newTrack;
		base.transform.rotation = Camera.main.transform.rotation;
	}

	// Token: 0x06000581 RID: 1409 RVA: 0x000186D0 File Offset: 0x000168D0
	private void GetCameraParameters()
	{
		this._playerPosition = this.PlayerTransform.position;
		this._closestTrackPoint = this.CameraTrack.FindClosestPoint(this._playerPosition, 0, -1, 10);
		this._currentPathPoint = this.CameraTrack.EvaluatePositionAtUnit(this._closestTrackPoint, CinemachinePathBase.PositionUnits.PathUnits);
		this._targetHeight = this._currentPathPoint.y;
		this._currentPathRotation = this.CameraTrack.EvaluateOrientationAtUnit(this._closestTrackPoint, CinemachinePathBase.PositionUnits.PathUnits);
		this._currentTrackYRotation = this._currentPathRotation.eulerAngles.y;
		this._tilt = -(this._playerPosition.y - this._currentPathPoint.y) * this.TiltMultiplier;
		this._pan = (this._playerPosition.x - this._currentPathPoint.x) * this.PanMultiplier;
	}

	// Token: 0x06000582 RID: 1410 RVA: 0x000187AC File Offset: 0x000169AC
	private void MoveCameraTarget()
	{
		this._targetPosition.Set(this._currentPathPoint.x, this._targetHeight, this._currentPathPoint.z);
		base.transform.position = Vector3.SmoothDamp(base.transform.position, this._targetPosition, ref this._dampVelocity, this.DampDuration);
	}

	// Token: 0x06000583 RID: 1411 RVA: 0x0001880D File Offset: 0x00016A0D
	private void RotateCameraTarget()
	{
		base.transform.rotation = Quaternion.RotateTowards(base.transform.rotation, Quaternion.AngleAxis(this._currentTrackYRotation, Vector3.up), this.RotationSpeed * Time.deltaTime);
	}

	// Token: 0x06000584 RID: 1412 RVA: 0x00018846 File Offset: 0x00016A46
	public float GetTilt()
	{
		return this._tilt;
	}

	// Token: 0x06000585 RID: 1413 RVA: 0x0001884E File Offset: 0x00016A4E
	public float GetPan()
	{
		return this._pan;
	}

	// Token: 0x040003D8 RID: 984
	public Transform PlayerTransform;

	// Token: 0x040003D9 RID: 985
	public CinemachinePathBase CameraTrack;

	// Token: 0x040003DA RID: 986
	private Vector3 _playerPosition;

	// Token: 0x040003DB RID: 987
	private float _targetHeight;

	// Token: 0x040003DC RID: 988
	private Vector3 _targetPosition;

	// Token: 0x040003DD RID: 989
	private float _closestTrackPoint;

	// Token: 0x040003DE RID: 990
	private Vector3 _currentPathPoint;

	// Token: 0x040003DF RID: 991
	private Quaternion _currentPathRotation;

	// Token: 0x040003E0 RID: 992
	private float _currentTrackYRotation;

	// Token: 0x040003E1 RID: 993
	private float _tilt;

	// Token: 0x040003E2 RID: 994
	private float _pan;

	// Token: 0x040003E3 RID: 995
	private Vector3 _dampVelocity;

	// Token: 0x040003E4 RID: 996
	public float DampDuration = 0.15f;

	// Token: 0x040003E5 RID: 997
	public float RotationSpeed = 30f;

	// Token: 0x040003E6 RID: 998
	public float PanMultiplier = 1.2f;

	// Token: 0x040003E7 RID: 999
	public float TiltMultiplier = 0.65f;
}
