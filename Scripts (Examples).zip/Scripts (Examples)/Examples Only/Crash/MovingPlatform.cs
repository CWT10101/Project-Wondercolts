﻿using System;
using UnityEngine;

// Token: 0x020000E7 RID: 231
[DefaultExecutionOrder(-10)]
public class MovingPlatform : Entity, IPlatform, IMetadataReceiver<EndpointMetadata>, IMetadataReceiver<SpeedMetadata>
{
	// Token: 0x0600070C RID: 1804 RVA: 0x0001E004 File Offset: 0x0001C204
	private void OnEnable()
	{
		this.unconfigured = (!this.pointA || !this.pointB);
		if (this.unconfigured)
		{
			this.unconf_startPos = base.transform.position;
			this.unconf_movingRight = true;
			this.unconf_delayedTick = 0;
		}
	}

	// Token: 0x0600070D RID: 1805 RVA: 0x0001E05C File Offset: 0x0001C25C
	private void OnDisable()
	{
		if (this.unconfigured)
		{
			base.transform.position = this.unconf_startPos;
			return;
		}
		base.transform.position = this.pointA.position;
	}

	// Token: 0x0600070E RID: 1806 RVA: 0x0001E090 File Offset: 0x0001C290
	public virtual void FixedUpdate()
	{
		if (this.unconfigured)
		{
			RaycastHit raycastHit2;
			if (this.unconf_delayedTick > 0)
			{
				this.unconf_moveDelta = 0f;
				RaycastHit raycastHit;
				if (Physics.BoxCast(base.transform.position, new Vector3(1f - Time.fixedDeltaTime * this.worldspaceSpeed, 0.4f, 0.4f), (!this.unconf_movingRight) ? Vector3.right : Vector3.left, out raycastHit, Quaternion.identity, Time.fixedDeltaTime * this.worldspaceSpeed * 2f))
				{
					MovingPlatform componentInParent = raycastHit.collider.GetComponentInParent<MovingPlatform>();
					if (componentInParent != null && componentInParent.unconf_delayedTick == 0 && componentInParent.unconf_movingRight != this.unconf_movingRight)
					{
						this.unconf_delayedTick = 0;
						this.unconf_movingRight = !this.unconf_movingRight;
					}
				}
				else
				{
					this.unconf_delayedTick -= 1;
					if (this.unconf_delayedTick == 0)
					{
						this.unconf_movingRight = !this.unconf_movingRight;
					}
				}
			}
			else if (Physics.BoxCast(base.transform.position, new Vector3(1f - Time.fixedDeltaTime * this.worldspaceSpeed, 0.4f, 0.4f), this.unconf_movingRight ? Vector3.right : Vector3.left, out raycastHit2, Quaternion.identity, Time.fixedDeltaTime * this.worldspaceSpeed * 2f))
			{
				MovingPlatform componentInParent2 = raycastHit2.collider.GetComponentInParent<MovingPlatform>();
				if (componentInParent2 == null || componentInParent2.unconf_delayedTick != 0 || componentInParent2.unconf_movingRight != this.unconf_movingRight)
				{
					this.unconf_moveDelta = (raycastHit2.distance - Time.fixedDeltaTime * this.worldspaceSpeed) * (float)(this.unconf_movingRight ? 1 : -1);
					this.unconf_delayedTick = 2;
				}
			}
			else
			{
				this.unconf_moveDelta = (this.unconf_movingRight ? (Time.fixedDeltaTime * this.worldspaceSpeed) : (-Time.fixedDeltaTime * this.worldspaceSpeed));
			}
		}
		this._delta = this.GetNextPosition() - base.transform.position;
		base.transform.position = this.GetNextPosition();
	}

	// Token: 0x0600070F RID: 1807 RVA: 0x0001E2A4 File Offset: 0x0001C4A4
	public virtual Vector3 GetNextPosition()
	{
		if (this.unconfigured)
		{
			return base.transform.position + new Vector3(this.unconf_moveDelta, 0f, 0f);
		}
		if (!this.useWorldspaceSpeed)
		{
			return Vector3.Lerp(this.pointA.position, this.pointB.position, this.speedCurve.Evaluate(Clock.SynchronizedTime + this.offset));
		}
		return Vector3.Lerp(this.pointA.position, this.pointB.position, this.speedCurve.Evaluate(Clock.SynchronizedTime / Vector3.Distance(this.pointA.position, this.pointB.position) * this.worldspaceSpeed + this.offset));
	}

	// Token: 0x06000710 RID: 1808 RVA: 0x0001E36F File Offset: 0x0001C56F
	public virtual void GetDelta(Transform tf, out Vector3 positionDelta)
	{
		positionDelta = this._delta;
	}

	// Token: 0x06000711 RID: 1809 RVA: 0x0001E380 File Offset: 0x0001C580
	public void ProcessMetadata(EndpointMetadata meta)
	{
		if (meta.HasData)
		{
			Transform transform = base.transform.parent.Find("A");
			Transform transform2 = base.transform.parent.Find("B");
			if (transform == null)
			{
				GameObject gameObject = new GameObject("A");
				gameObject.transform.SetParent(base.transform.parent);
				transform = gameObject.transform;
			}
			transform.localPosition = Vector3.zero;
			this.pointA = transform;
			if (transform2 == null)
			{
				GameObject gameObject2 = new GameObject("B");
				gameObject2.transform.SetParent(base.transform.parent);
				transform2 = gameObject2.transform;
			}
			transform2.position = meta.Position;
			this.pointB = transform2;
			return;
		}
		this.pointA = null;
		this.pointB = null;
	}

	// Token: 0x06000712 RID: 1810 RVA: 0x0001E460 File Offset: 0x0001C660
	public void ProcessMetadata(SpeedMetadata meta)
	{
		this.worldspaceSpeed = (float)meta.speed;
	}

	// Token: 0x06000713 RID: 1811 RVA: 0x0001E46F File Offset: 0x0001C66F
	public virtual void OnEnter(Transform tf)
	{
	}

	// Token: 0x06000714 RID: 1812 RVA: 0x0001E471 File Offset: 0x0001C671
	public virtual void OnExit(Transform tf)
	{
	}

	// Token: 0x0400054D RID: 1357
	public Transform pointA;

	// Token: 0x0400054E RID: 1358
	public Transform pointB;

	// Token: 0x0400054F RID: 1359
	public AnimationCurve speedCurve;

	// Token: 0x04000550 RID: 1360
	public bool useWorldspaceSpeed;

	// Token: 0x04000551 RID: 1361
	public float worldspaceSpeed = 1f;

	// Token: 0x04000552 RID: 1362
	public float offset;

	// Token: 0x04000553 RID: 1363
	protected bool unconfigured;

	// Token: 0x04000554 RID: 1364
	private bool unconf_movingRight = true;

	// Token: 0x04000555 RID: 1365
	private byte unconf_delayedTick;

	// Token: 0x04000556 RID: 1366
	private float unconf_moveDelta;

	// Token: 0x04000557 RID: 1367
	private Vector3 unconf_startPos;

	// Token: 0x04000558 RID: 1368
	protected Vector3 _delta;
}
