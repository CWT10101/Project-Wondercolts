﻿using System;
using UnityEngine;

// Token: 0x0200005B RID: 91
[DefaultExecutionOrder(-100)]
public class BackgroundController : MonoBehaviour
{
	// Token: 0x0600022F RID: 559 RVA: 0x00009A5A File Offset: 0x00007C5A
	private void Start()
	{
		this.sectionCopy = Object.Instantiate<GameObject>(this.section, base.transform);
	}

	// Token: 0x06000230 RID: 560 RVA: 0x00009A74 File Offset: 0x00007C74
	private void FixedUpdate()
	{
		float x = Camera.main.transform.position.x;
		float x2 = this.sectionWidth * Mathf.Floor(x / this.sectionWidth);
		float x3 = this.sectionWidth * Mathf.Floor((x + this.sectionWidth) / this.sectionWidth);
		this.section.transform.localPosition = new Vector3(x2, this.baseline, 0f);
		this.sectionCopy.transform.localPosition = new Vector3(x3, this.baseline, 0f);
	}

	// Token: 0x04000135 RID: 309
	public GameObject section;

	// Token: 0x04000136 RID: 310
	public float sectionWidth = 60f;

	// Token: 0x04000137 RID: 311
	public float baseline = -20f;

	// Token: 0x04000138 RID: 312
	private GameObject sectionCopy;
}
