﻿using System;
using System.Collections.Generic;
using System.Reflection;
using LevelEditor;
using UnityEngine;

// Token: 0x020000AA RID: 170
public class Enemy : Entity, ITouchTop, ITouchSide, ITouchBottom, IFallOn, ISpin, ISlam, ISlide
{
	// Token: 0x170000D5 RID: 213
	// (get) Token: 0x06000536 RID: 1334 RVA: 0x00017662 File Offset: 0x00015862
	public static int HitMask
	{
		get
		{
			return CollisionMask.Get("Entity");
		}
	}

	// Token: 0x170000D6 RID: 214
	// (get) Token: 0x06000537 RID: 1335 RVA: 0x0001766E File Offset: 0x0001586E
	public static int GroundMask
	{
		get
		{
			return 259;
		}
	}

	// Token: 0x170000D7 RID: 215
	// (get) Token: 0x06000538 RID: 1336 RVA: 0x00017675 File Offset: 0x00015875
	// (set) Token: 0x06000539 RID: 1337 RVA: 0x0001767D File Offset: 0x0001587D
	public Enemy.InteractionResponse OnTouchTop { get; protected set; } = Enemy.InteractionResponse.DieBounce;

	// Token: 0x170000D8 RID: 216
	// (get) Token: 0x0600053A RID: 1338 RVA: 0x00017686 File Offset: 0x00015886
	// (set) Token: 0x0600053B RID: 1339 RVA: 0x0001768E File Offset: 0x0001588E
	public Enemy.InteractionResponse OnTouchSide { get; protected set; } = Enemy.InteractionResponse.HurtCrash;

	// Token: 0x170000D9 RID: 217
	// (get) Token: 0x0600053C RID: 1340 RVA: 0x00017697 File Offset: 0x00015897
	// (set) Token: 0x0600053D RID: 1341 RVA: 0x0001769F File Offset: 0x0001589F
	public Enemy.InteractionResponse OnTouchBottom { get; protected set; } = Enemy.InteractionResponse.HurtCrash;

	// Token: 0x170000DA RID: 218
	// (get) Token: 0x0600053E RID: 1342 RVA: 0x000176A8 File Offset: 0x000158A8
	// (set) Token: 0x0600053F RID: 1343 RVA: 0x000176B0 File Offset: 0x000158B0
	public Enemy.InteractionResponse OnSpin { get; protected set; } = Enemy.InteractionResponse.DieSpin;

	// Token: 0x170000DB RID: 219
	// (get) Token: 0x06000540 RID: 1344 RVA: 0x000176B9 File Offset: 0x000158B9
	// (set) Token: 0x06000541 RID: 1345 RVA: 0x000176C1 File Offset: 0x000158C1
	public Enemy.InteractionResponse OnSlam { get; protected set; }

	// Token: 0x170000DC RID: 220
	// (get) Token: 0x06000542 RID: 1346 RVA: 0x000176CA File Offset: 0x000158CA
	// (set) Token: 0x06000543 RID: 1347 RVA: 0x000176D2 File Offset: 0x000158D2
	public Enemy.InteractionResponse OnSlide { get; protected set; } = Enemy.InteractionResponse.DieSpin;

	// Token: 0x170000DD RID: 221
	// (get) Token: 0x06000544 RID: 1348 RVA: 0x000176DB File Offset: 0x000158DB
	// (set) Token: 0x06000545 RID: 1349 RVA: 0x000176E3 File Offset: 0x000158E3
	public Collider[] Colliders { get; private set; }

	// Token: 0x170000DE RID: 222
	// (get) Token: 0x06000546 RID: 1350 RVA: 0x000176EC File Offset: 0x000158EC
	private Dictionary<Collider, Vector3> ColliderPositions { get; } = new Dictionary<Collider, Vector3>();

	// Token: 0x06000547 RID: 1351 RVA: 0x000176F4 File Offset: 0x000158F4
	protected virtual void Awake()
	{
		this.Colliders = base.GetComponentsInChildren<Collider>();
		this.DepenetrateFromEnemies();
	}

	// Token: 0x06000548 RID: 1352 RVA: 0x00017708 File Offset: 0x00015908
	protected virtual void OnEnable()
	{
		if (!this.isDead)
		{
			this.ResetEntity();
		}
		if (this.startingPos == null)
		{
			this.startingPos = new Vector3?(base.transform.localPosition);
		}
	}

	// Token: 0x06000549 RID: 1353 RVA: 0x0001773B File Offset: 0x0001593B
	protected virtual void Start()
	{
		if (Level.instance)
		{
			Level.instance.EnemiesInLevel.Add(this);
		}
	}

	// Token: 0x0600054A RID: 1354 RVA: 0x0001775C File Offset: 0x0001595C
	private void DepenetrateFromEnemies()
	{
		Collider collider = this.collider;
		Collider[] array = null;
		SphereCollider sphereCollider = collider as SphereCollider;
		if (sphereCollider != null)
		{
			array = Physics.OverlapSphere(sphereCollider.transform.TransformPoint(sphereCollider.center), sphereCollider.radius);
		}
		else
		{
			CapsuleCollider capsuleCollider = collider as CapsuleCollider;
			if (capsuleCollider != null)
			{
				Vector3 vector = default(Vector3);
				int i = capsuleCollider.direction;
				vector[i] = 1f;
				Vector3 a = vector;
				float d = capsuleCollider.height / 2f - capsuleCollider.radius;
				Vector3 vector2 = capsuleCollider.center - a * d;
				Vector3 vector3 = capsuleCollider.center + a * d;
				base.transform.TransformPoint(vector2);
				base.transform.TransformPoint(vector3);
				array = Physics.OverlapCapsule(vector2, vector3, capsuleCollider.radius);
			}
		}
		if (array != null)
		{
			foreach (Collider collider2 in array)
			{
				Enemy componentInParent = collider2.GetComponentInParent<Enemy>();
				Vector3 a2;
				float d2;
				if (componentInParent != null && componentInParent != this && Physics.ComputePenetration(collider, collider.transform.position, collider.transform.rotation, collider2, collider2.transform.position, collider2.transform.rotation, out a2, out d2))
				{
					CharacterController component = base.GetComponent<CharacterController>();
					if (component != null)
					{
						component.enabled = false;
						base.transform.Translate(a2 * d2, Space.World);
						component.enabled = true;
					}
				}
			}
		}
	}

	// Token: 0x0600054B RID: 1355 RVA: 0x000178E8 File Offset: 0x00015AE8
	protected virtual void FixedUpdate()
	{
		if (this.isDead)
		{
			return;
		}
		if (this.Colliders != null)
		{
			foreach (Collider collider in this.Colliders)
			{
				Vector3 center = collider.bounds.center;
				if (this.ColliderPositions.ContainsKey(collider))
				{
					Collider[] array = null;
					Vector3 vector = this.ColliderPositions[collider];
					Vector3 vector2 = center - vector;
					SphereCollider sphereCollider = collider as SphereCollider;
					if (sphereCollider != null)
					{
						array = Physics.OverlapCapsule(vector, center, sphereCollider.radius + 0.05f, LayerMask.GetMask(new string[]
						{
							"Player"
						}), QueryTriggerInteraction.Ignore);
					}
					else
					{
						BoxCollider boxCollider = collider as BoxCollider;
						if (boxCollider != null)
						{
							array = Physics.OverlapBox(base.transform.TransformPoint(boxCollider.center), boxCollider.size * 0.5f + Vector3.one * 0.05f, base.transform.rotation, LayerMask.GetMask(new string[]
							{
								"Player"
							}), QueryTriggerInteraction.Ignore);
						}
						else
						{
							CapsuleCollider capsuleCollider = collider as CapsuleCollider;
							if (capsuleCollider != null)
							{
								Vector3 vector3 = default(Vector3);
								int j = capsuleCollider.direction;
								vector3[j] = 1f;
								Vector3 a = vector3;
								float d = capsuleCollider.height / 2f - capsuleCollider.radius;
								Vector3 position = capsuleCollider.center - a * d;
								Vector3 position2 = capsuleCollider.center + a * d;
								Vector3 point = base.transform.TransformPoint(position);
								Vector3 point2 = base.transform.TransformPoint(position2);
								array = Physics.OverlapCapsule(point, point2, capsuleCollider.radius + 0.05f, LayerMask.GetMask(new string[]
								{
									"Player"
								}), QueryTriggerInteraction.Ignore);
							}
						}
					}
					if (array != null)
					{
						foreach (Collider collider2 in array)
						{
							CrashController crashController;
							if (collider2.TryGetComponent<CrashController>(out crashController))
							{
								Debug.DrawLine(center, collider2.bounds.center, Color.cyan, 1f, false);
								Vector3 vector4 = collider2.ClosestPoint(collider2.ClosestPoint(center));
								Vector3 normalized = (vector4 - center).normalized;
								this.GenerateCollision(crashController.controller, collider, normalized, vector4, (vector2.sqrMagnitude > 0f) ? vector2.normalized : Vector3.zero, Vector3.Distance(center, vector4));
							}
						}
					}
				}
				this.ColliderPositions[collider] = center;
			}
		}
	}

	// Token: 0x0600054C RID: 1356 RVA: 0x00017B89 File Offset: 0x00015D89
	public virtual void Bump(Enemy other)
	{
	}

	// Token: 0x0600054D RID: 1357 RVA: 0x00017B8B File Offset: 0x00015D8B
	public virtual void Slam(CrashController crash)
	{
		if (this.isDead)
		{
			return;
		}
		this.SelectResponse(this.OnSlam, crash);
	}

	// Token: 0x0600054E RID: 1358 RVA: 0x00017BA3 File Offset: 0x00015DA3
	public virtual void Slide(CrashController crash)
	{
		if (this.isDead)
		{
			return;
		}
		this.SelectResponse(this.OnSlide, crash);
	}

	// Token: 0x0600054F RID: 1359 RVA: 0x00017BBC File Offset: 0x00015DBC
	public virtual void Spin(CrashController crash)
	{
		if (this.isDead)
		{
			return;
		}
		Bounds bounds = crash.controller.bounds;
		Bounds bounds2 = this.collider.bounds;
		if (bounds.min.y > bounds2.center.y && this.OnSpin > this.OnTouchTop)
		{
			Debug.LogWarning("spin top");
			this.SpinDeath(crash.transform);
			return;
		}
		this.SelectResponse(this.OnSpin, crash);
	}

	// Token: 0x06000550 RID: 1360 RVA: 0x00017C36 File Offset: 0x00015E36
	public virtual void TouchBottom(CrashController crash)
	{
		if (this.isDead)
		{
			return;
		}
		this.SelectResponse(this.OnTouchBottom, crash);
	}

	// Token: 0x06000551 RID: 1361 RVA: 0x00017C4E File Offset: 0x00015E4E
	public virtual void TouchSide(CrashController crash)
	{
		if (this.isDead)
		{
			return;
		}
		this.SelectResponse(this.OnTouchSide, crash);
	}

	// Token: 0x06000552 RID: 1362 RVA: 0x00017C66 File Offset: 0x00015E66
	public virtual void TouchTop(CrashController crash)
	{
		if (this.isDead)
		{
			return;
		}
		if (crash.IsGrounded)
		{
			this.TouchSide(crash);
			return;
		}
		this.SelectResponse(this.OnTouchTop, crash);
	}

	// Token: 0x06000553 RID: 1363 RVA: 0x00017C8E File Offset: 0x00015E8E
	public void FallOn(CrashController crash)
	{
		this.TouchTop(crash);
	}

	// Token: 0x06000554 RID: 1364 RVA: 0x00017C97 File Offset: 0x00015E97
	protected void SelectResponse(Enemy.InteractionResponse ir, CrashController crash)
	{
		if (ir == Enemy.InteractionResponse.Die)
		{
			this.Die(true);
			return;
		}
		if (ir == Enemy.InteractionResponse.DieBounce)
		{
			this.BounceDeath(crash);
			return;
		}
		if (ir == Enemy.InteractionResponse.DieSpin)
		{
			this.SpinDeath(crash.transform);
			return;
		}
		if (ir == Enemy.InteractionResponse.HurtCrash)
		{
			this.HurtCrash(crash);
		}
	}

	// Token: 0x06000555 RID: 1365 RVA: 0x00017CCC File Offset: 0x00015ECC
	protected virtual void HurtCrash(CrashController crash)
	{
		if (!crash.TakeDamage(0))
		{
			this.SpinDeath(crash.transform);
		}
	}

	// Token: 0x06000556 RID: 1366 RVA: 0x00017CE3 File Offset: 0x00015EE3
	protected virtual void BounceDeath(CrashController crash)
	{
		crash.Bounce();
		this.Die(true);
		if (this.deathState)
		{
			this.deathState.SetActive(true);
		}
	}

	// Token: 0x06000557 RID: 1367 RVA: 0x00017D0C File Offset: 0x00015F0C
	public virtual void SpinDeath(Transform source)
	{
		Enemy.<>c__DisplayClass59_0 CS$<>8__locals1 = new Enemy.<>c__DisplayClass59_0();
		CS$<>8__locals1.<>4__this = this;
		this.isDead = true;
		Collider[] colliders = this.Colliders;
		for (int i = 0; i < colliders.Length; i++)
		{
			colliders[i].enabled = false;
		}
		this.RegisterKill();
		if (this.audioSource != null)
		{
			this.audioSource.enabled = false;
		}
		AudioManager.Play("SFX_KnockAwayEnemy", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		CS$<>8__locals1.dir = Vector3.ProjectOnPlane(base.transform.position - source.position, Vector3.up).normalized;
		base.StartCoroutine(CS$<>8__locals1.<SpinDeath>g__SpinAway|0());
	}

	// Token: 0x06000558 RID: 1368 RVA: 0x00017DCC File Offset: 0x00015FCC
	public virtual void Explode(Transform source)
	{
		this.SpinDeath(source);
	}

	// Token: 0x06000559 RID: 1369 RVA: 0x00017DD8 File Offset: 0x00015FD8
	public virtual void TrySpawnParticle()
	{
		if (this.deathParticle)
		{
			Renderer componentInChildren = this.visual.GetComponentInChildren<Renderer>();
			Vector3 position = (componentInChildren != null) ? componentInChildren.bounds.center : base.transform.position;
			Object.Instantiate<ParticleSystem>(this.deathParticle, position, Quaternion.identity).main.startColor = new ParticleSystem.MinMaxGradient(this.deathParticleColour);
		}
	}

	// Token: 0x0600055A RID: 1370 RVA: 0x00017E48 File Offset: 0x00016048
	public virtual void Die(bool playSFX = true)
	{
		if (playSFX)
		{
			AudioManager.Play("SFX_HitEnemy", AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		}
		if (this.audioSource != null)
		{
			this.audioSource.enabled = false;
		}
		this.isDead = true;
		this.TrySpawnParticle();
		Collider[] colliders = this.Colliders;
		for (int i = 0; i < colliders.Length; i++)
		{
			colliders[i].enabled = false;
		}
		base.DisableEntity();
		this.RegisterKill();
	}

	// Token: 0x0600055B RID: 1371 RVA: 0x00017ED0 File Offset: 0x000160D0
	public void RegisterKill()
	{
		if (Level.instance)
		{
			if (!Level.instance.EnemiesKilled.Contains(this))
			{
				Level.instance.EnemyKilled(this);
				this.TryPushToStack();
				return;
			}
		}
		else if (LevelInterfaceManager.instance && !LevelInterfaceManager.instance.EnemiesKilled.Contains(this))
		{
			LevelInterfaceManager.instance.EnemyKilled(this);
			this.TryPushToStack();
		}
	}

	// Token: 0x0600055C RID: 1372 RVA: 0x00017F3C File Offset: 0x0001613C
	protected void GenerateCollision(CharacterController controller, Collider collider, Vector3 normal, Vector3 point, Vector3 direction, float distance)
	{
		ControllerColliderHit controllerColliderHit = new ControllerColliderHit();
		Type typeFromHandle = typeof(ControllerColliderHit);
		typeFromHandle.GetField("m_Controller", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controllerColliderHit, controller);
		typeFromHandle.GetField("m_Collider", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controllerColliderHit, collider);
		typeFromHandle.GetField("m_Normal", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controllerColliderHit, normal);
		typeFromHandle.GetField("m_Point", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controllerColliderHit, point);
		typeFromHandle.GetField("m_MoveDirection", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controllerColliderHit, direction);
		typeFromHandle.GetField("m_MoveLength", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controllerColliderHit, distance);
		controller.SendMessage("OnControllerColliderHit", controllerColliderHit);
	}

	// Token: 0x0600055D RID: 1373 RVA: 0x00017FF4 File Offset: 0x000161F4
	public override void ResetEntity()
	{
		if (this.startingPos == null)
		{
			this.startingPos = new Vector3?(base.transform.localPosition);
		}
		CharacterController component = base.GetComponent<CharacterController>();
		if (component)
		{
			component.enabled = false;
		}
		base.transform.localPosition = this.startingPos.Value;
		if (component)
		{
			component.enabled = true;
		}
		if (Level.instance)
		{
			Level.instance.EnemyReset(this);
		}
		else if (LevelInterfaceManager.instance)
		{
			LevelInterfaceManager.instance.EnemyReset(this);
		}
		this.isDead = false;
		Collider[] colliders = this.Colliders;
		for (int i = 0; i < colliders.Length; i++)
		{
			colliders[i].enabled = true;
		}
		if (this.animator)
		{
			this.animator.SetTrigger("Reset");
		}
		if (this.audioSource != null)
		{
			this.audioSource.enabled = true;
		}
		base.ResetEntity();
	}

	// Token: 0x0600055E RID: 1374 RVA: 0x000180F4 File Offset: 0x000162F4
	protected bool IsAbove(CrashController crash)
	{
		return Vector3.Angle(Vector3.up, this.collider.ClosestPoint(crash.controller.ClosestPoint(this.collider.bounds.center)) - this.collider.bounds.center) < 40f;
	}

	// Token: 0x040003B8 RID: 952
	public Animator animator;

	// Token: 0x040003B9 RID: 953
	public GameObject deathState;

	// Token: 0x040003BA RID: 954
	public AudioSource audioSource;

	// Token: 0x040003BB RID: 955
	[HideInInspector]
	public bool isDead;

	// Token: 0x040003BC RID: 956
	public ParticleSystem deathParticle;

	// Token: 0x040003BD RID: 957
	public Color deathParticleColour;

	// Token: 0x040003C6 RID: 966
	protected Vector3? startingPos;

	// Token: 0x0200020E RID: 526
	public enum InteractionResponse
	{
		// Token: 0x04000CE1 RID: 3297
		Die,
		// Token: 0x04000CE2 RID: 3298
		DieBounce,
		// Token: 0x04000CE3 RID: 3299
		DieSpin,
		// Token: 0x04000CE4 RID: 3300
		HurtCrash
	}
}
