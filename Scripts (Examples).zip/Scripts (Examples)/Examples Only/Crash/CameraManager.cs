﻿using System;
using Cinemachine;
using UnityEngine;

// Token: 0x020000DD RID: 221
public class CameraManager : MonoBehaviour
{
	// Token: 0x06000693 RID: 1683 RVA: 0x0001C69C File Offset: 0x0001A89C
	private void Awake()
	{
		CameraManager.instance = this;
		if (CameraManager._first)
		{
			CameraManager._first = false;
			CameraManager._postProc = (PlayerPrefs.GetInt("Graphics_PostProcessing", this.psxEffects.postProcessing ? 1 : 0) != 0);
			CameraManager._resFactor = PlayerPrefs.GetInt("Graphics_ResolutionFactor", this.psxEffects.resolutionFactor);
			CameraManager._vertexInaccuracy = PlayerPrefs.GetInt("Graphics_VertexInaccuracy", this.psxEffects.vertexInaccuracy);
			CameraManager._colourDepth = PlayerPrefs.GetInt("Graphics_ColorDepth", this.psxEffects.colorDepth);
			CameraManager._subtractiveFade = PlayerPrefs.GetInt("Graphics_SubtractiveFade", this.psxEffects.subtractFade);
			CameraManager._affineWarp = (PlayerPrefs.GetInt("Graphics_AffineWarping", this.psxEffects.affineMapping ? 1 : 0) != 0);
			CameraManager._scanlines = (PlayerPrefs.GetInt("Graphics_Scanlines", this.psxEffects.scanlines ? 1 : 0) != 0);
			CameraManager._dither = (PlayerPrefs.GetInt("Graphics_Dither", this.psxEffects.dithering ? 1 : 0) != 0);
			int @int = PlayerPrefs.GetInt("Graphics_WindowWidth", Screen.width);
			int int2 = PlayerPrefs.GetInt("Graphics_WindowHeight", Screen.height);
			int int3 = PlayerPrefs.GetInt("Graphics_WindowMode", (int)Screen.fullScreenMode);
			Screen.SetResolution(@int, int2, (FullScreenMode)int3);
		}
		this.psxEffects.postProcessing = CameraManager._postProc;
		this.psxEffects.resolutionFactor = CameraManager._resFactor;
		this.psxEffects.vertexInaccuracy = CameraManager._vertexInaccuracy;
		this.psxEffects.colorDepth = CameraManager._colourDepth;
		this.psxEffects.subtractFade = CameraManager._subtractiveFade;
		this.psxEffects.affineMapping = CameraManager._affineWarp;
		this.psxEffects.scanlines = CameraManager._scanlines;
		this.psxEffects.dithering = CameraManager._dither;
		this.psxEffects.UpdateProperties();
	}

	// Token: 0x06000694 RID: 1684 RVA: 0x0001C874 File Offset: 0x0001AA74
	private void Start()
	{
		InterfaceManager.instance.postProcessingToggle.SetIsOnWithoutNotify(CameraManager._postProc);
		InterfaceManager.instance.resolutionSlider.SetValueWithoutNotify((float)CameraManager._resFactor);
		InterfaceManager.instance.vertexSlider.SetValueWithoutNotify((float)CameraManager._vertexInaccuracy);
		InterfaceManager.instance.colourDpethSlider.SetValueWithoutNotify((float)CameraManager._colourDepth);
		InterfaceManager.instance.subtractiveFadeSlider.SetValueWithoutNotify((float)CameraManager._subtractiveFade);
		InterfaceManager.instance.affineWarpingToggle.SetIsOnWithoutNotify(CameraManager._affineWarp);
		InterfaceManager.instance.scanlinesToggle.SetIsOnWithoutNotify(CameraManager._scanlines);
		InterfaceManager.instance.ditheringToggle.SetIsOnWithoutNotify(CameraManager._dither);
	}

	// Token: 0x06000695 RID: 1685 RVA: 0x0001C928 File Offset: 0x0001AB28
	public void AssignTarget(CrashController crash)
	{
		for (int i = 0; i < this.virtualCameras.Length; i++)
		{
			this.virtualCameras[i].Follow = crash.camTarget;
		}
	}

	// Token: 0x06000696 RID: 1686 RVA: 0x0001C95B File Offset: 0x0001AB5B
	public void SetVCam(CinemachineVirtualCameraBase vcam)
	{
		vcam.MoveToTopOfPrioritySubqueue();
	}

	// Token: 0x06000697 RID: 1687 RVA: 0x0001C963 File Offset: 0x0001AB63
	public void SetDollyTrack(CinemachinePathBase track)
	{
		this.cameraFollowTarget.SetCameraTrack(track);
	}

	// Token: 0x06000698 RID: 1688 RVA: 0x0001C974 File Offset: 0x0001AB74
	public void SetFOV(float FOV)
	{
		CinemachineVirtualCamera[] array = this.virtualCameras;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].m_Lens.FieldOfView = FOV;
		}
	}

	// Token: 0x06000699 RID: 1689 RVA: 0x0001C9A4 File Offset: 0x0001ABA4
	public static void SetScreenMode(FullScreenMode mode)
	{
		Screen.SetResolution(Screen.width, Screen.height, mode);
		PlayerPrefs.SetInt("Graphics_WindowMode", (int)mode);
	}

	// Token: 0x0600069A RID: 1690 RVA: 0x0001C9C1 File Offset: 0x0001ABC1
	public static void SetScreenResolution(int w, int h)
	{
		Screen.SetResolution(w, h, Screen.fullScreenMode);
		PlayerPrefs.SetInt("Graphics_WindowWidth", w);
		PlayerPrefs.SetInt("Graphics_WindowHeight", h);
	}

	// Token: 0x0600069B RID: 1691 RVA: 0x0001C9E5 File Offset: 0x0001ABE5
	public void SetPostProcessing(bool enabled)
	{
		PSXEffects psxeffects = this.psxEffects;
		CameraManager._postProc = enabled;
		psxeffects.postProcessing = enabled;
		PlayerPrefs.SetInt("Graphics_PostProcessing", enabled ? 1 : 0);
		this.psxEffects.UpdateProperties();
	}

	// Token: 0x0600069C RID: 1692 RVA: 0x0001CA15 File Offset: 0x0001AC15
	public void SetResolutionFactor(int factor)
	{
		PSXEffects psxeffects = this.psxEffects;
		CameraManager._resFactor = factor;
		psxeffects.resolutionFactor = factor;
		PlayerPrefs.SetInt("Graphics_ResolutionFactor", factor);
		this.psxEffects.UpdateProperties();
	}

	// Token: 0x0600069D RID: 1693 RVA: 0x0001CA3F File Offset: 0x0001AC3F
	public void SetVertexInaccuracy(int factor)
	{
		PSXEffects psxeffects = this.psxEffects;
		CameraManager._vertexInaccuracy = factor;
		psxeffects.vertexInaccuracy = factor;
		PlayerPrefs.SetInt("Graphics_VertexInaccuracy", factor);
		this.psxEffects.UpdateProperties();
	}

	// Token: 0x0600069E RID: 1694 RVA: 0x0001CA69 File Offset: 0x0001AC69
	public void SetColourDepth(int factor)
	{
		PSXEffects psxeffects = this.psxEffects;
		CameraManager._colourDepth = factor;
		psxeffects.colorDepth = factor;
		PlayerPrefs.SetInt("Graphics_ColorDepth", factor);
		this.psxEffects.UpdateProperties();
	}

	// Token: 0x0600069F RID: 1695 RVA: 0x0001CA93 File Offset: 0x0001AC93
	public void SetSubtractiveFade(int factor)
	{
		PSXEffects psxeffects = this.psxEffects;
		CameraManager._subtractiveFade = factor;
		psxeffects.subtractFade = factor;
		PlayerPrefs.SetInt("Graphics_SubtractiveFade", factor);
		this.psxEffects.UpdateProperties();
	}

	// Token: 0x060006A0 RID: 1696 RVA: 0x0001CABD File Offset: 0x0001ACBD
	public void SetAffineWarping(bool enabled)
	{
		PSXEffects psxeffects = this.psxEffects;
		CameraManager._affineWarp = enabled;
		psxeffects.affineMapping = enabled;
		PlayerPrefs.SetInt("Graphics_AffineWarping", enabled ? 1 : 0);
		this.psxEffects.UpdateProperties();
	}

	// Token: 0x060006A1 RID: 1697 RVA: 0x0001CAED File Offset: 0x0001ACED
	public void SetScanlines(bool enabled)
	{
		PSXEffects psxeffects = this.psxEffects;
		CameraManager._scanlines = enabled;
		psxeffects.scanlines = enabled;
		PlayerPrefs.SetInt("Graphics_Scanlines", enabled ? 1 : 0);
		this.psxEffects.UpdateProperties();
	}

	// Token: 0x060006A2 RID: 1698 RVA: 0x0001CB1D File Offset: 0x0001AD1D
	public void SetDithering(bool enabled)
	{
		PSXEffects psxeffects = this.psxEffects;
		CameraManager._dither = enabled;
		psxeffects.dithering = enabled;
		PlayerPrefs.SetInt("Graphics_Dither", enabled ? 1 : 0);
		this.psxEffects.UpdateProperties();
	}

	// Token: 0x040004CF RID: 1231
	public const string PREF_POSTPROCESSING = "Graphics_PostProcessing";

	// Token: 0x040004D0 RID: 1232
	public const string PREF_RESFACTOR = "Graphics_ResolutionFactor";

	// Token: 0x040004D1 RID: 1233
	public const string PREF_VERTINACCURACY = "Graphics_VertexInaccuracy";

	// Token: 0x040004D2 RID: 1234
	public const string PREF_COLDEPTH = "Graphics_ColorDepth";

	// Token: 0x040004D3 RID: 1235
	public const string PREF_SUBFADE = "Graphics_SubtractiveFade";

	// Token: 0x040004D4 RID: 1236
	public const string PREF_AFFINE = "Graphics_AffineWarping";

	// Token: 0x040004D5 RID: 1237
	public const string PREF_SCANLINES = "Graphics_Scanlines";

	// Token: 0x040004D6 RID: 1238
	public const string PREF_DITHER = "Graphics_Dither";

	// Token: 0x040004D7 RID: 1239
	public const string PREF_WINDOWMODE = "Graphics_WindowMode";

	// Token: 0x040004D8 RID: 1240
	public const string PREF_WINDOWWIDTH = "Graphics_WindowWidth";

	// Token: 0x040004D9 RID: 1241
	public const string PREF_WINDOWHEIGHT = "Graphics_WindowHeight";

	// Token: 0x040004DA RID: 1242
	public static CameraManager instance;

	// Token: 0x040004DB RID: 1243
	public CinemachineVirtualCameraBase introCam;

	// Token: 0x040004DC RID: 1244
	public CinemachineVirtualCamera[] virtualCameras;

	// Token: 0x040004DD RID: 1245
	public ExampleCameraFollowTarget cameraFollowTarget;

	// Token: 0x040004DE RID: 1246
	public ExamplePlayerCamera playerCamera;

	// Token: 0x040004DF RID: 1247
	public ExampleVirtualCameraScript virtualCameraLogic;

	// Token: 0x040004E0 RID: 1248
	[SerializeField]
	private PSXEffects psxEffects;

	// Token: 0x040004E1 RID: 1249
	private static bool _first = true;

	// Token: 0x040004E2 RID: 1250
	private static bool _postProc;

	// Token: 0x040004E3 RID: 1251
	private static int _resFactor;

	// Token: 0x040004E4 RID: 1252
	private static int _vertexInaccuracy;

	// Token: 0x040004E5 RID: 1253
	private static int _colourDepth;

	// Token: 0x040004E6 RID: 1254
	private static int _subtractiveFade;

	// Token: 0x040004E7 RID: 1255
	private static bool _affineWarp;

	// Token: 0x040004E8 RID: 1256
	private static bool _scanlines;

	// Token: 0x040004E9 RID: 1257
	private static bool _dither;
}
