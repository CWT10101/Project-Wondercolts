﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000155 RID: 341
[RequireComponent(typeof(Image))]
public class ScalePulse : MonoBehaviour
{
	// Token: 0x060009EF RID: 2543 RVA: 0x00027D99 File Offset: 0x00025F99
	private void Awake()
	{
		this.image = base.GetComponent<Image>();
	}

	// Token: 0x060009F0 RID: 2544 RVA: 0x00027DA8 File Offset: 0x00025FA8
	private void Update()
	{
		this.scalingTime = Time.time * this.scalingSpeed;
		this.image.rectTransform.localScale = new Vector3(Mathf.PingPong(this.scalingTime, this.length) + this.targetScale, Mathf.PingPong(this.scalingTime, this.length) + this.targetScale, 1f);
	}

	// Token: 0x0400071F RID: 1823
	private Image image;

	// Token: 0x04000720 RID: 1824
	public float scalingTime;

	// Token: 0x04000721 RID: 1825
	public float scalingSpeed = 0.3f;

	// Token: 0x04000722 RID: 1826
	public float targetScale = 2.5f;

	// Token: 0x04000723 RID: 1827
	public float length = 0.3f;
}
