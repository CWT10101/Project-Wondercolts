﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200000A RID: 10
public class LightSource : MonoBehaviour
{
	// Token: 0x06000029 RID: 41 RVA: 0x00003064 File Offset: 0x00001264
	private void OnEnable()
	{
		LightSource.lights.Add(this);
	}

	// Token: 0x0600002A RID: 42 RVA: 0x00003072 File Offset: 0x00001272
	private void OnDisable()
	{
		LightSource.lights.Remove(this);
	}

	// Token: 0x0600002B RID: 43 RVA: 0x00003080 File Offset: 0x00001280
	private void OnDrawGizmosSelected()
	{
		Gizmos.color = this.color;
		Gizmos.DrawWireSphere(base.transform.position, this.radius);
	}

	// Token: 0x04000028 RID: 40
	public float radius;

	// Token: 0x04000029 RID: 41
	[ColorUsage(true, true)]
	public Color color;

	// Token: 0x0400002A RID: 42
	public static readonly HashSet<LightSource> lights = new HashSet<LightSource>();
}
