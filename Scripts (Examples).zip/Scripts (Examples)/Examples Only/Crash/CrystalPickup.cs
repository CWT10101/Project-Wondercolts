﻿using System;
using UnityEngine;

// Token: 0x0200008F RID: 143
public class CrystalPickup : Pickup, IPlayModeCallback
{
	// Token: 0x170000B6 RID: 182
	// (get) Token: 0x06000450 RID: 1104 RVA: 0x00013E2F File Offset: 0x0001202F
	// (set) Token: 0x06000451 RID: 1105 RVA: 0x00013E37 File Offset: 0x00012037
	public bool Collected { get; protected set; }

	// Token: 0x06000452 RID: 1106 RVA: 0x00013E40 File Offset: 0x00012040
	protected virtual void OnEnable()
	{
		InterfaceManager.instance.hudTrack.gems[this.iconIndex].SetActive(this.Collected);
		if (this.Collected)
		{
			this.collider.enabled = false;
			this.visual.SetActive(false);
			return;
		}
		if (this.collectEffect)
		{
			Object.Instantiate<GameObject>(this.collectEffect, base.transform.position, Quaternion.identity);
		}
	}

	// Token: 0x06000453 RID: 1107 RVA: 0x00013EB8 File Offset: 0x000120B8
	public override void Spin(CrashController crash)
	{
	}

	// Token: 0x06000454 RID: 1108 RVA: 0x00013EBC File Offset: 0x000120BC
	public override void Despawn()
	{
		AudioManager.Play("SFX_Crystal", new Vector3?(base.transform.position), null);
		this.Collected = true;
		if (Level.instance)
		{
			InterfaceManager.instance.hudTrack.gems[this.iconIndex].SetActive(true);
			InterfaceManager.instance.hudTrack.ShowGems();
		}
		else if (LevelManager.instance)
		{
			PickupSetter componentInParent = base.GetComponentInParent<PickupSetter>();
			if (componentInParent != null)
			{
				componentInParent.Collected = true;
			}
			InterfaceManager.instance.hudTrack.gems[this.iconIndex].SetActive(true);
			InterfaceManager.instance.hudTrack.ShowGems();
		}
		base.Despawn();
	}

	// Token: 0x06000455 RID: 1109 RVA: 0x00013F7B File Offset: 0x0001217B
	public override void ResetEntity()
	{
		base.ResetEntity();
		this.Collected = false;
		InterfaceManager.instance.hudTrack.gems[this.iconIndex].SetActive(false);
	}

	// Token: 0x06000456 RID: 1110 RVA: 0x00013FA6 File Offset: 0x000121A6
	public void PlayModeChanged(bool isPlaying)
	{
		this.Collected = false;
	}

	// Token: 0x04000300 RID: 768
	public int iconIndex;
}
