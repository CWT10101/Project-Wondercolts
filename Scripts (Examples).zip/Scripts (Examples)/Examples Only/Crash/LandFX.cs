﻿using System;
using UnityEngine;

// Token: 0x02000051 RID: 81
public class LandFX : MonoBehaviour
{
	// Token: 0x06000216 RID: 534 RVA: 0x000096B0 File Offset: 0x000078B0
	private void OnEnable()
	{
		if (this.crash.velocity <= 0f)
		{
			Object.Instantiate<GameObject>(this.effect, base.transform.position, Quaternion.identity);
		}
	}

	// Token: 0x04000129 RID: 297
	public CrashController crash;

	// Token: 0x0400012A RID: 298
	public GameObject effect;
}
