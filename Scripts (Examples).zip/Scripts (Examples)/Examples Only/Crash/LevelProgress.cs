﻿using System;

// Token: 0x02000101 RID: 257
public struct LevelProgress
{
	// Token: 0x170000FD RID: 253
	// (get) Token: 0x060007DB RID: 2011 RVA: 0x00021606 File Offset: 0x0001F806
	public readonly bool Crystal { get; }

	// Token: 0x170000FE RID: 254
	// (get) Token: 0x060007DC RID: 2012 RVA: 0x0002160E File Offset: 0x0001F80E
	public readonly bool AllBoxes { get; }
}
