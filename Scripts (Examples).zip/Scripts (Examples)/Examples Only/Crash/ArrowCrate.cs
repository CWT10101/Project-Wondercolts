﻿using System;
using UnityEngine;

// Token: 0x02000059 RID: 89
public class ArrowCrate : BounceCrate, ICrateBouncer
{
	// Token: 0x0600022B RID: 555 RVA: 0x000099C4 File Offset: 0x00007BC4
	public void BounceCrate(Crate crate)
	{
		this.animator.SetTrigger("Bounce");
		AudioManager.Play("SFX_CrateBounce", new Vector3?(crate.transform.position), new Vector2?(Vector2.one * (0.8f + Mathf.Min(0.5f, 0.1f))));
		crate.Fall(-25f * Time.fixedUnscaledDeltaTime);
	}

	// Token: 0x0600022C RID: 556 RVA: 0x00009A31 File Offset: 0x00007C31
	public override void FallOn(CrashController crash)
	{
		this.animator.SetTrigger("Bounce");
		crash.ArrowBounce(true);
	}
}
