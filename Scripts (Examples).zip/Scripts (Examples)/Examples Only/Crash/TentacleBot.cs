﻿using System;
using UnityEngine;

// Token: 0x02000135 RID: 309
public class TentacleBot : BasicEnemy, IMetadataReceiver<PhaseMetadata>
{
	// Token: 0x1700011C RID: 284
	// (get) Token: 0x06000934 RID: 2356 RVA: 0x00025B0B File Offset: 0x00023D0B
	// (set) Token: 0x06000935 RID: 2357 RVA: 0x00025B14 File Offset: 0x00023D14
	public bool IsUp
	{
		get
		{
			return this._isUp;
		}
		set
		{
			if (value != this._isUp)
			{
				this._isUp = value;
				base.OnSlide = (this._isUp ? Enemy.InteractionResponse.DieSpin : Enemy.InteractionResponse.HurtCrash);
				base.OnSpin = (this._isUp ? Enemy.InteractionResponse.DieSpin : Enemy.InteractionResponse.HurtCrash);
				base.OnTouchTop = (base.OnSlam = (this._isUp ? Enemy.InteractionResponse.HurtCrash : Enemy.InteractionResponse.DieBounce));
				base.OnSlam = (this._isUp ? Enemy.InteractionResponse.HurtCrash : Enemy.InteractionResponse.Die);
			}
		}
	}

	// Token: 0x06000936 RID: 2358 RVA: 0x00025B82 File Offset: 0x00023D82
	protected override void OnEnable()
	{
		base.OnEnable();
		this.SetMode((int)this.mode);
	}

	// Token: 0x06000937 RID: 2359 RVA: 0x00025B98 File Offset: 0x00023D98
	public void SetMode(int index)
	{
		if (index == 1)
		{
			this.animator.SetTrigger("isMixed");
			return;
		}
		if (index == 0)
		{
			this.animator.SetTrigger("isAlwaysDown");
			this.IsUp = false;
			return;
		}
		if (index == 2)
		{
			this.animator.SetTrigger("isAlwaysUp");
			this.IsUp = true;
		}
	}

	// Token: 0x06000938 RID: 2360 RVA: 0x00025BF0 File Offset: 0x00023DF0
	public bool SetIsUp(int isUp)
	{
		return this.IsUp = (isUp != 0);
	}

	// Token: 0x06000939 RID: 2361 RVA: 0x00025C0C File Offset: 0x00023E0C
	public void PlaySFX()
	{
		if (!this.isDead)
		{
			AudioManager.Play(this.sfx, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		}
	}

	// Token: 0x0600093A RID: 2362 RVA: 0x00025C47 File Offset: 0x00023E47
	public void ProcessMetadata(PhaseMetadata meta)
	{
		this.mode = meta.Value;
	}

	// Token: 0x040006BB RID: 1723
	public string sfx = "SFX_ElectricEel";

	// Token: 0x040006BC RID: 1724
	private bool _isUp;

	// Token: 0x040006BD RID: 1725
	[SerializeField]
	private byte mode = 1;
}
