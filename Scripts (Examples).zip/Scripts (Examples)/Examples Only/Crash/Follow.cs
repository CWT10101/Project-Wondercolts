﻿using System;
using UnityEngine;

// Token: 0x0200014C RID: 332
public class Follow : MonoBehaviour
{
	// Token: 0x060009BE RID: 2494 RVA: 0x00027610 File Offset: 0x00025810
	private void LateUpdate()
	{
		if (this.target)
		{
			base.transform.rotation = this.target.rotation;
			base.transform.position = this.target.position + base.transform.TransformVector(this.offset);
		}
	}

	// Token: 0x04000711 RID: 1809
	public Transform target;

	// Token: 0x04000712 RID: 1810
	public Vector3 offset = new Vector3(0f, 5f, 0f);
}
