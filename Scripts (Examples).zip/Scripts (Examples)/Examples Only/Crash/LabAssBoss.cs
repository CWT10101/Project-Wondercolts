﻿using System;

// Token: 0x0200006F RID: 111
public class LabAssBoss : Boss
{
	// Token: 0x17000088 RID: 136
	// (get) Token: 0x06000310 RID: 784 RVA: 0x0000D5F9 File Offset: 0x0000B7F9
	protected override BossPhase[] Phases
	{
		get
		{
			return new BossPhase[0];
		}
	}

	// Token: 0x06000311 RID: 785 RVA: 0x0000D601 File Offset: 0x0000B801
	protected override void PerformLogic()
	{
		base.LookTowardCrash(90f, -1f);
	}
}
