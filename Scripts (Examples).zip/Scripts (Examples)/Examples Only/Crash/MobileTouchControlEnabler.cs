﻿using System;
using UnityEngine;

// Token: 0x020000E5 RID: 229
public class MobileTouchControlEnabler : MonoBehaviour
{
	// Token: 0x06000706 RID: 1798 RVA: 0x0001DF34 File Offset: 0x0001C134
	private void Start()
	{
		base.gameObject.SetActive(!this.EnableIfAndroid);
	}

	// Token: 0x04000549 RID: 1353
	public bool EnableIfAndroid = true;
}
