﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000BF RID: 191
public class GemLockBlock : MonoBehaviour, IPlayModeCallback
{
	// Token: 0x170000E1 RID: 225
	// (get) Token: 0x060005D2 RID: 1490 RVA: 0x00019BC9 File Offset: 0x00017DC9
	public static HashSet<GemLockBlock> Blocks { get; } = new HashSet<GemLockBlock>();

	// Token: 0x170000E2 RID: 226
	// (get) Token: 0x060005D3 RID: 1491 RVA: 0x00019BD0 File Offset: 0x00017DD0
	// (set) Token: 0x060005D4 RID: 1492 RVA: 0x00019BD7 File Offset: 0x00017DD7
	public static bool GemCollected { get; private set; }

	// Token: 0x060005D5 RID: 1493 RVA: 0x00019BE0 File Offset: 0x00017DE0
	public static void RestoreDefault()
	{
		GemLockBlock.GemCollected = false;
		foreach (GemLockBlock gemLockBlock in GemLockBlock.Blocks)
		{
			gemLockBlock.SetTangible(true);
		}
	}

	// Token: 0x060005D6 RID: 1494 RVA: 0x00019C38 File Offset: 0x00017E38
	public static void OnGemCollected()
	{
		GemLockBlock.GemCollected = true;
		foreach (GemLockBlock gemLockBlock in GemLockBlock.Blocks)
		{
			gemLockBlock.SetTangible(false);
			Crate crate;
			if (gemLockBlock.CrateCheck(out crate))
			{
				crate.Fall(0f);
			}
		}
	}

	// Token: 0x060005D7 RID: 1495 RVA: 0x00019CA4 File Offset: 0x00017EA4
	protected void OnEnable()
	{
		GemLockBlock.Blocks.Add(this);
	}

	// Token: 0x060005D8 RID: 1496 RVA: 0x00019CB2 File Offset: 0x00017EB2
	public void PlayModeChanged(bool isPlaying)
	{
		this.SetTangible(true);
	}

	// Token: 0x060005D9 RID: 1497 RVA: 0x00019CBB File Offset: 0x00017EBB
	private void OnDestroy()
	{
		GemLockBlock.Blocks.Remove(this);
	}

	// Token: 0x060005DA RID: 1498 RVA: 0x00019CCC File Offset: 0x00017ECC
	private void SetTangible(bool tangible)
	{
		if (tangible)
		{
			this.visual.SetActive(true);
			this.intangibleVis.SetActive(false);
		}
		else
		{
			this.visual.SetActive(false);
			this.intangibleVis.SetActive(true);
		}
		this.coll.enabled = tangible;
	}

	// Token: 0x060005DB RID: 1499 RVA: 0x00019D1C File Offset: 0x00017F1C
	public bool CrateCheck(out Crate crate)
	{
		RaycastHit raycastHit;
		if (Physics.Raycast(this.coll.bounds.center, Vector3.up, out raycastHit, this.coll.size.y, 1, QueryTriggerInteraction.Ignore) && raycastHit.collider.TryGetComponent<Crate>(out crate) && !crate.isBroken && !crate.IsFalling)
		{
			return true;
		}
		crate = null;
		return false;
	}

	// Token: 0x04000440 RID: 1088
	public BoxCollider coll;

	// Token: 0x04000441 RID: 1089
	public GameObject visual;

	// Token: 0x04000442 RID: 1090
	public GameObject mainVis;

	// Token: 0x04000443 RID: 1091
	public GameObject secondaryVis;

	// Token: 0x04000444 RID: 1092
	public GameObject intangibleVis;
}
