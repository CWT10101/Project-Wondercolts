﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000094 RID: 148
public class CustomWarpRoomLevelInput : MonoBehaviour
{
	// Token: 0x0600047B RID: 1147 RVA: 0x00014673 File Offset: 0x00012873
	private void Awake()
	{
		this.CheckStartingValue();
	}

	// Token: 0x0600047C RID: 1148 RVA: 0x0001467B File Offset: 0x0001287B
	public void CheckStartingValue()
	{
		this.inputfield.text = PlayerPrefs.GetString(string.Format("CustomInput{0}", this.index), this.startingString);
	}

	// Token: 0x0600047D RID: 1149 RVA: 0x000146A8 File Offset: 0x000128A8
	public void OnEndEditInput()
	{
		this.CheckForLevel(true);
	}

	// Token: 0x0600047E RID: 1150 RVA: 0x000146B1 File Offset: 0x000128B1
	public void SwitchLight(bool on, bool canError = false)
	{
		this.lightImage.color = (on ? this.onColour : (canError ? this.errorColor : this.offColour));
		if (canError && !on)
		{
			base.StartCoroutine(this.<SwitchLight>g__Routine|13_0());
		}
	}

	// Token: 0x0600047F RID: 1151 RVA: 0x000146ED File Offset: 0x000128ED
	public void SetFlash(bool on)
	{
		this.bgImage.color = (on ? this.bgFlashColour : this.bgDefaultColour);
	}

	// Token: 0x06000480 RID: 1152 RVA: 0x0001470C File Offset: 0x0001290C
	public void CheckForLevel(bool playSound = true)
	{
		bool flag = this.CheckForLevelExisting();
		if (playSound)
		{
			AudioManager.Play(flag ? "SFX_ValidLevel" : "SFX_InvalidLevel", AudioManager.MixerTarget.UI, null, null);
		}
		this.SwitchLight(flag, true);
		WarpRoom.instance.customWarpRoom.buttons[this.index].SetLevelString(this.inputfield.text);
		PlayerPrefs.SetString(string.Format("CustomInput{0}", this.index), this.inputfield.text);
		WarpRoom.instance.customWarpRoom.warpSphere.gameObject.SetActive(false);
	}

	// Token: 0x06000481 RID: 1153 RVA: 0x000147B8 File Offset: 0x000129B8
	public bool CheckForLevelExisting()
	{
		bool result = false;
		using (List<string>.Enumerator enumerator = LevelSerializer.instance.userCreatedList.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if (enumerator.Current == this.inputfield.text)
				{
					result = true;
					break;
				}
			}
		}
		return result;
	}

	// Token: 0x06000482 RID: 1154 RVA: 0x00014820 File Offset: 0x00012A20
	public void SetRandomLevel(int index)
	{
		this.inputfield.text = LevelSerializer.instance.userCreatedList[index];
	}

	// Token: 0x06000484 RID: 1156 RVA: 0x0001484C File Offset: 0x00012A4C
	[CompilerGenerated]
	private IEnumerator <SwitchLight>g__Routine|13_0()
	{
		float t = 0f;
		while (t < 1f)
		{
			this.lightImage.color = Color.Lerp(this.errorColor, this.offColour, t);
			t += Time.deltaTime;
			yield return new WaitForEndOfFrame();
		}
		this.lightImage.color = this.offColour;
		yield break;
	}

	// Token: 0x0400031E RID: 798
	public TMP_InputField inputfield;

	// Token: 0x0400031F RID: 799
	public Image lightImage;

	// Token: 0x04000320 RID: 800
	public Image bgImage;

	// Token: 0x04000321 RID: 801
	public Color offColour;

	// Token: 0x04000322 RID: 802
	public Color onColour;

	// Token: 0x04000323 RID: 803
	public Color errorColor;

	// Token: 0x04000324 RID: 804
	public Color bgDefaultColour;

	// Token: 0x04000325 RID: 805
	public Color bgFlashColour;

	// Token: 0x04000326 RID: 806
	public int index = -1;

	// Token: 0x04000327 RID: 807
	public string startingString;
}
