﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x02000070 RID: 112
public class NGinBoss : Boss
{
	// Token: 0x17000089 RID: 137
	// (get) Token: 0x06000313 RID: 787 RVA: 0x0000D61B File Offset: 0x0000B81B
	protected override BossPhase[] Phases
	{
		get
		{
			return null;
		}
	}

	// Token: 0x06000314 RID: 788 RVA: 0x0000D61E File Offset: 0x0000B81E
	protected override void PerformLogic()
	{
	}

	// Token: 0x06000315 RID: 789 RVA: 0x0000D620 File Offset: 0x0000B820
	protected override void Start()
	{
		base.Start();
		this.floor.RaisePlatformSouth();
		base.StartCoroutine(this.<Start>g__TempRoutine|5_0());
	}

	// Token: 0x06000316 RID: 790 RVA: 0x0000D640 File Offset: 0x0000B840
	public override void Spin(CrashController crash)
	{
		NGinBoss.<>c__DisplayClass6_0 CS$<>8__locals1 = new NGinBoss.<>c__DisplayClass6_0();
		CS$<>8__locals1.crash = crash;
		CS$<>8__locals1.<>4__this = this;
		base.LoseHP();
		if (this.currentHP <= 0)
		{
			base.StartCoroutine(CS$<>8__locals1.<Spin>g__WaitAndLoad|0());
			return;
		}
		this.SwitchSides();
		this.floor.LowerAll();
		base.StartCoroutine(CS$<>8__locals1.<Spin>g__TempRoutine|1());
	}

	// Token: 0x06000317 RID: 791 RVA: 0x0000D69C File Offset: 0x0000B89C
	private void SwitchSides()
	{
		if (base.transform.position.z > 0f)
		{
			CameraManager.instance.SetVCam(this.cams.followCamSouth);
		}
		else
		{
			CameraManager.instance.SetVCam(this.cams.followCamNorth);
		}
		base.transform.position = new Vector3(0f, base.transform.position.y, -base.transform.position.z);
		base.transform.rotation *= Quaternion.Euler(0f, 180f, 0f);
	}

	// Token: 0x06000319 RID: 793 RVA: 0x0000D754 File Offset: 0x0000B954
	[CompilerGenerated]
	private IEnumerator <Start>g__TempRoutine|5_0()
	{
		yield return new WaitForSeconds(4f);
		this.floor.Randomize();
		yield break;
	}

	// Token: 0x040001E6 RID: 486
	public BossCamera cams;

	// Token: 0x040001E7 RID: 487
	public TileFloorController floor;
}
