﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000087 RID: 135
public class ConfirmSaveUI : MonoBehaviour
{
	// Token: 0x060003B7 RID: 951 RVA: 0x0000F9FF File Offset: 0x0000DBFF
	public void Open(Action confirmAction)
	{
		UIScreen.Focus(this.screen);
		this.nameField.text = SaveData.Info.name;
		this.slotUI.Refresh();
		this.onConfirm = confirmAction;
	}

	// Token: 0x060003B8 RID: 952 RVA: 0x0000FA34 File Offset: 0x0000DC34
	public void Confirm()
	{
		SaveData.Info.name = this.nameField.text;
		if (string.IsNullOrWhiteSpace(SaveData.Info.name))
		{
			SaveData.Info.name = "Crash B.";
		}
		Action action = this.onConfirm;
		if (action != null)
		{
			action();
		}
		this.onConfirm = null;
		UIScreen.activeScreen.BackOrClose();
	}

	// Token: 0x060003B9 RID: 953 RVA: 0x0000FA98 File Offset: 0x0000DC98
	public void Cancel()
	{
		this.onConfirm = null;
		UIScreen.activeScreen.BackOrClose();
	}

	// Token: 0x04000273 RID: 627
	public UIScreen screen;

	// Token: 0x04000274 RID: 628
	public TMP_InputField nameField;

	// Token: 0x04000275 RID: 629
	public SaveSlotUI slotUI;

	// Token: 0x04000276 RID: 630
	private Action onConfirm;
}
