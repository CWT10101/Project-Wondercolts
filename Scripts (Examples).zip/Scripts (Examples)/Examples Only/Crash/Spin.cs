﻿using System;
using UnityEngine;

// Token: 0x02000157 RID: 343
public class Spin : MonoBehaviour
{
	// Token: 0x060009F5 RID: 2549 RVA: 0x00027ED1 File Offset: 0x000260D1
	private void Update()
	{
		base.transform.localRotation = Quaternion.AngleAxis(this.curve.Evaluate(Time.time * this.rate) * 360f, this.axis);
	}

	// Token: 0x04000729 RID: 1833
	public Vector3 axis = Vector3.up;

	// Token: 0x0400072A RID: 1834
	public float rate;

	// Token: 0x0400072B RID: 1835
	public AnimationCurve curve;
}
