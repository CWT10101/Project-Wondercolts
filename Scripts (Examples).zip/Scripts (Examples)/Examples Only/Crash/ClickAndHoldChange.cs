﻿using System;
using LevelEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Token: 0x02000082 RID: 130
public class ClickAndHoldChange : MonoBehaviour, IPointerDownHandler, IEventSystemHandler, IPointerUpHandler, IPointerExitHandler
{
	// Token: 0x0600039C RID: 924 RVA: 0x0000F6A8 File Offset: 0x0000D8A8
	public void CycleIndex()
	{
		if (this.currentIndex < this.strings.Length - 1)
		{
			this.currentIndex++;
		}
		else
		{
			this.currentIndex = 0;
		}
		this.affectedIcon.sprite = this.icons[this.currentIndex];
		AudioManager.Play("SFX_ValidLevel", AudioManager.MixerTarget.SFX, null, null);
	}

	// Token: 0x0600039D RID: 925 RVA: 0x0000F714 File Offset: 0x0000D914
	private void Update()
	{
		if (this.isHolding)
		{
			this.counter += Time.deltaTime;
			if (this.counter >= (float)this.changeTime)
			{
				this.CycleIndex();
				this.counter = 0f;
			}
		}
	}

	// Token: 0x0600039E RID: 926 RVA: 0x0000F750 File Offset: 0x0000D950
	public void OnPointerDown(PointerEventData eventData)
	{
		this.isHolding = true;
	}

	// Token: 0x0600039F RID: 927 RVA: 0x0000F759 File Offset: 0x0000D959
	public void OnPointerExit(PointerEventData eventData)
	{
		this.isHolding = false;
		this.counter = 0f;
	}

	// Token: 0x060003A0 RID: 928 RVA: 0x0000F76D File Offset: 0x0000D96D
	public void OnPointerUp(PointerEventData eventData)
	{
		this.isHolding = false;
		this.counter = 0f;
	}

	// Token: 0x060003A1 RID: 929 RVA: 0x0000F781 File Offset: 0x0000D981
	public void PassObjectToPlace()
	{
		LevelCreator.instance.PassGameObjectToPlace(this.strings[this.currentIndex]);
	}

	// Token: 0x04000264 RID: 612
	public string[] strings;

	// Token: 0x04000265 RID: 613
	public Sprite[] icons;

	// Token: 0x04000266 RID: 614
	public Image affectedIcon;

	// Token: 0x04000267 RID: 615
	private int currentIndex;

	// Token: 0x04000268 RID: 616
	public float counter;

	// Token: 0x04000269 RID: 617
	public int changeTime = 5;

	// Token: 0x0400026A RID: 618
	private bool isHolding;
}
