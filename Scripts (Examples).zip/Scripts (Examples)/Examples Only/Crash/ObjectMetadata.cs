﻿using System;
using System.IO;
using LevelEditor;
using UnityEngine;

// Token: 0x02000038 RID: 56
public abstract class ObjectMetadata : MonoBehaviour
{
	// Token: 0x1700005F RID: 95
	// (get) Token: 0x06000174 RID: 372
	public abstract bool SupportsMultiEditing { get; }

	// Token: 0x17000060 RID: 96
	// (get) Token: 0x06000175 RID: 373
	public abstract int Signature { get; }

	// Token: 0x17000061 RID: 97
	// (get) Token: 0x06000176 RID: 374
	public abstract int ValueHash { get; }

	// Token: 0x06000177 RID: 375
	public abstract void Serialize(BinaryWriter bw);

	// Token: 0x06000178 RID: 376
	public abstract void Deserialize(BinaryReader br, Tile[,] grid);

	// Token: 0x06000179 RID: 377
	public abstract void Apply(LevelObj obj);

	// Token: 0x0600017A RID: 378 RVA: 0x00006C48 File Offset: 0x00004E48
	public virtual void OnDeleted(LevelObj obj)
	{
	}
}
