﻿using System;

// Token: 0x020000CD RID: 205
public interface ISlide
{
	// Token: 0x06000619 RID: 1561
	void Slide(CrashController crash);
}
