﻿using System;
using System.Linq;
using UnityEngine;

// Token: 0x020000D3 RID: 211
public class KongBarrel : Projectile
{
	// Token: 0x170000E5 RID: 229
	// (get) Token: 0x06000624 RID: 1572 RVA: 0x0001ABD9 File Offset: 0x00018DD9
	public CapsuleCollider capCollider
	{
		get
		{
			return this.collider as CapsuleCollider;
		}
	}

	// Token: 0x06000625 RID: 1573 RVA: 0x0001ABE6 File Offset: 0x00018DE6
	private void Start()
	{
		this.trajectory = base.transform.forward;
		if (this.audioSource)
		{
			this.audioSource.enabled = false;
		}
	}

	// Token: 0x06000626 RID: 1574 RVA: 0x0001AC14 File Offset: 0x00018E14
	protected override void Break()
	{
		if (!string.IsNullOrEmpty(this.breakSFX))
		{
			AudioManager.Play(this.breakSFX, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		}
		base.Break();
	}

	// Token: 0x06000627 RID: 1575 RVA: 0x0001AC5C File Offset: 0x00018E5C
	protected override void FixedUpdate()
	{
		this.trajectory += this.gravity * Time.fixedDeltaTime * Vector3.up;
		this.trajectory.Normalize();
		float num = this.flightSpeed * Time.fixedDeltaTime;
		IOrderedEnumerable<RaycastHit> orderedEnumerable = from h in Physics.CapsuleCastAll(this.capPoint1.position, this.capPoint2.position, this.capCollider.radius, this.trajectory.normalized, num, this.collisionMask, QueryTriggerInteraction.Ignore)
		where h.collider.gameObject != base.gameObject
		orderby h.distance
		select h;
		if (orderedEnumerable.Count<RaycastHit>() > 0)
		{
			RaycastHit? raycastHit = null;
			foreach (RaycastHit value in orderedEnumerable)
			{
				CrashController crashController;
				Crate crate;
				ThinIce thinIce;
				Projectile projectile;
				Enemy enemy;
				if (value.collider.TryGetComponentInParent(out crashController))
				{
					if (CrashController.isTriple)
					{
						this.Break();
						return;
					}
					if (this.destroyOnSpin && crashController.animator.currentState == CrashController.instance.animator.spinObj)
					{
						this.Break();
						return;
					}
					CrashController.instance.TakeDamage(this.crashDeathIndex);
					if (this.breakOnImpactingCrash || !crashController.isDead)
					{
						this.Break();
						return;
					}
				}
				else if (this.breaksCrates && value.collider.TryGetComponentInParent(out crate))
				{
					DetonatorCrate detonatorCrate = crate as DetonatorCrate;
					if (detonatorCrate != null && value.collider != crate.collider)
					{
						detonatorCrate.SquashResponse();
					}
					else if (crate is SlamCrate)
					{
						crate.ForceBreak();
					}
					else
					{
						crate.Break();
					}
					if (!crate.isBroken && value.distance > 0f)
					{
						raycastHit = new RaycastHit?(value);
					}
				}
				else if (this.breaksCrates && value.collider.TryGetComponent<ThinIce>(out thinIce))
				{
					thinIce.Break();
				}
				else if (raycastHit == null && value.distance > 0f && !value.collider.TryGetComponent<Projectile>(out projectile) && !value.collider.TryGetComponent<Enemy>(out enemy))
				{
					raycastHit = new RaycastHit?(value);
					break;
				}
			}
			if (raycastHit != null)
			{
				RaycastHit valueOrDefault = raycastHit.GetValueOrDefault();
				Debug.DrawLine(this.capPoint1.position, valueOrDefault.point, Color.green, Time.fixedDeltaTime, false);
				Debug.DrawLine(this.capPoint2.position, valueOrDefault.point, Color.green, Time.fixedDeltaTime, false);
				this.MoveDistance(this.trajectory, valueOrDefault.distance);
				this.Land(valueOrDefault.point, valueOrDefault.normal);
				return;
			}
			this.MoveDistance(this.trajectory, num);
			return;
		}
		else
		{
			this.MoveDistance(this.trajectory, num);
		}
	}

	// Token: 0x06000628 RID: 1576 RVA: 0x0001AF7C File Offset: 0x0001917C
	private void Land(Vector3 point, Vector3 normal)
	{
		if (Vector3.Angle(Vector3.up, normal) > this.slopeLimit)
		{
			Debug.DrawRay(point, normal, Color.red, 1f, false);
			this.Break();
			return;
		}
		this.MoveDistance(normal, this.offset);
		this.trajectory = Vector3.Cross(normal, Vector3.Cross(this.trajectory, normal)) * this.flightSpeed;
		if (this.audioSource)
		{
			this.audioSource.enabled = true;
		}
	}

	// Token: 0x06000629 RID: 1577 RVA: 0x0001B000 File Offset: 0x00019200
	private void MoveDistance(Vector3 dir, float dist)
	{
		base.transform.Translate(dir.normalized * dist, Space.World);
		this.visual.transform.Rotate(base.transform.right, dist * 90f * this.rotateFactor, Space.World);
	}

	// Token: 0x0600062A RID: 1578 RVA: 0x0001B050 File Offset: 0x00019250
	protected override void OnTriggerEnter(Collider other)
	{
	}

	// Token: 0x04000480 RID: 1152
	public Transform capPoint1;

	// Token: 0x04000481 RID: 1153
	public Transform capPoint2;

	// Token: 0x04000482 RID: 1154
	public LayerMask collisionMask = -1;

	// Token: 0x04000483 RID: 1155
	public float gravity = -10f;

	// Token: 0x04000484 RID: 1156
	public float rotateFactor = 1f;

	// Token: 0x04000485 RID: 1157
	public float offset = 0.05f;

	// Token: 0x04000486 RID: 1158
	public float slopeLimit = 70f;

	// Token: 0x04000487 RID: 1159
	public AudioSource audioSource;

	// Token: 0x04000488 RID: 1160
	public string breakSFX = "SFX_CrateBreak";

	// Token: 0x04000489 RID: 1161
	public bool destroyOnSpin;

	// Token: 0x0400048A RID: 1162
	public bool breakOnImpactingCrash = true;

	// Token: 0x0400048B RID: 1163
	public bool breaksCrates;

	// Token: 0x0400048C RID: 1164
	private Vector3 trajectory;
}
