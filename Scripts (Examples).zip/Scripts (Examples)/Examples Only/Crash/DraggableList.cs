﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

// Token: 0x0200000C RID: 12
public class DraggableList : MonoBehaviour
{
	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000032 RID: 50 RVA: 0x000031E6 File Offset: 0x000013E6
	// (set) Token: 0x06000033 RID: 51 RVA: 0x000031EE File Offset: 0x000013EE
	public DraggableListElement[] Elements { get; private set; }

	// Token: 0x06000034 RID: 52 RVA: 0x000031F8 File Offset: 0x000013F8
	private void Awake()
	{
		this.Elements = base.GetComponentsInChildren<DraggableListElement>(true);
		DraggableListElement[] elements = this.Elements;
		for (int i = 0; i < elements.Length; i++)
		{
			elements[i].Init(this);
		}
	}

	// Token: 0x06000035 RID: 53 RVA: 0x00003230 File Offset: 0x00001430
	public void DropElement(DraggableListElement element, Vector2 position)
	{
		Debug.Log(position);
		if (!(this.layout is VerticalLayoutGroup))
		{
			if (this.layout is HorizontalLayoutGroup)
			{
				int i;
				for (i = 0; i < this.layout.transform.childCount; i++)
				{
					RectTransform rectTransform = this.layout.transform.GetChild(i) as RectTransform;
					if (rectTransform.TransformPoint(rectTransform.rect.center).x > position.x)
					{
						break;
					}
				}
				int siblingIndex = element.transform.GetSiblingIndex();
				if (siblingIndex < i)
				{
					i--;
				}
				element.transform.SetSiblingIndex(i);
				UnityEvent<int, int> unityEvent = this.onDragged;
				if (unityEvent != null)
				{
					unityEvent.Invoke(siblingIndex, i);
				}
				UnityEvent<int, int> onOrderChanged = element.onOrderChanged;
				if (onOrderChanged == null)
				{
					return;
				}
				onOrderChanged.Invoke(siblingIndex, i);
			}
			return;
		}
		int j;
		for (j = 0; j < this.layout.transform.childCount; j++)
		{
			RectTransform rectTransform2 = this.layout.transform.GetChild(j) as RectTransform;
			if (rectTransform2.TransformPoint(rectTransform2.rect.center).y < position.y)
			{
				break;
			}
		}
		int siblingIndex2 = element.transform.GetSiblingIndex();
		if (siblingIndex2 < j)
		{
			j--;
		}
		element.transform.SetSiblingIndex(j);
		UnityEvent<int, int> unityEvent2 = this.onDragged;
		if (unityEvent2 != null)
		{
			unityEvent2.Invoke(siblingIndex2, j);
		}
		UnityEvent<int, int> onOrderChanged2 = element.onOrderChanged;
		if (onOrderChanged2 == null)
		{
			return;
		}
		onOrderChanged2.Invoke(siblingIndex2, j);
	}

	// Token: 0x0400002E RID: 46
	public LayoutGroup layout;

	// Token: 0x0400002F RID: 47
	public Transform transit;

	// Token: 0x04000030 RID: 48
	public UnityEvent<int, int> onDragged;
}
