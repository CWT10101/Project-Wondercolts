﻿using System;
using UnityEngine;

// Token: 0x0200014A RID: 330
public class FaceCameraUI : MonoBehaviour
{
	// Token: 0x060009B9 RID: 2489 RVA: 0x000274BE File Offset: 0x000256BE
	private void LateUpdate()
	{
		base.transform.forward = Camera.main.transform.forward;
	}
}
