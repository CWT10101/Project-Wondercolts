﻿using System;
using UnityEngine;

// Token: 0x020000C9 RID: 201
public class InvincibilityDamager : MonoBehaviour
{
	// Token: 0x06000611 RID: 1553 RVA: 0x0001A8FC File Offset: 0x00018AFC
	private void OnTriggerEnter(Collider other)
	{
		Crate crate;
		if (!other.TryGetComponent<Crate>(out crate))
		{
			Enemy enemy;
			if (other.TryGetComponent<Enemy>(out enemy))
			{
				enemy.SpinDeath(CrashController.instance.transform);
			}
			return;
		}
		SlamCrate slamCrate = crate as SlamCrate;
		if (slamCrate != null)
		{
			slamCrate.Slam(CrashController.instance);
			return;
		}
		crate.Break();
	}
}
