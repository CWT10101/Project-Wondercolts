﻿using System;

// Token: 0x02000122 RID: 290
public class NoKillsGem : SpecialGem
{
}
