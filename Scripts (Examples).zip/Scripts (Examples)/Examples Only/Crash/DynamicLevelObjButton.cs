﻿using System;
using LevelEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Token: 0x02000018 RID: 24
public class DynamicLevelObjButton : MonoBehaviour, IPointerDownHandler, IEventSystemHandler, IPointerUpHandler, IPointerExitHandler
{
	// Token: 0x0600005C RID: 92 RVA: 0x000039FC File Offset: 0x00001BFC
	public void Init(string obj, Sprite icon, bool flipIcon = false)
	{
		this.plusIconObj.SetActive(string.IsNullOrEmpty(obj));
		this.objName = obj;
		this.objIcon.sprite = icon;
		this.radialFill.fillAmount = 0f;
		if (flipIcon)
		{
			this.objIcon.transform.localScale = new Vector3(-1f, 1f, 1f);
		}
	}

	// Token: 0x0600005D RID: 93 RVA: 0x00003A64 File Offset: 0x00001C64
	public void ClearObject()
	{
		this.Init(null, this.emptySprite, false);
	}

	// Token: 0x0600005E RID: 94 RVA: 0x00003A74 File Offset: 0x00001C74
	private void Update()
	{
		if (this.isHolding)
		{
			this.counter += Time.deltaTime;
			if (this.counter >= this.changeTime)
			{
				this.OpenMenu();
				this.counter = 0f;
			}
			this.radialFill.fillAmount = this.counter / this.changeTime;
		}
	}

	// Token: 0x0600005F RID: 95 RVA: 0x00003AD4 File Offset: 0x00001CD4
	public void OpenMenu()
	{
		AudioManager.Play("SFX_ValidLevel", AudioManager.MixerTarget.SFX, null, null);
		AudioManager.Play("clickUI", AudioManager.MixerTarget.SFX, null, null);
		LevelInterfaceManager.instance.favsButtonContext = this;
		UIScreen.activeScreen.FocusScreen(LevelInterfaceManager.instance.levelObjectSelectionScreen);
	}

	// Token: 0x06000060 RID: 96 RVA: 0x00003B3C File Offset: 0x00001D3C
	public void OnPointerDown(PointerEventData eventData)
	{
		this.isHolding = true;
	}

	// Token: 0x06000061 RID: 97 RVA: 0x00003B45 File Offset: 0x00001D45
	public void OnPointerExit(PointerEventData eventData)
	{
		this.isHolding = false;
		this.counter = 0f;
		this.radialFill.fillAmount = 0f;
	}

	// Token: 0x06000062 RID: 98 RVA: 0x00003B69 File Offset: 0x00001D69
	public void OnPointerUp(PointerEventData eventData)
	{
		this.isHolding = false;
		this.counter = 0f;
		this.radialFill.fillAmount = 0f;
	}

	// Token: 0x06000063 RID: 99 RVA: 0x00003B8D File Offset: 0x00001D8D
	public void PassGameObjectToPlaceHook()
	{
		if (!string.IsNullOrEmpty(this.objName))
		{
			LevelCreator.instance.PassGameObjectToPlace(this.objName);
		}
	}

	// Token: 0x04000047 RID: 71
	public string objName;

	// Token: 0x04000048 RID: 72
	public Image objIcon;

	// Token: 0x04000049 RID: 73
	public Image radialFill;

	// Token: 0x0400004A RID: 74
	public GameObject plusIconObj;

	// Token: 0x0400004B RID: 75
	public float counter;

	// Token: 0x0400004C RID: 76
	public float changeTime = 5f;

	// Token: 0x0400004D RID: 77
	private bool isHolding;

	// Token: 0x0400004E RID: 78
	public DynamicLevelObjButton nextButton;

	// Token: 0x0400004F RID: 79
	public Sprite emptySprite;
}
