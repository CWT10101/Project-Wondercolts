﻿using System;
using Cinemachine;
using UnityEngine;

// Token: 0x02000091 RID: 145
public class CustomWarpRoom : Floor
{
	// Token: 0x04000304 RID: 772
	public CustomWarpRoomButton[] buttons;

	// Token: 0x04000305 RID: 773
	public Transform crashSpawnPoint;

	// Token: 0x04000306 RID: 774
	public CinemachineVirtualCameraBase vcam;

	// Token: 0x04000307 RID: 775
	public WarpToEditorAndPlayTrigger warpSphere;

	// Token: 0x04000308 RID: 776
	public CustomWarpRoomOverlayCanvas overlayCanvas;
}
