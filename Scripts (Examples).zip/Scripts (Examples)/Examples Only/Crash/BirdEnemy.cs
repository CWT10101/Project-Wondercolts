﻿using System;
using System.Collections;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x02000060 RID: 96
public class BirdEnemy : Enemy, IMetadataReceiver<FlipMetadata>, IMetadataReceiver<RotationMetadata>
{
	// Token: 0x1700006C RID: 108
	// (get) Token: 0x06000252 RID: 594 RVA: 0x0000A745 File Offset: 0x00008945
	// (set) Token: 0x06000253 RID: 595 RVA: 0x0000A74D File Offset: 0x0000894D
	public Vector3 Direction { get; private set; }

	// Token: 0x06000254 RID: 596 RVA: 0x0000A756 File Offset: 0x00008956
	protected override void OnEnable()
	{
		base.OnEnable();
		this._dir = this.Direction;
		base.transform.rotation = Quaternion.LookRotation(this._dir);
	}

	// Token: 0x06000255 RID: 597 RVA: 0x0000A780 File Offset: 0x00008980
	protected override void FixedUpdate()
	{
		if (this.isDead)
		{
			return;
		}
		base.FixedUpdate();
		if (!this.isTriggered)
		{
			this.SightCheck();
			return;
		}
		this.controller.Move(this._dir * this.speed * Time.deltaTime);
	}

	// Token: 0x06000256 RID: 598 RVA: 0x0000A7D4 File Offset: 0x000089D4
	public override void ResetEntity()
	{
		this.speed = 0f;
		this.isTriggered = false;
		this.animator.SetTrigger("Reset");
		this._dir = this.Direction;
		base.transform.rotation = Quaternion.LookRotation(this._dir);
		this.hitTrigger.SetActive(false);
		base.ResetEntity();
	}

	// Token: 0x06000257 RID: 599 RVA: 0x0000A837 File Offset: 0x00008A37
	public override void Spin(CrashController crash)
	{
		if (this.GetDirectionalAlignment(crash) > 0.5f)
		{
			this.HurtCrash(crash);
			return;
		}
		this.SpinDeath(crash.transform);
	}

	// Token: 0x06000258 RID: 600 RVA: 0x0000A85B File Offset: 0x00008A5B
	public override void Slide(CrashController crash)
	{
		if (this.GetDirectionalAlignment(crash) > 0.5f)
		{
			this.HurtCrash(crash);
			return;
		}
		this.SpinDeath(crash.transform);
	}

	// Token: 0x06000259 RID: 601 RVA: 0x0000A880 File Offset: 0x00008A80
	private float GetDirectionalAlignment(CrashController crash)
	{
		return Vector3.Dot((crash.controller.ClosestPoint(this.controller.bounds.center) - this.controller.bounds.center).normalized, this.Direction);
	}

	// Token: 0x0600025A RID: 602 RVA: 0x0000A8D8 File Offset: 0x00008AD8
	public virtual void SightCheck()
	{
		if (!MathUtil.InRange(this.collider.bounds.center, CrashController.instance.transform.position, this.sightDistance))
		{
			return;
		}
		foreach (Collider collider in Physics.OverlapSphere(this.collider.bounds.center, this.sightDistance))
		{
			Debug.DrawLine(this.collider.bounds.center, collider.bounds.center, new Color(0f, 1f, 0f, 0.1f), Time.fixedDeltaTime);
			CrashController crashController;
			if (collider.TryGetComponent<CrashController>(out crashController))
			{
				Debug.DrawLine(this.collider.bounds.center, collider.bounds.center, new Color(0f, 1f, 0f), Time.fixedDeltaTime);
				Vector3 normalized = (collider.bounds.center - this.collider.bounds.center).normalized;
				if (Vector3.Dot(normalized, this._dir.normalized) > 0.5f)
				{
					Debug.DrawLine(this.collider.bounds.center, collider.bounds.center, new Color(1f, 1f, 0f), Time.fixedDeltaTime);
					RaycastHit raycastHit = (from h in Physics.RaycastAll(this.collider.bounds.center, normalized, this.sightDistance, -1, QueryTriggerInteraction.Ignore)
					orderby h.distance
					where h.collider.gameObject != base.gameObject
					select h).FirstOrDefault<RaycastHit>();
					if (raycastHit.collider == collider)
					{
						Debug.DrawLine(this.collider.bounds.center, raycastHit.point, new Color(1f, 0f, 0f), 1f);
						this.Swoop();
						return;
					}
				}
			}
		}
	}

	// Token: 0x0600025B RID: 603 RVA: 0x0000AB14 File Offset: 0x00008D14
	public virtual void Swoop()
	{
		if (!this.isDead)
		{
			this.isTriggered = true;
			this.animator.SetTrigger("Swoop");
			AudioManager.Play(this.sfxClip, new Vector3?(base.transform.position), null);
			base.StartCoroutine(this.<Swoop>g__SwoopRoutine|19_0());
			this.hitTrigger.SetActive(true);
		}
	}

	// Token: 0x0600025C RID: 604 RVA: 0x0000AB7E File Offset: 0x00008D7E
	public override void Die(bool useSFX)
	{
		this.hitTrigger.SetActive(false);
		base.Die(useSFX);
	}

	// Token: 0x0600025D RID: 605 RVA: 0x0000AB93 File Offset: 0x00008D93
	public void ProcessMetadata(FlipMetadata meta)
	{
		this.Direction = (meta.isFlipped ? Vector3.right : Vector3.left);
	}

	// Token: 0x0600025E RID: 606 RVA: 0x0000ABAF File Offset: 0x00008DAF
	public void ProcessMetadata(RotationMetadata meta)
	{
		this.Direction = meta.Rotation;
	}

	// Token: 0x06000261 RID: 609 RVA: 0x0000AC04 File Offset: 0x00008E04
	[CompilerGenerated]
	private IEnumerator <Swoop>g__SwoopRoutine|19_0()
	{
		yield return new WaitForSeconds(0.25f);
		this.speed = this.glideSpeed;
		yield break;
	}

	// Token: 0x04000154 RID: 340
	public GameObject hitTrigger;

	// Token: 0x04000155 RID: 341
	public float speed;

	// Token: 0x04000156 RID: 342
	public float glideSpeed = 7f;

	// Token: 0x04000157 RID: 343
	public float sightDistance = 10f;

	// Token: 0x04000158 RID: 344
	public bool isTriggered;

	// Token: 0x0400015A RID: 346
	public CharacterController controller;

	// Token: 0x0400015B RID: 347
	public string sfxClip = "SFX_BirdSwoop";

	// Token: 0x0400015C RID: 348
	private Vector3 _dir;
}
