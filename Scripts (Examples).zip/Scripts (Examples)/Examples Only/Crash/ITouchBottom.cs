﻿using System;

// Token: 0x020000CF RID: 207
public interface ITouchBottom
{
	// Token: 0x0600061B RID: 1563
	void TouchBottom(CrashController crash);
}
