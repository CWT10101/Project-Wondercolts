﻿using System;
using UnityEngine;

// Token: 0x02000088 RID: 136
public class ContactHazard : MonoBehaviour, ISlide, ITouchBottom, ITouchSide, ITouchTop, IFallOn
{
	// Token: 0x060003BB RID: 955 RVA: 0x0000FAB3 File Offset: 0x0000DCB3
	private void Awake()
	{
		if (!this.collider)
		{
			this.collider = base.GetComponent<Collider>();
		}
	}

	// Token: 0x060003BC RID: 956 RVA: 0x0000FACE File Offset: 0x0000DCCE
	public void FallOn(CrashController crash)
	{
		if (this.hazardousSides.HasFlag(ContactHazard.Direction.Top))
		{
			this.DoDamage(crash);
		}
	}

	// Token: 0x060003BD RID: 957 RVA: 0x0000FAF0 File Offset: 0x0000DCF0
	public void Slide(CrashController crash)
	{
		if (this.IsBelow(crash))
		{
			return;
		}
		if (this.IsAbove(crash))
		{
			if (!this.hazardousSides.HasFlag(ContactHazard.Direction.Top))
			{
				return;
			}
			if (!this.hazardousSides.HasFlag(ContactHazard.Direction.Side))
			{
				return;
			}
		}
		this.DoDamage(crash);
	}

	// Token: 0x060003BE RID: 958 RVA: 0x0000FB49 File Offset: 0x0000DD49
	public void TouchBottom(CrashController crash)
	{
		if (this.hazardousSides.HasFlag(ContactHazard.Direction.Bottom))
		{
			this.DoDamage(crash);
		}
	}

	// Token: 0x060003BF RID: 959 RVA: 0x0000FB6A File Offset: 0x0000DD6A
	public void TouchSide(CrashController crash)
	{
		if (this.hazardousSides.HasFlag(ContactHazard.Direction.Side))
		{
			this.DoDamage(crash);
		}
	}

	// Token: 0x060003C0 RID: 960 RVA: 0x0000FB8B File Offset: 0x0000DD8B
	public void TouchTop(CrashController crash)
	{
		if (this.hazardousSides.HasFlag(ContactHazard.Direction.Top))
		{
			this.DoDamage(crash);
		}
	}

	// Token: 0x060003C1 RID: 961 RVA: 0x0000FBAC File Offset: 0x0000DDAC
	protected bool IsAbove(CrashController crash)
	{
		return this.collider.ClosestPoint(crash.controller.ClosestPoint(this.collider.bounds.center)).y - this.collider.bounds.max.y >= 0f;
	}

	// Token: 0x060003C2 RID: 962 RVA: 0x0000FC0C File Offset: 0x0000DE0C
	protected bool IsBelow(CrashController crash)
	{
		return this.collider.ClosestPoint(crash.controller.ClosestPoint(this.collider.bounds.center)).y - this.collider.bounds.min.y <= 0f;
	}

	// Token: 0x060003C3 RID: 963 RVA: 0x0000FC6C File Offset: 0x0000DE6C
	private void DoDamage(CrashController crash)
	{
		if (this.damageEffect != null)
		{
			Object.Instantiate<GameObject>(this.damageEffect, crash.transform.position, Quaternion.identity);
		}
		if (this.isLethal)
		{
			crash.Die(this.crashDeathEffectIndex);
			return;
		}
		crash.TakeDamage(this.crashDeathEffectIndex);
	}

	// Token: 0x04000277 RID: 631
	public Collider collider;

	// Token: 0x04000278 RID: 632
	public int crashDeathEffectIndex;

	// Token: 0x04000279 RID: 633
	public ContactHazard.Direction hazardousSides = (ContactHazard.Direction)(-1);

	// Token: 0x0400027A RID: 634
	public bool isLethal;

	// Token: 0x0400027B RID: 635
	public GameObject damageEffect;

	// Token: 0x020001FB RID: 507
	[Flags]
	public enum Direction
	{
		// Token: 0x04000CA0 RID: 3232
		Top = 1,
		// Token: 0x04000CA1 RID: 3233
		Side = 2,
		// Token: 0x04000CA2 RID: 3234
		Bottom = 4
	}
}
