﻿using System;
using UnityEngine;

// Token: 0x020000F5 RID: 245
[DefaultExecutionOrder(-10)]
public class PathingPlatform : MonoBehaviour, IPlatform
{
	// Token: 0x0600078A RID: 1930 RVA: 0x0001FFD0 File Offset: 0x0001E1D0
	private void FixedUpdate()
	{
		Vector3 nextPosition = this.GetNextPosition();
		this._delta = nextPosition - base.transform.position;
		base.transform.position = nextPosition;
	}

	// Token: 0x0600078B RID: 1931 RVA: 0x00020007 File Offset: 0x0001E207
	public void GetDelta(Transform tf, out Vector3 positionDelta)
	{
		positionDelta = this._delta;
	}

	// Token: 0x0600078C RID: 1932 RVA: 0x00020018 File Offset: 0x0001E218
	public Vector3 GetNextPosition()
	{
		float num = (float)(Time.timeSinceLevelLoadAsDouble * (double)this.speed);
		int num2 = (int)(num % (float)this.points.Length);
		int num3 = (num2 + 1) % this.points.Length;
		float t = num % 1f;
		return Vector3.Lerp(this.points[num2].position, this.points[num3].position, t);
	}

	// Token: 0x0600078D RID: 1933 RVA: 0x00020074 File Offset: 0x0001E274
	private Vector3 P(Vector3 a, Vector3 b, Vector3 c, float t)
	{
		Vector3 a2 = Vector3.Lerp(a, b, t);
		Vector3 b2 = Vector3.Lerp(b, c, t);
		return Vector3.Lerp(a2, b2, t);
	}

	// Token: 0x0600078E RID: 1934 RVA: 0x0002009C File Offset: 0x0001E29C
	public virtual void OnEnter(Transform tf)
	{
	}

	// Token: 0x0600078F RID: 1935 RVA: 0x0002009E File Offset: 0x0001E29E
	public virtual void OnExit(Transform tf)
	{
	}

	// Token: 0x0400059E RID: 1438
	public Transform[] points;

	// Token: 0x0400059F RID: 1439
	public float speed = 1f;

	// Token: 0x040005A0 RID: 1440
	protected Vector3 _delta;
}
