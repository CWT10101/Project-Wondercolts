﻿using System;
using UnityEngine;

// Token: 0x02000125 RID: 293
public class SpeedPitchMetadataReceiver : MonoBehaviour, IMetadataReceiver<SpeedMetadata>
{
	// Token: 0x060008C7 RID: 2247 RVA: 0x0002482E File Offset: 0x00022A2E
	public void ProcessMetadata(SpeedMetadata meta)
	{
		this.source.pitch = this.pitchCurve.Evaluate((float)meta.speed);
	}

	// Token: 0x04000667 RID: 1639
	public AnimationCurve pitchCurve;

	// Token: 0x04000668 RID: 1640
	public AudioSource source;
}
