﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x020000D5 RID: 213
public class Level : MonoBehaviour
{
	// Token: 0x170000E6 RID: 230
	// (get) Token: 0x06000630 RID: 1584 RVA: 0x0001B120 File Offset: 0x00019320
	// (set) Token: 0x06000631 RID: 1585 RVA: 0x0001B127 File Offset: 0x00019327
	public static int LastLoadedIndex { get; private set; } = -1;

	// Token: 0x170000E7 RID: 231
	// (get) Token: 0x06000632 RID: 1586 RVA: 0x0001B12F File Offset: 0x0001932F
	public HashSet<Enemy> EnemiesInLevel { get; } = new HashSet<Enemy>();

	// Token: 0x170000E8 RID: 232
	// (get) Token: 0x06000633 RID: 1587 RVA: 0x0001B137 File Offset: 0x00019337
	public HashSet<Enemy> EnemiesKilled { get; } = new HashSet<Enemy>();

	// Token: 0x170000E9 RID: 233
	// (get) Token: 0x06000634 RID: 1588 RVA: 0x0001B13F File Offset: 0x0001933F
	public bool CollectedAllCratesGem
	{
		get
		{
			return this.allCratesGem != null && this.allCratesGem.Collected;
		}
	}

	// Token: 0x170000EA RID: 234
	// (get) Token: 0x06000635 RID: 1589 RVA: 0x0001B15C File Offset: 0x0001935C
	public bool CollectedSpecialGem
	{
		get
		{
			return this.specialGem != null && this.specialGem.Collected;
		}
	}

	// Token: 0x06000636 RID: 1590 RVA: 0x0001B179 File Offset: 0x00019379
	private void Awake()
	{
		Level.instance = this;
		this.crates = base.GetComponentsInChildren<Crate>();
	}

	// Token: 0x06000637 RID: 1591 RVA: 0x0001B18D File Offset: 0x0001938D
	private void OnDestroy()
	{
		if (Level.instance == this)
		{
			Level.instance = null;
		}
	}

	// Token: 0x06000638 RID: 1592 RVA: 0x0001B1A4 File Offset: 0x000193A4
	private void Start()
	{
		this.InitCratesCollected();
		Level.LastLoadedIndex = this.index;
		this.PlayBGM();
		if (InterfaceManager.instance)
		{
			InterfaceManager.instance.HUD.gameObject.SetActive(true);
		}
		CameraManager.instance.SetVCam(CameraManager.instance.introCam);
		Clock.SetCrashSpawnTime();
		if (BonusManager.instance)
		{
			BonusManager.instance.ResetBonusLivesAndWumpa();
		}
	}

	// Token: 0x06000639 RID: 1593 RVA: 0x0001B218 File Offset: 0x00019418
	public void InitCratesCollected()
	{
		this.crateCollectionText.text = string.Format("{0}/{1}", this.cratesCollected, this.crateCount);
		InterfaceManager.instance.hudTrack.crateCollectionText.text = string.Format("{0}/{1}", this.cratesCollected, this.crateCount);
	}

	// Token: 0x0600063A RID: 1594 RVA: 0x0001B284 File Offset: 0x00019484
	public void UpdateCrateCollectedObj(bool showCrates = true)
	{
		this.crateCollectionText.text = string.Format("{0}/{1}", this.cratesCollected, this.crateCount);
		InterfaceManager.instance.hudTrack.crateCollectionText.text = string.Format("{0}/{1}", this.cratesCollected, this.crateCount);
		if (showCrates)
		{
			InterfaceManager.instance.hudTrack.ShowCrates();
		}
	}

	// Token: 0x0600063B RID: 1595 RVA: 0x0001B302 File Offset: 0x00019502
	private void SpawnCrateGem()
	{
		this.allCratesGem.gameObject.SetActive(true);
	}

	// Token: 0x170000EB RID: 235
	// (get) Token: 0x0600063C RID: 1596 RVA: 0x0001B315 File Offset: 0x00019515
	private HashSet<Crate> CrateSet { get; } = new HashSet<Crate>();

	// Token: 0x0600063D RID: 1597 RVA: 0x0001B320 File Offset: 0x00019520
	public void AddCrateCollected(Crate crate)
	{
		if (!this.CrateSet.Add(crate))
		{
			Debug.LogWarning(string.Format("{0} is already collected", crate));
		}
		this.cratesCollected++;
		this.CheckCratesCollected();
		this.UpdateCrateCollectedObj(false);
		if (CrashController.instance.inBonus)
		{
			BonusManager.instance.AddBonusCrate();
		}
	}

	// Token: 0x0600063E RID: 1598 RVA: 0x0001B37C File Offset: 0x0001957C
	public void RemoveCrateCollected(Crate crate)
	{
		this.CrateSet.Remove(crate);
		this.cratesCollected--;
		this.CheckCratesCollected();
		this.UpdateCrateCollectedObj(false);
	}

	// Token: 0x0600063F RID: 1599 RVA: 0x0001B3A6 File Offset: 0x000195A6
	public void EnemyKilled(Enemy enemy)
	{
		this.EnemiesKilled.Add(enemy);
		InterfaceManager.instance.hudTrack.SetKillsText();
		this.CheckEnemiesKilled();
	}

	// Token: 0x06000640 RID: 1600 RVA: 0x0001B3CA File Offset: 0x000195CA
	public void EnemyReset(Enemy enemy)
	{
		this.EnemiesKilled.Remove(enemy);
		this.CheckEnemiesKilled();
	}

	// Token: 0x06000641 RID: 1601 RVA: 0x0001B3E0 File Offset: 0x000195E0
	public void LevelComplete()
	{
		Debug.Log("Level Complete");
		SaveData.Info.wumpa = (byte)CrashController.instance.pickupHandler.wumpa;
		if (this.CollectedAllCratesGem)
		{
			SaveData.Info.lvlAllCrates[this.index] = true;
		}
		if (this.collectedTape)
		{
			SaveData.Info.lvlTapes[this.index] = true;
		}
		if (this.collectedTrial)
		{
			SaveData.Info.lvlTrials[this.index] = true;
		}
		if (this.CollectedSpecialGem)
		{
			SaveData.Info.lvlSpecialGems[this.index - 5] = true;
		}
		SaveData.Autosave();
	}

	// Token: 0x06000642 RID: 1602 RVA: 0x0001B480 File Offset: 0x00019680
	private void CheckCratesCollected()
	{
		if (this.index != -1 && !SaveData.Info.lvlAllCrates[this.index])
		{
			this.allCratesGem.gameObject.SetActive(this.cratesCollected >= this.crateCount);
		}
		if (this.specialGem is NoCratesGem)
		{
			this.specialGem.gameObject.SetActive(this.cratesCollected <= 0);
			this.crateCollectionObj.SetActive(this.cratesCollected > 0 && this.cratesCollected < this.crateCount);
			return;
		}
		this.crateCollectionObj.SetActive(this.cratesCollected < this.crateCount);
	}

	// Token: 0x06000643 RID: 1603 RVA: 0x0001B534 File Offset: 0x00019734
	private void CheckEnemiesKilled()
	{
		if (this.specialGem is NoKillsGem)
		{
			this.specialGem.gameObject.SetActive(this.EnemiesKilled.Count <= 0);
			return;
		}
		if (this.specialGem is AllKillsGem)
		{
			Debug.Log(string.Format("Kills: {0}/{1}", this.EnemiesKilled.Count, this.EnemiesInLevel.Count));
			this.specialGem.gameObject.SetActive(this.EnemiesKilled.Count >= this.EnemiesInLevel.Count);
		}
	}

	// Token: 0x06000644 RID: 1604 RVA: 0x0001B5D7 File Offset: 0x000197D7
	public void PlayBGM()
	{
	}

	// Token: 0x06000645 RID: 1605 RVA: 0x0001B5D9 File Offset: 0x000197D9
	public static void ClearLastLoadedIndex()
	{
		Level.LastLoadedIndex = -1;
	}

	// Token: 0x0400048F RID: 1167
	public static Level instance;

	// Token: 0x04000491 RID: 1169
	public int index = -1;

	// Token: 0x04000492 RID: 1170
	public new string name;

	// Token: 0x04000493 RID: 1171
	public int crateCount;

	// Token: 0x04000494 RID: 1172
	public int cratesCollected;

	// Token: 0x04000497 RID: 1175
	public GameObject levelObject;

	// Token: 0x04000498 RID: 1176
	public CrystalPickup allCratesGem;

	// Token: 0x04000499 RID: 1177
	public GameObject crateCollectionObj;

	// Token: 0x0400049A RID: 1178
	public TMP_Text crateCollectionText;

	// Token: 0x0400049B RID: 1179
	public TapePickup tape;

	// Token: 0x0400049C RID: 1180
	public SpecialGem specialGem;

	// Token: 0x0400049D RID: 1181
	public bool collectedTape;

	// Token: 0x0400049E RID: 1182
	public bool collectedTrial;

	// Token: 0x0400049F RID: 1183
	private Crate[] crates;
}
