﻿using System;
using UnityEngine;

// Token: 0x0200005D RID: 93
public class BarrelRoll : MonoBehaviour
{
	// Token: 0x06000236 RID: 566 RVA: 0x00009C6F File Offset: 0x00007E6F
	private void FixedUpdate()
	{
		base.transform.localEulerAngles = Vector3.forward * -this.tf.localEulerAngles.z * (1f + this.amount);
	}

	// Token: 0x04000140 RID: 320
	public Transform tf;

	// Token: 0x04000141 RID: 321
	public float amount = 1f;
}
