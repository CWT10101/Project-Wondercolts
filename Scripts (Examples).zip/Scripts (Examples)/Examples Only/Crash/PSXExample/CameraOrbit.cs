﻿using System;
using UnityEngine;

namespace PSXExample
{
	// Token: 0x020001A1 RID: 417
	public class CameraOrbit : MonoBehaviour
	{
		// Token: 0x0600105E RID: 4190 RVA: 0x000393DD File Offset: 0x000375DD
		private void Start()
		{
		}

		// Token: 0x0600105F RID: 4191 RVA: 0x000393E0 File Offset: 0x000375E0
		private void Update()
		{
			base.transform.LookAt(this.origin);
			if (this.scrollControl)
			{
				base.transform.Translate(Vector3.forward * Input.GetAxis("Mouse ScrollWheel") * this.scrollSpeed);
			}
			base.transform.RotateAround(this.origin.position, this.origin.transform.up, Time.deltaTime * this.speed);
		}

		// Token: 0x04000A94 RID: 2708
		public Transform origin;

		// Token: 0x04000A95 RID: 2709
		public float speed = 20f;

		// Token: 0x04000A96 RID: 2710
		public bool scrollControl;

		// Token: 0x04000A97 RID: 2711
		public float scrollSpeed = 10f;
	}
}
