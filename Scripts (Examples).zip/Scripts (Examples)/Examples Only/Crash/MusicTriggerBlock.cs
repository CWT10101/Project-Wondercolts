﻿using System;
using LevelEditor;

// Token: 0x020000EB RID: 235
public class MusicTriggerBlock : BlockTrigger, IMetadataReceiver<MusicMetadata>
{
	// Token: 0x0600072C RID: 1836 RVA: 0x0001E974 File Offset: 0x0001CB74
	public override void Triggered()
	{
		this.SetMusic(this.musicToSet);
		base.Triggered();
	}

	// Token: 0x0600072D RID: 1837 RVA: 0x0001E988 File Offset: 0x0001CB88
	public void SetMusic(int index)
	{
		LevelInterfaceManager.instance.SetMusicForLevel(index);
	}

	// Token: 0x0600072E RID: 1838 RVA: 0x0001E995 File Offset: 0x0001CB95
	public void ProcessMetadata(MusicMetadata meta)
	{
		this.musicToSet = (int)meta.musicIndex;
	}

	// Token: 0x0400055D RID: 1373
	public int musicToSet;
}
