﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

// Token: 0x02000011 RID: 17
public class FileSystemViewer : MonoBehaviour
{
	// Token: 0x06000047 RID: 71 RVA: 0x00003580 File Offset: 0x00001780
	private void Start()
	{
		foreach (string item in from w in this._excludeExtensionsCSV.Split(',', StringSplitOptions.None)
		select w.Trim())
		{
			this.excludeExtensionsSet.Add(item);
		}
		if (!string.IsNullOrWhiteSpace(this._rootDirectory))
		{
			this.Load(this._rootDirectory);
			return;
		}
		this.Load(LevelSerializer.UserCreatedPath);
	}

	// Token: 0x06000048 RID: 72 RVA: 0x00003624 File Offset: 0x00001824
	public void Load(string root)
	{
		Debug.Log("Loading " + root);
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		Queue<string> queue = new Queue<string>();
		queue.Enqueue(root);
		while (queue.Count > 0)
		{
			string text = queue.Dequeue();
			list2.Add(text);
			foreach (string item in Directory.GetDirectories(text))
			{
				queue.Enqueue(item);
			}
			string[] files = Directory.GetFiles(text);
			list.AddRange(from f in files
			where !this.excludeExtensionsSet.Contains(Path.GetExtension(f))
			select f);
		}
		Debug.Log(string.Join("\n", list2));
		Debug.Log(string.Join("\n", list));
	}

	// Token: 0x0400003C RID: 60
	[SerializeField]
	public RectTransform container;

	// Token: 0x0400003D RID: 61
	[SerializeField]
	private string _rootDirectory;

	// Token: 0x0400003E RID: 62
	[SerializeField]
	private string _excludeExtensionsCSV = ".meta";

	// Token: 0x0400003F RID: 63
	private HashSet<string> excludeExtensionsSet = new HashSet<string>();
}
