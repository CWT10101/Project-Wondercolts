﻿using System;
using UnityEngine;

// Token: 0x020000B7 RID: 183
public class FireflyFollower : Pickup
{
	// Token: 0x060005AC RID: 1452 RVA: 0x000191EC File Offset: 0x000173EC
	private void OnDisable()
	{
		Debug.Log("disable");
	}

	// Token: 0x060005AD RID: 1453 RVA: 0x000191F8 File Offset: 0x000173F8
	public virtual void SetTarget(Transform targ)
	{
		this.target = targ;
		if (targ == null && CrashController.instance.pickupHandler.currentFirefly == this)
		{
			CrashController.instance.pickupHandler.currentFirefly = null;
		}
	}

	// Token: 0x060005AE RID: 1454 RVA: 0x00019234 File Offset: 0x00017434
	public override void OnTriggerEnter(Collider other)
	{
		PickupHandler pickupHandler;
		if (other.TryGetComponent<PickupHandler>(out pickupHandler))
		{
			if (pickupHandler.currentFirefly)
			{
				pickupHandler.currentFirefly.timeActive = this.duration - 2f;
			}
			pickupHandler.currentFirefly = this;
			this.TryPushToStack();
			this.SetTarget(pickupHandler.transform);
			this.collider.enabled = false;
			if (this.collectEffect)
			{
				Object.Instantiate<GameObject>(this.collectEffect, base.transform.position, Quaternion.identity);
			}
		}
	}

	// Token: 0x060005AF RID: 1455 RVA: 0x000192C0 File Offset: 0x000174C0
	protected virtual void LateUpdate()
	{
		if (this.target)
		{
			float num = this.orbitRate.Evaluate(this.timeActive);
			float num2 = this.orbitRadius.Evaluate(this.timeActive);
			this.angle += num * Time.deltaTime;
			Vector3 b = new Vector3(num2 * Mathf.Sin(this.angle * 3.1415927f * 2f), this.orbitHeight.Evaluate(this.timeActive), num2 * Mathf.Cos(this.angle * 3.1415927f * 2f));
			base.transform.position = this.target.position + b;
			this.timeActive += Time.deltaTime;
			if (this.timeActive >= this.duration)
			{
				this.FlyAway();
			}
		}
	}

	// Token: 0x060005B0 RID: 1456 RVA: 0x000193A1 File Offset: 0x000175A1
	public override void Spin(CrashController crash)
	{
	}

	// Token: 0x060005B1 RID: 1457 RVA: 0x000193A3 File Offset: 0x000175A3
	public override void ResetEntity()
	{
		Debug.Log("resetentity");
		this.SetTarget(null);
		this.timeActive = 0f;
		this.angle = 0f;
		base.ResetEntity();
	}

	// Token: 0x060005B2 RID: 1458 RVA: 0x000193D2 File Offset: 0x000175D2
	private void FlyAway()
	{
		this.SetTarget(null);
		this.timeActive = 0f;
		this.angle = 0f;
		base.DisableEntity();
	}

	// Token: 0x0400040C RID: 1036
	[ReadOnly]
	public Transform target;

	// Token: 0x0400040D RID: 1037
	public AnimationCurve orbitRadius;

	// Token: 0x0400040E RID: 1038
	public AnimationCurve orbitRate;

	// Token: 0x0400040F RID: 1039
	public AnimationCurve orbitHeight;

	// Token: 0x04000410 RID: 1040
	public float duration = 25f;

	// Token: 0x04000411 RID: 1041
	private float timeActive;

	// Token: 0x04000412 RID: 1042
	private float angle;
}
