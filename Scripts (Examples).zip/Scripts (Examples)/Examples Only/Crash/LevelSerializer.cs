﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using LevelEditor;
using SFB;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

// Token: 0x02000020 RID: 32
public class LevelSerializer : MonoBehaviour
{
	// Token: 0x0600008F RID: 143 RVA: 0x000047EA File Offset: 0x000029EA
	public IEnumerable<string> AllLoadedLevels()
	{
		foreach (string text in this.flashbackTapesList)
		{
			yield return text;
		}
		List<string>.Enumerator enumerator = default(List<string>.Enumerator);
		foreach (string text2 in this.ukaTrialsList)
		{
			yield return text2;
		}
		enumerator = default(List<string>.Enumerator);
		foreach (string text3 in this.userCreatedList)
		{
			yield return text3;
		}
		enumerator = default(List<string>.Enumerator);
		yield break;
		yield break;
	}

	// Token: 0x1700000C RID: 12
	// (get) Token: 0x06000090 RID: 144 RVA: 0x000047FA File Offset: 0x000029FA
	public static string CreatorContentPath
	{
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		get
		{
			return Path.Combine(Application.streamingAssetsPath, "Crash-Creator-Content");
		}
	}

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x06000091 RID: 145 RVA: 0x0000480B File Offset: 0x00002A0B
	public static string FlashbackTapePath
	{
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		get
		{
			return Path.Combine(LevelSerializer.CreatorContentPath, "Flashback-Tapes");
		}
	}

	// Token: 0x1700000E RID: 14
	// (get) Token: 0x06000092 RID: 146 RVA: 0x0000481C File Offset: 0x00002A1C
	public static string UkaTrialsPath
	{
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		get
		{
			return Path.Combine(LevelSerializer.CreatorContentPath, "Uka-Trials");
		}
	}

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x06000093 RID: 147 RVA: 0x0000482D File Offset: 0x00002A2D
	public static string UserCreatedPath
	{
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		get
		{
			return Path.Combine(LevelSerializer.CreatorContentPath, "User-Created");
		}
	}

	// Token: 0x17000010 RID: 16
	// (get) Token: 0x06000094 RID: 148 RVA: 0x0000483E File Offset: 0x00002A3E
	public static string InternalPath
	{
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		get
		{
			return Path.Combine(LevelSerializer.CreatorContentPath, "internal");
		}
	}

	// Token: 0x17000011 RID: 17
	// (get) Token: 0x06000095 RID: 149 RVA: 0x0000484F File Offset: 0x00002A4F
	public static string TempPath
	{
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		get
		{
			return Path.Combine(Application.streamingAssetsPath, ".temp");
		}
	}

	// Token: 0x06000096 RID: 150 RVA: 0x00004860 File Offset: 0x00002A60
	private void Awake()
	{
		LevelSerializer.instance = this;
		Object.DontDestroyOnLoad(base.gameObject);
		BetterStreamingAssets.Initialize();
		this.LoadAllLevelFiles();
		Directory.CreateDirectory(LevelSerializer.TempPath).Attributes |= FileAttributes.Hidden;
	}

	// Token: 0x06000097 RID: 151 RVA: 0x00004895 File Offset: 0x00002A95
	private void OnApplicationQuit()
	{
		Directory.Delete(LevelSerializer.TempPath, true);
	}

	// Token: 0x06000098 RID: 152 RVA: 0x000048A4 File Offset: 0x00002AA4
	public void CreateDirectories()
	{
		if (!new DirectoryInfo(LevelSerializer.CreatorContentPath).Exists)
		{
			Directory.CreateDirectory(LevelSerializer.CreatorContentPath);
		}
		if (!new DirectoryInfo(LevelSerializer.FlashbackTapePath).Exists)
		{
			Directory.CreateDirectory(LevelSerializer.FlashbackTapePath);
		}
		if (!new DirectoryInfo(LevelSerializer.UkaTrialsPath).Exists)
		{
			Directory.CreateDirectory(LevelSerializer.UkaTrialsPath);
		}
		if (!new DirectoryInfo(LevelSerializer.InternalPath).Exists)
		{
			Directory.CreateDirectory(LevelSerializer.InternalPath);
		}
		if (!new DirectoryInfo(LevelSerializer.UserCreatedPath).Exists)
		{
			Directory.CreateDirectory(LevelSerializer.UserCreatedPath);
		}
	}

	// Token: 0x06000099 RID: 153 RVA: 0x00004940 File Offset: 0x00002B40
	private bool GetFromJar(string uri, out byte[] data)
	{
		UnityWebRequest unityWebRequest = UnityWebRequest.Get(uri);
		unityWebRequest.SendWebRequest();
		while (unityWebRequest.result == UnityWebRequest.Result.InProgress)
		{
		}
		if (unityWebRequest.result != UnityWebRequest.Result.Success)
		{
			data = null;
			return false;
		}
		data = unityWebRequest.downloadHandler.data;
		return true;
	}

	// Token: 0x0600009A RID: 154 RVA: 0x00004980 File Offset: 0x00002B80
	private void CopyFromJar(string src, string dest, string filename)
	{
		src = Path.Combine(src, filename);
		dest = Path.Combine(dest, filename);
		byte[] bytes;
		if (this.GetFromJar(src, out bytes))
		{
			File.WriteAllBytes(dest, bytes);
		}
	}

	// Token: 0x0600009B RID: 155 RVA: 0x000049B1 File Offset: 0x00002BB1
	public void LoadAllLevelFiles()
	{
		this.CreateDirectories();
		this.LoadSubFolderContent("Flashback-Tapes", this.flashbackTapesList);
		this.LoadSubFolderContent("Uka-Trials", this.ukaTrialsList);
		this.LoadSubFolderContent("User-Created", this.userCreatedList);
	}

	// Token: 0x0600009C RID: 156 RVA: 0x000049EC File Offset: 0x00002BEC
	public static void SetActiveFolder(string newFolder)
	{
		LevelSerializer.activeFolder = newFolder;
	}

	// Token: 0x0600009D RID: 157 RVA: 0x000049F4 File Offset: 0x00002BF4
	public void LoadSubFolderContent(string subfolder, List<string> listToAdd = null)
	{
		try
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(Path.Combine(LevelSerializer.CreatorContentPath, subfolder));
			if (!directoryInfo.Exists)
			{
				Debug.LogWarning("Directory doesn't exist");
			}
			else
			{
				FileInfo[] files = directoryInfo.GetFiles();
				if (listToAdd != null)
				{
					char[] array = new char[8];
					foreach (FileInfo fileInfo in files)
					{
						using (StreamReader streamReader = fileInfo.OpenText())
						{
							streamReader.ReadBlock(array, 0, 8);
						}
						if (array.SequenceEqual(LevelSerializer.headerLabel))
						{
							listToAdd.Add(fileInfo.Name);
						}
					}
				}
			}
		}
		catch (Exception message)
		{
			Debug.LogError(message);
		}
	}

	// Token: 0x0600009E RID: 158 RVA: 0x00004AB4 File Offset: 0x00002CB4
	public void ReloadUserLevels()
	{
		this.userCreatedList.Clear();
		this.LoadSubFolderContent("User-Created", this.userCreatedList);
	}

	// Token: 0x0600009F RID: 159 RVA: 0x00004AD2 File Offset: 0x00002CD2
	public void SaveLevelButton(string saveName)
	{
		this.SaveLevel("User-Created", saveName);
		this.ReloadFiles();
	}

	// Token: 0x060000A0 RID: 160 RVA: 0x00004AE6 File Offset: 0x00002CE6
	public void LoadLevelButton(string saveName)
	{
		this.LoadLevel(LevelSerializer.activeFolder, saveName);
	}

	// Token: 0x060000A1 RID: 161 RVA: 0x00004AF8 File Offset: 0x00002CF8
	private static string SaveLocation(string saveFolder, string levelName)
	{
		string text = Path.Combine(LevelSerializer.CreatorContentPath, saveFolder);
		if (!Directory.Exists(text))
		{
			Debug.LogWarning("Invalid save location: " + text);
		}
		return Path.Combine(text, levelName);
	}

	// Token: 0x060000A2 RID: 162 RVA: 0x00004B30 File Offset: 0x00002D30
	public static LevelSerializer.LevelHeader GetHeader(string levelName)
	{
		return new LevelSerializer.LevelHeader(LevelSerializer.SaveLocation("User-Created", levelName));
	}

	// Token: 0x060000A3 RID: 163 RVA: 0x00004B44 File Offset: 0x00002D44
	private void SaveLevel(string saveFolder, string saveName)
	{
		LevelObj[] array = Object.FindObjectsOfType<LevelObj>();
		this.saveLevelObjectsList.Clear();
		LevelSerializer.LevelSaveable levelSaveable = new LevelSerializer.LevelSaveable();
		levelSaveable.saveLevelObjectsList = this.saveLevelObjectsList;
		levelSaveable.skyboxIndex = LevelInterfaceManager.instance.currentSkybox;
		levelSaveable.sceneryIndex = LevelInterfaceManager.instance.currentSceneryContent;
		levelSaveable.weatherIndex = LevelInterfaceManager.instance.initialWeather;
		levelSaveable.bgm = LevelInterfaceManager.instance.initialMusic;
		levelSaveable.levelType = LevelInterfaceManager.instance.currentLevelType;
		levelSaveable.authorString = LevelInterfaceManager.instance.levelAuthorInputField.text;
		levelSaveable.levelNameString = LevelInterfaceManager.instance.saveInputField.text;
		levelSaveable.timeTrialTicksBronze = LevelInterfaceManager.instance.timeTrialBronze;
		levelSaveable.timeTrialTicksSilver = LevelInterfaceManager.instance.timeTrialSilver;
		levelSaveable.timeTrialTicksGold = LevelInterfaceManager.instance.timeTrialGold;
		LevelInterfaceManager.instance.levelStats.PopulateStats(levelSaveable);
		string path = LevelSerializer.SaveLocation(saveFolder, saveName);
		try
		{
			using (FileStream fileStream = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None))
			{
				using (BinaryWriter binaryWriter = new BinaryWriter(fileStream))
				{
					binaryWriter.Write(LevelSerializer.headerLabel);
					binaryWriter.Write(4);
					binaryWriter.Write(Application.version);
					binaryWriter.Write(levelSaveable.levelNameString);
					binaryWriter.Write(levelSaveable.authorString);
					binaryWriter.Write(levelSaveable.levelType);
					binaryWriter.Write(levelSaveable.skyboxIndex);
					binaryWriter.Write(levelSaveable.sceneryIndex);
					binaryWriter.Write(levelSaveable.weatherIndex);
					binaryWriter.Write(levelSaveable.bgm);
					if (levelSaveable.levelType == 2)
					{
						binaryWriter.Write(levelSaveable.timeTrialTicksBronze);
						binaryWriter.Write(levelSaveable.timeTrialTicksSilver);
						binaryWriter.Write(levelSaveable.timeTrialTicksGold);
					}
					binaryWriter.Write(array.Length);
					for (int i = 0; i < array.Length; i++)
					{
						array[i].Serialize(binaryWriter);
					}
				}
			}
		}
		catch (Exception ex)
		{
			LevelInterfaceManager.instance.warningScreen.confirmActionButton.onClick.RemoveAllListeners();
			LevelInterfaceManager.instance.warningScreen.SetWarningText("Error Saving", string.Concat(new string[]
			{
				ex.GetType().Name,
				": ",
				ex.Message,
				"\n",
				ex.StackTrace
			}));
			UIScreen.Focus(LevelInterfaceManager.instance.warningScreen.screen);
			throw;
		}
	}

	// Token: 0x060000A4 RID: 164 RVA: 0x00004E08 File Offset: 0x00003008
	public bool LoadLevel(string foldername, string saveName)
	{
		bool result = true;
		string text = LevelSerializer.SaveLocation(foldername, saveName);
		try
		{
			if (!File.Exists(text))
			{
				Debug.LogWarning("Cant find level '" + text + "'");
				result = false;
			}
			else
			{
				LevelSerializer.LevelSaveable levelSaveable = new LevelSerializer.LevelSaveable();
				using (FileStream fileStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					using (BinaryReader binaryReader = new BinaryReader(fileStream))
					{
						binaryReader.ReadChars(LevelSerializer.headerLabel.Length);
						byte b = binaryReader.ReadByte();
						if (b >= 4)
						{
							binaryReader.ReadString();
						}
						levelSaveable.levelNameString = binaryReader.ReadString();
						levelSaveable.authorString = binaryReader.ReadString();
						levelSaveable.levelType = binaryReader.ReadInt32();
						levelSaveable.skyboxIndex = binaryReader.ReadInt32();
						levelSaveable.sceneryIndex = binaryReader.ReadInt32();
						if (b > 2)
						{
							levelSaveable.weatherIndex = binaryReader.ReadInt32();
						}
						levelSaveable.bgm = binaryReader.ReadInt32();
						if (levelSaveable.levelType == 2)
						{
							levelSaveable.timeTrialTicksBronze = binaryReader.ReadInt32();
							levelSaveable.timeTrialTicksSilver = binaryReader.ReadInt32();
							levelSaveable.timeTrialTicksGold = binaryReader.ReadInt32();
						}
						if (b == 1)
						{
							levelSaveable.saveLevelObjectsList = new List<SaveableLevelObject>();
							int num = binaryReader.ReadInt32();
							for (int i = 0; i < num; i++)
							{
								levelSaveable.saveLevelObjectsList.Add(new SaveableLevelObject
								{
									obj_ID = binaryReader.ReadString(),
									posX = binaryReader.ReadInt32(),
									posY = binaryReader.ReadInt32()
								});
							}
						}
						else if (b == 2)
						{
							levelSaveable.saveLevelObjectsList = new List<SaveableLevelObject>();
							int num2 = binaryReader.ReadInt32();
							for (int j = 0; j < num2; j++)
							{
								levelSaveable.saveLevelObjectsList.Add(LevelObj.Deserialize(b, binaryReader));
							}
						}
						else
						{
							if (b != 3 && b != 4)
							{
								Debug.LogError("Unknown version number " + b.ToString());
								return false;
							}
							levelSaveable.saveLevelObjectsList = new List<SaveableLevelObject>();
							int num3 = binaryReader.ReadInt32();
							for (int k = 0; k < num3; k++)
							{
								levelSaveable.saveLevelObjectsList.Add(LevelObj.Deserialize(b, binaryReader));
							}
						}
					}
				}
				LevelInterfaceManager.instance.saveInputField.text = levelSaveable.levelNameString;
				if (levelSaveable.saveLevelObjectsList.FirstOrDefault((SaveableLevelObject obj) => obj.obj_ID == "Obj_CrashSpawnPoint") == null)
				{
					Debug.LogWarning("No spawnpoint!");
					LevelInterfaceManager.instance.editorOverlay.SetActive(true);
				}
				this.LoadLevelActual(levelSaveable);
			}
		}
		catch (Exception ex)
		{
			LevelInterfaceManager.instance.warningScreen.confirmActionButton.onClick.RemoveAllListeners();
			LevelInterfaceManager.instance.warningScreen.SetWarningText("Error Loading", string.Concat(new string[]
			{
				ex.GetType().Name,
				": ",
				ex.Message,
				"\n",
				ex.StackTrace
			}));
			UIScreen.Focus(LevelInterfaceManager.instance.warningScreen.screen);
			throw;
		}
		return result;
	}

	// Token: 0x060000A5 RID: 165 RVA: 0x00005170 File Offset: 0x00003370
	private void LoadLevelActual(LevelSerializer.LevelSaveable levelSaveable)
	{
		LevelManager.instance.ClearSceneObjects();
		LevelInterfaceManager.instance.SetSkyboxContent(levelSaveable.skyboxIndex);
		LevelInterfaceManager.instance.SetSceneryContent(levelSaveable.sceneryIndex);
		LevelInterfaceManager.instance.SetWeatherContent(levelSaveable.weatherIndex);
		LevelInterfaceManager.instance.initialMusic = levelSaveable.bgm;
		LevelManager.instance.SetLevelMusic(levelSaveable.bgm);
		LevelManager.instance.SetLevelType(levelSaveable.levelType);
		LevelInterfaceManager.instance.levelStats.PopulateStats(levelSaveable);
		LevelInterfaceManager.instance.levelAuthorInputField.text = levelSaveable.authorString;
		LevelInterfaceManager.instance.musicDropdown.SetValueWithoutNotify(levelSaveable.bgm);
		LevelInterfaceManager.instance.currentMusic = levelSaveable.bgm;
		LevelInterfaceManager.instance.levelTypeDropdown.SetValueWithoutNotify(levelSaveable.levelType);
		LevelInterfaceManager.instance.currentLevelType = levelSaveable.levelType;
		LevelInterfaceManager.instance.timeTrialBronze = levelSaveable.timeTrialTicksBronze;
		LevelInterfaceManager.instance.timeTrialSilver = levelSaveable.timeTrialTicksSilver;
		LevelInterfaceManager.instance.timeTrialGold = levelSaveable.timeTrialTicksGold;
		InterfaceManager.instance.SetTitleAndAuthor(levelSaveable.levelNameString, levelSaveable.authorString);
		if (LevelInterfaceManager.instance.currentLevelType == 2)
		{
			LevelInterfaceManager.instance.goldInputfield.text = string.Format("{0:0.##}", (float)levelSaveable.timeTrialTicksGold * Time.fixedUnscaledDeltaTime);
			LevelInterfaceManager.instance.silverInputfield.text = string.Format("{0:0.##}", (float)levelSaveable.timeTrialTicksSilver * Time.fixedUnscaledDeltaTime);
			LevelInterfaceManager.instance.bronzeInputfield.text = string.Format("{0:0.##}", (float)levelSaveable.timeTrialTicksBronze * Time.fixedUnscaledDeltaTime);
		}
		if (!string.IsNullOrEmpty(this.loadOnPlayString))
		{
			Bounds bounds = new Bounds(Vector3.zero, Vector3.zero);
			for (int i = 0; i < levelSaveable.saveLevelObjectsList.Count; i++)
			{
				SaveableLevelObject saveableLevelObject = levelSaveable.saveLevelObjectsList[i];
				bounds.Encapsulate(new Vector3((float)saveableLevelObject.posX, (float)saveableLevelObject.posY, 0f));
			}
			GridManager.instance.sizeX = (int)bounds.max.x + 1;
			GridManager.instance.sizeY = (int)bounds.max.y + 9;
			GridManager.instance.CreateGrid();
		}
		for (int j = 0; j < levelSaveable.saveLevelObjectsList.Count; j++)
		{
			SaveableLevelObject saveableLevelObject2 = levelSaveable.saveLevelObjectsList[j];
			Tile tile = GridManager.instance.grid[saveableLevelObject2.posX, saveableLevelObject2.posY];
			GameObject gameObject = Object.Instantiate<GameObject>(LevelResourcesManager.instance.GetObjBase(saveableLevelObject2.obj_ID).objPrefab, tile.Position, Quaternion.identity);
			gameObject.transform.parent = LevelManager.instance.levelObjectsHolder;
			LevelManager.instance.inSceneLevelObjects.Add(gameObject);
			tile.placedObj = gameObject.GetComponent<LevelObj>();
			tile.placedObj.gridPosX = tile.posX;
			tile.placedObj.gridPosY = tile.posY;
		}
		for (int k = 0; k < levelSaveable.saveLevelObjectsList.Count; k++)
		{
			SaveableLevelObject saveableLevelObject3 = levelSaveable.saveLevelObjectsList[k];
			Tile tile2 = GridManager.instance.grid[saveableLevelObject3.posX, saveableLevelObject3.posY];
			MemoryStream metaStream = saveableLevelObject3.metaStream;
			if (metaStream != null && metaStream.Length > 0L)
			{
				ObjectMetadata[] metadata = tile2.placedObj.GetMetadata();
				using (BinaryReader binaryReader = new BinaryReader(saveableLevelObject3.metaStream))
				{
					binaryReader.BaseStream.Position = 0L;
					for (int l = 0; l < metadata.Length; l++)
					{
						try
						{
							metadata[l].Deserialize(binaryReader, GridManager.instance.grid);
							metadata[l].Apply(tile2.placedObj);
						}
						catch (EndOfStreamException)
						{
						}
						catch (Exception ex)
						{
							Debug.LogError(string.Format("{0} : {1}", metadata[l].GetType(), metadata[l]));
							throw ex;
						}
					}
				}
			}
		}
	}

	// Token: 0x060000A6 RID: 166 RVA: 0x000055C4 File Offset: 0x000037C4
	public void DeleteLevel(string levelName)
	{
		string text = Path.Combine(LevelSerializer.UserCreatedPath, levelName);
		Debug.Log("Deleting level '" + text + "'");
		if (File.Exists(text))
		{
			this.userCreatedList.Remove(text);
			string text2 = Path.Combine(LevelSerializer.TempPath, levelName);
			if (File.Exists(text2))
			{
				File.Delete(text2);
			}
			File.Move(text, text2);
			AudioManager.Play("SFX_Scrap", AudioManager.MixerTarget.SFX, null, null);
			ScreenCanvas.instance.RefreshUserLevels();
			return;
		}
		Debug.LogWarning("file doesn't exist");
	}

	// Token: 0x060000A7 RID: 167 RVA: 0x0000565C File Offset: 0x0000385C
	public void ReloadFiles()
	{
		Button[] componentsInChildren = LevelInterfaceManager.instance.userCreatedButtonHolder.GetComponentsInChildren<Button>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			Object.Destroy(componentsInChildren[i].gameObject);
		}
		componentsInChildren = LevelInterfaceManager.instance.ukaTrialsButtonHolder.GetComponentsInChildren<Button>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			Object.Destroy(componentsInChildren[i].gameObject);
		}
		componentsInChildren = LevelInterfaceManager.instance.flashbackTapesButtonHolder.GetComponentsInChildren<Button>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			Object.Destroy(componentsInChildren[i].gameObject);
		}
		this.userCreatedList.Clear();
		this.flashbackTapesList.Clear();
		this.ukaTrialsList.Clear();
		this.LoadAllLevelFiles();
		LevelInterfaceManager.instance.CreateButtonsForList(this.userCreatedList, LevelInterfaceManager.instance.userCreatedButtonHolder);
		LevelInterfaceManager.instance.CreateButtonsForList(this.ukaTrialsList, LevelInterfaceManager.instance.ukaTrialsButtonHolder);
		LevelInterfaceManager.instance.CreateButtonsForList(this.flashbackTapesList, LevelInterfaceManager.instance.flashbackTapesButtonHolder);
	}

	// Token: 0x060000A8 RID: 168 RVA: 0x00005760 File Offset: 0x00003960
	public void ExportLevel(string saveLocation)
	{
		saveLocation = Path.Combine(LevelSerializer.UserCreatedPath, saveLocation);
		string text = StandaloneFileBrowser.SaveFilePanel("Export Level", "", Path.GetFileName(saveLocation), "");
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		File.Copy(saveLocation, text, true);
	}

	// Token: 0x060000A9 RID: 169 RVA: 0x000057A6 File Offset: 0x000039A6
	public void ImportLevel()
	{
		LevelSerializer.<ImportLevel>g__Import_Internal|49_0(StandaloneFileBrowser.OpenFilePanel("Import Level", "", "", false)[0]);
	}

	// Token: 0x060000AC RID: 172 RVA: 0x00005834 File Offset: 0x00003A34
	[CompilerGenerated]
	internal static void <ImportLevel>g__Import_Internal|49_0(string path)
	{
		Debug.Log("Import file '" + path + "'");
		if (string.IsNullOrWhiteSpace(path))
		{
			return;
		}
		char[] array = new char[8];
		new FileInfo(path).OpenText().ReadBlock(array, 0, 8);
		if (array.SequenceEqual(LevelSerializer.headerLabel))
		{
			File.Copy(path, Path.Combine(LevelSerializer.UserCreatedPath, Path.GetFileNameWithoutExtension(path)), true);
			ScreenCanvas.instance.RefreshUserLevels();
			return;
		}
		Debug.LogError("Invalid level file");
		LevelInterfaceManager.instance.warningScreen.confirmActionButton.onClick.RemoveAllListeners();
		LevelInterfaceManager.instance.warningScreen.SetWarningText("Invalid Level", "The selected file is not a Back In Time level file.");
		UIScreen.Focus(LevelInterfaceManager.instance.warningScreen.screen);
	}

	// Token: 0x0400006B RID: 107
	public static LevelSerializer instance;

	// Token: 0x0400006C RID: 108
	private List<SaveableLevelObject> saveLevelObjectsList = new List<SaveableLevelObject>();

	// Token: 0x0400006D RID: 109
	private List<SaveableTileObject> saveTileObjectsList = new List<SaveableTileObject>();

	// Token: 0x0400006E RID: 110
	public List<string> flashbackTapesList = new List<string>();

	// Token: 0x0400006F RID: 111
	public List<string> ukaTrialsList = new List<string>();

	// Token: 0x04000070 RID: 112
	public List<string> userCreatedList = new List<string>();

	// Token: 0x04000071 RID: 113
	public static string activeFolder = null;

	// Token: 0x04000072 RID: 114
	public const string crashCreatorContent = "Crash-Creator-Content";

	// Token: 0x04000073 RID: 115
	public const string flashbackTapeFolder = "Flashback-Tapes";

	// Token: 0x04000074 RID: 116
	public const string ukaTrialsFolder = "Uka-Trials";

	// Token: 0x04000075 RID: 117
	public const string userCreatedFolder = "User-Created";

	// Token: 0x04000076 RID: 118
	public const string internalFolder = "internal";

	// Token: 0x04000077 RID: 119
	public const string tempFolder = ".temp";

	// Token: 0x04000078 RID: 120
	public string loadOnPlayString;

	// Token: 0x04000079 RID: 121
	public int tapeIndex = -1;

	// Token: 0x0400007A RID: 122
	public int akuHitCounter;

	// Token: 0x0400007B RID: 123
	private static readonly char[] headerLabel = new char[]
	{
		'C',
		'R',
		'A',
		'S',
		'H',
		'L',
		'V',
		'L'
	};

	// Token: 0x020001D6 RID: 470
	[Serializable]
	public class LevelSaveable
	{
		// Token: 0x04000C2B RID: 3115
		public string levelNameString;

		// Token: 0x04000C2C RID: 3116
		public string authorString;

		// Token: 0x04000C2D RID: 3117
		public int levelType;

		// Token: 0x04000C2E RID: 3118
		public int skyboxIndex;

		// Token: 0x04000C2F RID: 3119
		public int weatherIndex;

		// Token: 0x04000C30 RID: 3120
		public int bgm;

		// Token: 0x04000C31 RID: 3121
		public int sceneryIndex;

		// Token: 0x04000C32 RID: 3122
		public int timeTrialTicksBronze;

		// Token: 0x04000C33 RID: 3123
		public int timeTrialTicksSilver;

		// Token: 0x04000C34 RID: 3124
		public int timeTrialTicksGold;

		// Token: 0x04000C35 RID: 3125
		public List<SaveableLevelObject> saveLevelObjectsList;

		// Token: 0x04000C36 RID: 3126
		public List<SaveableTileObject> saveTileObjectsList;
	}

	// Token: 0x020001D7 RID: 471
	public class LevelHeader
	{
		// Token: 0x17000472 RID: 1138
		// (get) Token: 0x06001238 RID: 4664 RVA: 0x00040F62 File Offset: 0x0003F162
		public string Title { get; }

		// Token: 0x17000473 RID: 1139
		// (get) Token: 0x06001239 RID: 4665 RVA: 0x00040F6A File Offset: 0x0003F16A
		public string Author { get; }

		// Token: 0x17000474 RID: 1140
		// (get) Token: 0x0600123A RID: 4666 RVA: 0x00040F72 File Offset: 0x0003F172
		public int LevelType { get; }

		// Token: 0x17000475 RID: 1141
		// (get) Token: 0x0600123B RID: 4667 RVA: 0x00040F7A File Offset: 0x0003F17A
		public int Skybox { get; }

		// Token: 0x17000476 RID: 1142
		// (get) Token: 0x0600123C RID: 4668 RVA: 0x00040F82 File Offset: 0x0003F182
		public int Scenery { get; }

		// Token: 0x17000477 RID: 1143
		// (get) Token: 0x0600123D RID: 4669 RVA: 0x00040F8A File Offset: 0x0003F18A
		public int Music { get; }

		// Token: 0x0600123E RID: 4670 RVA: 0x00040F94 File Offset: 0x0003F194
		public LevelHeader(string file)
		{
			using (FileStream fileStream = new FileStream(file, FileMode.Open))
			{
				using (BinaryReader binaryReader = new BinaryReader(fileStream))
				{
					binaryReader.ReadChars(LevelSerializer.headerLabel.Length);
					if (binaryReader.ReadByte() == 4)
					{
						binaryReader.ReadString();
					}
					this.Title = binaryReader.ReadString();
					this.Author = binaryReader.ReadString();
					this.LevelType = binaryReader.ReadInt32();
					this.Skybox = binaryReader.ReadInt32();
					this.Scenery = binaryReader.ReadInt32();
					this.Music = binaryReader.ReadInt32();
				}
			}
		}
	}
}
