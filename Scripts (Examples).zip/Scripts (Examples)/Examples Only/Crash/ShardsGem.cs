﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000123 RID: 291
public class ShardsGem : SpecialGem
{
	// Token: 0x060008BE RID: 2238 RVA: 0x00024638 File Offset: 0x00022838
	public override void OnTriggerEnter(Collider other)
	{
		PickupHandler pickupHandler;
		if (other.TryGetComponent<PickupHandler>(out pickupHandler))
		{
			this.BecomeShards();
		}
	}

	// Token: 0x060008BF RID: 2239 RVA: 0x00024658 File Offset: 0x00022858
	public void BecomeShards()
	{
		this.visual.SetActive(false);
		this.collider.enabled = false;
		AudioManager.Play(this.becomeShardsSFX, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position), null);
		this.shards.Clear();
		for (int i = 0; i < this.shardCount; i++)
		{
			GemShard gemShard = Object.Instantiate<GemShard>(this.gemShardPrefab, base.transform.position, Quaternion.identity, LevelManager.instance.projectileHolder);
			gemShard.Init(this, i);
			this.shards.Add(gemShard);
			gemShard.transform.position = base.transform.position + this.targetLocations[i];
		}
	}

	// Token: 0x060008C0 RID: 2240 RVA: 0x00024725 File Offset: 0x00022925
	public void CollectShard(int index)
	{
		this.shards[index].collected = true;
		if (this.CheckCompleteCollection())
		{
			this.FinishCollection();
		}
	}

	// Token: 0x060008C1 RID: 2241 RVA: 0x00024748 File Offset: 0x00022948
	public bool CheckCompleteCollection()
	{
		bool flag = false;
		foreach (GemShard gemShard in this.shards)
		{
			Debug.Log(string.Format("Shard Collected: {0}", flag));
			if (!gemShard.collected)
			{
				return false;
			}
			flag = true;
		}
		return flag;
	}

	// Token: 0x060008C2 RID: 2242 RVA: 0x000247BC File Offset: 0x000229BC
	public void FinishCollection()
	{
		this.Despawn();
	}

	// Token: 0x060008C3 RID: 2243 RVA: 0x000247C4 File Offset: 0x000229C4
	public override void ResetEntity()
	{
		this.collider.enabled = true;
		base.ResetEntity();
	}

	// Token: 0x04000662 RID: 1634
	public int shardCount = 3;

	// Token: 0x04000663 RID: 1635
	public GemShard gemShardPrefab;

	// Token: 0x04000664 RID: 1636
	public List<GemShard> shards;

	// Token: 0x04000665 RID: 1637
	public Vector2[] targetLocations;

	// Token: 0x04000666 RID: 1638
	public string becomeShardsSFX;
}
