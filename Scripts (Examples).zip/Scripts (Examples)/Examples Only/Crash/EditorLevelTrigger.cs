﻿using System;
using System.Collections;
using LevelEditor;
using UnityEngine;

// Token: 0x02000019 RID: 25
public class EditorLevelTrigger : MonoBehaviour
{
	// Token: 0x06000065 RID: 101 RVA: 0x00003BC0 File Offset: 0x00001DC0
	private void OnTriggerEnter(Collider other)
	{
		CrashController crashController;
		if (other.TryGetComponent<CrashController>(out crashController) && !this.isTriggered)
		{
			crashController.enabled = false;
			if (!string.IsNullOrEmpty(this.crashAnimState))
			{
				Transform transform = crashController.animator.transform.GetChild(0).Find(this.crashAnimState);
				if (transform)
				{
					Debug.Log(transform, transform);
					crashController.animator.SetState(transform.gameObject, false);
					if (this.setCrashOrientation)
					{
						transform.rotation = Quaternion.LookRotation(base.transform.position - (crashController.transform.position + Vector3.up * this.oriuentationOffset));
					}
				}
				else
				{
					Debug.LogWarning("Didn't find " + this.crashAnimState);
				}
			}
			this.Trigger();
		}
	}

	// Token: 0x06000066 RID: 102 RVA: 0x00003C9C File Offset: 0x00001E9C
	public void Trigger()
	{
		AudioManager.Play("SFX_WarpAreaTriggered", new Vector3?(base.transform.position), null);
		if (LevelInterfaceManager.instance.currentLevelType == 2)
		{
			LevelInterfaceManager.instance.FinishTimeTrial();
		}
		if (CrashController.instance.pickupHandler.currentMask != null)
		{
			CrashController.instance.pickupHandler.LoseMask(false);
		}
		base.StartCoroutine(this.WaitAndLoad());
	}

	// Token: 0x06000067 RID: 103 RVA: 0x00003D18 File Offset: 0x00001F18
	private IEnumerator WaitAndLoad()
	{
		yield return new WaitForSeconds(this.waitTime);
		if (string.IsNullOrEmpty(LevelSerializer.instance.loadOnPlayString))
		{
			LevelManager.instance.SetEditorMode();
		}
		else if (LevelInterfaceManager.instance.currentLevelType == 0)
		{
			LevelManager.instance.LoadWarpRoom();
		}
		else if (LevelInterfaceManager.instance.currentLevelType == 1)
		{
			UIScreen.Focus(LevelInterfaceManager.instance.flashbackResults);
			CrashController.instance.enabled = false;
		}
		else if (LevelInterfaceManager.instance.currentLevelType == 2)
		{
			UIScreen.Focus(LevelInterfaceManager.instance.ukaTrialResults);
			CrashController.instance.enabled = false;
		}
		else if (LevelInterfaceManager.instance.currentLevelType == 3)
		{
			UIScreen.Focus(LevelInterfaceManager.instance.dynamicResults);
			CrashController.instance.enabled = false;
		}
		else
		{
			Debug.LogError("Invalid level type " + LevelInterfaceManager.instance.currentLevelType.ToString());
		}
		yield break;
	}

	// Token: 0x04000050 RID: 80
	public float waitTime = 1f;

	// Token: 0x04000051 RID: 81
	public string crashAnimState = "";

	// Token: 0x04000052 RID: 82
	public bool setCrashOrientation;

	// Token: 0x04000053 RID: 83
	public float oriuentationOffset;

	// Token: 0x04000054 RID: 84
	private bool isTriggered;
}
