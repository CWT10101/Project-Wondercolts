﻿using System;
using UnityEngine;

// Token: 0x02000007 RID: 7
public class CameraReplacementRender : MonoBehaviour
{
	// Token: 0x06000016 RID: 22 RVA: 0x00002936 File Offset: 0x00000B36
	private void Start()
	{
		this.cam.SetReplacementShader(this.shader, "");
		this.rt = RenderTexture.GetTemporary(Screen.width, Screen.height);
		this.cam.targetTexture = this.rt;
	}

	// Token: 0x06000017 RID: 23 RVA: 0x00002974 File Offset: 0x00000B74
	private void OnDestroy()
	{
		RenderTexture.ReleaseTemporary(this.rt);
		this.rt = null;
	}

	// Token: 0x04000014 RID: 20
	[SerializeField]
	private Camera cam;

	// Token: 0x04000015 RID: 21
	[SerializeField]
	private Shader shader;

	// Token: 0x04000016 RID: 22
	private RenderTexture rt;
}
