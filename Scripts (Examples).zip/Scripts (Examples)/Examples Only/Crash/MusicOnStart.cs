﻿using System;
using UnityEngine;

// Token: 0x020000EA RID: 234
public class MusicOnStart : MonoBehaviour
{
	// Token: 0x0600072A RID: 1834 RVA: 0x0001E95A File Offset: 0x0001CB5A
	private void Start()
	{
		AudioManager.PlayMusic(this.music, 1f);
	}

	// Token: 0x0400055C RID: 1372
	public string music;
}
