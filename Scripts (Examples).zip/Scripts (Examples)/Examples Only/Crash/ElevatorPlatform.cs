﻿using System;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x020000A7 RID: 167
[DefaultExecutionOrder(-10)]
public class ElevatorPlatform : MovingPlatform
{
	// Token: 0x06000524 RID: 1316 RVA: 0x00016E68 File Offset: 0x00015068
	public void GoDown()
	{
		if (this.tActive == -1f)
		{
			this.tActive = Time.timeSinceLevelLoad;
			this.goingUp = false;
			UnityEvent unityEvent = this.onStarted;
			if (unityEvent == null)
			{
				return;
			}
			unityEvent.Invoke();
		}
	}

	// Token: 0x06000525 RID: 1317 RVA: 0x00016E99 File Offset: 0x00015099
	public void GoUp()
	{
		if (this.tActive == -2f)
		{
			this.tActive = Time.timeSinceLevelLoad;
			this.goingUp = true;
			UnityEvent unityEvent = this.onStarted;
			if (unityEvent == null)
			{
				return;
			}
			unityEvent.Invoke();
		}
	}

	// Token: 0x06000526 RID: 1318 RVA: 0x00016ECA File Offset: 0x000150CA
	public void SetToTop()
	{
		this.tActive = -1f;
		UnityEvent unityEvent = this.onReachedTop;
		if (unityEvent == null)
		{
			return;
		}
		unityEvent.Invoke();
	}

	// Token: 0x06000527 RID: 1319 RVA: 0x00016EE7 File Offset: 0x000150E7
	public void SetToBottom()
	{
		this.tActive = -2f;
		UnityEvent unityEvent = this.onReachedBottom;
		if (unityEvent == null)
		{
			return;
		}
		unityEvent.Invoke();
	}

	// Token: 0x06000528 RID: 1320 RVA: 0x00016F04 File Offset: 0x00015104
	public override void FixedUpdate()
	{
		this._delta = this.GetNextPosition() - base.transform.position;
		base.transform.position = this.GetNextPosition();
	}

	// Token: 0x06000529 RID: 1321 RVA: 0x00016F34 File Offset: 0x00015134
	public override Vector3 GetNextPosition()
	{
		if (this.tActive == -1f)
		{
			return this.pointA.position;
		}
		if (this.tActive == -2f)
		{
			return this.pointB.position;
		}
		float t = this.speedCurve.Evaluate(Time.timeSinceLevelLoad - this.tActive);
		if (this.goingUp)
		{
			if (Time.timeSinceLevelLoad - this.tActive >= this.speedCurve.keys[this.speedCurve.length - 1].time)
			{
				this.tActive = -1f;
				UnityEvent unityEvent = this.onFinished;
				if (unityEvent != null)
				{
					unityEvent.Invoke();
				}
				UnityEvent unityEvent2 = this.onReachedTop;
				if (unityEvent2 != null)
				{
					unityEvent2.Invoke();
				}
			}
			return Vector3.Lerp(this.pointB.position, this.pointA.position, t);
		}
		if (Time.timeSinceLevelLoad - this.tActive >= this.speedCurve.keys[this.speedCurve.length - 1].time)
		{
			this.tActive = -2f;
			UnityEvent unityEvent3 = this.onFinished;
			if (unityEvent3 != null)
			{
				unityEvent3.Invoke();
			}
			UnityEvent unityEvent4 = this.onReachedBottom;
			if (unityEvent4 != null)
			{
				unityEvent4.Invoke();
			}
		}
		return Vector3.Lerp(this.pointA.position, this.pointB.position, t);
	}

	// Token: 0x040003A0 RID: 928
	public UnityEvent onStarted;

	// Token: 0x040003A1 RID: 929
	public UnityEvent onFinished;

	// Token: 0x040003A2 RID: 930
	public UnityEvent onReachedTop;

	// Token: 0x040003A3 RID: 931
	public UnityEvent onReachedBottom;

	// Token: 0x040003A4 RID: 932
	private float tActive = -1f;

	// Token: 0x040003A5 RID: 933
	private bool goingUp;
}
