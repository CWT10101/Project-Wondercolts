﻿using System;
using UnityEngine;

// Token: 0x020000D9 RID: 217
public class Log : MonoBehaviour, IMetadataReceiver<PhaseMetadata>
{
	// Token: 0x170000EC RID: 236
	// (get) Token: 0x06000657 RID: 1623 RVA: 0x0001BA04 File Offset: 0x00019C04
	private float CurveDuration
	{
		get
		{
			return this.curve[this.curve.length - 1].time;
		}
	}

	// Token: 0x06000658 RID: 1624 RVA: 0x0001BA34 File Offset: 0x00019C34
	private void OnEnable()
	{
		if (!this.hasOffsetData && LevelManager.instance && Mathf.Round(base.transform.position.x) % 2f == 0f)
		{
			this.offset = 0.5f;
		}
	}

	// Token: 0x06000659 RID: 1625 RVA: 0x0001BA84 File Offset: 0x00019C84
	private void FixedUpdate()
	{
		float y = base.transform.localScale.y;
		float num = Time.timeSinceLevelLoad + this.offset * this.CurveDuration;
		base.transform.localScale = new Vector3(1f, this.RemapFrom01(this.curve.Evaluate(num), this.minLength, this.maxLength), 1f);
		if ((num - Time.deltaTime) % this.CurveDuration < this.impactTime && num % this.CurveDuration >= this.impactTime && !string.IsNullOrWhiteSpace(this.sfx))
		{
			AudioManager.Play(this.sfx, AudioManager.MixerTarget.SFX, new Vector3?(base.transform.position + this.direction * this.maxLength), null);
		}
		if (base.transform.localScale.y > y)
		{
			float num2 = Mathf.Abs(base.transform.lossyScale.y - y) / 2f;
			Collider[] array = Physics.OverlapBox(base.transform.position + this.direction * (base.transform.lossyScale.y - num2), new Vector3(this.size, num2, this.size));
			for (int i = 0; i < array.Length; i++)
			{
				CrashController crashController;
				if (array[i].TryGetComponent<CrashController>(out crashController))
				{
					crashController.TakeDamage(this.deathIndex);
					return;
				}
			}
		}
	}

	// Token: 0x0600065A RID: 1626 RVA: 0x0001BC07 File Offset: 0x00019E07
	private float RemapFrom01(float x, float min, float max)
	{
		return x * (max - min) + min;
	}

	// Token: 0x0600065B RID: 1627 RVA: 0x0001BC10 File Offset: 0x00019E10
	public void ProcessMetadata(PhaseMetadata meta)
	{
		this.hasOffsetData = meta.HasData;
		if (this.hasOffsetData)
		{
			this.offset = meta.NormalizedValue;
		}
	}

	// Token: 0x040004AC RID: 1196
	public AnimationCurve curve;

	// Token: 0x040004AD RID: 1197
	public string sfx = "SFX_Impact";

	// Token: 0x040004AE RID: 1198
	public float impactTime = 1f;

	// Token: 0x040004AF RID: 1199
	public float minLength = 0.125f;

	// Token: 0x040004B0 RID: 1200
	public float maxLength = 4f;

	// Token: 0x040004B1 RID: 1201
	public float size = 0.5f;

	// Token: 0x040004B2 RID: 1202
	public int deathIndex = 1;

	// Token: 0x040004B3 RID: 1203
	[SerializeField]
	private Vector3 direction = Vector3.down;

	// Token: 0x040004B4 RID: 1204
	public bool hasOffsetData;

	// Token: 0x040004B5 RID: 1205
	public float offset;
}
