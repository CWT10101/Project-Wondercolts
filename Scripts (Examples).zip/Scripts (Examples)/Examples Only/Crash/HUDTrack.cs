﻿using System;
using LevelEditor;
using TMPro;
using UnityEngine;

// Token: 0x020000C4 RID: 196
public class HUDTrack : MonoBehaviour
{
	// Token: 0x060005ED RID: 1517 RVA: 0x00019FDC File Offset: 0x000181DC
	private void Update()
	{
		this.UpdateWumpaElement();
		this.UpdateLivesElement();
		if (this.IsKillsSpecialGemPresent())
		{
			this.UpdateEnemiesElement();
		}
		this.UpdateDeathElement();
		if (Level.instance || LevelInterfaceManager.instance)
		{
			this.UpdateGemsElement();
		}
		if (Level.instance)
		{
			this.UpdateCrateElement();
		}
	}

	// Token: 0x060005EE RID: 1518 RVA: 0x0001A03C File Offset: 0x0001823C
	public void SetLifeIcon(int index)
	{
		GameObject[] array = this.bandicootIcons;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(false);
		}
		this.bandicootIcons[index].SetActive(true);
		array = this.bonusBandicootIcons;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(false);
		}
		this.bonusBandicootIcons[index].SetActive(true);
	}

	// Token: 0x060005EF RID: 1519 RVA: 0x0001A0A4 File Offset: 0x000182A4
	public void DisplayHUD()
	{
		this.ShowLives();
		this.ShowWumpa();
		if (this.IsKillsSpecialGemPresent())
		{
			this.ShowEnemies();
		}
		this.ShowDeaths();
		if (Level.instance && Level.instance.index != -1 && !BonusManager.instance.inBonus)
		{
			this.ShowCrates();
		}
		if ((Level.instance || LevelInterfaceManager.instance) && (BonusManager.instance == null || !BonusManager.instance.inBonus))
		{
			this.ShowGems();
		}
	}

	// Token: 0x060005F0 RID: 1520 RVA: 0x0001A133 File Offset: 0x00018333
	public void SetLivesText()
	{
		this.livesText.text = string.Format("{0:00}", SaveData.Info.lives);
	}

	// Token: 0x060005F1 RID: 1521 RVA: 0x0001A159 File Offset: 0x00018359
	public void SetWumpaText(int wumpa)
	{
		this.wumpaText.text = string.Format("{0:00}", wumpa);
	}

	// Token: 0x060005F2 RID: 1522 RVA: 0x0001A178 File Offset: 0x00018378
	private void UpdateLivesElement()
	{
		if (this.livesTimer > 0f)
		{
			this.livesTimer -= Time.deltaTime;
			this.livesElement.transform.position = Vector3.Lerp(this.livesElement.transform.position, this.livesShowTarget.position, this.transitionSpeed * Time.deltaTime);
			return;
		}
		this.livesElement.transform.position = Vector3.Lerp(this.livesElement.transform.position, this.livesHideTarget.position, this.transitionSpeed * Time.deltaTime);
	}

	// Token: 0x060005F3 RID: 1523 RVA: 0x0001A220 File Offset: 0x00018420
	private void UpdateWumpaElement()
	{
		if (this.wumpaTimer > 0f)
		{
			this.wumpaTimer -= Time.deltaTime;
			this.wumpaElement.transform.position = Vector3.Lerp(this.wumpaElement.transform.position, this.wumpaShowTarget.position, this.transitionSpeed * Time.deltaTime);
			return;
		}
		this.wumpaElement.transform.position = Vector3.Lerp(this.wumpaElement.transform.position, this.wumpaHideTarget.position, this.transitionSpeed * Time.deltaTime);
	}

	// Token: 0x060005F4 RID: 1524 RVA: 0x0001A2C8 File Offset: 0x000184C8
	private void UpdateGemsElement()
	{
		if (CrashController.instance.inBonus)
		{
			return;
		}
		if (this.gemsTimer > 0f)
		{
			this.gemsTimer -= Time.deltaTime;
			this.gemsElement.transform.position = Vector3.Lerp(this.gemsElement.transform.position, this.gemsShowTarget.position, this.transitionSpeed * Time.deltaTime);
			return;
		}
		this.gemsElement.transform.position = Vector3.Lerp(this.gemsElement.transform.position, this.gemsHideTarget.position, this.transitionSpeed * Time.deltaTime);
	}

	// Token: 0x060005F5 RID: 1525 RVA: 0x0001A37C File Offset: 0x0001857C
	private void UpdateCrateElement()
	{
		if (this.crateCollectionTimer > 0f)
		{
			this.crateCollectionTimer -= Time.deltaTime;
			this.crateElement.transform.position = Vector3.Lerp(this.crateElement.transform.position, this.cratesShowTarget.position, this.transitionSpeed * Time.deltaTime);
			return;
		}
		this.crateElement.transform.position = Vector3.Lerp(this.crateElement.transform.position, this.cratesHideTarget.position, this.transitionSpeed * Time.deltaTime);
	}

	// Token: 0x060005F6 RID: 1526 RVA: 0x0001A424 File Offset: 0x00018624
	private void UpdateEnemiesElement()
	{
		if (this.enemiesTimer > 0f)
		{
			this.enemiesTimer -= Time.deltaTime;
			this.enemiesElement.transform.position = Vector3.Lerp(this.enemiesElement.transform.position, this.enemiesShowTarget.position, this.transitionSpeed * Time.deltaTime);
			return;
		}
		this.enemiesElement.transform.position = Vector3.Lerp(this.enemiesElement.transform.position, this.enemiesHideTarget.position, this.transitionSpeed * Time.deltaTime);
	}

	// Token: 0x060005F7 RID: 1527 RVA: 0x0001A4CC File Offset: 0x000186CC
	private void UpdateDeathElement()
	{
		if (this.deathTimer > 0f)
		{
			this.deathTimer -= Time.deltaTime;
			this.deathsElement.transform.position = Vector3.Lerp(this.deathsElement.transform.position, this.deathShowTarget.position, this.transitionSpeed * Time.deltaTime);
			return;
		}
		this.deathsElement.transform.position = Vector3.Lerp(this.deathsElement.transform.position, this.deathHideTarget.position, this.transitionSpeed * Time.deltaTime);
	}

	// Token: 0x060005F8 RID: 1528 RVA: 0x0001A571 File Offset: 0x00018771
	public void ShowWumpa()
	{
		if (!InterfaceManager.instance.bossUIHolder.activeInHierarchy)
		{
			this.wumpaTimer = this.showLength;
		}
	}

	// Token: 0x060005F9 RID: 1529 RVA: 0x0001A590 File Offset: 0x00018790
	public void ShowLives()
	{
		this.livesTimer = this.showLength;
	}

	// Token: 0x060005FA RID: 1530 RVA: 0x0001A59E File Offset: 0x0001879E
	public void ShowCrates()
	{
		this.crateCollectionTimer = this.showLength;
	}

	// Token: 0x060005FB RID: 1531 RVA: 0x0001A5AC File Offset: 0x000187AC
	public void ShowGems()
	{
		this.gemsTimer = this.showLength;
	}

	// Token: 0x060005FC RID: 1532 RVA: 0x0001A5BA File Offset: 0x000187BA
	public void ShowEnemies()
	{
		this.enemiesTimer = this.showLength;
	}

	// Token: 0x060005FD RID: 1533 RVA: 0x0001A5C8 File Offset: 0x000187C8
	public void ShowDeaths()
	{
		this.deathTimer = this.showLength;
	}

	// Token: 0x060005FE RID: 1534 RVA: 0x0001A5D8 File Offset: 0x000187D8
	public void ClearGems()
	{
		for (int i = 0; i < this.gems.Length; i++)
		{
			this.gems[i].SetActive(false);
		}
		this.scrollIconGO.SetActive(false);
		this.flashbackTapeIconGO.SetActive(false);
	}

	// Token: 0x060005FF RID: 1535 RVA: 0x0001A620 File Offset: 0x00018820
	public void SetKillsText()
	{
		SpecialGem specialGem;
		if (this.IsKillsSpecialGemPresent(out specialGem))
		{
			this.enemiesElement.SetActive(true);
			if (Level.instance)
			{
				this.enemiesText.text = string.Format("{0:00}/{1:00}", Level.instance.EnemiesKilled.Count, (specialGem is AllKillsGem) ? Level.instance.EnemiesInLevel.Count : 0);
				return;
			}
			if (LevelInterfaceManager.instance)
			{
				this.enemiesText.text = string.Format("{0:00}/{1:00}", LevelInterfaceManager.instance.EnemiesKilled.Count, (specialGem is AllKillsGem) ? LevelInterfaceManager.instance.EnemiesInLevel.Count : 0);
				return;
			}
		}
		else
		{
			this.enemiesElement.SetActive(false);
			this.enemiesText.text = "00/00";
		}
	}

	// Token: 0x06000600 RID: 1536 RVA: 0x0001A70C File Offset: 0x0001890C
	public void SetDeathsText()
	{
		if (this.IsNoDeathSpecialGemPresent())
		{
			this.deathsElement.SetActive(true);
			this.deathsText.text = string.Format("{0:00}", CrashController.instance.pickupHandler.deaths);
			return;
		}
		this.deathsElement.SetActive(false);
		this.deathsText.text = "00";
	}

	// Token: 0x06000601 RID: 1537 RVA: 0x0001A774 File Offset: 0x00018974
	public bool IsKillsSpecialGemPresent()
	{
		SpecialGem specialGem;
		return this.IsKillsSpecialGemPresent(out specialGem);
	}

	// Token: 0x06000602 RID: 1538 RVA: 0x0001A78C File Offset: 0x0001898C
	public bool IsKillsSpecialGemPresent(out SpecialGem specialGem)
	{
		if (Level.instance)
		{
			SpecialGem specialGem2 = Level.instance.specialGem;
			if (specialGem2 != null && (specialGem2 is AllKillsGem || specialGem2 is NoKillsGem))
			{
				specialGem = specialGem2;
				return true;
			}
		}
		if (LevelInterfaceManager.instance)
		{
			SpecialGem specialGem3 = LevelInterfaceManager.instance.GetSpecialGem();
			if (specialGem3 != null && (specialGem3 is AllKillsGem || specialGem3 is NoKillsGem))
			{
				specialGem = specialGem3;
				return true;
			}
		}
		specialGem = null;
		return false;
	}

	// Token: 0x06000603 RID: 1539 RVA: 0x0001A7FC File Offset: 0x000189FC
	public bool IsNoDeathSpecialGemPresent()
	{
		return (Level.instance && Level.instance.specialGem is NoDeathGem) || (LevelInterfaceManager.instance && LevelInterfaceManager.instance.GetSpecialGem() is NoDeathGem);
	}

	// Token: 0x0400044F RID: 1103
	public TMP_Text livesText;

	// Token: 0x04000450 RID: 1104
	public TMP_Text wumpaText;

	// Token: 0x04000451 RID: 1105
	public TMP_Text crateCollectionText;

	// Token: 0x04000452 RID: 1106
	public TMP_Text enemiesText;

	// Token: 0x04000453 RID: 1107
	public TMP_Text deathsText;

	// Token: 0x04000454 RID: 1108
	public float showLength = 6f;

	// Token: 0x04000455 RID: 1109
	private float wumpaTimer;

	// Token: 0x04000456 RID: 1110
	private float livesTimer;

	// Token: 0x04000457 RID: 1111
	private float crateCollectionTimer;

	// Token: 0x04000458 RID: 1112
	private float gemsTimer;

	// Token: 0x04000459 RID: 1113
	private float enemiesTimer;

	// Token: 0x0400045A RID: 1114
	private float deathTimer;

	// Token: 0x0400045B RID: 1115
	public float transitionSpeed = 0.25f;

	// Token: 0x0400045C RID: 1116
	public GameObject wumpaElement;

	// Token: 0x0400045D RID: 1117
	public GameObject livesElement;

	// Token: 0x0400045E RID: 1118
	public GameObject crateElement;

	// Token: 0x0400045F RID: 1119
	public GameObject enemiesElement;

	// Token: 0x04000460 RID: 1120
	public GameObject deathsElement;

	// Token: 0x04000461 RID: 1121
	public Transform wumpaShowTarget;

	// Token: 0x04000462 RID: 1122
	public Transform wumpaHideTarget;

	// Token: 0x04000463 RID: 1123
	public Transform livesShowTarget;

	// Token: 0x04000464 RID: 1124
	public Transform livesHideTarget;

	// Token: 0x04000465 RID: 1125
	public Transform cratesShowTarget;

	// Token: 0x04000466 RID: 1126
	public Transform cratesHideTarget;

	// Token: 0x04000467 RID: 1127
	public Transform enemiesShowTarget;

	// Token: 0x04000468 RID: 1128
	public Transform enemiesHideTarget;

	// Token: 0x04000469 RID: 1129
	public Transform deathShowTarget;

	// Token: 0x0400046A RID: 1130
	public Transform deathHideTarget;

	// Token: 0x0400046B RID: 1131
	public GameObject gemsElement;

	// Token: 0x0400046C RID: 1132
	public GameObject[] gems;

	// Token: 0x0400046D RID: 1133
	public GameObject flashbackTapeIconGO;

	// Token: 0x0400046E RID: 1134
	public GameObject scrollIconGO;

	// Token: 0x0400046F RID: 1135
	public Transform gemsShowTarget;

	// Token: 0x04000470 RID: 1136
	public Transform gemsHideTarget;

	// Token: 0x04000471 RID: 1137
	public GameObject[] bandicootIcons;

	// Token: 0x04000472 RID: 1138
	public GameObject[] bonusBandicootIcons;
}
