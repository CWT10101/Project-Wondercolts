﻿using System;
using System.Collections.Generic;

// Token: 0x02000013 RID: 19
public class FSFolder : FSObject
{
	// Token: 0x17000005 RID: 5
	// (get) Token: 0x0600004C RID: 76 RVA: 0x0000371C File Offset: 0x0000191C
	public Dictionary<string, FSFile> Files { get; } = new Dictionary<string, FSFile>();

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x0600004D RID: 77 RVA: 0x00003724 File Offset: 0x00001924
	public Dictionary<string, FSFolder> Folders { get; } = new Dictionary<string, FSFolder>();

	// Token: 0x0600004E RID: 78 RVA: 0x0000372C File Offset: 0x0000192C
	public FSFolder(string name, FSFolder folder) : base(name, folder)
	{
	}

	// Token: 0x0600004F RID: 79 RVA: 0x0000374C File Offset: 0x0000194C
	public FSFile GetFile(string path)
	{
		FSFile result;
		if (this.Files.TryGetValue(path, out result))
		{
			return result;
		}
		return null;
	}

	// Token: 0x06000050 RID: 80 RVA: 0x0000376C File Offset: 0x0000196C
	public FSFolder GetFolder(string path)
	{
		FSFolder result;
		if (this.Folders.TryGetValue(path, out result))
		{
			return result;
		}
		return null;
	}
}
