﻿using System;
using PathCreation;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000064 RID: 100
[DefaultExecutionOrder(-10)]
public class BonusPlatform : MovingPlatform
{
	// Token: 0x06000279 RID: 633 RVA: 0x0000B17A File Offset: 0x0000937A
	public void SetActive()
	{
		this.tActive = Time.timeSinceLevelLoad;
		this.SetSafetyWallsEnabled(true);
	}

	// Token: 0x0600027A RID: 634 RVA: 0x0000B18E File Offset: 0x0000938E
	public void ResetTime()
	{
		this.tActive = -1f;
	}

	// Token: 0x0600027B RID: 635 RVA: 0x0000B19B File Offset: 0x0000939B
	public void SetSafetyWallsEnabled(bool enabled)
	{
		this.safetyWalls.SetActive(enabled);
	}

	// Token: 0x0600027C RID: 636 RVA: 0x0000B1A9 File Offset: 0x000093A9
	public override void FixedUpdate()
	{
		this._delta = this.GetNextPosition() - base.transform.position;
		base.transform.position = this.GetNextPosition();
	}

	// Token: 0x0600027D RID: 637 RVA: 0x0000B1D8 File Offset: 0x000093D8
	public override Vector3 GetNextPosition()
	{
		if (this.tActive == -1f)
		{
			return this.pathCreator.path.GetPoint(0);
		}
		if (this.tActive == -2f)
		{
			return this.pathCreator.path.GetPoint(this.pathCreator.path.NumPoints - 1);
		}
		if (Time.timeSinceLevelLoad - this.tActive >= this.speedCurve.keys[this.speedCurve.length - 1].time)
		{
			this.tActive = -2f;
			UnityEvent unityEvent = this.onEnd;
			if (unityEvent != null)
			{
				unityEvent.Invoke();
			}
			return this.pathCreator.path.GetPoint(this.pathCreator.path.NumPoints - 1);
		}
		return this.pathCreator.path.GetPointAtTime(this.speedCurve.Evaluate(Time.timeSinceLevelLoad - this.tActive), EndOfPathInstruction.Stop);
	}

	// Token: 0x0600027E RID: 638 RVA: 0x0000B2CB File Offset: 0x000094CB
	public void ShowBonusUI(bool show)
	{
		BonusManager.instance.ShowBonusUI(show);
	}

	// Token: 0x0600027F RID: 639 RVA: 0x0000B2D8 File Offset: 0x000094D8
	public override void OnExit(Transform tf)
	{
		Debug.Log("Crash left bonus platform");
	}

	// Token: 0x0400016D RID: 365
	public GameObject safetyWalls;

	// Token: 0x0400016E RID: 366
	public UnityEvent onEnd;

	// Token: 0x0400016F RID: 367
	public PathCreator pathCreator;

	// Token: 0x04000170 RID: 368
	private float tActive = -1f;
}
