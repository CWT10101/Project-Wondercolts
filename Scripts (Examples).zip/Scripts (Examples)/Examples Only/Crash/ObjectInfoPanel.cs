﻿using System;
using System.Collections.Generic;
using System.Linq;
using LevelEditor;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020000F2 RID: 242
public class ObjectInfoPanel : MonoBehaviour
{
	// Token: 0x170000F8 RID: 248
	// (get) Token: 0x0600076B RID: 1899 RVA: 0x0001EFF4 File Offset: 0x0001D1F4
	public static Dictionary<ObjectMetadata, LevelObj> Context { get; } = new Dictionary<ObjectMetadata, LevelObj>();

	// Token: 0x0600076C RID: 1900 RVA: 0x0001EFFB File Offset: 0x0001D1FB
	private void Start()
	{
		this.InitializeMusicDropdown();
	}

	// Token: 0x0600076D RID: 1901 RVA: 0x0001F004 File Offset: 0x0001D204
	public void InitializeMusicDropdown()
	{
		this.musicDropdown.ClearOptions();
		List<string> list = new List<string>();
		for (int i = 0; i < LevelResourcesManager.instance.backgroundSongs.Count; i++)
		{
			list.Add(LevelResourcesManager.instance.backgroundSongs[i]);
		}
		this.musicDropdown.AddOptions(list);
		this.musicDropdown.value = 0;
	}

	// Token: 0x0600076E RID: 1902 RVA: 0x0001F06A File Offset: 0x0001D26A
	private void OnDestroy()
	{
		ObjectInfoPanel.Context.Clear();
	}

	// Token: 0x0600076F RID: 1903 RVA: 0x0001F078 File Offset: 0x0001D278
	public void SetContext(IEnumerable<LevelObj> objs)
	{
		ObjectInfoPanel.Context.Clear();
		ObjectInfoPanel.metadata.Clear();
		if (objs != null && objs.Count<LevelObj>() > 0)
		{
			foreach (IGrouping<Type, ObjectMetadata> grouping in from m in objs.SelectMany((LevelObj o) => o.GetMetadata())
			group m by m.GetType() into g
			where g.Count<ObjectMetadata>() == objs.Count<LevelObj>()
			where (from m in g
			group m by m.Signature).Count<IGrouping<int, ObjectMetadata>>() == 1
			select g)
			{
				ObjectInfoPanel.metadata.Add(grouping.Key, grouping.ToArray<ObjectMetadata>());
				foreach (ObjectMetadata objectMetadata in grouping)
				{
					ObjectInfoPanel.Context.Add(objectMetadata, objectMetadata.GetComponent<LevelObj>());
				}
			}
			if (ObjectInfoPanel.metadata.Count > 0)
			{
				IEnumerable<LevelObj> source = ObjectInfoPanel.Context.Values.Distinct<LevelObj>();
				IGrouping<string, LevelObj>[] array = (from o in source
				group o by o.obj_ID).ToArray<IGrouping<string, LevelObj>>();
				base.gameObject.SetActive(true);
				if (array.Length == 1)
				{
					int num = array[0].Count<LevelObj>();
					if (num == 1)
					{
						this.headerText.text = array[0].Key;
					}
					else
					{
						this.headerText.text = string.Format("{0}x {1}", num, array[0].Key);
					}
				}
				else
				{
					this.headerText.text = string.Format("{0} Objects", source.Count<LevelObj>());
				}
				this.flipPanel.SetActive(false);
				this.connectionsPanel.SetActive(false);
				this.detonationsPanel.SetActive(false);
				this.endpointPanel.SetActive(false);
				this.speedPanel.SetActive(false);
				this.rangePanel.SetActive(false);
				this.canFallPanel.SetActive(false);
				this.statePanel.SetActive(false);
				this.weatherDropdownPanel.SetActive(false);
				this.musicDropdownPanel.SetActive(false);
				this.oneWayTogglePanel.SetActive(false);
				this.phasePanel.SetActive(false);
				this.maxHPPanel.SetActive(false);
				this.aggressionPanel.SetActive(false);
				this.slotCrateOptionsPanel.SetActive(false);
				this.projectileDropdownPanel.SetActive(false);
				this.bonusUIPanel.SetActive(false);
				this.spawnWarpPanel.SetActive(false);
				this.quickThrowPanel.SetActive(false);
				this.shootsOncePanel.SetActive(false);
				using (Dictionary<Type, ObjectMetadata[]>.ValueCollection.Enumerator enumerator3 = ObjectInfoPanel.metadata.Values.GetEnumerator())
				{
					while (enumerator3.MoveNext())
					{
						ObjectMetadata[] source2 = enumerator3.Current;
						bool flag = (from m in source2
						group m by m.ValueHash).Count<IGrouping<int, ObjectMetadata>>() == 1;
						ObjectMetadata objectMetadata2 = source2.FirstOrDefault<ObjectMetadata>();
						FlipMetadata flipMetadata = objectMetadata2 as FlipMetadata;
						if (flipMetadata != null)
						{
							this.flipPanel.SetActive(true);
							this.flipToggle.SetIsOnWithoutNotify(flag && flipMetadata.isFlipped);
							if (!flag)
							{
								this.flipToggle.graphic.CrossFadeAlpha(0.5f, 0f, true);
							}
						}
						else
						{
							WarpSpawnMetadata warpSpawnMetadata = objectMetadata2 as WarpSpawnMetadata;
							if (warpSpawnMetadata != null)
							{
								this.spawnWarpPanel.SetActive(true);
								this.spawnWarpToggle.SetIsOnWithoutNotify(flag && warpSpawnMetadata.spawnsWarpPortal);
								if (!flag)
								{
									this.spawnWarpToggle.graphic.CrossFadeAlpha(0.5f, 0f, true);
								}
							}
							else if (objectMetadata2 is ConnectionsMetadata)
							{
								this.connectionsPanel.SetActive(true);
							}
							else if (objectMetadata2 is DetonatorLinkMetadata)
							{
								this.detonationsPanel.SetActive(true);
							}
							else if (objectMetadata2 is EndpointMetadata)
							{
								this.endpointPanel.SetActive(true);
							}
							else
							{
								SpeedMetadata speedMetadata = objectMetadata2 as SpeedMetadata;
								if (speedMetadata != null)
								{
									this.speedPanel.SetActive(true);
									this.speedSlider.SetValueWithoutNotify((float)(flag ? ((int)speedMetadata.speed) : -1));
								}
								else
								{
									RangeMetadata rangeMetadata = objectMetadata2 as RangeMetadata;
									if (rangeMetadata != null)
									{
										this.rangePanel.SetActive(true);
										this.rangeSlider.SetValueWithoutNotify((float)rangeMetadata.range);
									}
									else
									{
										MaxHPMetadata maxHPMetadata = objectMetadata2 as MaxHPMetadata;
										if (maxHPMetadata != null)
										{
											this.maxHPPanel.SetActive(true);
											this.maxHPSlider.SetValueWithoutNotify((float)maxHPMetadata.maxHP);
										}
										else
										{
											CanFallMetadata canFallMetadata = objectMetadata2 as CanFallMetadata;
											if (canFallMetadata != null)
											{
												this.canFallPanel.SetActive(true);
												this.canFallToggle.SetIsOnWithoutNotify(canFallMetadata.value);
											}
											else
											{
												ShootsOneMetadata shootsOneMetadata = objectMetadata2 as ShootsOneMetadata;
												if (shootsOneMetadata != null)
												{
													this.shootsOncePanel.SetActive(true);
													this.shootsOnceToggle.SetIsOnWithoutNotify(shootsOneMetadata.shootsOnce);
												}
												else
												{
													KongQuickThrowMetadata kongQuickThrowMetadata = objectMetadata2 as KongQuickThrowMetadata;
													if (kongQuickThrowMetadata != null)
													{
														this.quickThrowPanel.SetActive(true);
														this.quickThrowToggle.SetIsOnWithoutNotify(kongQuickThrowMetadata.value);
													}
													else
													{
														StateMetadata stateMetadata = objectMetadata2 as StateMetadata;
														if (stateMetadata != null)
														{
															this.statePanel.SetActive(true);
															this.stateLabel.text = (string.IsNullOrWhiteSpace(stateMetadata.StateDisplayText) ? "State" : stateMetadata.StateDisplayText);
															this.stateSlider.maxValue = (float)stateMetadata.MaxStateValue;
															this.stateSlider.SetValueWithoutNotify((float)stateMetadata.state);
														}
														else
														{
															WeatherMetadata weatherMetadata = objectMetadata2 as WeatherMetadata;
															if (weatherMetadata != null)
															{
																this.weatherDropdownPanel.SetActive(true);
																this.weatherDropdown.SetValueWithoutNotify((int)weatherMetadata.weatherIndex);
															}
															else
															{
																ProjectileMetadata projectileMetadata = objectMetadata2 as ProjectileMetadata;
																if (projectileMetadata != null)
																{
																	this.projectileDropdownPanel.SetActive(true);
																	this.projectileDropdown.ClearOptions();
																	this.projectileDropdown.AddOptions(projectileMetadata.projectileOptions);
																	this.projectileDropdown.SetValueWithoutNotify((int)projectileMetadata.projectileIndex);
																}
																else
																{
																	MusicMetadata musicMetadata = objectMetadata2 as MusicMetadata;
																	if (musicMetadata != null)
																	{
																		this.musicDropdownPanel.SetActive(true);
																		this.musicDropdown.SetValueWithoutNotify((int)musicMetadata.musicIndex);
																	}
																	else
																	{
																		OneWayMetadata oneWayMetadata = objectMetadata2 as OneWayMetadata;
																		if (oneWayMetadata != null)
																		{
																			this.oneWayTogglePanel.SetActive(true);
																			this.oneWayToggle.SetIsOnWithoutNotify(oneWayMetadata.value);
																		}
																		else
																		{
																			BonusUIMetadata bonusUIMetadata = objectMetadata2 as BonusUIMetadata;
																			if (bonusUIMetadata != null)
																			{
																				this.bonusUIPanel.SetActive(true);
																				this.bonusUIToggle.SetIsOnWithoutNotify(bonusUIMetadata.value);
																			}
																			else
																			{
																				SlotCrateMetadata slotCrateMetadata = objectMetadata2 as SlotCrateMetadata;
																				if (slotCrateMetadata != null)
																				{
																					this.slotCrateOptionsPanel.SetActive(true);
																					for (int i = 0; i < this.slotCrateOptionToggles.Length; i++)
																					{
																						this.slotCrateOptionToggles[i].SetIsOnWithoutNotify(slotCrateMetadata.Values[i]);
																					}
																					this.slotCrateMetalToggle.SetIsOnWithoutNotify(slotCrateMetadata.BecomesMetal);
																				}
																				else
																				{
																					PhaseMetadata phaseMetadata = objectMetadata2 as PhaseMetadata;
																					if (phaseMetadata != null)
																					{
																						this.phasePanel.SetActive(true);
																						this.usePhaseToggle.gameObject.SetActive(!phaseMetadata.RequiresData);
																						if (!phaseMetadata.RequiresData)
																						{
																							this.usePhaseToggle.SetIsOnWithoutNotify(phaseMetadata.HasData);
																						}
																						this.phaseSlider.maxValue = (float)(phaseMetadata.Steps - 1);
																						this.phaseSlider.SetValueWithoutNotify((float)phaseMetadata.Value);
																						this.phaseSlider.interactable = phaseMetadata.HasData;
																					}
																					else
																					{
																						AggressionMetadata aggressionMetadata = objectMetadata2 as AggressionMetadata;
																						if (aggressionMetadata != null)
																						{
																							this.aggressionPanel.SetActive(true);
																							this.aggressionSlider.SetValueWithoutNotify((float)aggressionMetadata.aggressionLevel);
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					return;
				}
			}
			base.gameObject.SetActive(false);
			return;
		}
		base.gameObject.SetActive(false);
	}

	// Token: 0x06000770 RID: 1904 RVA: 0x0001F904 File Offset: 0x0001DB04
	public void SetFlip(bool flip)
	{
		FlipMetadata[] array;
		if (ObjectInfoPanel.GetMeta<FlipMetadata>(out array))
		{
			foreach (FlipMetadata flipMetadata in array)
			{
				flipMetadata.isFlipped = flip;
				flipMetadata.Apply(ObjectInfoPanel.Context[flipMetadata]);
			}
		}
	}

	// Token: 0x06000771 RID: 1905 RVA: 0x0001F948 File Offset: 0x0001DB48
	public void SetShootOnce(bool shootsOnce)
	{
		ShootsOneMetadata[] array;
		if (ObjectInfoPanel.GetMeta<ShootsOneMetadata>(out array))
		{
			foreach (ShootsOneMetadata shootsOneMetadata in array)
			{
				shootsOneMetadata.shootsOnce = shootsOnce;
				shootsOneMetadata.Apply(ObjectInfoPanel.Context[shootsOneMetadata]);
			}
		}
	}

	// Token: 0x06000772 RID: 1906 RVA: 0x0001F98C File Offset: 0x0001DB8C
	public void SetWarpSpawn(bool spawnWarp)
	{
		WarpSpawnMetadata[] array;
		if (ObjectInfoPanel.GetMeta<WarpSpawnMetadata>(out array))
		{
			foreach (WarpSpawnMetadata warpSpawnMetadata in array)
			{
				warpSpawnMetadata.spawnsWarpPortal = spawnWarp;
				warpSpawnMetadata.Apply(ObjectInfoPanel.Context[warpSpawnMetadata]);
			}
		}
	}

	// Token: 0x06000773 RID: 1907 RVA: 0x0001F9D0 File Offset: 0x0001DBD0
	public void SetSpeed(float value)
	{
		SpeedMetadata[] array;
		if (ObjectInfoPanel.GetMeta<SpeedMetadata>(out array))
		{
			foreach (SpeedMetadata speedMetadata in array)
			{
				speedMetadata.speed = (byte)value;
				speedMetadata.Apply(ObjectInfoPanel.Context[speedMetadata]);
			}
		}
	}

	// Token: 0x06000774 RID: 1908 RVA: 0x0001FA14 File Offset: 0x0001DC14
	public void SetProjectileIndex(int index)
	{
		ProjectileMetadata[] array;
		if (ObjectInfoPanel.GetMeta<ProjectileMetadata>(out array))
		{
			foreach (ProjectileMetadata projectileMetadata in array)
			{
				projectileMetadata.projectileIndex = (byte)index;
				projectileMetadata.Apply(ObjectInfoPanel.Context[projectileMetadata]);
			}
		}
	}

	// Token: 0x06000775 RID: 1909 RVA: 0x0001FA58 File Offset: 0x0001DC58
	public void SetRange(float value)
	{
		RangeMetadata[] array;
		if (ObjectInfoPanel.GetMeta<RangeMetadata>(out array))
		{
			foreach (RangeMetadata rangeMetadata in array)
			{
				rangeMetadata.range = (byte)value;
				rangeMetadata.Apply(ObjectInfoPanel.Context[rangeMetadata]);
			}
		}
	}

	// Token: 0x06000776 RID: 1910 RVA: 0x0001FA9C File Offset: 0x0001DC9C
	public void SetAggression(float value)
	{
		AggressionMetadata[] array;
		if (ObjectInfoPanel.GetMeta<AggressionMetadata>(out array))
		{
			foreach (AggressionMetadata aggressionMetadata in array)
			{
				aggressionMetadata.aggressionLevel = (byte)value;
				aggressionMetadata.Apply(ObjectInfoPanel.Context[aggressionMetadata]);
			}
		}
	}

	// Token: 0x06000777 RID: 1911 RVA: 0x0001FAE0 File Offset: 0x0001DCE0
	public void SetMaxHP(float value)
	{
		MaxHPMetadata[] array;
		if (ObjectInfoPanel.GetMeta<MaxHPMetadata>(out array))
		{
			foreach (MaxHPMetadata maxHPMetadata in array)
			{
				maxHPMetadata.maxHP = (byte)value;
				maxHPMetadata.Apply(ObjectInfoPanel.Context[maxHPMetadata]);
			}
		}
	}

	// Token: 0x06000778 RID: 1912 RVA: 0x0001FB24 File Offset: 0x0001DD24
	public void SetCanFall(bool value)
	{
		CanFallMetadata[] array;
		if (ObjectInfoPanel.GetMeta<CanFallMetadata>(out array))
		{
			foreach (CanFallMetadata canFallMetadata in array)
			{
				canFallMetadata.value = value;
				canFallMetadata.Apply(ObjectInfoPanel.Context[canFallMetadata]);
			}
		}
	}

	// Token: 0x06000779 RID: 1913 RVA: 0x0001FB68 File Offset: 0x0001DD68
	public void SetQuickThrow(bool value)
	{
		KongQuickThrowMetadata[] array;
		if (ObjectInfoPanel.GetMeta<KongQuickThrowMetadata>(out array))
		{
			foreach (KongQuickThrowMetadata kongQuickThrowMetadata in array)
			{
				kongQuickThrowMetadata.value = value;
				kongQuickThrowMetadata.Apply(ObjectInfoPanel.Context[kongQuickThrowMetadata]);
			}
		}
	}

	// Token: 0x0600077A RID: 1914 RVA: 0x0001FBAC File Offset: 0x0001DDAC
	public void SetBonusUI(bool value)
	{
		BonusUIMetadata[] array;
		if (ObjectInfoPanel.GetMeta<BonusUIMetadata>(out array))
		{
			foreach (BonusUIMetadata bonusUIMetadata in array)
			{
				bonusUIMetadata.value = value;
				bonusUIMetadata.Apply(ObjectInfoPanel.Context[bonusUIMetadata]);
			}
		}
	}

	// Token: 0x0600077B RID: 1915 RVA: 0x0001FBF0 File Offset: 0x0001DDF0
	public void SetOneWay(bool value)
	{
		OneWayMetadata[] array;
		if (ObjectInfoPanel.GetMeta<OneWayMetadata>(out array))
		{
			foreach (OneWayMetadata oneWayMetadata in array)
			{
				oneWayMetadata.value = value;
				oneWayMetadata.Apply(ObjectInfoPanel.Context[oneWayMetadata]);
			}
		}
	}

	// Token: 0x0600077C RID: 1916 RVA: 0x0001FC34 File Offset: 0x0001DE34
	public void SetState(float state)
	{
		StateMetadata[] array;
		if (ObjectInfoPanel.GetMeta<StateMetadata>(out array))
		{
			foreach (StateMetadata stateMetadata in array)
			{
				stateMetadata.state = (byte)state;
				stateMetadata.Apply(ObjectInfoPanel.Context[stateMetadata]);
			}
		}
	}

	// Token: 0x0600077D RID: 1917 RVA: 0x0001FC78 File Offset: 0x0001DE78
	public void SetWeather(int index)
	{
		WeatherMetadata[] array;
		if (ObjectInfoPanel.GetMeta<WeatherMetadata>(out array))
		{
			foreach (WeatherMetadata weatherMetadata in array)
			{
				weatherMetadata.weatherIndex = (byte)index;
				weatherMetadata.Apply(ObjectInfoPanel.Context[weatherMetadata]);
			}
		}
	}

	// Token: 0x0600077E RID: 1918 RVA: 0x0001FCBC File Offset: 0x0001DEBC
	public void SetMusic(int index)
	{
		MusicMetadata[] array;
		if (ObjectInfoPanel.GetMeta<MusicMetadata>(out array))
		{
			foreach (MusicMetadata musicMetadata in array)
			{
				musicMetadata.musicIndex = (sbyte)index;
				musicMetadata.Apply(ObjectInfoPanel.Context[musicMetadata]);
			}
		}
	}

	// Token: 0x0600077F RID: 1919 RVA: 0x0001FD00 File Offset: 0x0001DF00
	public void SetSlots(int index)
	{
		SlotCrateMetadata[] array;
		if (ObjectInfoPanel.GetMeta<SlotCrateMetadata>(out array))
		{
			foreach (SlotCrateMetadata slotCrateMetadata in array)
			{
				if (!this.slotCrateOptionToggles[index].isOn && slotCrateMetadata.Values.CountNotDefault<bool>() <= 1)
				{
					this.slotCrateOptionToggles[index].SetIsOnWithoutNotify(true);
				}
				else
				{
					slotCrateMetadata.SetValue(index, this.slotCrateOptionToggles[index].isOn);
					slotCrateMetadata.Apply(ObjectInfoPanel.Context[slotCrateMetadata]);
				}
			}
		}
	}

	// Token: 0x06000780 RID: 1920 RVA: 0x0001FD7C File Offset: 0x0001DF7C
	public void SetSlotMetal(bool value)
	{
		SlotCrateMetadata[] array;
		if (ObjectInfoPanel.GetMeta<SlotCrateMetadata>(out array))
		{
			foreach (SlotCrateMetadata slotCrateMetadata in array)
			{
				slotCrateMetadata.SetBecomesMetal(value);
				slotCrateMetadata.Apply(ObjectInfoPanel.Context[slotCrateMetadata]);
			}
		}
	}

	// Token: 0x06000781 RID: 1921 RVA: 0x0001FDC0 File Offset: 0x0001DFC0
	public void SetPhase(float value)
	{
		Debug.Log("set phase " + value.ToString());
		PhaseMetadata[] array;
		if (ObjectInfoPanel.GetMeta<PhaseMetadata>(out array))
		{
			foreach (PhaseMetadata phaseMetadata in array)
			{
				phaseMetadata.SetData((byte)value);
				phaseMetadata.Apply(ObjectInfoPanel.Context[phaseMetadata]);
			}
		}
	}

	// Token: 0x06000782 RID: 1922 RVA: 0x0001FE1C File Offset: 0x0001E01C
	public void UsePhase(bool use)
	{
		Debug.Log("use phase " + use.ToString());
		PhaseMetadata[] array;
		if (ObjectInfoPanel.GetMeta<PhaseMetadata>(out array))
		{
			foreach (PhaseMetadata phaseMetadata in array)
			{
				this.phaseSlider.interactable = use;
				if (use)
				{
					phaseMetadata.SetData((byte)this.phaseSlider.value);
				}
				else
				{
					phaseMetadata.ClearData();
				}
				phaseMetadata.Apply(ObjectInfoPanel.Context[phaseMetadata]);
			}
		}
	}

	// Token: 0x06000783 RID: 1923 RVA: 0x0001FE98 File Offset: 0x0001E098
	public static bool GetMeta<T>(out T[] meta) where T : ObjectMetadata
	{
		if (ObjectInfoPanel.metadata.ContainsKey(typeof(T)))
		{
			ObjectMetadata[] array = ObjectInfoPanel.metadata[typeof(T)];
			meta = Array.ConvertAll<ObjectMetadata, T>(array, (ObjectMetadata e) => (T)((object)e));
			return meta != null;
		}
		meta = null;
		return false;
	}

	// Token: 0x04000570 RID: 1392
	public TMP_Text headerText;

	// Token: 0x04000571 RID: 1393
	public Transform itemHolder;

	// Token: 0x04000572 RID: 1394
	public GameObject flipPanel;

	// Token: 0x04000573 RID: 1395
	public GameObject speedPanel;

	// Token: 0x04000574 RID: 1396
	public GameObject rangePanel;

	// Token: 0x04000575 RID: 1397
	public GameObject maxHPPanel;

	// Token: 0x04000576 RID: 1398
	public GameObject connectionsPanel;

	// Token: 0x04000577 RID: 1399
	public GameObject detonationsPanel;

	// Token: 0x04000578 RID: 1400
	public GameObject endpointPanel;

	// Token: 0x04000579 RID: 1401
	public GameObject canFallPanel;

	// Token: 0x0400057A RID: 1402
	public GameObject statePanel;

	// Token: 0x0400057B RID: 1403
	public GameObject weatherDropdownPanel;

	// Token: 0x0400057C RID: 1404
	public GameObject musicDropdownPanel;

	// Token: 0x0400057D RID: 1405
	public GameObject oneWayTogglePanel;

	// Token: 0x0400057E RID: 1406
	public GameObject slotCrateOptionsPanel;

	// Token: 0x0400057F RID: 1407
	public GameObject phasePanel;

	// Token: 0x04000580 RID: 1408
	public GameObject projectileDropdownPanel;

	// Token: 0x04000581 RID: 1409
	public GameObject spawnWarpPanel;

	// Token: 0x04000582 RID: 1410
	public GameObject aggressionPanel;

	// Token: 0x04000583 RID: 1411
	public GameObject bonusUIPanel;

	// Token: 0x04000584 RID: 1412
	public GameObject quickThrowPanel;

	// Token: 0x04000585 RID: 1413
	public GameObject shootsOncePanel;

	// Token: 0x04000586 RID: 1414
	public Toggle flipToggle;

	// Token: 0x04000587 RID: 1415
	public Toggle canFallToggle;

	// Token: 0x04000588 RID: 1416
	public Toggle oneWayToggle;

	// Token: 0x04000589 RID: 1417
	public Toggle[] slotCrateOptionToggles;

	// Token: 0x0400058A RID: 1418
	public Toggle slotCrateMetalToggle;

	// Token: 0x0400058B RID: 1419
	public Toggle usePhaseToggle;

	// Token: 0x0400058C RID: 1420
	public Toggle spawnWarpToggle;

	// Token: 0x0400058D RID: 1421
	public Toggle bonusUIToggle;

	// Token: 0x0400058E RID: 1422
	public Toggle quickThrowToggle;

	// Token: 0x0400058F RID: 1423
	public Toggle shootsOnceToggle;

	// Token: 0x04000590 RID: 1424
	public Slider speedSlider;

	// Token: 0x04000591 RID: 1425
	public Slider rangeSlider;

	// Token: 0x04000592 RID: 1426
	public Slider aggressionSlider;

	// Token: 0x04000593 RID: 1427
	public Slider maxHPSlider;

	// Token: 0x04000594 RID: 1428
	public Slider stateSlider;

	// Token: 0x04000595 RID: 1429
	public Slider phaseSlider;

	// Token: 0x04000596 RID: 1430
	public TMP_Dropdown weatherDropdown;

	// Token: 0x04000597 RID: 1431
	public TMP_Dropdown musicDropdown;

	// Token: 0x04000598 RID: 1432
	public TMP_Dropdown projectileDropdown;

	// Token: 0x04000599 RID: 1433
	public TMP_Text stateLabel;

	// Token: 0x0400059B RID: 1435
	private static readonly Dictionary<Type, ObjectMetadata[]> metadata = new Dictionary<Type, ObjectMetadata[]>();
}
