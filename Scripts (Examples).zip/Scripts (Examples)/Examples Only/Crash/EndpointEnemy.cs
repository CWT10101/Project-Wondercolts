﻿using System;
using UnityEngine;

// Token: 0x020000A9 RID: 169
public class EndpointEnemy : Enemy, IMetadataReceiver<EndpointMetadata>, IMetadataReceiver<SpeedMetadata>, IMetadataReceiver<FlipMetadata>
{
	// Token: 0x0600052E RID: 1326 RVA: 0x00017124 File Offset: 0x00015324
	protected override void OnEnable()
	{
		base.OnEnable();
		this.unconfigured = (!this.pointA || !this.pointB);
		if (this.unconfigured)
		{
			this.unconf_startPos = base.transform.position;
			this.unconf_movingRight = this.unconf_movingRightOnStart;
			this.unconf_delayedTick = 0;
		}
	}

	// Token: 0x0600052F RID: 1327 RVA: 0x00017187 File Offset: 0x00015387
	private void OnDisable()
	{
		if (this.unconfigured)
		{
			base.transform.position = this.unconf_startPos;
			return;
		}
		base.transform.position = this.pointA.position;
	}

	// Token: 0x06000530 RID: 1328 RVA: 0x000171BC File Offset: 0x000153BC
	protected override void FixedUpdate()
	{
		base.FixedUpdate();
		if (!this.isDead)
		{
			if (this.unconfigured)
			{
				RaycastHit raycastHit2;
				if (this.unconf_delayedTick > 0)
				{
					this.unconf_moveDelta = 0f;
					RaycastHit raycastHit;
					if (Physics.BoxCast(this.collider.bounds.center, this.collider.bounds.extents * 0.99f, (!this.unconf_movingRight) ? Vector3.right : Vector3.left, out raycastHit, Quaternion.identity, Time.fixedDeltaTime * this.worldspaceSpeed * 2f))
					{
						EndpointEnemy componentInParent = raycastHit.collider.GetComponentInParent<EndpointEnemy>();
						if (componentInParent != null && componentInParent.unconf_delayedTick == 0 && componentInParent.unconf_movingRight != this.unconf_movingRight)
						{
							this.unconf_delayedTick = 0;
							this.unconf_movingRight = !this.unconf_movingRight;
						}
					}
					else
					{
						this.unconf_delayedTick -= 1;
						if (this.unconf_delayedTick == 0)
						{
							this.unconf_movingRight = !this.unconf_movingRight;
						}
					}
				}
				else if (Physics.BoxCast(this.collider.bounds.center, this.collider.bounds.extents * 0.99f, this.unconf_movingRight ? Vector3.right : Vector3.left, out raycastHit2, Quaternion.identity, Time.fixedDeltaTime * this.worldspaceSpeed * 2f))
				{
					EndpointEnemy componentInParent2 = raycastHit2.collider.GetComponentInParent<EndpointEnemy>();
					if (componentInParent2 == null || componentInParent2.unconf_delayedTick != 0 || componentInParent2.unconf_movingRight != this.unconf_movingRight)
					{
						this.unconf_moveDelta = (raycastHit2.distance - Time.fixedDeltaTime * this.worldspaceSpeed) * (float)(this.unconf_movingRight ? 1 : -1);
						this.unconf_delayedTick = 2;
					}
				}
				else
				{
					this.unconf_moveDelta = (this.unconf_movingRight ? (Time.fixedDeltaTime * this.worldspaceSpeed) : (-Time.fixedDeltaTime * this.worldspaceSpeed));
				}
			}
			Vector3 nextPosition = this.GetNextPosition();
			this._delta = nextPosition - base.transform.position;
			RaycastHit raycastHit3;
			if (this._delta.sqrMagnitude > 0f && Physics.SphereCast(base.transform.position, this.physicalRadius, this._delta, out raycastHit3, this._delta.magnitude, 8, QueryTriggerInteraction.Ignore))
			{
				base.GenerateCollision(CrashController.instance.controller, this.collider, raycastHit3.normal, raycastHit3.point, this._delta.normalized, raycastHit3.distance);
			}
			base.transform.position = nextPosition;
		}
	}

	// Token: 0x06000531 RID: 1329 RVA: 0x00017460 File Offset: 0x00015660
	public virtual Vector3 GetNextPosition()
	{
		if (this.unconfigured)
		{
			return base.transform.position + new Vector3(this.unconf_moveDelta, 0f, 0f);
		}
		if (!this.useWorldspaceSpeed)
		{
			return Vector3.Lerp(this.pointA.position, this.pointB.position, this.speedCurve.Evaluate(Clock.SynchronizedTime + this.offset));
		}
		return Vector3.Lerp(this.pointA.position, this.pointB.position, this.speedCurve.Evaluate(Clock.SynchronizedTime / Vector3.Distance(this.pointA.position, this.pointB.position) * this.worldspaceSpeed + this.offset));
	}

	// Token: 0x06000532 RID: 1330 RVA: 0x0001752C File Offset: 0x0001572C
	public void ProcessMetadata(EndpointMetadata meta)
	{
		if (meta.HasData)
		{
			Transform transform = base.transform.parent.parent.Find("A");
			Transform transform2 = base.transform.parent.parent.Find("B");
			if (transform == null)
			{
				GameObject gameObject = new GameObject("A");
				gameObject.transform.SetParent(base.transform.parent.parent);
				transform = gameObject.transform;
			}
			transform.localPosition = Vector3.zero;
			this.pointA = transform;
			if (transform2 == null)
			{
				GameObject gameObject2 = new GameObject("B");
				gameObject2.transform.SetParent(base.transform.parent.parent);
				transform2 = gameObject2.transform;
			}
			transform2.position = meta.Position;
			this.pointB = transform2;
			return;
		}
		this.pointA = null;
		this.pointB = null;
	}

	// Token: 0x06000533 RID: 1331 RVA: 0x00017620 File Offset: 0x00015820
	public void ProcessMetadata(SpeedMetadata meta)
	{
		this.worldspaceSpeed = (float)meta.speed;
	}

	// Token: 0x06000534 RID: 1332 RVA: 0x0001762F File Offset: 0x0001582F
	public void ProcessMetadata(FlipMetadata meta)
	{
		this.unconf_movingRightOnStart = meta.isFlipped;
	}

	// Token: 0x040003AA RID: 938
	public Transform pointA;

	// Token: 0x040003AB RID: 939
	public Transform pointB;

	// Token: 0x040003AC RID: 940
	public AnimationCurve speedCurve;

	// Token: 0x040003AD RID: 941
	public bool useWorldspaceSpeed;

	// Token: 0x040003AE RID: 942
	public float worldspaceSpeed = 1f;

	// Token: 0x040003AF RID: 943
	public float offset;

	// Token: 0x040003B0 RID: 944
	public float physicalRadius = 0.5f;

	// Token: 0x040003B1 RID: 945
	protected bool unconfigured;

	// Token: 0x040003B2 RID: 946
	private bool unconf_movingRight = true;

	// Token: 0x040003B3 RID: 947
	private bool unconf_movingRightOnStart;

	// Token: 0x040003B4 RID: 948
	private byte unconf_delayedTick;

	// Token: 0x040003B5 RID: 949
	private float unconf_moveDelta;

	// Token: 0x040003B6 RID: 950
	private Vector3 unconf_startPos;

	// Token: 0x040003B7 RID: 951
	protected Vector3 _delta;
}
