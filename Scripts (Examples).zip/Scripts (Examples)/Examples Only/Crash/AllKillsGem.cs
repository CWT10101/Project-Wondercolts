﻿using System;

// Token: 0x0200011D RID: 285
public class AllKillsGem : SpecialGem
{
}
