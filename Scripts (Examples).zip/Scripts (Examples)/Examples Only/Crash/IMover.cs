﻿using System;
using UnityEngine;

// Token: 0x0200006D RID: 109
public interface IMover
{
	// Token: 0x17000083 RID: 131
	// (get) Token: 0x060002F5 RID: 757
	bool Is2D { get; }

	// Token: 0x17000084 RID: 132
	// (get) Token: 0x060002F6 RID: 758
	bool CanUpdate { get; }

	// Token: 0x060002F7 RID: 759
	IMover.MoveResult Move(Vector3 velocity, float dt);

	// Token: 0x060002F8 RID: 760
	void Teleport(Vector3 position);

	// Token: 0x020001EF RID: 495
	[Serializable]
	public struct MoveResult
	{
		// Token: 0x1700048C RID: 1164
		// (get) Token: 0x060012A8 RID: 4776 RVA: 0x0004271D File Offset: 0x0004091D
		// (set) Token: 0x060012A9 RID: 4777 RVA: 0x00042725 File Offset: 0x00040925
		public Vector3 MoveDelta { readonly get; set; }

		// Token: 0x1700048D RID: 1165
		// (get) Token: 0x060012AA RID: 4778 RVA: 0x0004272E File Offset: 0x0004092E
		// (set) Token: 0x060012AB RID: 4779 RVA: 0x00042736 File Offset: 0x00040936
		public IMover.MoveHit[] Hits { readonly get; set; }

		// Token: 0x1700048E RID: 1166
		// (get) Token: 0x060012AC RID: 4780 RVA: 0x0004273F File Offset: 0x0004093F
		// (set) Token: 0x060012AD RID: 4781 RVA: 0x00042747 File Offset: 0x00040947
		public bool Grounded { readonly get; set; }

		// Token: 0x1700048F RID: 1167
		// (get) Token: 0x060012AE RID: 4782 RVA: 0x00042750 File Offset: 0x00040950
		// (set) Token: 0x060012AF RID: 4783 RVA: 0x00042758 File Offset: 0x00040958
		public bool Wall { readonly get; set; }
	}

	// Token: 0x020001F0 RID: 496
	[Serializable]
	public struct MoveHit
	{
		// Token: 0x17000490 RID: 1168
		// (get) Token: 0x060012B0 RID: 4784 RVA: 0x00042761 File Offset: 0x00040961
		// (set) Token: 0x060012B1 RID: 4785 RVA: 0x00042769 File Offset: 0x00040969
		public Vector3 Position { readonly get; set; }

		// Token: 0x17000491 RID: 1169
		// (get) Token: 0x060012B2 RID: 4786 RVA: 0x00042772 File Offset: 0x00040972
		// (set) Token: 0x060012B3 RID: 4787 RVA: 0x0004277A File Offset: 0x0004097A
		public Vector3 Normal { readonly get; set; }

		// Token: 0x17000492 RID: 1170
		// (get) Token: 0x060012B4 RID: 4788 RVA: 0x00042783 File Offset: 0x00040983
		// (set) Token: 0x060012B5 RID: 4789 RVA: 0x0004278B File Offset: 0x0004098B
		public Collider Collider { readonly get; set; }
	}
}
