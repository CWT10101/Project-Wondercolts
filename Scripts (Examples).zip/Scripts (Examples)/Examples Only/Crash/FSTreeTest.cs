﻿using System;
using System.IO;
using UnityEngine;

// Token: 0x02000016 RID: 22
public class FSTreeTest : MonoBehaviour
{
	// Token: 0x06000058 RID: 88 RVA: 0x00003970 File Offset: 0x00001B70
	private void Start()
	{
		Debug.Log(new FSTree(new DirectoryInfo("Assets/Scenes")).GetFolder("Levels").GetFolder("Level03").Files.Count);
	}
}
