﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200012A RID: 298
public class SpinningPlatform : Entity, ISpin
{
	// Token: 0x060008E7 RID: 2279 RVA: 0x00024EB0 File Offset: 0x000230B0
	private void OnEnable()
	{
		this.isVertical = true;
	}

	// Token: 0x060008E8 RID: 2280 RVA: 0x00024EB9 File Offset: 0x000230B9
	public override void ResetEntity()
	{
		this.isVertical = true;
		base.ResetEntity();
	}

	// Token: 0x060008E9 RID: 2281 RVA: 0x00024EC8 File Offset: 0x000230C8
	public void Spin(CrashController crash)
	{
		if (this.isVertical)
		{
			this.isVertical = false;
			this.animator.SetTrigger("Spin");
			AudioManager.Play(this.spinSound, new Vector3?(base.transform.position), new Vector2?(this.pitchRange));
			base.StartCoroutine(this.FallTimerRoutine());
		}
	}

	// Token: 0x060008EA RID: 2282 RVA: 0x00024F28 File Offset: 0x00023128
	private IEnumerator FallTimerRoutine()
	{
		float t = Time.timeSinceLevelLoad;
		while (Time.timeSinceLevelLoad - t < this.fallTimer)
		{
			yield return new WaitForFixedUpdate();
		}
		this.animator.SetTrigger("Fall");
		this.isVertical = true;
		yield break;
	}

	// Token: 0x04000683 RID: 1667
	public Animator animator;

	// Token: 0x04000684 RID: 1668
	public string spinSound = "SFX_SpinningPlatformHit";

	// Token: 0x04000685 RID: 1669
	public float fallTimer = 10f;

	// Token: 0x04000686 RID: 1670
	public Vector2 pitchRange = Vector2.one;

	// Token: 0x04000687 RID: 1671
	private bool isVertical = true;
}
